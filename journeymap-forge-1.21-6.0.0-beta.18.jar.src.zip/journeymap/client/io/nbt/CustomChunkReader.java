/*     */ package journeymap.client.io.nbt;
/*     */ 
/*     */ import com.mojang.serialization.Codec;
/*     */ import com.mojang.serialization.DynamicOps;
/*     */ import java.util.EnumSet;
/*     */ import java.util.function.Function;
/*     */ import journeymap.common.Journeymap;
/*     */ import net.minecraft.core.Holder;
/*     */ import net.minecraft.core.IdMap;
/*     */ import net.minecraft.core.Registry;
/*     */ import net.minecraft.core.SectionPos;
/*     */ import net.minecraft.core.registries.Registries;
/*     */ import net.minecraft.nbt.CompoundTag;
/*     */ import net.minecraft.nbt.ListTag;
/*     */ import net.minecraft.nbt.NbtOps;
/*     */ import net.minecraft.server.level.ServerLevel;
/*     */ import net.minecraft.world.entity.ai.village.poi.PoiManager;
/*     */ import net.minecraft.world.level.ChunkPos;
/*     */ import net.minecraft.world.level.Level;
/*     */ import net.minecraft.world.level.biome.Biome;
/*     */ import net.minecraft.world.level.biome.Biomes;
/*     */ import net.minecraft.world.level.block.Block;
/*     */ import net.minecraft.world.level.block.Blocks;
/*     */ import net.minecraft.world.level.block.state.BlockState;
/*     */ import net.minecraft.world.level.chunk.ChunkAccess;
/*     */ import net.minecraft.world.level.chunk.LevelChunk;
/*     */ import net.minecraft.world.level.chunk.LevelChunkSection;
/*     */ import net.minecraft.world.level.chunk.PalettedContainer;
/*     */ import net.minecraft.world.level.chunk.PalettedContainerRO;
/*     */ import net.minecraft.world.level.chunk.status.ChunkType;
/*     */ import net.minecraft.world.level.chunk.storage.ChunkSerializer;
/*     */ import net.minecraft.world.level.levelgen.Heightmap;
/*     */ import org.apache.logging.log4j.Logger;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class CustomChunkReader
/*     */ {
/*  42 */   private static final Logger logger = Journeymap.getLogger();
/*     */ 
/*     */ 
/*     */   
/*     */   public static ProcessedChunk read(ServerLevel level, PoiManager manager, ChunkPos chunkPos, CompoundTag chunkTag) {
/*  47 */     if (ChunkType.LEVELCHUNK == ChunkSerializer.getChunkTypeFromTag(chunkTag)) {
/*     */       
/*  49 */       byte[][][][] lights = new byte[24][16][16][16];
/*     */       
/*  51 */       boolean lightOn = chunkTag.getBoolean("isLightOn");
/*  52 */       ListTag sections = chunkTag.getList("sections", 10);
/*  53 */       int sectionsCount = level.getSectionsCount();
/*  54 */       LevelChunkSection[] chunkSections = new LevelChunkSection[sectionsCount];
/*  55 */       Registry<Biome> registry = level.registryAccess().registryOrThrow(Registries.BIOME);
/*  56 */       Codec<PalettedContainerRO<Holder<Biome>>> codec = ChunkSerializer.makeBiomeCodec(registry);
/*     */       
/*  58 */       for (int j = 0; j < sections.size(); j++) {
/*     */         
/*  60 */         CompoundTag section = sections.getCompound(j);
/*  61 */         int sectionTopY = section.getByte("Y");
/*  62 */         int sectionIndex = level.getSectionIndexFromSectionY(sectionTopY);
/*  63 */         if (sectionIndex >= 0 && sectionIndex < chunkSections.length) {
/*     */           PalettedContainer<BlockState> blockStateContainer;
/*     */           PalettedContainer palettedContainer;
/*  66 */           if (section.contains("block_states", 10)) {
/*     */ 
/*     */ 
/*     */             
/*  70 */             blockStateContainer = (PalettedContainer<BlockState>)ChunkSerializer.BLOCK_STATE_CODEC.parse((DynamicOps)NbtOps.INSTANCE, section.getCompound("block_states")).promotePartial(stringx -> ChunkSerializer.logErrors(chunkPos, sectionTopY, stringx)).getOrThrow(net.minecraft.world.level.chunk.storage.ChunkSerializer.ChunkReadException::new);
/*     */           }
/*     */           else {
/*     */             
/*  74 */             blockStateContainer = new PalettedContainer((IdMap)Block.BLOCK_STATE_REGISTRY, Blocks.AIR.defaultBlockState(), PalettedContainer.Strategy.SECTION_STATES);
/*     */           } 
/*     */ 
/*     */           
/*  78 */           if (section.contains("biomes", 10)) {
/*     */ 
/*     */ 
/*     */             
/*  82 */             PalettedContainerRO<Holder<Biome>> biomeContainer = (PalettedContainerRO<Holder<Biome>>)codec.parse((DynamicOps)NbtOps.INSTANCE, section.getCompound("biomes")).promotePartial(stringx -> ChunkSerializer.logErrors(chunkPos, sectionTopY, stringx)).getOrThrow(net.minecraft.world.level.chunk.storage.ChunkSerializer.ChunkReadException::new);
/*     */           }
/*     */           else {
/*     */             
/*  86 */             palettedContainer = new PalettedContainer(registry.asHolderIdMap(), registry.getHolderOrThrow(Biomes.PLAINS), PalettedContainer.Strategy.SECTION_BIOMES);
/*     */           } 
/*     */           
/*  89 */           LevelChunkSection chunkSection = new LevelChunkSection(blockStateContainer, (PalettedContainerRO)palettedContainer);
/*  90 */           chunkSections[sectionIndex] = chunkSection;
/*  91 */           manager.checkConsistencyWithBlocks(SectionPos.of(chunkPos, sectionTopY), chunkSection);
/*     */         } 
/*  93 */         if (lightOn)
/*     */         {
/*  95 */           if (section.contains("BlockLight", 7)) {
/*     */             
/*  97 */             SectionPos lightPos = SectionPos.of(chunkPos, sectionTopY);
/*  98 */             byte[] lightsArray = section.getByteArray("BlockLight");
/*     */             
/* 100 */             for (int z = 0; z <= 15; z++) {
/*     */               
/* 102 */               for (int x = 0; x <= 15; x++) {
/*     */                 
/* 104 */                 for (int y = lightPos.minBlockY(); y <= lightPos.maxBlockY(); y++) {
/*     */                   
/* 106 */                   if (lightsArray.length == 2048) {
/*     */                     
/* 108 */                     int localY = SectionPos.sectionRelative(y);
/* 109 */                     lights[j][x][localY][z] = getSectionLightValue(lightsArray, x, localY, z);
/*     */                   } 
/*     */                 } 
/*     */               } 
/*     */             } 
/*     */           } 
/*     */         }
/*     */       } 
/*     */       
/* 118 */       LevelChunk levelChunk = new LevelChunk((Level)level.getLevel(), chunkPos, null, null, null, 0L, chunkSections, null, null);
/* 119 */       levelChunk.setLightCorrect(lightOn);
/* 120 */       CompoundTag heightmaps = chunkTag.getCompound("Heightmaps");
/* 121 */       EnumSet<Heightmap.Types> heightmapEnums = EnumSet.noneOf(Heightmap.Types.class);
/*     */       
/* 123 */       for (Heightmap.Types heightmapTypes : levelChunk.getPersistedStatus().heightmapsAfter()) {
/*     */         
/* 125 */         String key = heightmapTypes.getSerializationKey();
/* 126 */         if (heightmaps.contains(key, 12)) {
/*     */           
/* 128 */           levelChunk.setHeightmap(heightmapTypes, heightmaps.getLongArray(key));
/*     */           
/*     */           continue;
/*     */         } 
/* 132 */         heightmapEnums.add(heightmapTypes);
/*     */       } 
/*     */ 
/*     */       
/* 136 */       Heightmap.primeHeightmaps((ChunkAccess)levelChunk, heightmapEnums);
/*     */       
/* 138 */       return new ProcessedChunk(levelChunk, lights);
/*     */     } 
/* 140 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private static byte getSectionLightValue(byte[] array, int x, int y, int z) {
/*     */     try {
/* 147 */       if (array != null)
/*     */       {
/* 149 */         int index = y << 8 | (z << 4) + x;
/* 150 */         int byteIndex = index >> 1;
/* 151 */         int nibbleIndex = index & 0x1;
/* 152 */         return (byte)(array[byteIndex] >> 4 * nibbleIndex & 0xF);
/*     */       }
/*     */     
/* 155 */     } catch (Exception exception) {}
/*     */ 
/*     */ 
/*     */     
/* 159 */     return 0;
/*     */   }
/*     */   public static final class ProcessedChunk extends Record { private final LevelChunk chunk; private final byte[][][][] light;
/* 162 */     public ProcessedChunk(LevelChunk chunk, byte[][][][] light) { this.chunk = chunk; this.light = light; } public final String toString() { // Byte code:
/*     */       //   0: aload_0
/*     */       //   1: <illegal opcode> toString : (Ljourneymap/client/io/nbt/CustomChunkReader$ProcessedChunk;)Ljava/lang/String;
/*     */       //   6: areturn
/*     */       // Line number table:
/*     */       //   Java source line number -> byte code offset
/*     */       //   #162	-> 0
/*     */       // Local variable table:
/*     */       //   start	length	slot	name	descriptor
/* 162 */       //   0	7	0	this	Ljourneymap/client/io/nbt/CustomChunkReader$ProcessedChunk; } public LevelChunk chunk() { return this.chunk; } public final int hashCode() { // Byte code:
/*     */       //   0: aload_0
/*     */       //   1: <illegal opcode> hashCode : (Ljourneymap/client/io/nbt/CustomChunkReader$ProcessedChunk;)I
/*     */       //   6: ireturn
/*     */       // Line number table:
/*     */       //   Java source line number -> byte code offset
/*     */       //   #162	-> 0
/*     */       // Local variable table:
/*     */       //   start	length	slot	name	descriptor
/*     */       //   0	7	0	this	Ljourneymap/client/io/nbt/CustomChunkReader$ProcessedChunk; } public final boolean equals(Object o) { // Byte code:
/*     */       //   0: aload_0
/*     */       //   1: aload_1
/*     */       //   2: <illegal opcode> equals : (Ljourneymap/client/io/nbt/CustomChunkReader$ProcessedChunk;Ljava/lang/Object;)Z
/*     */       //   7: ireturn
/*     */       // Line number table:
/*     */       //   Java source line number -> byte code offset
/*     */       //   #162	-> 0
/*     */       // Local variable table:
/*     */       //   start	length	slot	name	descriptor
/*     */       //   0	8	0	this	Ljourneymap/client/io/nbt/CustomChunkReader$ProcessedChunk;
/* 162 */       //   0	8	1	o	Ljava/lang/Object; } public byte[][][][] light() { return this.light; }
/*     */      }
/*     */ 
/*     */ }


/* Location:              C:\Users\Administrator\Downloads\journeymap-forge-1.21-6.0.0-beta.18.jar!\journeymap\client\io\nbt\CustomChunkReader.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */