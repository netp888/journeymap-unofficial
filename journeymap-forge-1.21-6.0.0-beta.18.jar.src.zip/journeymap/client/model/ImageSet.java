/*     */ package journeymap.client.model;
/*     */ 
/*     */ import com.google.common.base.MoreObjects;
/*     */ import com.mojang.blaze3d.platform.NativeImage;
/*     */ import java.io.File;
/*     */ import java.util.Collections;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import journeymap.common.Journeymap;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class ImageSet
/*     */ {
/*  28 */   protected final Map<MapType, ImageHolder> imageHolders = Collections.synchronizedMap(new HashMap<>(8));
/*     */ 
/*     */ 
/*     */   
/*     */   protected abstract ImageHolder getHolder(MapType paramMapType);
/*     */ 
/*     */ 
/*     */   
/*     */   protected abstract ImageHolder getExistingHolder(MapType paramMapType);
/*     */ 
/*     */ 
/*     */   
/*     */   protected abstract ImageHolder getHolderAsyncLoad(MapType paramMapType);
/*     */ 
/*     */ 
/*     */   
/*     */   public abstract int hashCode();
/*     */ 
/*     */ 
/*     */   
/*     */   public abstract boolean equals(Object paramObject);
/*     */ 
/*     */   
/*     */   public NativeImage getImage(MapType mapType) {
/*  52 */     return getHolder(mapType).getImage();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int writeToDiskAsync(boolean force) {
/*  62 */     return writeToDisk(force, true);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int writeToDisk(boolean force) {
/*  72 */     return writeToDisk(force, false);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private int writeToDisk(boolean force, boolean async) {
/*  84 */     long now = System.currentTimeMillis();
/*  85 */     int count = 0;
/*     */     
/*     */     try {
/*  88 */       synchronized (this.imageHolders) {
/*     */         
/*  90 */         for (ImageHolder imageHolder : this.imageHolders.values())
/*     */         {
/*  92 */           if (imageHolder.isDirty())
/*     */           {
/*  94 */             if (force || now - imageHolder.getImageTimestamp() > 10000L)
/*     */             {
/*  96 */               imageHolder.writeToDisk(async);
/*  97 */               count++;
/*     */             }
/*     */           
/*     */           }
/*     */         }
/*     */       
/*     */       } 
/* 104 */     } catch (Throwable t) {
/*     */       
/* 106 */       Journeymap.getLogger().error("Error writing ImageSet to disk: " + String.valueOf(t));
/*     */     } 
/* 108 */     return count;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean updatedSince(MapType mapType, long time) {
/* 113 */     synchronized (this.imageHolders) {
/*     */       
/* 115 */       if (mapType == null) {
/*     */         
/* 117 */         for (ImageHolder holder : this.imageHolders.values())
/*     */         {
/* 119 */           if (holder != null && holder.getImageTimestamp() >= time)
/*     */           {
/* 121 */             return true;
/*     */           }
/*     */         }
/*     */       
/*     */       } else {
/*     */         
/* 127 */         ImageHolder imageHolder = this.imageHolders.get(mapType);
/* 128 */         if (imageHolder != null && imageHolder.getImageTimestamp() >= time)
/*     */         {
/* 130 */           return true;
/*     */         }
/*     */       } 
/*     */     } 
/* 134 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public void clear() {
/* 139 */     synchronized (this.imageHolders) {
/*     */       
/* 141 */       for (ImageHolder imageHolder : this.imageHolders.values())
/*     */       {
/* 143 */         imageHolder.clear();
/*     */       }
/* 145 */       this.imageHolders.clear();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 152 */     return MoreObjects.toStringHelper(this)
/* 153 */       .add("imageHolders", this.imageHolders.entrySet())
/* 154 */       .toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected abstract int getImageSize();
/*     */ 
/*     */ 
/*     */   
/*     */   protected ImageHolder addHolder(MapType mapType, File imageFile) {
/* 165 */     return addHolder(new ImageHolder(mapType, imageFile, getImageSize()));
/*     */   }
/*     */ 
/*     */   
/*     */   protected ImageHolder addHolder(ImageHolder imageHolder) {
/* 170 */     this.imageHolders.put(imageHolder.mapType, imageHolder);
/* 171 */     return imageHolder;
/*     */   }
/*     */ }


/* Location:              C:\Users\Administrator\Downloads\journeymap-forge-1.21-6.0.0-beta.18.jar!\journeymap\client\model\ImageSet.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */