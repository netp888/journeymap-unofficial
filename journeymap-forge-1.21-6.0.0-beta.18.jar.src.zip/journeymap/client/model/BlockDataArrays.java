/*     */ package journeymap.client.model;
/*     */ 
/*     */ import java.util.HashMap;
/*     */ import java.util.function.Supplier;
/*     */ import java.util.stream.IntStream;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class BlockDataArrays
/*     */ {
/*  22 */   private HashMap<MapType, Dataset> datasets = new HashMap<>(8);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void clearAll() {
/*  29 */     this.datasets.clear();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Dataset get(MapType mapType) {
/*  40 */     Dataset dataset = this.datasets.get(mapType);
/*  41 */     if (dataset == null) {
/*     */       
/*  43 */       dataset = new Dataset();
/*  44 */       this.datasets.put(mapType, dataset);
/*     */     } 
/*  46 */     return dataset;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static class Dataset
/*     */   {
/*     */     private BlockDataArrays.DataArray<Integer> ints;
/*     */ 
/*     */     
/*     */     private BlockDataArrays.DataArray<Float> floats;
/*     */ 
/*     */     
/*     */     private BlockDataArrays.DataArray<Boolean> booleans;
/*     */ 
/*     */     
/*     */     private BlockDataArrays.DataArray<Object> objects;
/*     */ 
/*     */ 
/*     */     
/*     */     Dataset() {}
/*     */ 
/*     */     
/*     */     public Dataset(MapType mapType) {}
/*     */ 
/*     */     
/*     */     protected void clear() {
/*  73 */       this.ints = null;
/*  74 */       this.floats = null;
/*  75 */       this.booleans = null;
/*  76 */       this.objects = null;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public BlockDataArrays.DataArray<Integer> ints() {
/*  86 */       if (this.ints == null)
/*     */       {
/*  88 */         this.ints = new BlockDataArrays.DataArray<>(() -> new Integer[16][16]);
/*     */       }
/*  90 */       return this.ints;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public BlockDataArrays.DataArray<Float> floats() {
/* 100 */       if (this.floats == null)
/*     */       {
/* 102 */         this.floats = new BlockDataArrays.DataArray<>(() -> new Float[16][16]);
/*     */       }
/* 104 */       return this.floats;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public BlockDataArrays.DataArray<Boolean> booleans() {
/* 114 */       if (this.booleans == null)
/*     */       {
/* 116 */         this.booleans = new BlockDataArrays.DataArray<>(() -> new Boolean[16][16]);
/*     */       }
/* 118 */       return this.booleans;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public BlockDataArrays.DataArray<Object> objects() {
/* 128 */       if (this.objects == null)
/*     */       {
/* 130 */         this.objects = new BlockDataArrays.DataArray(() -> new Object[16][16]);
/*     */       }
/* 132 */       return this.objects;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static class DataArray<T>
/*     */   {
/* 143 */     private final HashMap<String, T[][]> map = new HashMap<>(4);
/*     */ 
/*     */ 
/*     */     
/*     */     private final Supplier<T[][]> initFn;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     protected DataArray(Supplier<T[][]> initFn) {
/* 153 */       this.initFn = initFn;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public boolean has(String name) {
/* 164 */       return this.map.containsKey(name);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public T[][] get(String name) {
/* 175 */       return this.map.computeIfAbsent(name, s -> (Object[][])this.initFn.get());
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public T get(String name, int x, int z) {
/* 188 */       return get(name)[z][x];
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public boolean set(String name, int x, int z, T value) {
/* 202 */       T[][] arr = get(name);
/* 203 */       T old = arr[z][x];
/* 204 */       arr[z][x] = value;
/* 205 */       return (value != old);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public T[][] copy(String name) {
/* 216 */       T[][] src = get(name);
/* 217 */       T[][] dest = this.initFn.get();
/* 218 */       for (int i = 0; i < src.length; i++)
/*     */       {
/* 220 */         System.arraycopy(src[i], 0, dest[i], 0, (src[0]).length);
/*     */       }
/* 222 */       return dest;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public void copyTo(String srcName, String dstName) {
/* 233 */       this.map.put(dstName, copy(srcName));
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public void clear(String name) {
/* 243 */       this.map.remove(name);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean areIdentical(int[][] arr, int[][] arr2) {
/* 256 */     boolean match = true;
/* 257 */     for (int j = 0; j < arr.length; j++) {
/*     */       
/* 259 */       int[] row = arr[j];
/* 260 */       int[] row2 = arr2[j];
/* 261 */       match = IntStream.range(0, row.length).map(i -> row[i] ^ 0xFFFFFFFF | row2[i]).allMatch(n -> (n == -1));
/* 262 */       if (!match) {
/*     */         break;
/*     */       }
/*     */     } 
/*     */     
/* 267 */     return match;
/*     */   }
/*     */ }


/* Location:              C:\Users\Administrator\Downloads\journeymap-forge-1.21-6.0.0-beta.18.jar!\journeymap\client\model\BlockDataArrays.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */