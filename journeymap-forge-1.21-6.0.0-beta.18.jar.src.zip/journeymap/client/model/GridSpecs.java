/*    */ package journeymap.client.model;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class GridSpecs
/*    */ {
/* 13 */   public static final GridSpec DEFAULT_DAY = new GridSpec(GridSpec.Style.Squares, 0.5F, 0.5F, 0.5F, 0.5F);
/* 14 */   public static final GridSpec DEFAULT_NIGHT = new GridSpec(GridSpec.Style.Squares, 0.5F, 0.5F, 1.0F, 0.3F);
/* 15 */   public static final GridSpec DEFAULT_UNDERGROUND = new GridSpec(GridSpec.Style.Squares, 0.5F, 0.5F, 0.5F, 0.3F);
/*    */   
/*    */   private GridSpec day;
/*    */   
/*    */   private GridSpec night;
/*    */   private GridSpec underground;
/*    */   
/*    */   public GridSpecs() {
/* 23 */     this(DEFAULT_DAY.clone(), DEFAULT_NIGHT.clone(), DEFAULT_UNDERGROUND.clone());
/*    */   }
/*    */ 
/*    */   
/*    */   public GridSpecs(GridSpec day, GridSpec night, GridSpec underground) {
/* 28 */     this.day = day;
/* 29 */     this.night = night;
/* 30 */     this.underground = underground;
/*    */   }
/*    */ 
/*    */   
/*    */   public GridSpec getSpec(MapType mapType) {
/* 35 */     switch (mapType.name) {
/*    */       
/*    */       case day:
/* 38 */         return this.day;
/*    */       case night:
/* 40 */         return this.night;
/*    */       case underground:
/* 42 */         return this.underground;
/*    */     } 
/* 44 */     return this.day;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public void setSpec(MapType mapType, GridSpec newSpec) {
/* 50 */     switch (mapType.name) {
/*    */ 
/*    */       
/*    */       case day:
/* 54 */         this.day = newSpec.clone();
/*    */         return;
/*    */ 
/*    */       
/*    */       case night:
/* 59 */         this.night = newSpec.clone();
/*    */         return;
/*    */ 
/*    */       
/*    */       case underground:
/* 64 */         this.underground = newSpec.clone();
/*    */         return;
/*    */     } 
/*    */ 
/*    */     
/* 69 */     this.day = newSpec.clone();
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public GridSpecs clone() {
/* 76 */     return new GridSpecs(this.day.clone(), this.night.clone(), this.underground.clone());
/*    */   }
/*    */ 
/*    */   
/*    */   public void updateFrom(GridSpecs other) {
/* 81 */     this.day = other.day.clone();
/* 82 */     this.night = other.night.clone();
/* 83 */     this.underground = other.underground.clone();
/*    */   }
/*    */ }


/* Location:              C:\Users\Administrator\Downloads\journeymap-forge-1.21-6.0.0-beta.18.jar!\journeymap\client\model\GridSpecs.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */