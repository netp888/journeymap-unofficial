/*     */ package journeymap.client.model;
/*     */ 
/*     */ import com.mojang.authlib.GameProfile;
/*     */ import java.awt.geom.Rectangle2D;
/*     */ import java.util.List;
/*     */ import java.util.Random;
/*     */ import java.util.UUID;
/*     */ import journeymap.client.Constants;
/*     */ import journeymap.client.texture.Texture;
/*     */ import journeymap.client.texture.TextureCache;
/*     */ import journeymap.client.ui.component.buttons.Button;
/*     */ import net.minecraft.client.gui.Font;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SplashPerson
/*     */ {
/*     */   public final String name;
/*     */   public final String uuid;
/*     */   public final String title;
/*     */   public Button button;
/*     */   public int width;
/*     */   public double moveX;
/*     */   public double moveY;
/*  53 */   private double moveDistance = 1.0D;
/*  54 */   private Random r = new Random();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SplashPerson(String uuid, String name, String titleKey) {
/*  65 */     this.uuid = uuid;
/*  66 */     this.name = name;
/*  67 */     if (titleKey != null) {
/*     */       
/*  69 */       this.title = Constants.getString(titleKey);
/*     */     }
/*     */     else {
/*     */       
/*  73 */       this.title = "";
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Button getButton() {
/*  84 */     return this.button;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setButton(Button button) {
/*  94 */     this.button = button;
/*  95 */     randomizeVector();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Texture getSkin() {
/* 105 */     return TextureCache.getPlayerSkin(new GameProfile(UUID.fromString(this.uuid), this.name));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getWidth(Font fr) {
/* 116 */     this.width = fr.width(this.title);
/* 117 */     String[] nameParts = this.name.trim().split(" ");
/* 118 */     for (String part : nameParts)
/*     */     {
/* 120 */       this.width = Math.max(this.width, fr.width(part));
/*     */     }
/* 122 */     return this.width;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setWidth(int minWidth) {
/* 132 */     this.width = minWidth;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void randomizeVector() {
/* 140 */     this.moveDistance = this.r.nextDouble() + 0.5D;
/* 141 */     this.moveX = this.r.nextBoolean() ? this.moveDistance : -this.moveDistance;
/* 142 */     this.moveDistance = this.r.nextDouble() + 0.5D;
/* 143 */     this.moveY = this.r.nextBoolean() ? this.moveDistance : -this.moveDistance;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void adjustVector(Rectangle2D.Double screenBounds) {
/* 153 */     Rectangle2D.Double buttonBounds = this.button.getBounds();
/* 154 */     if (!screenBounds.contains(buttonBounds)) {
/*     */       
/* 156 */       int xMargin = this.button.getWidth();
/* 157 */       int yMargin = this.button.getHeight();
/* 158 */       if (buttonBounds.getMinX() <= xMargin) {
/*     */         
/* 160 */         this.moveX = this.moveDistance;
/*     */       }
/* 162 */       else if (buttonBounds.getMaxX() >= screenBounds.getWidth() - xMargin) {
/*     */         
/* 164 */         this.moveX = -this.moveDistance;
/*     */       } 
/*     */       
/* 167 */       if (buttonBounds.getMinY() <= yMargin) {
/*     */         
/* 169 */         this.moveY = this.moveDistance;
/*     */       }
/* 171 */       else if (buttonBounds.getMaxY() >= screenBounds.getHeight() - yMargin) {
/*     */         
/* 173 */         this.moveY = -this.moveDistance;
/*     */       } 
/*     */     } 
/*     */     
/* 177 */     continueVector();
/*     */   }
/*     */ 
/*     */   
/*     */   public void continueVector() {
/* 182 */     this.button.setX((int)Math.round(this.button.getX() + this.moveX));
/* 183 */     this.button.setY((int)Math.round(this.button.getY() + this.moveY));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void avoid(List<SplashPerson> others) {
/* 193 */     for (SplashPerson other : others) {
/*     */       
/* 195 */       if (this == other) {
/*     */         continue;
/*     */       }
/*     */ 
/*     */       
/* 200 */       if (getDistance(other) <= this.button.getWidth()) {
/*     */         
/* 202 */         randomizeVector();
/*     */         break;
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public double getDistance(SplashPerson other) {
/* 213 */     double px = (this.button.getCenterX() - other.button.getCenterX());
/* 214 */     double py = (this.button.getMiddleY() - other.button.getMiddleY());
/* 215 */     return Math.sqrt(px * px + py * py);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static class Fake
/*     */     extends SplashPerson
/*     */   {
/*     */     private Texture texture;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Fake(String name, String title, Texture texture) {
/* 234 */       super(name, title, null);
/* 235 */       this.texture = texture;
/*     */     }
/*     */ 
/*     */     
/*     */     public Texture getSkin() {
/* 240 */       return this.texture;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\Administrator\Downloads\journeymap-forge-1.21-6.0.0-beta.18.jar!\journeymap\client\model\SplashPerson.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */