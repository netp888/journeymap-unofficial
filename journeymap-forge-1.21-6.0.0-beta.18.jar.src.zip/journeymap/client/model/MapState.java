/*     */ package journeymap.client.model;
/*     */ 
/*     */ import com.google.common.base.Objects;
/*     */ import com.google.common.collect.Iterables;
/*     */ import java.io.File;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.Collections;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.concurrent.atomic.AtomicBoolean;
/*     */ import journeymap.api.client.impl.ClientAPI;
/*     */ import journeymap.client.JourneymapClient;
/*     */ import journeymap.client.data.DataCache;
/*     */ import journeymap.client.feature.Feature;
/*     */ import journeymap.client.feature.FeatureManager;
/*     */ import journeymap.client.io.FileHandler;
/*     */ import journeymap.client.log.StatTimer;
/*     */ import journeymap.client.properties.CoreProperties;
/*     */ import journeymap.client.properties.InGameMapProperties;
/*     */ import journeymap.client.properties.MapProperties;
/*     */ import journeymap.client.render.draw.DrawStep;
/*     */ import journeymap.client.render.draw.DrawWayPointStep;
/*     */ import journeymap.client.render.draw.RadarDrawStepFactory;
/*     */ import journeymap.client.render.draw.WaypointDrawStepFactory;
/*     */ import journeymap.client.render.map.Renderer;
/*     */ import journeymap.client.task.multi.MapPlayerTask;
/*     */ import journeymap.common.Journeymap;
/*     */ import journeymap.common.log.LogFormatter;
/*     */ import journeymap.common.properties.catagory.Category;
/*     */ import journeymap.common.properties.config.IntegerField;
/*     */ import net.minecraft.client.Minecraft;
/*     */ import net.minecraft.client.multiplayer.ClientLevel;
/*     */ import net.minecraft.resources.ResourceKey;
/*     */ import net.minecraft.world.entity.Entity;
/*     */ import net.minecraft.world.entity.player.Player;
/*     */ import net.minecraft.world.level.Level;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MapState
/*     */ {
/*     */   public final int minZoom;
/*  60 */   public final int maxZoom = 16384;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  66 */   public AtomicBoolean follow = new AtomicBoolean(true);
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  71 */   public String playerLastPos = "0,0";
/*     */   
/*  73 */   private StatTimer refreshTimer = StatTimer.get("MapState.refresh");
/*  74 */   private StatTimer generateDrawStepsTimer = StatTimer.get("MapState.generateDrawSteps");
/*     */   
/*     */   private MapType lastMapType;
/*     */   
/*  78 */   private File worldDir = null;
/*  79 */   private long lastRefresh = 0L;
/*  80 */   private long lastMapTypeChange = 0L;
/*     */   
/*  82 */   private IntegerField lastSlice = new IntegerField(Category.Hidden, "", -4, 15, 4);
/*     */   private boolean surfaceMappingAllowed = false;
/*     */   private boolean caveMappingAllowed = false;
/*     */   private boolean caveMappingEnabled = false;
/*     */   private boolean topoMappingAllowed = false;
/*     */   private boolean biomeMappingAllowed = false;
/*  88 */   private List<DrawStep> drawStepList = new ArrayList<>();
/*  89 */   private List<DrawWayPointStep> drawWaypointStepList = new ArrayList<>();
/*  90 */   private String playerBiome = "";
/*  91 */   private InGameMapProperties lastMapProperties = null;
/*  92 */   private List<EntityDTO> entityList = new ArrayList<>(32);
/*  93 */   private int lastPlayerChunkX = 0;
/*  94 */   private int lastPlayerChunkY = 0;
/*  95 */   private int lastPlayerChunkZ = 0;
/*     */ 
/*     */   
/*     */   private String lastWorldName;
/*     */   
/*     */   private boolean forceRefreshState = false;
/*     */ 
/*     */   
/*     */   public MapState() {
/* 104 */     this.minZoom = 2;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void refresh(Minecraft mc, Player player, InGameMapProperties mapProperties) {
/* 116 */     ClientLevel clientLevel = mc.level;
/* 117 */     if (clientLevel == null || clientLevel.dimensionType() == null) {
/*     */       return;
/*     */     }
/*     */ 
/*     */     
/* 122 */     this.refreshTimer.start();
/*     */     
/*     */     try {
/* 125 */       CoreProperties coreProperties = JourneymapClient.getInstance().getCoreProperties();
/* 126 */       this.lastMapProperties = mapProperties;
/*     */ 
/*     */       
/* 129 */       if (!FileHandler.getWorldDirectoryName(mc).equals(this.lastWorldName)) {
/*     */         
/* 131 */         this.worldDir = FileHandler.getJMWorldDir(mc);
/* 132 */         this.lastWorldName = FileHandler.getWorldDirectoryName(mc);
/*     */       } 
/*     */ 
/*     */       
/* 136 */       if (clientLevel != null && clientLevel.dimensionType().logicalHeight() != 256 && this.lastSlice.getMaxValue() != clientLevel.dimensionType().logicalHeight() / 16 - 1) {
/*     */         
/* 138 */         int maxSlice = clientLevel.dimensionType().logicalHeight() / 16 - 1;
/* 139 */         int minSlice = clientLevel.dimensionType().minY() / 16;
/* 140 */         int seaLevel = Math.round((clientLevel.getSeaLevel() >> 4));
/* 141 */         int currentSlice = this.lastSlice.get().intValue();
/* 142 */         this.lastSlice = new IntegerField(Category.Hidden, "", minSlice, maxSlice, seaLevel);
/* 143 */         this.lastSlice.set(Integer.valueOf(currentSlice));
/*     */       } 
/* 145 */       this.caveMappingAllowed = FeatureManager.getInstance().isAllowed(Feature.MapCaves);
/* 146 */       this.caveMappingEnabled = (this.caveMappingAllowed && mapProperties.showCaves.get().booleanValue());
/* 147 */       this.surfaceMappingAllowed = FeatureManager.getInstance().isAllowed(Feature.MapSurface);
/* 148 */       this.topoMappingAllowed = (FeatureManager.getInstance().isAllowed(Feature.MapTopo) && coreProperties.mapTopography.get().booleanValue());
/* 149 */       this.biomeMappingAllowed = (FeatureManager.getInstance().isAllowed(Feature.MapBiome) && coreProperties.mapBiome.get().booleanValue());
/* 150 */       this.lastPlayerChunkX = (player.chunkPosition()).x;
/* 151 */       this.lastPlayerChunkY = player.getBlockY() >> 4;
/* 152 */       this.lastPlayerChunkZ = (player.chunkPosition()).z;
/* 153 */       EntityDTO playerDTO = DataCache.getPlayer();
/* 154 */       this.playerBiome = playerDTO.biome;
/*     */       
/* 156 */       if (this.lastMapType != null)
/*     */       {
/* 158 */         if (player.level().dimension() != this.lastMapType.dimension) {
/*     */           
/* 160 */           this.lastMapType = null;
/*     */         }
/* 162 */         else if (this.caveMappingEnabled && this.follow.get() && playerDTO.underground.booleanValue() && !this.lastMapType.isUnderground()) {
/*     */           
/* 164 */           this.lastMapType = null;
/*     */         }
/* 166 */         else if (this.caveMappingEnabled && this.follow.get() && !playerDTO.underground.booleanValue() && this.lastMapType.isUnderground()) {
/*     */           
/* 168 */           this.lastMapType = null;
/*     */         }
/* 170 */         else if (!this.lastMapType.isAllowed()) {
/*     */           
/* 172 */           this.lastMapType = null;
/*     */         } 
/*     */       }
/*     */       
/* 176 */       this.lastMapType = getMapType();
/*     */       
/* 178 */       updateLastRefresh();
/*     */     }
/* 180 */     catch (Exception e) {
/*     */       
/* 182 */       Journeymap.getLogger().error("Error refreshing MapState: " + LogFormatter.toPartialString(e));
/*     */     }
/*     */     finally {
/*     */       
/* 186 */       this.refreshTimer.stop();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MapType setMapType(MapType.Name mapTypeName) {
/* 197 */     return setMapType(MapType.from(mapTypeName, DataCache.getPlayer()));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MapType toggleMapType() {
/* 205 */     MapType.Name next = getNextMapType((getMapType()).name);
/* 206 */     return setMapType(next);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MapType.Name getNextMapType(MapType.Name name) {
/* 216 */     EntityDTO player = DataCache.getPlayer();
/* 217 */     Entity playerEntity = player.entityRef.get();
/* 218 */     if (playerEntity == null)
/*     */     {
/* 220 */       return name;
/*     */     }
/*     */     
/* 223 */     List<MapType.Name> types = new ArrayList<>(4);
/*     */     
/* 225 */     if (this.surfaceMappingAllowed) {
/*     */       
/* 227 */       types.add(MapType.Name.day);
/* 228 */       types.add(MapType.Name.night);
/*     */     } 
/*     */     
/* 231 */     if (this.caveMappingAllowed && (player.underground.booleanValue() || name == MapType.Name.underground))
/*     */     {
/* 233 */       types.add(MapType.Name.underground);
/*     */     }
/*     */     
/* 236 */     if (this.topoMappingAllowed)
/*     */     {
/* 238 */       types.add(MapType.Name.topo);
/*     */     }
/*     */     
/* 241 */     if (this.biomeMappingAllowed)
/*     */     {
/* 243 */       types.add(MapType.Name.biome);
/*     */     }
/*     */     
/* 246 */     if (name == MapType.Name.none && !types.isEmpty())
/*     */     {
/* 248 */       return types.get(0);
/*     */     }
/*     */     
/* 251 */     if (types.contains(name)) {
/*     */       
/* 253 */       Iterator<MapType.Name> cyclingIterator = Iterables.cycle(types).iterator();
/* 254 */       while (cyclingIterator.hasNext()) {
/*     */         
/* 256 */         MapType.Name current = cyclingIterator.next();
/* 257 */         if (current == name)
/*     */         {
/* 259 */           return cyclingIterator.next();
/*     */         }
/*     */       } 
/*     */     } 
/*     */ 
/*     */     
/* 265 */     return name;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MapType setMapType(MapType mapType) {
/* 275 */     if (!mapType.isAllowed()) {
/*     */       
/* 277 */       mapType = MapType.from(getNextMapType(mapType.name), DataCache.getPlayer());
/*     */       
/* 279 */       if (!mapType.isAllowed())
/*     */       {
/* 281 */         mapType = MapType.none();
/*     */       }
/*     */     } 
/*     */     
/* 285 */     EntityDTO player = DataCache.getPlayer();
/* 286 */     if (player.underground.booleanValue() != mapType.isUnderground())
/*     */     {
/* 288 */       this.follow.set(false);
/*     */     }
/*     */     
/* 291 */     if (mapType.isUnderground()) {
/*     */       
/* 293 */       if (player.chunkCoordY != mapType.vSlice.intValue())
/*     */       {
/* 295 */         this.follow.set(false);
/*     */       }
/* 297 */       this.lastSlice.set(mapType.vSlice);
/*     */     }
/* 299 */     else if (this.lastMapProperties != null && mapType.name != MapType.Name.none && this.lastMapProperties.preferredMapType.get() != mapType.name) {
/*     */       
/* 301 */       this.lastMapProperties.preferredMapType.set(mapType.name);
/* 302 */       this.lastMapProperties.save();
/*     */     } 
/*     */     
/* 305 */     setLastMapTypeChange(mapType);
/*     */     
/* 307 */     return this.lastMapType;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MapType getMapType() {
/* 317 */     if (this.lastMapType == null) {
/*     */       
/* 319 */       EntityDTO player = DataCache.getPlayer();
/* 320 */       MapType mapType = null;
/*     */       
/*     */       try {
/* 323 */         if (this.caveMappingEnabled && player.underground.booleanValue()) {
/*     */           
/* 325 */           mapType = MapType.underground(player);
/*     */         }
/* 327 */         else if (this.follow.get()) {
/*     */           
/* 329 */           if (this.surfaceMappingAllowed && !player.underground.booleanValue()) {
/*     */             
/* 331 */             mapType = MapType.day(player);
/*     */           }
/* 333 */           else if (this.topoMappingAllowed && !player.underground.booleanValue()) {
/*     */             
/* 335 */             mapType = MapType.topo(player);
/*     */           }
/* 337 */           else if (this.biomeMappingAllowed && !player.underground.booleanValue()) {
/*     */             
/* 339 */             mapType = MapType.biome(player);
/*     */           } 
/*     */         } 
/*     */         
/* 343 */         if (mapType == null)
/*     */         {
/* 345 */           mapType = MapType.from((MapType.Name)this.lastMapProperties.preferredMapType.get(), player);
/*     */         }
/*     */       }
/* 348 */       catch (Exception e) {
/*     */         
/* 350 */         mapType = MapType.day(player);
/*     */       } 
/*     */       
/* 353 */       setMapType(mapType);
/*     */     } 
/*     */     
/* 356 */     return this.lastMapType;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public long getLastMapTypeChange() {
/* 366 */     return this.lastMapTypeChange;
/*     */   }
/*     */ 
/*     */   
/*     */   private void setLastMapTypeChange(MapType mapType) {
/* 371 */     if (!Objects.equal(mapType, this.lastMapType)) {
/*     */       
/* 373 */       this.lastMapTypeChange = System.currentTimeMillis();
/* 374 */       requireRefresh();
/*     */     } 
/* 376 */     this.lastMapType = mapType;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isUnderground() {
/* 386 */     return getMapType().isUnderground();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public File getWorldDir() {
/* 396 */     return this.worldDir;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getPlayerBiome() {
/* 406 */     return this.playerBiome;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List<? extends DrawStep> getDrawSteps() {
/* 416 */     return this.drawStepList;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List<DrawWayPointStep> getDrawWaypointSteps() {
/* 426 */     return this.drawWaypointStepList;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void generateDrawSteps(Minecraft mc, Renderer renderer, WaypointDrawStepFactory waypointRenderer, RadarDrawStepFactory radarRenderer, InGameMapProperties mapProperties, boolean checkWaypointDistance) {
/* 441 */     this.generateDrawStepsTimer.start();
/* 442 */     this.lastMapProperties = mapProperties;
/*     */     
/* 444 */     this.drawStepList.clear();
/* 445 */     this.drawWaypointStepList.clear();
/* 446 */     this.entityList.clear();
/*     */     
/* 448 */     ClientAPI.INSTANCE.getDrawSteps(this.drawStepList, renderer.getUIState());
/*     */     
/* 450 */     if (FeatureManager.getInstance().isAllowed(Feature.RadarAnimals)) {
/*     */       
/* 452 */       if (mapProperties.showAnimals.get().booleanValue() || mapProperties.showPets.get().booleanValue())
/*     */       {
/* 454 */         this.entityList.addAll(DataCache.INSTANCE.getAnimals(false).values());
/*     */       }
/* 456 */       if (mapProperties.showAmbientCreatures.get().booleanValue())
/*     */       {
/* 458 */         this.entityList.addAll(DataCache.INSTANCE.getAmbientCreatures(false).values());
/*     */       }
/*     */     } 
/* 461 */     if (FeatureManager.getInstance().isAllowed(Feature.RadarVillagers))
/*     */     {
/* 463 */       if (mapProperties.showVillagers.get().booleanValue())
/*     */       {
/* 465 */         this.entityList.addAll(DataCache.INSTANCE.getVillagers(false).values());
/*     */       }
/*     */     }
/* 468 */     if (FeatureManager.getInstance().isAllowed(Feature.RadarMobs))
/*     */     {
/* 470 */       if (mapProperties.showMobs.get().booleanValue())
/*     */       {
/* 472 */         this.entityList.addAll(DataCache.INSTANCE.getMobs(false).values());
/*     */       }
/*     */     }
/*     */     
/* 476 */     if (FeatureManager.getInstance().isAllowed(Feature.RadarPlayers))
/*     */     {
/* 478 */       if (mapProperties.showPlayers.get().booleanValue()) {
/*     */         
/* 480 */         mc.player.level().players();
/* 481 */         Collection<EntityDTO> cachedPlayers = DataCache.INSTANCE.getPlayers(false).values();
/* 482 */         if (cachedPlayers.size() != mc.getConnection().getOnlinePlayers().size())
/*     */         {
/* 484 */           cachedPlayers = DataCache.INSTANCE.getPlayers(true).values();
/*     */         }
/* 486 */         this.entityList.addAll(cachedPlayers);
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/* 491 */     if (!this.entityList.isEmpty()) {
/*     */       
/* 493 */       Collections.sort(this.entityList, EntityHelper.entityMapComparator);
/* 494 */       this.drawStepList.addAll(radarRenderer.prepareSteps(this.entityList, renderer, mapProperties));
/*     */     } 
/*     */ 
/*     */     
/* 498 */     if (mapProperties.showWaypoints.get().booleanValue()) {
/*     */       
/* 500 */       boolean showLabel = mapProperties.showWaypointLabels.get().booleanValue();
/* 501 */       this.drawWaypointStepList.addAll(waypointRenderer.prepareSteps(DataCache.INSTANCE.getWaypoints(false), renderer, checkWaypointDistance, showLabel));
/*     */     } 
/*     */     
/* 504 */     this.generateDrawStepsTimer.stop();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean minimapZoomIn() {
/* 514 */     if (this.lastMapProperties.zoomLevel.get().intValue() < 16384)
/*     */     {
/* 516 */       return setZoom(this.lastMapProperties.zoomLevel.get().intValue() * 2);
/*     */     }
/* 518 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean minimapZoomOut() {
/* 528 */     if (this.lastMapProperties.zoomLevel.get().intValue() > 256)
/*     */     {
/* 530 */       return setZoom(this.lastMapProperties.zoomLevel.get().intValue() / 2);
/*     */     }
/* 532 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean setZoom(int zoom) {
/* 543 */     if (zoom > 16384 || zoom < this.minZoom || zoom == this.lastMapProperties.zoomLevel.get().intValue())
/*     */     {
/* 545 */       return false;
/*     */     }
/* 547 */     this.lastMapProperties.zoomLevel.set(Integer.valueOf(zoom));
/* 548 */     requireRefresh();
/* 549 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getZoom() {
/* 559 */     return this.lastMapProperties.zoomLevel.get().intValue();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void requireRefresh() {
/* 567 */     this.lastRefresh = 0L;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void updateLastRefresh() {
/* 575 */     this.lastRefresh = System.currentTimeMillis();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean shouldRefresh(Minecraft mc, MapProperties mapProperties) {
/* 587 */     if (ClientAPI.INSTANCE.isDrawStepsUpdateNeeded())
/*     */     {
/* 589 */       return true;
/*     */     }
/*     */     
/* 592 */     if (MapPlayerTask.getlastTaskCompleted() - this.lastRefresh > 500L)
/*     */     {
/* 594 */       return true;
/*     */     }
/*     */     
/* 597 */     if (this.lastMapType == null)
/*     */     {
/* 599 */       return true;
/*     */     }
/*     */     
/* 602 */     EntityDTO player = DataCache.getPlayer();
/*     */     
/* 604 */     if (!player.dimension.equals((getMapType()).dimension))
/*     */     {
/* 606 */       return true;
/*     */     }
/*     */ 
/*     */     
/* 610 */     double d0 = (this.lastPlayerChunkX - player.chunkCoordX);
/* 611 */     double d1 = (this.lastPlayerChunkY - player.chunkCoordY);
/* 612 */     double d2 = (this.lastPlayerChunkZ - player.chunkCoordZ);
/* 613 */     double diff = Math.sqrt(d0 * d0 + d1 * d1 + d2 * d2);
/*     */     
/* 615 */     if (diff > 2.0D)
/*     */     {
/* 617 */       return true;
/*     */     }
/*     */     
/* 620 */     if (this.lastMapProperties == null || !this.lastMapProperties.equals(mapProperties))
/*     */     {
/* 622 */       return true;
/*     */     }
/*     */     
/* 625 */     if (this.forceRefreshState) {
/*     */       
/* 627 */       this.forceRefreshState = false;
/* 628 */       return true;
/*     */     } 
/*     */     
/* 631 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setForceRefreshState(boolean force) {
/* 636 */     this.forceRefreshState = force;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isCaveMappingAllowed() {
/* 647 */     return this.caveMappingAllowed;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isCaveMappingEnabled() {
/* 657 */     return this.caveMappingEnabled;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isSurfaceMappingAllowed() {
/* 667 */     return this.surfaceMappingAllowed;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isTopoMappingAllowed() {
/* 678 */     return this.topoMappingAllowed;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ResourceKey<Level> getDimension() {
/* 688 */     return (getMapType()).dimension;
/*     */   }
/*     */ 
/*     */   
/*     */   public IntegerField getLastSlice() {
/* 693 */     return this.lastSlice;
/*     */   }
/*     */ 
/*     */   
/*     */   public void resetMapType() {
/* 698 */     this.lastMapType = null;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isBiomeMappingAllowed() {
/* 703 */     return this.biomeMappingAllowed;
/*     */   }
/*     */ }


/* Location:              C:\Users\Administrator\Downloads\journeymap-forge-1.21-6.0.0-beta.18.jar!\journeymap\client\model\MapState.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */