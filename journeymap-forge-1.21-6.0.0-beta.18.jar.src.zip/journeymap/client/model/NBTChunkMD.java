/*     */ package journeymap.client.model;
/*     */ 
/*     */ import journeymap.common.helper.BiomeHelper;
/*     */ import journeymap.common.nbt.RegionData;
/*     */ import net.minecraft.core.BlockPos;
/*     */ import net.minecraft.nbt.CompoundTag;
/*     */ import net.minecraft.world.level.ChunkPos;
/*     */ import net.minecraft.world.level.biome.Biome;
/*     */ import net.minecraft.world.level.block.state.BlockState;
/*     */ import net.minecraft.world.level.chunk.LevelChunk;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class NBTChunkMD
/*     */   extends ChunkMD
/*     */ {
/*     */   final CompoundTag data;
/*     */   final LevelChunk chunk;
/*     */   final ChunkPos chunkPos;
/*     */   final MapType mapType;
/*     */   
/*     */   public NBTChunkMD(LevelChunk chunk, ChunkPos chunkPos, CompoundTag data, MapType mapType) {
/*  26 */     super(chunk, false);
/*  27 */     this.chunk = chunk;
/*  28 */     this.mapType = mapType;
/*  29 */     this.data = data;
/*  30 */     this.chunkPos = chunkPos;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean hasChunk() {
/*  41 */     return (this.data != null);
/*     */   }
/*     */ 
/*     */   
/*     */   public LevelChunk getChunk() {
/*  46 */     return this.chunk;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getPrecipitationHeight(int localX, int localZ) {
/*  59 */     return getPrecipitationHeight(getBlockPos(localX, 0, localZ));
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public BlockState getChunkBlockState(BlockPos blockPos) {
/*  65 */     BlockState state = getBlockState(blockPos);
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  70 */     return state;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getSavedLightValue(int localX, int y, int localZ) {
/*  84 */     BlockPos pos = getBlockPos(localX, y, localZ);
/*  85 */     return getGetLightValue(pos).intValue();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public BlockMD getBlockMD(BlockPos blockPos) {
/*  98 */     return BlockMD.get(getBlockState(blockPos));
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean canBlockSeeTheSky(int localX, int y, int localZ) {
/* 104 */     return !this.mapType.isUnderground();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getPrecipitationHeight(BlockPos blockPos) {
/* 116 */     return getTopY(blockPos).intValue();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public int getHeight(BlockPos blockPos) {
/* 122 */     BlockPos pos = new BlockPos(toWorldX(blockPos.getX()), blockPos.getY(), toWorldZ(blockPos.getZ()));
/* 123 */     Integer surfaceY = getSurfaceY(pos);
/* 124 */     if (surfaceY == null)
/*     */     {
/* 126 */       surfaceY = getTopY(pos);
/*     */     }
/* 128 */     return surfaceY.intValue();
/*     */   }
/*     */ 
/*     */   
/*     */   public BlockMD getBlockMD(int localX, int y, int localZ) {
/* 133 */     return BlockMD.get(getBlockState(getBlockPos(localX, y, localZ)));
/*     */   }
/*     */ 
/*     */   
/*     */   public Biome getBiome(BlockPos blockPos) {
/* 138 */     CompoundTag blockData = getBlockNBT(blockPos);
/* 139 */     if (blockData.contains("biome_name")) {
/*     */       
/* 141 */       String biomeName = blockData.getString("biome_name");
/* 142 */       return BiomeHelper.getBiomeFromResourceString(biomeName);
/*     */     } 
/* 144 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   public Integer getTopY(BlockPos blockPos) {
/* 149 */     CompoundTag blockData = getBlockNBT(blockPos);
/* 150 */     if (blockData.contains("top_y"))
/*     */     {
/* 152 */       return Integer.valueOf(blockData.getInt("top_y"));
/*     */     }
/*     */     
/* 155 */     return Integer.valueOf(blockPos.getY());
/*     */   }
/*     */ 
/*     */   
/*     */   public Integer getGetLightValue(BlockPos blockPos) {
/* 160 */     CompoundTag blockData = getBlockNBT(blockPos);
/* 161 */     if (blockData.contains("light_value"))
/*     */     {
/* 163 */       return Integer.valueOf(blockData.getInt("light_value"));
/*     */     }
/*     */     
/* 166 */     return Integer.valueOf(0);
/*     */   }
/*     */ 
/*     */   
/*     */   private Integer getSurfaceY(BlockPos blockPos) {
/* 171 */     CompoundTag blockData = getBlockNBT(blockPos);
/* 172 */     if (blockData.contains("surface_y"))
/*     */     {
/* 174 */       return Integer.valueOf(blockData.getInt("surface_y"));
/*     */     }
/* 176 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public BlockState getBlockState(BlockPos blockPos) {
/* 182 */     CompoundTag blockData = getBlockNBT(blockPos);
/* 183 */     BlockState blockState = RegionData.getBlockState(blockData, blockPos, this.mapType);
/* 184 */     return blockState;
/*     */   }
/*     */ 
/*     */   
/*     */   private CompoundTag getBlockNBT(BlockPos blockPos) {
/* 189 */     return RegionData.getBlockDataForChunk(this.data, blockPos.getX(), blockPos.getZ());
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean fromNbt() {
/* 195 */     return true;
/*     */   }
/*     */ }


/* Location:              C:\Users\Administrator\Downloads\journeymap-forge-1.21-6.0.0-beta.18.jar!\journeymap\client\model\NBTChunkMD.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */