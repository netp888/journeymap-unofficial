/*     */ package journeymap.client.model;
/*     */ 
/*     */ import java.lang.reflect.Method;
/*     */ import journeymap.client.properties.ClientCategory;
/*     */ import journeymap.client.ui.UIManager;
/*     */ import journeymap.client.ui.component.screens.JmUI;
/*     */ import journeymap.client.ui.component.screens.JmUILegacy;
/*     */ import journeymap.client.ui.option.ClientOptionsManager;
/*     */ import journeymap.common.Journeymap;
/*     */ import journeymap.common.log.LogFormatter;
/*     */ import journeymap.common.properties.catagory.Category;
/*     */ import net.minecraft.client.gui.screens.Screen;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Line
/*     */ {
/*     */   public String label;
/*     */   public String action;
/*     */   
/*     */   public Line() {}
/*     */   
/*     */   public Line(String label, String action) {
/*  67 */     this.label = label;
/*  68 */     this.action = action;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean hasAction() {
/*  78 */     return (this.action != null && this.action.trim().length() > 0);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void invokeAction(JmUILegacy returnUi) {
/*  88 */     if (!hasAction()) {
/*     */       return;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     try {
/*  95 */       String[] parts = this.action.split("#");
/*  96 */       String className = parts[0];
/*  97 */       String action = null;
/*  98 */       if (parts.length > 1)
/*     */       {
/* 100 */         action = parts[1];
/*     */       }
/*     */       
/* 103 */       Class<? extends Screen> uiClass = (Class)Class.forName("journeymap.client.ui." + className);
/*     */       
/* 105 */       if (uiClass.equals(ClientOptionsManager.class) && action != null) {
/*     */         
/* 107 */         Category category = ClientCategory.valueOf(action);
/* 108 */         UIManager.INSTANCE.openOptionsManager((Screen)returnUi, new Category[] { category });
/*     */         return;
/*     */       } 
/* 111 */       if (action != null) {
/*     */         
/* 113 */         String arg = (parts.length == 3) ? parts[2] : null;
/*     */ 
/*     */         
/*     */         try {
/* 117 */           Object instance = null;
/* 118 */           if (JmUILegacy.class.isAssignableFrom(uiClass) || JmUI.class.isAssignableFrom(uiClass)) {
/*     */             
/* 120 */             instance = UIManager.INSTANCE.open(uiClass, (Screen)returnUi);
/*     */           }
/*     */           else {
/*     */             
/* 124 */             instance = uiClass.newInstance();
/*     */           } 
/*     */           
/* 127 */           if (arg == null) {
/*     */             
/* 129 */             Method actionMethod = uiClass.getMethod(action, new Class[0]);
/* 130 */             actionMethod.invoke(instance, new Object[0]);
/*     */           }
/*     */           else {
/*     */             
/* 134 */             Method actionMethod = uiClass.getMethod(action, new Class[] { String.class });
/* 135 */             actionMethod.invoke(instance, new Object[] { arg });
/*     */           } 
/*     */           
/*     */           return;
/* 139 */         } catch (Exception e) {
/*     */           
/* 141 */           Journeymap.getLogger().warn("Couldn't perform action " + action + " on " + String.valueOf(uiClass) + ": " + e.getMessage());
/*     */         } 
/*     */       } 
/*     */       
/* 145 */       if (uiClass.getSuperclass().isAssignableFrom(JmUILegacy.class) || uiClass
/* 146 */         .getSuperclass().isAssignableFrom(JmUI.class) || uiClass
/* 147 */         .getSuperclass().getSuperclass().isAssignableFrom(JmUI.class))
/*     */       {
/* 149 */         UIManager.INSTANCE.open(uiClass, (Screen)returnUi);
/*     */       }
/*     */     }
/* 152 */     catch (Throwable t) {
/*     */       
/* 154 */       Journeymap.getLogger().error("Couldn't invoke action: " + this.action + ": " + LogFormatter.toString(t));
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\Administrator\Downloads\journeymap-forge-1.21-6.0.0-beta.18.jar!\journeymap\client\model\SplashInfo$Line.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */