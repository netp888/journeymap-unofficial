/*     */ package journeymap.client.model;
/*     */ 
/*     */ import com.mojang.blaze3d.platform.NativeImage;
/*     */ import java.io.File;
/*     */ import java.util.StringJoiner;
/*     */ import java.util.concurrent.CompletableFuture;
/*     */ import journeymap.client.io.RegionImageHandler;
/*     */ import journeymap.client.texture.ComparableNativeImage;
/*     */ import journeymap.client.texture.ImageUtil;
/*     */ import net.minecraft.Util;
/*     */ import net.minecraft.resources.ResourceKey;
/*     */ import net.minecraft.world.level.Level;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class RegionImageSet
/*     */   extends ImageSet
/*     */ {
/*     */   protected final Key key;
/*     */   
/*     */   public RegionImageSet(Key key) {
/*  33 */     this.key = key;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public ImageHolder getHolder(MapType mapType) {
/*  39 */     synchronized (this.imageHolders) {
/*     */       
/*  41 */       ImageHolder imageHolder = this.imageHolders.get(mapType);
/*  42 */       if (imageHolder == null || imageHolder.getImage() == null || (imageHolder.getImage()).pixels == 0L) {
/*     */ 
/*     */         
/*  45 */         File imageFile = RegionImageHandler.getRegionImageFile(getRegionCoord(), mapType);
/*     */ 
/*     */         
/*  48 */         imageHolder = addHolder(mapType, imageFile);
/*     */       } 
/*  50 */       return imageHolder;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public ImageHolder getHolderAsyncLoad(MapType mapType) {
/*  57 */     synchronized (this.imageHolders) {
/*     */       
/*  59 */       ImageHolder imageHolder = this.imageHolders.get(mapType);
/*  60 */       if (imageHolder == null || imageHolder.getImage() == null || (imageHolder.getImage()).pixels == 0L)
/*     */       {
/*  62 */         CompletableFuture.supplyAsync(() -> RegionImageHandler.getRegionImageFile(getRegionCoord(), mapType), Util.backgroundExecutor())
/*  63 */           .whenCompleteAsync((file, throwable) -> addHolder(mapType, file));
/*     */       }
/*  65 */       return imageHolder;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public ImageHolder getExistingHolder(MapType mapType) {
/*  72 */     synchronized (this.imageHolders) {
/*     */       
/*  74 */       return this.imageHolders.get(mapType);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public ComparableNativeImage getChunkImage(ChunkMD chunkMd, MapType mapType) {
/*  80 */     RegionCoord regionCoord = getRegionCoord();
/*  81 */     NativeImage regionImage = getHolder(mapType).getImage();
/*     */     
/*  83 */     ComparableNativeImage sub = ImageUtil.getComparableSubImage(regionCoord
/*  84 */         .getXOffset((chunkMd.getCoord()).x), regionCoord
/*  85 */         .getZOffset((chunkMd.getCoord()).z), 16, 16, regionImage, false);
/*     */     
/*  87 */     return sub;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setChunkImage(ChunkMD chunkMd, MapType mapType, ComparableNativeImage chunkImage) {
/*  92 */     ImageHolder holder = getHolder(mapType);
/*  93 */     boolean wasBlank = holder.blank;
/*  94 */     if (chunkImage.isChanged() || wasBlank) {
/*     */       
/*  96 */       RegionCoord regionCoord = getRegionCoord();
/*  97 */       holder.partialImageUpdate((NativeImage)chunkImage, regionCoord.getXOffset((chunkMd.getCoord()).x), regionCoord.getZOffset((chunkMd.getCoord()).z));
/*     */     } 
/*  99 */     if (wasBlank) {
/*     */       
/* 101 */       holder.getTexture();
/* 102 */       holder.finishPartialImageUpdates();
/* 103 */       RegionImageCache.INSTANCE.getRegionImageSet(getRegionCoord());
/*     */     } 
/* 105 */     chunkMd.setRendered(mapType);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean hasChunkUpdates() {
/* 110 */     synchronized (this.imageHolders) {
/*     */       
/* 112 */       for (ImageHolder holder : this.imageHolders.values()) {
/*     */         
/* 114 */         if (holder.partialUpdate)
/*     */         {
/* 116 */           return true;
/*     */         }
/*     */       } 
/*     */     } 
/* 120 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public void finishChunkUpdates() {
/* 125 */     synchronized (this.imageHolders) {
/*     */       
/* 127 */       for (ImageHolder holder : this.imageHolders.values())
/*     */       {
/* 129 */         holder.finishPartialImageUpdates();
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public RegionCoord getRegionCoord() {
/* 136 */     return RegionCoord.fromRegionPos(this.key.worldDir, this.key.regionX, this.key.regionZ, this.key.dimension);
/*     */   }
/*     */ 
/*     */   
/*     */   public long getOldestTimestamp() {
/* 141 */     long time = System.currentTimeMillis();
/* 142 */     synchronized (this.imageHolders) {
/*     */       
/* 144 */       for (ImageHolder holder : this.imageHolders.values()) {
/*     */         
/* 146 */         if (holder != null)
/*     */         {
/* 148 */           time = Math.min(time, holder.getImageTimestamp());
/*     */         }
/*     */       } 
/*     */     } 
/* 152 */     return time;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 158 */     return this.key.hashCode();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean equals(Object obj) {
/* 164 */     if (this == obj)
/*     */     {
/* 166 */       return true;
/*     */     }
/* 168 */     if (obj == null)
/*     */     {
/* 170 */       return false;
/*     */     }
/* 172 */     if (getClass() != obj.getClass())
/*     */     {
/* 174 */       return false;
/*     */     }
/* 176 */     return this.key.equals(((RegionImageSet)obj).key);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected int getImageSize() {
/* 182 */     return 512;
/*     */   }
/*     */ 
/*     */   
/*     */   public static class Key
/*     */   {
/*     */     private final File worldDir;
/*     */     private final int regionX;
/*     */     private final int regionZ;
/*     */     private final ResourceKey<Level> dimension;
/*     */     
/*     */     private Key(File worldDir, int regionX, int regionZ, ResourceKey<Level> dimension) {
/* 194 */       this.worldDir = worldDir;
/* 195 */       this.regionX = regionX;
/* 196 */       this.regionZ = regionZ;
/* 197 */       this.dimension = dimension;
/*     */     }
/*     */ 
/*     */     
/*     */     public static Key from(RegionCoord rCoord) {
/* 202 */       return new Key(rCoord.worldDir, rCoord.regionX, rCoord.regionZ, rCoord.dimension);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public boolean equals(Object o) {
/* 208 */       if (this == o)
/*     */       {
/* 210 */         return true;
/*     */       }
/* 212 */       if (o == null || getClass() != o.getClass())
/*     */       {
/* 214 */         return false;
/*     */       }
/*     */       
/* 217 */       Key key = (Key)o;
/*     */       
/* 219 */       if (this.dimension != key.dimension)
/*     */       {
/* 221 */         return false;
/*     */       }
/* 223 */       if (this.regionX != key.regionX)
/*     */       {
/* 225 */         return false;
/*     */       }
/* 227 */       if (this.regionZ != key.regionZ)
/*     */       {
/* 229 */         return false;
/*     */       }
/* 231 */       if (!this.worldDir.equals(key.worldDir))
/*     */       {
/* 233 */         return false;
/*     */       }
/*     */       
/* 236 */       return true;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public int hashCode() {
/* 242 */       int result = this.worldDir.hashCode();
/* 243 */       result = 31 * result + this.regionX;
/* 244 */       result = 31 * result + this.regionZ;
/* 245 */       result = 31 * result + this.dimension.hashCode();
/* 246 */       return result;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public String toString() {
/* 252 */       return (new StringJoiner(", ", Key.class.getSimpleName() + "[", "]"))
/* 253 */         .add("worldDir=" + String.valueOf(this.worldDir))
/* 254 */         .add("regionX=" + this.regionX)
/* 255 */         .add("regionZ=" + this.regionZ)
/* 256 */         .add("dimension=" + String.valueOf(this.dimension))
/* 257 */         .toString();
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\Administrator\Downloads\journeymap-forge-1.21-6.0.0-beta.18.jar!\journeymap\client\model\RegionImageSet.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */