/*     */ package journeymap.client.model;
/*     */ 
/*     */ import com.google.common.base.MoreObjects;
/*     */ import com.mojang.blaze3d.platform.NativeImage;
/*     */ import java.io.File;
/*     */ import java.io.IOException;
/*     */ import java.nio.file.Path;
/*     */ import java.util.HashSet;
/*     */ import java.util.concurrent.TimeUnit;
/*     */ import java.util.concurrent.locks.ReentrantLock;
/*     */ import journeymap.client.io.RegionImageHandler;
/*     */ import journeymap.client.log.StatTimer;
/*     */ import journeymap.client.task.main.ExpireTextureTask;
/*     */ import journeymap.client.texture.ImageUtil;
/*     */ import journeymap.client.texture.RegionTexture;
/*     */ import journeymap.client.texture.Texture;
/*     */ import journeymap.common.Journeymap;
/*     */ import journeymap.common.log.LogFormatter;
/*     */ import net.minecraft.Util;
/*     */ import net.minecraft.world.level.ChunkPos;
/*     */ import org.apache.logging.log4j.Level;
/*     */ import org.apache.logging.log4j.Logger;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ImageHolder
/*     */ {
/*  34 */   static final Logger logger = Journeymap.getLogger();
/*     */   final MapType mapType;
/*     */   final Path imagePath;
/*     */   final int imageSize;
/*     */   boolean blank = true;
/*     */   boolean dirty = true;
/*     */   boolean partialUpdate;
/*  41 */   private volatile ReentrantLock writeLock = new ReentrantLock();
/*     */   private volatile RegionTexture texture;
/*     */   private boolean debug;
/*  44 */   private HashSet<ChunkPos> updatedChunks = new HashSet<>();
/*     */ 
/*     */   
/*     */   ImageHolder(MapType mapType, File imageFile, int imageSize) {
/*  48 */     this.mapType = mapType;
/*  49 */     this.imagePath = imageFile.toPath();
/*  50 */     this.imageSize = imageSize;
/*  51 */     this.debug = logger.isEnabled(Level.DEBUG);
/*  52 */     getTexture();
/*     */   }
/*     */ 
/*     */   
/*     */   File getFile() {
/*  57 */     return this.imagePath.toFile();
/*     */   }
/*     */ 
/*     */   
/*     */   MapType getMapType() {
/*  62 */     return this.mapType;
/*     */   }
/*     */ 
/*     */   
/*     */   NativeImage getImage() {
/*  67 */     return this.texture.getNativeImage();
/*     */   }
/*     */ 
/*     */   
/*     */   void setImage(NativeImage image) {
/*  72 */     this.texture.setNativeImage(image, true);
/*  73 */     setDirty();
/*     */   }
/*     */ 
/*     */   
/*     */   void partialImageUpdate(NativeImage imagePart, int startX, int startY) {
/*  78 */     this.writeLock.lock();
/*  79 */     StatTimer timer = StatTimer.get("ImageHolder.partialImageUpdate", 5, 500);
/*  80 */     timer.start();
/*     */     
/*     */     try {
/*  83 */       if (this.texture != null)
/*     */       {
/*  85 */         this.blank = false;
/*  86 */         int width = imagePart.getWidth();
/*  87 */         int height = imagePart.getHeight();
/*  88 */         for (int y = 0; y < height; y++) {
/*     */           
/*  90 */           for (int x = 0; x < width; x++)
/*     */           {
/*  92 */             this.texture.getNativeImage().setPixelRGBA(x + startX, y + startY, imagePart.getPixelRGBA(x, y));
/*     */           }
/*     */         } 
/*  95 */         this.partialUpdate = true;
/*  96 */         this.updatedChunks.add(new ChunkPos(startX, startY));
/*     */       }
/*     */       else
/*     */       {
/* 100 */         logger.warn(String.valueOf(this) + " can't partialImageUpdate without a texture.");
/*     */       }
/*     */     
/*     */     } finally {
/*     */       
/* 105 */       timer.stop();
/* 106 */       this.writeLock.unlock();
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   void finishPartialImageUpdates() {
/* 112 */     this.writeLock.lock();
/*     */     
/*     */     try {
/* 115 */       if (this.partialUpdate && !this.updatedChunks.isEmpty())
/*     */       {
/* 117 */         NativeImage textureImage = this.texture.getNativeImage();
/*     */         
/* 119 */         this.texture.setNativeImage(textureImage, true, this.updatedChunks);
/* 120 */         setDirty();
/* 121 */         this.partialUpdate = false;
/* 122 */         this.updatedChunks.clear();
/*     */       }
/*     */     
/*     */     }
/*     */     finally {
/*     */       
/* 128 */       this.writeLock.unlock();
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean hasTexture() {
/* 134 */     return (this.texture != null && !this.texture.isDefunct());
/*     */   }
/*     */ 
/*     */   
/*     */   public RegionTexture getTexture() {
/* 139 */     if (!hasTexture()) {
/*     */       
/* 141 */       if (!this.imagePath.toFile().exists()) {
/*     */ 
/*     */         
/* 144 */         File temp = new File(String.valueOf(this.imagePath) + ".new");
/* 145 */         if (temp.exists()) {
/*     */           
/* 147 */           Journeymap.getLogger().warn("Recovered image file: " + String.valueOf(temp));
/* 148 */           temp.renameTo(this.imagePath.toFile());
/*     */         } 
/*     */       } 
/*     */       
/* 152 */       NativeImage image = RegionImageHandler.readRegionImage(this.imagePath.toFile());
/* 153 */       if (image == null || image.pixels == 0L || image.getWidth() != this.imageSize || image.getHeight() != this.imageSize) {
/*     */         
/* 155 */         image = ImageUtil.getNewBlankImage(this.imageSize, this.imageSize);
/* 156 */         this.blank = true;
/* 157 */         this.dirty = false;
/*     */       }
/*     */       else {
/*     */         
/* 161 */         this.blank = false;
/*     */       } 
/* 163 */       this.texture = new RegionTexture(image, this.imagePath.toString());
/*     */     } 
/* 165 */     return this.texture;
/*     */   }
/*     */ 
/*     */   
/*     */   private void setDirty() {
/* 170 */     this.dirty = true;
/*     */   }
/*     */ 
/*     */   
/*     */   boolean isDirty() {
/* 175 */     return this.dirty;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected boolean writeToDisk(boolean async) {
/* 186 */     if (this.blank || this.texture == null || !this.texture.hasImage())
/*     */     {
/* 188 */       return false;
/*     */     }
/*     */ 
/*     */     
/* 192 */     if (async) {
/*     */ 
/*     */       
/*     */       try {
/* 196 */         Util.ioPool().execute(this::writeNextIO);
/*     */       }
/* 198 */       catch (Exception e) {
/*     */         
/* 200 */         Journeymap.getLogger().warn("Failed to write image async: " + String.valueOf(this));
/*     */       } 
/* 202 */       return true;
/*     */     } 
/*     */ 
/*     */     
/* 206 */     int tries = 0;
/* 207 */     boolean success = false;
/* 208 */     while (tries < 5) {
/*     */       
/* 210 */       if (writeNextIO()) {
/*     */         
/* 212 */         tries++;
/*     */         
/*     */         continue;
/*     */       } 
/* 216 */       success = true;
/*     */     } 
/*     */ 
/*     */     
/* 220 */     if (!success)
/*     */     {
/* 222 */       Journeymap.getLogger().warn("Couldn't write file after 5 tries: " + String.valueOf(this));
/*     */     }
/* 224 */     return success;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean writeNextIO() {
/* 238 */     if (this.texture == null || !this.texture.hasImage())
/*     */     {
/* 240 */       return false;
/*     */     }
/*     */ 
/*     */     
/*     */     try {
/* 245 */       if (this.writeLock.tryLock(250L, TimeUnit.MILLISECONDS)) {
/*     */         
/* 247 */         writeImageToFile();
/* 248 */         this.writeLock.unlock();
/* 249 */         return false;
/*     */       } 
/*     */ 
/*     */       
/* 253 */       logger.warn("Couldn't get write lock for file: " + String.valueOf(this.writeLock) + " for " + String.valueOf(this));
/* 254 */       return true;
/*     */     
/*     */     }
/* 257 */     catch (InterruptedException e) {
/*     */       
/* 259 */       logger.warn("Timeout waiting for write lock  " + String.valueOf(this.writeLock) + " for " + String.valueOf(this));
/* 260 */       return true;
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   private void writeImageToFile() {
/* 266 */     File imageFile = this.imagePath.toFile();
/*     */ 
/*     */     
/*     */     try {
/* 270 */       NativeImage image = this.texture.getNativeImage();
/* 271 */       if (image != null)
/*     */       {
/* 273 */         if (!imageFile.exists())
/*     */         {
/* 275 */           imageFile.getParentFile().mkdirs();
/*     */         }
/*     */         
/* 278 */         File temp = new File(imageFile.getParentFile(), imageFile.getName() + ".new");
/*     */         
/* 280 */         image.writeToFile(temp);
/*     */         
/* 282 */         if (imageFile.exists())
/*     */         {
/* 284 */           if (!imageFile.delete())
/*     */           {
/* 286 */             logger.warn("Couldn't delete old file " + imageFile.getName());
/*     */           }
/*     */         }
/*     */         
/* 290 */         if (temp.renameTo(imageFile)) {
/*     */           
/* 292 */           this.dirty = false;
/*     */         }
/*     */         else {
/*     */           
/* 296 */           logger.warn("Couldn't rename temp file to " + imageFile.getName());
/*     */         } 
/*     */         
/* 299 */         if (this.debug)
/*     */         {
/* 301 */           logger.debug("Wrote to disk: " + String.valueOf(imageFile));
/*     */         }
/*     */       }
/*     */     
/* 305 */     } catch (IOException e) {
/*     */       
/* 307 */       if (imageFile.exists()) {
/*     */         
/*     */         try
/*     */         {
/* 311 */           logger.error("IOException updating file, will delete and retry: " + String.valueOf(this) + ": " + LogFormatter.toPartialString(e));
/* 312 */           imageFile.delete();
/* 313 */           writeImageToFile();
/*     */         }
/* 315 */         catch (Throwable e2)
/*     */         {
/* 317 */           logger.error("Exception after delete/retry: " + String.valueOf(this) + ": " + LogFormatter.toPartialString(e));
/*     */         }
/*     */       
/*     */       } else {
/*     */         
/* 322 */         logger.error("IOException creating file: " + String.valueOf(this) + ": " + LogFormatter.toPartialString(e));
/*     */       }
/*     */     
/* 325 */     } catch (Throwable e) {
/*     */       
/* 327 */       logger.error("Exception writing to disk: " + String.valueOf(this) + ": " + LogFormatter.toPartialString(e));
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 334 */     return MoreObjects.toStringHelper(this)
/* 335 */       .add("mapType", this.mapType)
/* 336 */       .add("textureId", (this.texture == null) ? null : Integer.valueOf(this.texture.isBound() ? this.texture.getTextureId() : -1))
/* 337 */       .add("dirty", this.dirty)
/* 338 */       .add("imagePath", this.imagePath)
/* 339 */       .toString();
/*     */   }
/*     */ 
/*     */   
/*     */   public void clear() {
/* 344 */     this.writeLock.lock();
/* 345 */     ExpireTextureTask.queue((Texture)this.texture);
/* 346 */     this.texture = null;
/* 347 */     this.writeLock.unlock();
/*     */   }
/*     */ 
/*     */   
/*     */   public long getImageTimestamp() {
/* 352 */     if (this.texture != null)
/*     */     {
/* 354 */       return this.texture.getLastImageUpdate();
/*     */     }
/* 356 */     return 0L;
/*     */   }
/*     */ }


/* Location:              C:\Users\Administrator\Downloads\journeymap-forge-1.21-6.0.0-beta.18.jar!\journeymap\client\model\ImageHolder.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */