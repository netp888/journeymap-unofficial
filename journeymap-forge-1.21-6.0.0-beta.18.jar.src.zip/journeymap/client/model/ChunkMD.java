/*     */ package journeymap.client.model;
/*     */ 
/*     */ import java.io.Serializable;
/*     */ import java.lang.ref.WeakReference;
/*     */ import java.util.HashMap;
/*     */ import java.util.Random;
/*     */ import javax.annotation.Nullable;
/*     */ import journeymap.client.world.JmBlockAccess;
/*     */ import journeymap.common.Journeymap;
/*     */ import net.minecraft.client.Minecraft;
/*     */ import net.minecraft.client.multiplayer.ClientLevel;
/*     */ import net.minecraft.core.BlockPos;
/*     */ import net.minecraft.core.SectionPos;
/*     */ import net.minecraft.resources.ResourceKey;
/*     */ import net.minecraft.server.level.ServerLevel;
/*     */ import net.minecraft.world.level.BlockGetter;
/*     */ import net.minecraft.world.level.ChunkPos;
/*     */ import net.minecraft.world.level.Level;
/*     */ import net.minecraft.world.level.LightLayer;
/*     */ import net.minecraft.world.level.biome.Biome;
/*     */ import net.minecraft.world.level.block.state.BlockState;
/*     */ import net.minecraft.world.level.chunk.LevelChunk;
/*     */ import net.minecraft.world.level.levelgen.Heightmap;
/*     */ import net.minecraft.world.level.levelgen.WorldgenRandom;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ChunkMD
/*     */ {
/*     */   public static final String PROP_IS_SLIME_CHUNK = "isSlimeChunk";
/*     */   public static final String PROP_LOADED = "loaded";
/*     */   public static final String PROP_LAST_RENDERED = "lastRendered";
/*     */   protected final WeakReference<LevelChunk> chunkReference;
/*     */   private final ChunkPos coord;
/*  53 */   private final HashMap<String, Serializable> properties = new HashMap<>();
/*  54 */   private BlockDataArrays blockDataArrays = new BlockDataArrays();
/*     */ 
/*     */   
/*     */   private final Random random;
/*     */ 
/*     */   
/*     */   protected LevelChunk retainedChunk;
/*     */ 
/*     */   
/*     */   private byte[][][][] lights;
/*     */ 
/*     */   
/*     */   public ChunkMD(LevelChunk chunk) {
/*  67 */     this(chunk, false);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ChunkMD(LevelChunk chunk, boolean forceRetain, byte[][][][] lights) {
/*  78 */     this(chunk, forceRetain);
/*  79 */     this.lights = lights;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ChunkMD(LevelChunk chunk, boolean forceRetain) {
/*  90 */     if (chunk == null)
/*     */     {
/*  92 */       throw new IllegalArgumentException("Chunk can't be null");
/*     */     }
/*  94 */     this.random = new Random();
/*  95 */     this.coord = new ChunkPos((chunk.getPos()).x, (chunk.getPos()).z);
/*     */ 
/*     */     
/*  98 */     setProperty("loaded", Long.valueOf(System.currentTimeMillis()));
/*     */ 
/*     */     
/* 101 */     this.properties.put("isSlimeChunk", Boolean.valueOf(isSlimeChunk(chunk)));
/*     */     
/* 103 */     this.chunkReference = new WeakReference<>(chunk);
/* 104 */     if (forceRetain)
/*     */     {
/* 106 */       this.retainedChunk = chunk;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public BlockState getBlockState(int localX, int y, int localZ) {
/* 120 */     if (localX < 0 || localX > 15 || localZ < 0 || localZ > 15)
/*     */     {
/* 122 */       Journeymap.getLogger().warn("Expected local coords, got global coords");
/*     */     }
/* 124 */     return getBlockState(new BlockPos(toWorldX(localX), y, toWorldZ(localZ)));
/*     */   }
/*     */ 
/*     */   
/*     */   public BlockState getChunkBlockState(BlockPos blockPos) {
/* 129 */     return getChunk().getBlockState(blockPos);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public BlockState getBlockState(BlockPos blockPos) {
/* 140 */     return JmBlockAccess.INSTANCE.getBlockState(blockPos);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public BlockMD getBlockMD(BlockPos blockPos) {
/* 151 */     return BlockMD.getBlockMD(this, blockPos);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public Biome getBiome(BlockPos pos) {
/* 162 */     return (Biome)getChunk().getNoiseBiome(pos.getX() >> 2, pos.getY() >> 2, pos.getZ() >> 2).value();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getSavedLightValue(int localX, int y, int localZ) {
/* 175 */     if (this.lights != null) {
/*     */       
/*     */       try {
/*     */ 
/*     */         
/* 180 */         int localY = SectionPos.sectionRelative(y);
/* 181 */         int sectionIndex = getChunk().getLevel().getSectionIndex(y);
/* 182 */         int light = this.lights[sectionIndex][localX][localY][localZ];
/* 183 */         return light;
/*     */       }
/* 185 */       catch (Exception exception) {}
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     try {
/* 193 */       return getChunk().getLevel().getLightEngine().getLayerListener(LightLayer.BLOCK).getLightValue(getBlockPos(localX, y, localZ));
/*     */     }
/* 195 */     catch (ArrayIndexOutOfBoundsException e) {
/*     */ 
/*     */       
/* 198 */       return 1;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public BlockMD getBlockMD(int localX, int y, int localZ) {
/* 212 */     return BlockMD.getBlockMD(this, getBlockPos(localX, y, localZ));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int ceiling(int localX, int localZ) {
/* 224 */     int y = getPrecipitationHeight(getBlockPos(localX, 0, localZ));
/* 225 */     BlockPos blockPos = null;
/*     */ 
/*     */     
/*     */     try {
/* 229 */       while (y >= getMinY().intValue())
/*     */       {
/* 231 */         blockPos = getBlockPos(localX, y, localZ);
/* 232 */         BlockMD blockMD = getBlockMD(blockPos);
/*     */         
/* 234 */         if (blockMD == null) {
/*     */           
/* 236 */           y--; continue;
/*     */         } 
/* 238 */         if (blockMD.isIgnore() || blockMD.hasFlag(BlockFlag.OpenToSky)) {
/*     */           
/* 240 */           y--; continue;
/*     */         } 
/* 242 */         if (canBlockSeeTheSky(localX, y, localZ))
/*     */         {
/* 244 */           y--;
/*     */         
/*     */         }
/*     */       
/*     */       }
/*     */ 
/*     */     
/*     */     }
/* 252 */     catch (Exception e) {
/*     */       
/* 254 */       Journeymap.getLogger().warn(String.valueOf(e) + " at " + String.valueOf(e), e);
/*     */     } 
/*     */     
/* 257 */     return Math.max(getMinY().intValue(), y);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean hasChunk() {
/* 267 */     LevelChunk chunk = this.chunkReference.get();
/* 268 */     boolean result = (chunk != null && !(chunk instanceof net.minecraft.world.level.chunk.EmptyLevelChunk));
/* 269 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getHeight(BlockPos blockPos) {
/* 280 */     LevelChunk chunk = getChunk();
/* 281 */     return chunk.getHeight(Heightmap.Types.WORLD_SURFACE, blockPos.getX(), blockPos.getZ());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getPrecipitationHeight(int localX, int localZ) {
/* 293 */     return getPrecipitationHeight(getBlockPos(localX, 0, localZ));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getPrecipitationHeight(BlockPos blockPos) {
/* 310 */     return getChunk().getHeight(Heightmap.Types.WORLD_SURFACE, blockPos.getX(), blockPos.getZ());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getLightOpacity(BlockMD blockMD, int localX, int y, int localZ) {
/* 324 */     BlockPos pos = getBlockPos(localX, y, localZ);
/* 325 */     return blockMD.getBlockState().getLightBlock((BlockGetter)JmBlockAccess.INSTANCE, pos);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Serializable getProperty(String name) {
/* 336 */     return this.properties.get(name);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Serializable getProperty(String name, Serializable defaultValue) {
/* 348 */     Serializable currentValue = getProperty(name);
/* 349 */     if (currentValue == null) {
/*     */       
/* 351 */       setProperty(name, defaultValue);
/* 352 */       currentValue = defaultValue;
/*     */     } 
/* 354 */     return currentValue;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Serializable setProperty(String name, Serializable value) {
/* 366 */     return this.properties.put(name, value);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 372 */     return getCoord().hashCode();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean equals(Object obj) {
/* 378 */     if (this == obj)
/*     */     {
/* 380 */       return true;
/*     */     }
/* 382 */     if (obj == null)
/*     */     {
/* 384 */       return false;
/*     */     }
/* 386 */     if (getClass() != obj.getClass())
/*     */     {
/* 388 */       return false;
/*     */     }
/* 390 */     ChunkMD other = (ChunkMD)obj;
/* 391 */     return getCoord().equals(other.getCoord());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public LevelChunk getChunk() {
/* 401 */     LevelChunk chunk = this.chunkReference.get();
/* 402 */     if (chunk == null)
/*     */     {
/* 404 */       throw new ChunkMissingException(getCoord());
/*     */     }
/* 406 */     return chunk;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ClientLevel getWorld() {
/* 416 */     return (Minecraft.getInstance()).level;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getWorldActualHeight() {
/* 427 */     return getWorld().dimensionType().logicalHeight() + 1;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Boolean hasNoSky() {
/* 437 */     return Boolean.valueOf(!getWorld().dimensionType().natural());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean canBlockSeeTheSky(int localX, int y, int localZ) {
/* 450 */     int i = localX & 0xF;
/* 451 */     int k = localZ & 0xF;
/*     */     
/* 453 */     return getChunk().getLevel().canSeeSky(getBlockPos(localX, y, localZ));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ChunkPos getCoord() {
/* 463 */     return this.coord;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean isSlimeChunk(LevelChunk chunk) {
/* 473 */     if (chunk.getLevel() instanceof ServerLevel)
/*     */     {
/* 475 */       return (WorldgenRandom.seedSlimeChunk((chunk.getPos()).x, (chunk.getPos()).z, ((ServerLevel)chunk.getLevel()).getSeed(), 987234911L).nextInt(10) == 0);
/*     */     }
/*     */ 
/*     */     
/* 479 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public long getLoaded() {
/* 490 */     return ((Long)getProperty("loaded", Long.valueOf(0L))).longValue();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void resetRenderTimes() {
/* 498 */     getRenderTimes().clear();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void resetRenderTime(MapType mapType) {
/* 508 */     getRenderTimes().put(mapType, Long.valueOf(0L));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void resetBlockData(MapType mapType) {
/* 518 */     getBlockData().get(mapType).clear();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected HashMap<MapType, Long> getRenderTimes() {
/* 528 */     Serializable<Object, Object> obj = this.properties.get("lastRendered");
/* 529 */     if (!(obj instanceof HashMap)) {
/*     */       
/* 531 */       obj = new HashMap<>();
/* 532 */       this.properties.put("lastRendered", obj);
/*     */     } 
/* 534 */     return (HashMap)obj;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public long getLastRendered(MapType mapType) {
/* 545 */     return ((Long)getRenderTimes().getOrDefault(mapType, Long.valueOf(0L))).longValue();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public long setRendered(MapType mapType) {
/* 556 */     long now = System.currentTimeMillis();
/* 557 */     getRenderTimes().put(mapType, Long.valueOf(now));
/* 558 */     return now;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public BlockPos getBlockPos(int localX, int y, int localZ) {
/* 571 */     return new BlockPos(toWorldX(localX), y, toWorldZ(localZ));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int toWorldX(int localX) {
/* 582 */     return (this.coord.x << 4) + localX;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int toWorldZ(int localZ) {
/* 593 */     return (this.coord.z << 4) + localZ;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public BlockDataArrays getBlockData() {
/* 603 */     return this.blockDataArrays;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public BlockDataArrays.DataArray<Integer> getBlockDataInts(MapType mapType) {
/* 614 */     return this.blockDataArrays.get(mapType).ints();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public BlockDataArrays.DataArray<Float> getBlockDataFloats(MapType mapType) {
/* 625 */     return this.blockDataArrays.get(mapType).floats();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public BlockDataArrays.DataArray<Boolean> getBlockDataBooleans(MapType mapType) {
/* 636 */     return this.blockDataArrays.get(mapType).booleans();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 642 */     return "ChunkMD{coord=" + String.valueOf(this.coord) + ", properties=" + String.valueOf(this.properties) + "}";
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ResourceKey<Level> getDimension() {
/* 655 */     return getWorld().dimension();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void stopChunkRetention() {
/* 663 */     this.retainedChunk = null;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean hasRetainedChunk() {
/* 668 */     return (this.retainedChunk != null);
/*     */   }
/*     */ 
/*     */   
/*     */   public Integer getMinY() {
/* 673 */     return Integer.valueOf(getWorld().getMinBuildHeight());
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean fromNbt() {
/* 678 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public long getLongCoord() {
/* 683 */     return this.coord.toLong();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static class ChunkMissingException
/*     */     extends RuntimeException
/*     */   {
/*     */     ChunkMissingException(ChunkPos coord) {
/* 698 */       super("Chunk missing: " + String.valueOf(coord));
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\Administrator\Downloads\journeymap-forge-1.21-6.0.0-beta.18.jar!\journeymap\client\model\ChunkMD.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */