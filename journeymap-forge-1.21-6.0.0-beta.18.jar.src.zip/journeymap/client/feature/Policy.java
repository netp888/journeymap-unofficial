/*     */ package journeymap.client.feature;
/*     */ 
/*     */ import java.util.EnumSet;
/*     */ import java.util.HashSet;
/*     */ import java.util.Set;
/*     */ import net.minecraft.client.Minecraft;
/*     */ import net.minecraft.client.server.IntegratedServer;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Policy
/*     */ {
/*  20 */   static Minecraft mc = Minecraft.getInstance();
/*     */   
/*     */   final Feature feature;
/*     */   
/*     */   final boolean allowInSingleplayer;
/*     */   
/*     */   final boolean allowInMultiplayer;
/*     */ 
/*     */   
/*     */   public Policy(Feature feature, boolean allowInSingleplayer, boolean allowInMultiplayer) {
/*  30 */     this.feature = feature;
/*  31 */     this.allowInSingleplayer = allowInSingleplayer;
/*  32 */     this.allowInMultiplayer = allowInMultiplayer;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Set<Policy> bulkCreate(boolean allowInSingleplayer, boolean allowInMultiplayer) {
/*  44 */     return bulkCreate(Feature.all(), allowInSingleplayer, allowInMultiplayer);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Set<Policy> bulkCreate(EnumSet<Feature> features, boolean allowInSingleplayer, boolean allowInMultiplayer) {
/*  56 */     Set<Policy> policies = new HashSet<>();
/*  57 */     for (Feature feature : features)
/*     */     {
/*  59 */       policies.add(new Policy(feature, allowInSingleplayer, allowInMultiplayer));
/*     */     }
/*  61 */     return policies;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isCurrentlyAllowed() {
/*  71 */     if (this.allowInSingleplayer == this.allowInMultiplayer)
/*     */     {
/*  73 */       return this.allowInSingleplayer;
/*     */     }
/*     */ 
/*     */     
/*  77 */     IntegratedServer server = mc.getSingleplayerServer();
/*  78 */     boolean isSinglePlayer = (server != null && !server.isPublished());
/*     */     
/*  80 */     if (this.allowInSingleplayer && isSinglePlayer)
/*     */     {
/*  82 */       return true;
/*     */     }
/*  84 */     if (this.allowInMultiplayer && !isSinglePlayer)
/*     */     {
/*  86 */       return true;
/*     */     }
/*     */     
/*  89 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean equals(Object o) {
/*  95 */     if (this == o)
/*     */     {
/*  97 */       return true;
/*     */     }
/*  99 */     if (o == null || getClass() != o.getClass())
/*     */     {
/* 101 */       return false;
/*     */     }
/*     */     
/* 104 */     Policy policy = (Policy)o;
/*     */     
/* 106 */     if (this.allowInMultiplayer != policy.allowInMultiplayer)
/*     */     {
/* 108 */       return false;
/*     */     }
/* 110 */     if (this.allowInSingleplayer != policy.allowInSingleplayer)
/*     */     {
/* 112 */       return false;
/*     */     }
/* 114 */     if (this.feature != policy.feature)
/*     */     {
/* 116 */       return false;
/*     */     }
/*     */     
/* 119 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 125 */     int result = this.feature.hashCode();
/* 126 */     result = 31 * result + (this.allowInSingleplayer ? 1 : 0);
/* 127 */     result = 31 * result + (this.allowInMultiplayer ? 1 : 0);
/* 128 */     return result;
/*     */   }
/*     */ }


/* Location:              C:\Users\Administrator\Downloads\journeymap-forge-1.21-6.0.0-beta.18.jar!\journeymap\client\feature\Policy.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */