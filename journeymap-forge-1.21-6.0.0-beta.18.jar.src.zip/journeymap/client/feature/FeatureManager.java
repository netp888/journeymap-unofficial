/*     */ package journeymap.client.feature;
/*     */ 
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import journeymap.api.v2.client.display.Context;
/*     */ import journeymap.client.data.DataCache;
/*     */ import journeymap.client.model.MapType;
/*     */ import journeymap.client.ui.fullscreen.Fullscreen;
/*     */ import journeymap.client.ui.minimap.MiniMap;
/*     */ import journeymap.common.Journeymap;
/*     */ import journeymap.common.properties.GlobalProperties;
/*     */ import journeymap.common.properties.ServerOption;
/*     */ import net.minecraft.resources.ResourceKey;
/*     */ import net.minecraft.world.entity.Entity;
/*     */ import net.minecraft.world.level.Level;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class FeatureManager
/*     */ {
/*     */   private static FeatureManager INSTANCE;
/*  28 */   private final HashMap<Feature, Policy> policyMap = new HashMap<>();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private FeatureManager() {
/*  35 */     reset();
/*     */   }
/*     */ 
/*     */   
/*     */   public static FeatureManager getInstance() {
/*  40 */     if (INSTANCE == null)
/*     */     {
/*  42 */       INSTANCE = new FeatureManager();
/*     */     }
/*  44 */     return INSTANCE;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getPolicyDetails() {
/*  54 */     StringBuilder sb = new StringBuilder("Features: ");
/*  55 */     for (Feature feature : Feature.values()) {
/*     */       
/*  57 */       boolean single = false;
/*  58 */       boolean multi = false;
/*  59 */       if (INSTANCE.policyMap.containsKey(feature)) {
/*     */         
/*  61 */         single = ((Policy)INSTANCE.policyMap.get(feature)).allowInSingleplayer;
/*  62 */         multi = ((Policy)INSTANCE.policyMap.get(feature)).allowInMultiplayer;
/*     */       } 
/*     */       
/*  65 */       sb.append(String.format("\n\t%s : singleplayer = %s , multiplayer = %s", new Object[] { feature.name(), Boolean.valueOf(single), Boolean.valueOf(multi) }));
/*     */     } 
/*  67 */     return sb.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isAllowed(Feature feature) {
/*  78 */     Policy policy = INSTANCE.policyMap.get(feature);
/*  79 */     return (policy != null && policy.isCurrentlyAllowed());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Map<Feature, Boolean> getAllowedFeatures() {
/*  89 */     Map<Feature, Boolean> map = new HashMap<>((Feature.values()).length * 2);
/*  90 */     for (Feature feature : Feature.values())
/*     */     {
/*  92 */       map.put(feature, Boolean.valueOf(isAllowed(feature)));
/*     */     }
/*  94 */     return map;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void updateDimensionFeatures(GlobalProperties properties) {
/* 105 */     if (((Policy)this.policyMap.get(Feature.MapSurface)).isCurrentlyAllowed() && !((ServerOption)properties.surfaceMapping.get()).enabled()) {
/*     */       
/* 107 */       Journeymap.getLogger().info("Feature disabled: " + String.valueOf(Feature.MapSurface));
/* 108 */       nextMapType(Feature.MapSurface);
/* 109 */       this.policyMap.put(Feature.MapSurface, new Policy(Feature.MapSurface, false, false));
/*     */     }
/* 111 */     else if (!((Policy)this.policyMap.get(Feature.MapSurface)).isCurrentlyAllowed() && ((ServerOption)properties.surfaceMapping.get()).enabled()) {
/*     */       
/* 113 */       Journeymap.getLogger().info("Feature enabled: " + String.valueOf(Feature.MapSurface));
/* 114 */       this.policyMap.put(Feature.MapSurface, new Policy(Feature.MapSurface, true, true));
/*     */       
/* 116 */       if (MapType.none().equals(Fullscreen.state().getMapType())) {
/*     */         
/* 118 */         long time = ((Entity)(DataCache.getPlayer()).entityRef.get()).getCommandSenderWorld().getLevelData().getGameTime() % 24000L;
/* 119 */         MapType mapType = (time < 13800L) ? MapType.day(DataCache.getPlayer()) : MapType.night(DataCache.getPlayer());
/* 120 */         setMapType(mapType);
/*     */       } 
/*     */     } 
/*     */     
/* 124 */     if (((Policy)this.policyMap.get(Feature.MapTopo)).isCurrentlyAllowed() && !((ServerOption)properties.topoMapping.get()).enabled()) {
/*     */       
/* 126 */       Journeymap.getLogger().info("Feature disabled: " + String.valueOf(Feature.MapTopo));
/* 127 */       nextMapType(Feature.MapTopo);
/* 128 */       this.policyMap.put(Feature.MapTopo, new Policy(Feature.MapTopo, false, false));
/*     */     }
/* 130 */     else if (!((Policy)this.policyMap.get(Feature.MapTopo)).isCurrentlyAllowed() && ((ServerOption)properties.topoMapping.get()).enabled()) {
/*     */       
/* 132 */       Journeymap.getLogger().info("Feature enabled: " + String.valueOf(Feature.MapTopo));
/* 133 */       this.policyMap.put(Feature.MapTopo, new Policy(Feature.MapTopo, true, true));
/* 134 */       if (MapType.none().equals(Fullscreen.state().getMapType()))
/*     */       {
/* 136 */         setMapType(MapType.topo(DataCache.getPlayer()));
/*     */       }
/*     */     } 
/*     */     
/* 140 */     if (((Policy)this.policyMap.get(Feature.MapBiome)).isCurrentlyAllowed() && !((ServerOption)properties.biomeMapping.get()).enabled()) {
/*     */       
/* 142 */       Journeymap.getLogger().info("Feature disabled: " + String.valueOf(Feature.MapBiome));
/* 143 */       nextMapType(Feature.MapBiome);
/* 144 */       this.policyMap.put(Feature.MapBiome, new Policy(Feature.MapBiome, false, false));
/*     */     }
/* 146 */     else if (!((Policy)this.policyMap.get(Feature.MapBiome)).isCurrentlyAllowed() && ((ServerOption)properties.biomeMapping.get()).enabled()) {
/*     */       
/* 148 */       Journeymap.getLogger().info("Feature enabled: " + String.valueOf(Feature.MapBiome));
/* 149 */       this.policyMap.put(Feature.MapBiome, new Policy(Feature.MapBiome, true, true));
/* 150 */       if (MapType.none().equals(Fullscreen.state().getMapType()))
/*     */       {
/* 152 */         setMapType(MapType.biome(DataCache.getPlayer()));
/*     */       }
/*     */     } 
/*     */     
/* 156 */     if (((Policy)this.policyMap.get(Feature.MapCaves)).isCurrentlyAllowed() && !((ServerOption)properties.caveMapping.get()).enabled()) {
/*     */       
/* 158 */       Journeymap.getLogger().info("Feature disabled: " + String.valueOf(Feature.MapCaves));
/* 159 */       nextMapType(Feature.MapCaves);
/* 160 */       this.policyMap.put(Feature.MapCaves, new Policy(Feature.MapCaves, false, false));
/*     */     }
/* 162 */     else if (!((Policy)this.policyMap.get(Feature.MapCaves)).isCurrentlyAllowed() && ((ServerOption)properties.caveMapping.get()).enabled()) {
/*     */       
/* 164 */       Journeymap.getLogger().info("Feature enabled: " + String.valueOf(Feature.MapCaves));
/* 165 */       this.policyMap.put(Feature.MapCaves, new Policy(Feature.MapCaves, true, true));
/* 166 */       if (MapType.none().equals(Fullscreen.state().getMapType()))
/*     */       {
/* 168 */         setMapType(MapType.underground(DataCache.getPlayer()));
/*     */       }
/*     */     } 
/*     */     
/* 172 */     if (((ServerOption)properties.radarEnabled.get()).enabled()) {
/*     */       
/* 174 */       setMultiplayerFeature(Feature.RadarAnimals, properties.animalRadarEnabled.get().booleanValue());
/* 175 */       setMultiplayerFeature(Feature.RadarMobs, properties.mobRadarEnabled.get().booleanValue());
/* 176 */       setMultiplayerFeature(Feature.RadarPlayers, properties.playerRadarEnabled.get().booleanValue());
/* 177 */       setMultiplayerFeature(Feature.RadarVillagers, properties.villagerRadarEnabled.get().booleanValue());
/*     */     }
/*     */     else {
/*     */       
/* 181 */       setMultiplayerFeature(Feature.RadarAnimals, false);
/* 182 */       setMultiplayerFeature(Feature.RadarMobs, false);
/* 183 */       setMultiplayerFeature(Feature.RadarPlayers, false);
/* 184 */       setMultiplayerFeature(Feature.RadarVillagers, false);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   private void nextMapType(Feature feature) {
/* 190 */     if (((Policy)this.policyMap.get(feature)).isCurrentlyAllowed() && Fullscreen.state() != null)
/*     */     {
/* 192 */       if (Fullscreen.state().isSurfaceMappingAllowed() && !Feature.MapSurface.equals(feature)) {
/*     */         
/* 194 */         setMapType(MapType.day(DataCache.getPlayer()));
/*     */       }
/* 196 */       else if (Fullscreen.state().isTopoMappingAllowed() && !Feature.MapTopo.equals(feature)) {
/*     */         
/* 198 */         setMapType(MapType.topo(DataCache.getPlayer()));
/*     */       }
/* 200 */       else if (Fullscreen.state().isCaveMappingAllowed() && !Feature.MapCaves.equals(feature)) {
/*     */         
/* 202 */         setMapType(MapType.underground(DataCache.getPlayer()));
/*     */       }
/* 204 */       else if (Fullscreen.state().isBiomeMappingAllowed() && !Feature.MapBiome.equals(feature)) {
/*     */         
/* 206 */         setMapType(MapType.biome(DataCache.getPlayer()));
/*     */       } 
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private void setMapType(MapType to) {
/* 214 */     Fullscreen.state().setMapType(to);
/* 215 */     MiniMap.state().setMapType(to);
/*     */   }
/*     */ 
/*     */   
/*     */   private void setMultiplayerFeature(Feature feature, boolean enable) {
/* 220 */     if (!enable && ((Policy)this.policyMap.get(feature)).isCurrentlyAllowed()) {
/*     */       
/* 222 */       Journeymap.getLogger().info("Feature disabled: " + String.valueOf(feature));
/*     */     }
/* 224 */     else if (enable && !((Policy)this.policyMap.get(feature)).isCurrentlyAllowed()) {
/*     */       
/* 226 */       Journeymap.getLogger().info("Feature enabled: " + String.valueOf(feature));
/*     */     } 
/* 228 */     this.policyMap.put(feature, new Policy(feature, true, enable));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void reset() {
/* 236 */     for (Policy policy : Policy.bulkCreate(true, true))
/*     */     {
/* 238 */       this.policyMap.put(policy.feature, policy);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public void disableFeature(Context.MapType apiMapType, Context.UI mapUI, ResourceKey<Level> dimension) {
/* 244 */     Feature feature = Feature.fromApiMapType(apiMapType, dimension);
/* 245 */     nextMapType(feature);
/* 246 */     Journeymap.getLogger().info("Feature disabled: " + String.valueOf(feature));
/* 247 */     this.policyMap.put(feature, new Policy(feature, false, false));
/*     */   }
/*     */ }


/* Location:              C:\Users\Administrator\Downloads\journeymap-forge-1.21-6.0.0-beta.18.jar!\journeymap\client\feature\FeatureManager.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */