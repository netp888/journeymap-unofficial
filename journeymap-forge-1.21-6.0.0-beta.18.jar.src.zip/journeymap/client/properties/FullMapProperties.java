/*    */ package journeymap.client.properties;
/*    */ 
/*    */ import journeymap.common.properties.catagory.Category;
/*    */ import journeymap.common.properties.config.BooleanField;
/*    */ import journeymap.common.properties.config.IntegerField;
/*    */ import net.minecraft.client.Minecraft;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class FullMapProperties
/*    */   extends InGameMapProperties
/*    */ {
/* 21 */   public final BooleanField showKeys = new BooleanField(Category.Inherit, "jm.common.show_keys", true, 3);
/* 22 */   public final BooleanField showPlayerLoc = new BooleanField(Category.Inherit, "jm.common.show_player_loc", true, 1);
/* 23 */   public final BooleanField showMouseLoc = new BooleanField(Category.Inherit, "jm.common.show_mouse_loc", true, 2);
/* 24 */   public final IntegerField dragScale = new IntegerField(Category.Inherit, "jm.common.fullscreen_drag_scale", 1, 5, 1, 200);
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public FullMapProperties() {
/* 31 */     setPropertiesId(Integer.valueOf(0));
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public void postLoad(boolean isNew) {
/* 37 */     super.postLoad(isNew);
/*    */     
/* 39 */     if (isNew && Minecraft.getInstance() != null)
/*    */     {
/* 41 */       if ((Minecraft.getInstance()).font.isBidirectional())
/*    */       {
/* 43 */         this.fontScale.set(Float.valueOf(2.0F));
/*    */       }
/*    */     }
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public String getName() {
/* 51 */     return "fullmap";
/*    */   }
/*    */ }


/* Location:              C:\Users\Administrator\Downloads\journeymap-forge-1.21-6.0.0-beta.18.jar!\journeymap\client\properties\FullMapProperties.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */