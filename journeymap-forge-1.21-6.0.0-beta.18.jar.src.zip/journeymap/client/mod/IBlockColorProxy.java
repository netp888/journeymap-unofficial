package journeymap.client.mod;

import javax.annotation.Nullable;
import journeymap.client.model.BlockMD;
import journeymap.client.model.ChunkMD;
import net.minecraft.core.BlockPos;

public interface IBlockColorProxy {
  @Nullable
  int deriveBlockColor(BlockMD paramBlockMD, @Nullable ChunkMD paramChunkMD, @Nullable BlockPos paramBlockPos);
  
  int getBlockColor(ChunkMD paramChunkMD, BlockMD paramBlockMD, BlockPos paramBlockPos);
}


/* Location:              C:\Users\Administrator\Downloads\journeymap-forge-1.21-6.0.0-beta.18.jar!\journeymap\client\mod\IBlockColorProxy.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */