/*     */ package journeymap.client.mod.vanilla;
/*     */ 
/*     */ import com.google.common.collect.ListMultimap;
/*     */ import com.google.common.collect.MultimapBuilder;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.HashMap;
/*     */ import journeymap.client.JourneymapClient;
/*     */ import journeymap.client.mod.IModBlockHandler;
/*     */ import journeymap.client.mod.ModBlockDelegate;
/*     */ import journeymap.client.model.BlockFlag;
/*     */ import journeymap.client.model.BlockMD;
/*     */ import journeymap.client.properties.CoreProperties;
/*     */ import net.minecraft.world.level.block.Block;
/*     */ import net.minecraft.world.level.block.Blocks;
/*     */ import net.minecraft.world.level.block.BushBlock;
/*     */ import net.minecraft.world.level.block.CactusBlock;
/*     */ import net.minecraft.world.level.block.DoublePlantBlock;
/*     */ import net.minecraft.world.level.block.FenceBlock;
/*     */ import net.minecraft.world.level.block.FenceGateBlock;
/*     */ import net.minecraft.world.level.block.GrassBlock;
/*     */ import net.minecraft.world.level.block.IronBarsBlock;
/*     */ import net.minecraft.world.level.block.LeavesBlock;
/*     */ import net.minecraft.world.level.block.PinkPetalsBlock;
/*     */ import net.minecraft.world.level.block.RailBlock;
/*     */ import net.minecraft.world.level.block.RedStoneWireBlock;
/*     */ import net.minecraft.world.level.block.RenderShape;
/*     */ import net.minecraft.world.level.block.SeagrassBlock;
/*     */ import net.minecraft.world.level.block.StainedGlassBlock;
/*     */ import net.minecraft.world.level.block.StainedGlassPaneBlock;
/*     */ import net.minecraft.world.level.block.SugarCaneBlock;
/*     */ import net.minecraft.world.level.block.TorchBlock;
/*     */ import net.minecraft.world.level.block.TransparentBlock;
/*     */ import net.minecraft.world.level.block.VineBlock;
/*     */ import net.minecraft.world.level.block.state.BlockState;
/*     */ import net.minecraft.world.level.block.state.properties.DoubleBlockHalf;
/*     */ import net.minecraft.world.level.block.state.properties.Property;
/*     */ import net.minecraft.world.level.material.MapColor;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class VanillaBlockHandler
/*     */   implements IModBlockHandler
/*     */ {
/*  70 */   ListMultimap<MapColor, BlockFlag> materialFlags = MultimapBuilder.ListMultimapBuilder.linkedHashKeys().arrayListValues().build();
/*     */ 
/*     */ 
/*     */   
/*  74 */   ListMultimap<Class<?>, BlockFlag> blockClassFlags = MultimapBuilder.ListMultimapBuilder.linkedHashKeys().arrayListValues().build();
/*     */ 
/*     */ 
/*     */   
/*  78 */   ListMultimap<Block, BlockFlag> blockFlags = MultimapBuilder.ListMultimapBuilder.linkedHashKeys().arrayListValues().build();
/*     */ 
/*     */ 
/*     */   
/*  82 */   HashMap<MapColor, Float> materialAlphas = new HashMap<>();
/*     */ 
/*     */ 
/*     */   
/*  86 */   HashMap<Block, Float> blockAlphas = new HashMap<>();
/*     */ 
/*     */ 
/*     */   
/*  90 */   HashMap<Class<?>, Float> blockClassAlphas = new HashMap<>();
/*     */ 
/*     */   
/*     */   private boolean mapPlants;
/*     */   
/*     */   private boolean mapPlantShadows;
/*     */   
/*     */   private boolean mapCrops;
/*     */ 
/*     */   
/*     */   public VanillaBlockHandler() {
/* 101 */     preInitialize();
/*     */   }
/*     */ 
/*     */   
/*     */   private void preInitialize() {
/* 106 */     CoreProperties coreProperties = JourneymapClient.getInstance().getCoreProperties();
/* 107 */     this.mapPlants = coreProperties.mapPlants.get().booleanValue();
/* 108 */     this.mapCrops = coreProperties.mapCrops.get().booleanValue();
/* 109 */     this.mapPlantShadows = coreProperties.mapPlantShadows.get().booleanValue();
/*     */ 
/*     */     
/* 112 */     setFlags(Blocks.BARRIER, new BlockFlag[] { BlockFlag.Ignore });
/* 113 */     setFlags(Blocks.AIR, new BlockFlag[] { BlockFlag.Ignore });
/* 114 */     setFlags(Blocks.GLASS, Float.valueOf(0.4F), new BlockFlag[] { BlockFlag.Transparency });
/* 115 */     setFlags(TransparentBlock.class, Float.valueOf(0.4F), new BlockFlag[] { BlockFlag.Transparency });
/* 116 */     setFlags(IronBarsBlock.class, Float.valueOf(0.4F), new BlockFlag[] { BlockFlag.Transparency });
/* 117 */     setFlags(StainedGlassPaneBlock.class, Float.valueOf(0.4F), new BlockFlag[] { BlockFlag.Transparency });
/* 118 */     setFlags(StainedGlassBlock.class, Float.valueOf(0.4F), new BlockFlag[] { BlockFlag.Transparency });
/* 119 */     setFlags(Blocks.SHORT_GRASS, new BlockFlag[] { BlockFlag.Grass });
/* 120 */     if (coreProperties.caveIgnoreGlass.get().booleanValue())
/*     */     {
/* 122 */       setFlags(Blocks.GLASS, new BlockFlag[] { BlockFlag.OpenToSky });
/*     */     }
/* 124 */     setFlags(Blocks.LAVA, Float.valueOf(1.0F), new BlockFlag[] { BlockFlag.NoShadow });
/* 125 */     setFlags(MapColor.WATER, Float.valueOf(0.25F), new BlockFlag[] { BlockFlag.Water, BlockFlag.NoShadow });
/* 126 */     setFlags(MapColor.WOOD, new BlockFlag[] { BlockFlag.NoTopo });
/*     */     
/* 128 */     setFlags(MapColor.PLANT, new BlockFlag[] { BlockFlag.Plant, BlockFlag.NoTopo });
/* 129 */     setFlags(Blocks.BAMBOO, new BlockFlag[] { BlockFlag.NoTopo });
/* 130 */     setFlags(Blocks.BAMBOO_SAPLING, new BlockFlag[] { BlockFlag.NoTopo });
/*     */     
/* 132 */     this.materialAlphas.put(MapColor.ICE, Float.valueOf(0.8F));
/*     */ 
/*     */ 
/*     */     
/* 136 */     setFlags(Blocks.IRON_BARS, Float.valueOf(0.4F), new BlockFlag[] { BlockFlag.Transparency });
/* 137 */     setFlags(Blocks.FIRE, new BlockFlag[] { BlockFlag.NoShadow });
/* 138 */     setFlags(Blocks.LADDER, new BlockFlag[] { BlockFlag.OpenToSky });
/* 139 */     setFlags(Blocks.SNOW, new BlockFlag[] { BlockFlag.NoTopo, BlockFlag.NoShadow });
/* 140 */     setFlags(Blocks.TRIPWIRE, new BlockFlag[] { BlockFlag.Ignore });
/* 141 */     setFlags(Blocks.TRIPWIRE_HOOK, new BlockFlag[] { BlockFlag.Ignore });
/* 142 */     setFlags(Blocks.COBWEB, new BlockFlag[] { BlockFlag.OpenToSky, BlockFlag.NoShadow });
/*     */ 
/*     */     
/* 145 */     setFlags(FenceBlock.class, Float.valueOf(0.4F), new BlockFlag[] { BlockFlag.Transparency });
/* 146 */     setFlags(FenceGateBlock.class, Float.valueOf(0.4F), new BlockFlag[] { BlockFlag.Transparency });
/* 147 */     setFlags(GrassBlock.class, new BlockFlag[] { BlockFlag.Grass });
/* 148 */     setFlags(PinkPetalsBlock.class, new BlockFlag[] { BlockFlag.Grass });
/* 149 */     setFlags(LeavesBlock.class, new BlockFlag[] { BlockFlag.OpenToSky, BlockFlag.Foliage, BlockFlag.NoTopo });
/*     */ 
/*     */     
/* 152 */     setFlags(RailBlock.class, new BlockFlag[] { BlockFlag.NoShadow, BlockFlag.NoTopo });
/* 153 */     setFlags(RedStoneWireBlock.class, new BlockFlag[] { BlockFlag.Ignore });
/* 154 */     setFlags(TorchBlock.class, new BlockFlag[] { BlockFlag.Ignore });
/* 155 */     setFlags(VineBlock.class, Float.valueOf(0.2F), new BlockFlag[] { BlockFlag.OpenToSky, BlockFlag.Foliage, BlockFlag.NoShadow });
/* 156 */     setFlags(BushBlock.class, new BlockFlag[] { BlockFlag.Plant });
/* 157 */     setFlags(CactusBlock.class, new BlockFlag[] { BlockFlag.Plant, BlockFlag.NoTopo });
/* 158 */     setFlags(SugarCaneBlock.class, new BlockFlag[] { BlockFlag.Plant, BlockFlag.NoTopo });
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 163 */     setFlags(SeagrassBlock.class, new BlockFlag[] { BlockFlag.Plant, BlockFlag.NoTopo });
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void initialize(BlockMD blockMD) {
/* 173 */     Block block = blockMD.getBlockState().getBlock();
/* 174 */     MapColor mapColor = blockMD.getBlock().defaultMapColor();
/* 175 */     BlockState blockState = blockMD.getBlockState();
/*     */ 
/*     */     
/* 178 */     if (blockState.getRenderShape() == RenderShape.INVISIBLE && !(blockState.getBlock() instanceof net.minecraft.world.level.block.LiquidBlock)) {
/*     */       
/* 180 */       blockMD.addFlags(new BlockFlag[] { BlockFlag.Ignore });
/*     */       
/*     */       return;
/*     */     } 
/*     */     
/* 185 */     blockMD.addFlags(this.materialFlags.get(mapColor));
/*     */ 
/*     */     
/* 188 */     Float alpha = this.materialAlphas.get(mapColor);
/* 189 */     if (alpha != null)
/*     */     {
/* 191 */       blockMD.setAlpha(alpha.floatValue());
/*     */     }
/*     */ 
/*     */     
/* 195 */     if (this.blockFlags.containsKey(block))
/*     */     {
/* 197 */       blockMD.addFlags(this.blockFlags.get(block));
/*     */     }
/*     */ 
/*     */     
/* 201 */     alpha = this.blockAlphas.get(block);
/* 202 */     if (alpha != null)
/*     */     {
/* 204 */       blockMD.setAlpha(alpha.floatValue());
/*     */     }
/*     */ 
/*     */     
/* 208 */     for (Class<?> parentClass : (Iterable<Class<?>>)this.blockClassFlags.keys()) {
/*     */       
/* 210 */       if (parentClass.isAssignableFrom(block.getClass())) {
/*     */         
/* 212 */         blockMD.addFlags(this.blockClassFlags.get(parentClass));
/* 213 */         alpha = this.blockClassAlphas.get(parentClass);
/* 214 */         if (alpha != null)
/*     */         {
/* 216 */           blockMD.setAlpha(alpha.floatValue());
/*     */         }
/*     */         
/*     */         break;
/*     */       } 
/*     */     } 
/*     */     
/* 223 */     if (block instanceof net.minecraft.world.level.block.LiquidBlock) {
/*     */       
/* 225 */       blockMD.addFlags(new BlockFlag[] { BlockFlag.Fluid, BlockFlag.NoShadow });
/* 226 */       blockMD.setAlpha(0.7F);
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 241 */     if (block instanceof BushBlock && blockMD.getBlockState().getProperties().contains(DoublePlantBlock.HALF) && blockMD.getBlockState().getValue((Property)DoublePlantBlock.HALF) == DoubleBlockHalf.UPPER)
/*     */     {
/* 243 */       blockMD.addFlags(new BlockFlag[] { BlockFlag.Ignore });
/*     */     }
/*     */ 
/*     */     
/* 247 */     if (block instanceof net.minecraft.world.level.block.CropBlock)
/*     */     {
/* 249 */       blockMD.addFlags(new BlockFlag[] { BlockFlag.Crop });
/*     */     }
/* 251 */     if (block instanceof net.minecraft.world.level.block.FlowerBlock || block instanceof net.minecraft.world.level.block.FlowerPotBlock)
/*     */     {
/* 253 */       blockMD.setBlockColorProxy(FlowerBlockProxy.INSTANCE);
/*     */     }
/*     */     
/* 256 */     if (block instanceof net.minecraft.world.level.block.BedBlock)
/*     */     {
/* 258 */       blockMD.setBlockColorProxy(BedBlockProxy.INSTANCE);
/*     */     }
/*     */     
/* 261 */     if (block instanceof PinkPetalsBlock)
/*     */     {
/* 263 */       blockMD.setBlockColorProxy(PetalBlockProxy.getInstance());
/*     */     }
/*     */     
/* 266 */     String uid = blockMD.getBlockId();
/* 267 */     if (uid.toLowerCase().contains("leaves")) {
/*     */       
/* 269 */       blockMD.removeFlags(new BlockFlag[] { BlockFlag.Plant });
/* 270 */       blockMD.addFlags(new BlockFlag[] { BlockFlag.OpenToSky, BlockFlag.Foliage, BlockFlag.NoTopo });
/*     */     } 
/* 272 */     if (uid.toLowerCase().contains("log") || uid.toLowerCase().contains("wood"))
/*     */     {
/* 274 */       blockMD.addFlags(new BlockFlag[] { BlockFlag.NoTopo });
/*     */     }
/* 276 */     if (uid.equals("minecraft:bell")) {
/*     */       
/* 278 */       blockMD.setBlockColorProxy(ModBlockDelegate.INSTANCE.getMaterialBlockColorProxy());
/*     */       
/*     */       return;
/*     */     } 
/* 282 */     if (blockMD.isVanillaBlock()) {
/*     */       return;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/* 288 */     if (uid.toLowerCase().contains("torch")) {
/*     */       
/* 290 */       blockMD.addFlags(new BlockFlag[] { BlockFlag.Ignore });
/*     */       return;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void postInitialize(BlockMD blockMD) {
/* 303 */     if (blockMD.hasFlag(BlockFlag.Crop))
/*     */     {
/* 305 */       blockMD.removeFlags(new BlockFlag[] { BlockFlag.Plant });
/*     */     }
/*     */ 
/*     */     
/* 309 */     if (blockMD.hasAnyFlag(BlockMD.FlagsPlantAndCrop))
/*     */     {
/* 311 */       if ((!this.mapPlants && blockMD.hasFlag(BlockFlag.Plant)) || (!this.mapCrops && blockMD.hasFlag(BlockFlag.Crop))) {
/*     */         
/* 313 */         blockMD.addFlags(new BlockFlag[] { BlockFlag.Ignore });
/*     */       }
/* 315 */       else if (!this.mapPlantShadows) {
/*     */         
/* 317 */         blockMD.addFlags(new BlockFlag[] { BlockFlag.NoShadow });
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 334 */     if (blockMD.isIgnore())
/*     */     {
/* 336 */       blockMD.removeFlags(BlockMD.FlagsNormal);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   private void setFlags(MapColor material, BlockFlag... flags) {
/* 342 */     this.materialFlags.putAll(material, new ArrayList(Arrays.asList((Object[])flags)));
/*     */   }
/*     */ 
/*     */   
/*     */   private void setFlags(MapColor material, Float alpha, BlockFlag... flags) {
/* 347 */     this.materialAlphas.put(material, alpha);
/* 348 */     setFlags(material, flags);
/*     */   }
/*     */ 
/*     */   
/*     */   private void setFlags(Class parentClass, BlockFlag... flags) {
/* 353 */     this.blockClassFlags.putAll(parentClass, new ArrayList(Arrays.asList((Object[])flags)));
/*     */   }
/*     */ 
/*     */   
/*     */   private void setFlags(Class<?> parentClass, Float alpha, BlockFlag... flags) {
/* 358 */     this.blockClassAlphas.put(parentClass, alpha);
/* 359 */     setFlags(parentClass, flags);
/*     */   }
/*     */ 
/*     */   
/*     */   private void setFlags(Block block, BlockFlag... flags) {
/* 364 */     this.blockFlags.putAll(block, new ArrayList(Arrays.asList((Object[])flags)));
/*     */   }
/*     */ 
/*     */   
/*     */   private void setFlags(Block block, Float alpha, BlockFlag... flags) {
/* 369 */     this.blockAlphas.put(block, alpha);
/* 370 */     setFlags(block, flags);
/*     */   }
/*     */ }


/* Location:              C:\Users\Administrator\Downloads\journeymap-forge-1.21-6.0.0-beta.18.jar!\journeymap\client\mod\vanilla\VanillaBlockHandler.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */