/*     */ package journeymap.client.mod.vanilla;
/*     */ 
/*     */ import java.util.Collection;
/*     */ import javax.annotation.Nonnull;
/*     */ import javax.annotation.Nullable;
/*     */ import journeymap.api.services.Services;
/*     */ import journeymap.client.JourneymapClient;
/*     */ import journeymap.client.cartography.color.ColorManager;
/*     */ import journeymap.client.cartography.color.ColoredSprite;
/*     */ import journeymap.client.cartography.color.RGB;
/*     */ import journeymap.client.mod.IBlockColorProxy;
/*     */ import journeymap.client.model.BlockFlag;
/*     */ import journeymap.client.model.BlockMD;
/*     */ import journeymap.client.model.ChunkMD;
/*     */ import journeymap.client.properties.CoreProperties;
/*     */ import journeymap.client.world.JmBlockAccess;
/*     */ import journeymap.common.Journeymap;
/*     */ import journeymap.common.log.LogFormatter;
/*     */ import net.minecraft.client.Minecraft;
/*     */ import net.minecraft.client.color.block.BlockColors;
/*     */ import net.minecraft.client.renderer.BiomeColors;
/*     */ import net.minecraft.core.BlockPos;
/*     */ import net.minecraft.world.level.BlockAndTintGetter;
/*     */ import net.minecraft.world.level.block.state.BlockState;
/*     */ import org.apache.logging.log4j.Logger;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class VanillaBlockColorProxy
/*     */   implements IBlockColorProxy
/*     */ {
/*  38 */   static Logger logger = Journeymap.getLogger();
/*     */   
/*  40 */   private final BlockColors blockColors = Minecraft.getInstance().getBlockColors();
/*     */   
/*     */   private final CoreProperties coreProperties;
/*     */   
/*     */   public VanillaBlockColorProxy() {
/*  45 */     this.coreProperties = JourneymapClient.getInstance().getCoreProperties();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public int deriveBlockColor(BlockMD blockMD, @Nullable ChunkMD chunkMD, @Nullable BlockPos blockPos) {
/*  51 */     BlockState blockState = blockMD.getBlockState();
/*     */ 
/*     */     
/*     */     try {
/*  55 */       if (blockState.getBlock() instanceof net.minecraft.world.level.block.LiquidBlock)
/*     */       {
/*  57 */         return getSpriteColor(blockMD, Integer.valueOf(12369084), chunkMD, blockPos).intValue();
/*     */       }
/*     */       
/*  60 */       Integer color = getSpriteColor(blockMD, null, chunkMD, blockPos);
/*     */       
/*  62 */       if (color == null)
/*     */       {
/*  64 */         color = Integer.valueOf(setBlockColorToMaterial(blockMD));
/*     */       }
/*  66 */       return color.intValue();
/*     */     }
/*  68 */     catch (Throwable e) {
/*     */       
/*  70 */       logger.error("Error deriving color for " + String.valueOf(blockMD) + ": " + LogFormatter.toPartialString(e));
/*  71 */       blockMD.addFlags(new BlockFlag[] { BlockFlag.Error });
/*  72 */       return setBlockColorToMaterial(blockMD);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getBlockColor(ChunkMD chunkMD, BlockMD blockMD, BlockPos blockPos) {
/*  87 */     boolean showBiomeWaterColor = this.coreProperties.mapWaterBiomeColors.get().booleanValue();
/*  88 */     int result = blockMD.getTextureColor(chunkMD, blockPos);
/*     */     
/*  90 */     if (blockMD.isFoliage()) {
/*     */ 
/*     */       
/*  93 */       result = RGB.adjustBrightness(result, 0.8F);
/*     */     }
/*  95 */     else if (blockMD.isFluid() && (!blockMD.isWater() || !showBiomeWaterColor)) {
/*     */ 
/*     */       
/*  98 */       return RGB.multiply(result, Services.CLIENT_SERVICE.getFluidTint(blockMD));
/*     */     } 
/*     */     
/* 101 */     return RGB.multiply(result, getColorMultiplier(chunkMD, blockMD, blockPos, blockMD.getBlockState().getRenderShape().ordinal()));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getColorMultiplier(ChunkMD chunkMD, BlockMD blockMD, BlockPos blockPos, int tintIndex) {
/* 115 */     boolean blendFoliage = this.coreProperties.mapBlendFoliage.get().booleanValue();
/* 116 */     boolean blendGrass = this.coreProperties.mapBlendGrass.get().booleanValue();
/* 117 */     boolean blendWater = this.coreProperties.mapBlendWater.get().booleanValue();
/*     */ 
/*     */     
/* 120 */     if (blockMD.isGrass()) {
/*     */       
/* 122 */       if (blendGrass)
/*     */       {
/* 124 */         return BiomeColors.getAverageGrassColor((BlockAndTintGetter)JmBlockAccess.INSTANCE, blockPos);
/*     */       }
/* 126 */       return chunkMD.getBiome(blockPos).getGrassColor(blockPos.getX(), blockPos.getZ());
/*     */     } 
/*     */     
/* 129 */     if (blockMD.isFoliage() && !blockMD.isLeavesBlock()) {
/*     */       
/* 131 */       if (blendFoliage)
/*     */       {
/* 133 */         return BiomeColors.getAverageFoliageColor((BlockAndTintGetter)JmBlockAccess.INSTANCE, blockPos);
/*     */       }
/* 135 */       return chunkMD.getBiome(blockPos).getFoliageColor();
/*     */     } 
/*     */     
/* 138 */     if (blockMD.isWater()) {
/*     */       
/* 140 */       if (blendWater)
/*     */       {
/* 142 */         return BiomeColors.getAverageWaterColor((BlockAndTintGetter)JmBlockAccess.INSTANCE, blockPos);
/*     */       }
/* 144 */       return chunkMD.getBiome(blockPos).getWaterColor();
/*     */     } 
/*     */     
/* 147 */     return this.blockColors.getColor(blockMD.getBlockState(), (BlockAndTintGetter)JmBlockAccess.INSTANCE, blockPos, tintIndex);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Integer getSpriteColor(@Nonnull BlockMD blockMD, @Nullable Integer defaultColor, @Nullable ChunkMD chunkMD, @Nullable BlockPos blockPos) {
/* 159 */     Collection<ColoredSprite> sprites = blockMD.getBlockSpritesProxy().getSprites(blockMD, chunkMD, blockPos);
/* 160 */     float[] rgba = ColorManager.INSTANCE.getAverageColor(sprites);
/*     */     
/* 162 */     if (rgba != null)
/*     */     {
/* 164 */       return Integer.valueOf(RGB.toInteger(rgba));
/*     */     }
/* 166 */     return defaultColor;
/*     */   }
/*     */ 
/*     */   
/*     */   public static int setBlockColorToError(BlockMD blockMD) {
/* 171 */     blockMD.setAlpha(0.0F);
/* 172 */     blockMD.addFlags(new BlockFlag[] { BlockFlag.Ignore, BlockFlag.Error });
/* 173 */     blockMD.setColor(-1);
/* 174 */     return -1;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static int setBlockColorToMaterial(BlockMD blockMD) {
/*     */     try {
/* 181 */       blockMD.setAlpha(1.0F);
/* 182 */       blockMD.addFlags(new BlockFlag[] { BlockFlag.Ignore });
/* 183 */       return blockMD.setColor((blockMD.getBlock().defaultMapColor()).col);
/*     */     }
/* 185 */     catch (Exception e) {
/*     */       
/* 187 */       logger.warn(String.format("Failed to use MaterialMapColor, marking as error: %s", new Object[] { blockMD }));
/* 188 */       return setBlockColorToError(blockMD);
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\Administrator\Downloads\journeymap-forge-1.21-6.0.0-beta.18.jar!\journeymap\client\mod\vanilla\VanillaBlockColorProxy.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */