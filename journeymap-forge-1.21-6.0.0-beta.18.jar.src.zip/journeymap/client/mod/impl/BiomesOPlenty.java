/*    */ package journeymap.client.mod.impl;
/*    */ 
/*    */ import java.util.Arrays;
/*    */ import java.util.Collections;
/*    */ import java.util.List;
/*    */ import journeymap.client.mod.IModBlockHandler;
/*    */ import journeymap.client.model.BlockFlag;
/*    */ import journeymap.client.model.BlockMD;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class BiomesOPlenty
/*    */   implements IModBlockHandler
/*    */ {
/* 23 */   private final List<String> plants = Arrays.asList(new String[] { "flower", "mushroom", "sapling", "plant", "ivy", "waterlily", "moss", "lavender" });
/* 24 */   private final List<String> crops = Collections.singletonList("turnip");
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void initialize(BlockMD blockMD) {
/* 33 */     String name = blockMD.getBlockId().toLowerCase();
/* 34 */     for (String plant : this.plants) {
/*    */       
/* 36 */       if (name.contains(plant)) {
/*    */         
/* 38 */         blockMD.addFlags(new BlockFlag[] { BlockFlag.Plant });
/*    */         
/*    */         break;
/*    */       } 
/*    */     } 
/* 43 */     for (String crop : this.crops) {
/*    */       
/* 45 */       if (name.contains(crop)) {
/*    */         
/* 47 */         blockMD.addFlags(new BlockFlag[] { BlockFlag.Crop });
/*    */         break;
/*    */       } 
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Users\Administrator\Downloads\journeymap-forge-1.21-6.0.0-beta.18.jar!\journeymap\client\mod\impl\BiomesOPlenty.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */