/*     */ package journeymap.client.mod;
/*     */ 
/*     */ import java.lang.reflect.Method;
/*     */ import java.util.Collection;
/*     */ import javax.annotation.Nullable;
/*     */ import javax.annotation.ParametersAreNonnullByDefault;
/*     */ import journeymap.api.services.Services;
/*     */ import journeymap.common.Journeymap;
/*     */ import journeymap.common.log.LogFormatter;
/*     */ import net.minecraft.world.level.block.state.BlockState;
/*     */ import net.minecraft.world.level.block.state.properties.EnumProperty;
/*     */ import net.minecraft.world.level.block.state.properties.Property;
/*     */ import org.apache.logging.log4j.Logger;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @ParametersAreNonnullByDefault
/*     */ public class ModPropertyEnum<T>
/*     */ {
/*  30 */   private static final Logger logger = Journeymap.getLogger();
/*     */ 
/*     */   
/*     */   private final boolean valid;
/*     */ 
/*     */   
/*     */   private final EnumProperty propertyEnum;
/*     */ 
/*     */   
/*     */   private final Method method;
/*     */ 
/*     */ 
/*     */   
/*     */   public ModPropertyEnum(EnumProperty propertyEnum, Method method, Class<T> returnType) {
/*  44 */     this.valid = (propertyEnum != null && method != null);
/*  45 */     this.propertyEnum = propertyEnum;
/*  46 */     this.method = method;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ModPropertyEnum(EnumProperty propertyEnum, String methodName, Class<T> returnType, Class<?>[] methodArgTypes) {
/*  58 */     this(propertyEnum, lookupMethod(propertyEnum, methodName, methodArgTypes), returnType);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ModPropertyEnum(String declaringClassName, String propertyEnumStaticFieldName, String methodName, Class<T> returnType) {
/*  70 */     this(declaringClassName, propertyEnumStaticFieldName, methodName, returnType, new Class[0]);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ModPropertyEnum(String declaringClassName, String propertyEnumStaticFieldName, String methodName, Class<T> returnType, Class<?>[] methodArgTypes) {
/*  83 */     this(lookupPropertyEnum(declaringClassName, propertyEnumStaticFieldName), methodName, returnType, methodArgTypes);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ModPropertyEnum(String declaringClassName, String propertyEnumStaticFieldName, Method method, Class<T> returnType) {
/*  95 */     this(lookupPropertyEnum(declaringClassName, propertyEnumStaticFieldName), method, returnType);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static EnumProperty lookupPropertyEnum(String declaringClassName, String propertyEnumStaticFieldName) {
/*     */     try {
/* 109 */       Class<?> declaringClass = Class.forName(declaringClassName);
/* 110 */       return (EnumProperty)Services.COMMON_SERVICE.getObfHelper().findField(declaringClass, propertyEnumStaticFieldName).get(declaringClass);
/*     */     }
/* 112 */     catch (Exception e) {
/*     */       
/* 114 */       Journeymap.getLogger().error("Error reflecting PropertyEnum on %s.%s: %s", declaringClassName, propertyEnumStaticFieldName, 
/* 115 */           LogFormatter.toPartialString(e));
/*     */       
/* 117 */       return null;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Method lookupMethod(EnumProperty propertyEnum, String methodName, Class... methodArgTypes) {
/* 130 */     if (propertyEnum != null)
/*     */     {
/* 132 */       return lookupMethod(propertyEnum.getValueClass().getName(), methodName, methodArgTypes);
/*     */     }
/* 134 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Method lookupMethod(String declaringClassName, String methodName, Class... methodArgTypes) {
/*     */     try {
/* 149 */       Class<?> declaringClass = Class.forName(declaringClassName);
/* 150 */       return Services.COMMON_SERVICE.getObfHelper().findMethod(declaringClass, methodName, methodArgTypes);
/*     */     }
/* 152 */     catch (Exception e) {
/*     */       
/* 154 */       Journeymap.getLogger().error("Error reflecting method %s.%s(): %s", declaringClassName, methodName, 
/* 155 */           LogFormatter.toPartialString(e));
/*     */       
/* 157 */       return null;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public EnumProperty getPropertyEnum() {
/* 167 */     return this.propertyEnum;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isValid() {
/* 177 */     return this.valid;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public T getValue(BlockState blockState, @Nullable Object... args) {
/* 192 */     if (this.valid) {
/*     */       
/*     */       try {
/*     */         
/* 196 */         Comparable<?> enumValue = blockState.getValue((Property)this.propertyEnum);
/* 197 */         if (enumValue != null)
/*     */         {
/* 199 */           return (T)this.method.invoke(enumValue, args);
/*     */         }
/*     */       }
/* 202 */       catch (Exception e) {
/*     */         
/* 204 */         logger.error("Error using mod PropertyEnum: " + LogFormatter.toPartialString(e));
/*     */       } 
/*     */     }
/* 207 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public static <T> T getFirstValue(Collection<ModPropertyEnum<T>> modPropertyEnums, BlockState blockState, @Nullable Object... args) {
/* 222 */     for (ModPropertyEnum<T> modPropertyEnum : modPropertyEnums) {
/*     */       
/* 224 */       T result = modPropertyEnum.getValue(blockState, args);
/* 225 */       if (result != null)
/*     */       {
/* 227 */         return result;
/*     */       }
/*     */     } 
/* 230 */     return null;
/*     */   }
/*     */ }


/* Location:              C:\Users\Administrator\Downloads\journeymap-forge-1.21-6.0.0-beta.18.jar!\journeymap\client\mod\ModPropertyEnum.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */