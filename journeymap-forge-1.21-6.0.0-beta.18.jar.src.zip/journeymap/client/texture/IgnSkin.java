/*     */ package journeymap.client.texture;
/*     */ 
/*     */ import com.google.common.collect.Maps;
/*     */ import com.mojang.authlib.GameProfile;
/*     */ import com.mojang.authlib.minecraft.MinecraftProfileTexture;
/*     */ import com.mojang.authlib.minecraft.MinecraftProfileTextures;
/*     */ import com.mojang.authlib.minecraft.MinecraftSessionService;
/*     */ import com.mojang.blaze3d.platform.NativeImage;
/*     */ import java.net.HttpURLConnection;
/*     */ import java.net.URL;
/*     */ import java.util.Map;
/*     */ import java.util.Optional;
/*     */ import java.util.UUID;
/*     */ import java.util.concurrent.CompletableFuture;
/*     */ import java.util.function.Consumer;
/*     */ import journeymap.common.Journeymap;
/*     */ import net.minecraft.Util;
/*     */ import net.minecraft.client.Minecraft;
/*     */ import net.minecraft.client.resources.DefaultPlayerSkin;
/*     */ import net.minecraft.resources.ResourceLocation;
/*     */ import net.minecraft.world.level.block.entity.SkullBlockEntity;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class IgnSkin
/*     */ {
/*  33 */   private static final Map<UUID, NativeImage> faceImageCache = Maps.newHashMap();
/*  34 */   private static final Map<URL, CompletableFuture<NativeImage>> imageRequests = Maps.newConcurrentMap();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static NativeImage getFaceImage(GameProfile profile) {
/*  44 */     String username = profile.getName();
/*  45 */     boolean firstPass = !faceImageCache.containsKey(profile.getId());
/*  46 */     if (firstPass) {
/*     */ 
/*     */       
/*  49 */       faceImageCache.put(profile.getId(), null);
/*     */       
/*  51 */       SkullBlockEntity.fetchGameProfile(username).thenAccept(optional -> {
/*     */             GameProfile gameProfile = optional.orElse(new GameProfile(Util.NIL_UUID, username));
/*     */             
/*     */             try {
/*     */               MinecraftSessionService mss = Minecraft.getInstance().getMinecraftSessionService();
/*     */               
/*     */               MinecraftProfileTextures textures = mss.getTextures(gameProfile);
/*     */               
/*     */               if (textures != null) {
/*     */                 Journeymap.getLogger().debug("Retrieved skin for {} : {}", profile.getId(), username);
/*     */                 
/*     */                 MinecraftProfileTexture mpt = textures.skin();
/*     */                 
/*     */                 getImageFromUrl(new URL(mpt.getUrl()), ());
/*     */               } else {
/*     */                 Journeymap.getLogger().debug("Unable to retrieve skin for {} : {}", profile.getId(), profile.getName());
/*     */                 
/*     */                 ResourceLocation resourceLocation = DefaultPlayerSkin.get(profile.getId()).texture();
/*     */                 NativeImage skinImage = TextureCache.getTexture(resourceLocation).getNativeImage();
/*     */                 faceImageCache.put(profile.getId(), cropToFace(skinImage));
/*     */               } 
/*  72 */             } catch (Throwable e) {
/*     */               Journeymap.getLogger().warn("Error getting face image for " + profile.getName() + ": " + e.getMessage());
/*     */             } 
/*     */           });
/*     */     } 
/*     */     
/*  78 */     return faceImageCache.get(profile.getId());
/*     */   }
/*     */ 
/*     */   
/*     */   private static void getImageFromUrl(URL imageURL, Consumer<NativeImage> imageConsumer) {
/*  83 */     CompletableFuture<NativeImage> future = imageRequests.get(imageURL);
/*  84 */     if (future != null) {
/*     */       
/*  86 */       imageRequests.put(imageURL, future.whenCompleteAsync((image, throwable) -> imageConsumer.accept(image), Util.backgroundExecutor()));
/*     */     }
/*     */     else {
/*     */       
/*  90 */       imageRequests.put(imageURL, 
/*  91 */           CompletableFuture.<NativeImage>supplyAsync(() -> downloadImage(imageURL), Util.backgroundExecutor())
/*  92 */           .whenCompleteAsync((image, throwable) -> imageConsumer.accept(image), Util.backgroundExecutor()));
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   private static NativeImage downloadImage(URL imageURL) {
/*  98 */     NativeImage img = null;
/*  99 */     HttpURLConnection conn = null;
/*     */     
/*     */     try {
/* 102 */       conn = (HttpURLConnection)imageURL.openConnection(Minecraft.getInstance().getProxy());
/* 103 */       HttpURLConnection.setFollowRedirects(true);
/* 104 */       conn.setInstanceFollowRedirects(true);
/* 105 */       conn.setDoInput(true);
/* 106 */       conn.setDoOutput(false);
/* 107 */       conn.setReadTimeout(3000);
/* 108 */       conn.setConnectTimeout(3000);
/* 109 */       conn.connect();
/* 110 */       if (conn.getResponseCode() / 100 == 2)
/*     */       {
/* 112 */         img = NativeImage.read(conn.getInputStream());
/*     */       }
/*     */       else
/*     */       {
/* 116 */         Journeymap.getLogger().debug("Bad Response getting image: " + String.valueOf(imageURL) + " : " + conn.getResponseCode());
/*     */       }
/*     */     
/* 119 */     } catch (Throwable e) {
/*     */       
/* 121 */       Journeymap.getLogger().error("Error getting skin image: " + String.valueOf(imageURL) + " : " + e.getMessage());
/*     */     }
/*     */     finally {
/*     */       
/* 125 */       if (conn != null)
/*     */       {
/* 127 */         conn.disconnect();
/*     */       }
/*     */     } 
/* 130 */     Journeymap.getLogger().debug("Getting Skin for URL: {}", imageURL);
/* 131 */     return img;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static NativeImage cropToFace(NativeImage playerSkin) {
/* 143 */     if (playerSkin != null) {
/*     */ 
/*     */       
/* 146 */       if (playerSkin.format().hasAlpha()) {
/*     */         
/* 148 */         NativeImage hat = ImageUtil.getSubImage(40, 8, 8, 8, playerSkin, false);
/*     */         
/* 150 */         for (int x = 0; x < 8; x++) {
/*     */           
/* 152 */           for (int y = 0; y < 8; y++) {
/*     */             
/* 154 */             int hatPixel = hat.getPixelRGBA(x, y);
/* 155 */             playerSkin.blendPixel(x + 8, y + 8, hatPixel);
/*     */           } 
/*     */         } 
/* 158 */         hat.close();
/*     */       } 
/* 160 */       NativeImage sub = ImageUtil.getSubImage(8, 8, 8, 8, playerSkin, true);
/*     */ 
/*     */       
/* 163 */       return ImageUtil.getSizedImage(24, 24, sub, true);
/*     */     } 
/*     */     
/* 166 */     return new NativeImage(24, 24, false);
/*     */   }
/*     */ }


/* Location:              C:\Users\Administrator\Downloads\journeymap-forge-1.21-6.0.0-beta.18.jar!\journeymap\client\texture\IgnSkin.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */