/*     */ package journeymap.client.texture;
/*     */ 
/*     */ import com.mojang.blaze3d.platform.NativeImage;
/*     */ import it.unimi.dsi.fastutil.floats.Float2ObjectMap;
/*     */ import it.unimi.dsi.fastutil.floats.Float2ObjectOpenHashMap;
/*     */ import journeymap.client.cartography.color.RGB;
/*     */ import journeymap.common.Journeymap;
/*     */ import net.minecraft.client.renderer.texture.DynamicTexture;
/*     */ import net.minecraft.resources.ResourceLocation;
/*     */ import org.jetbrains.annotations.Nullable;
/*     */ 
/*     */ public class DynamicTextureImpl
/*     */   extends DynamicTexture
/*     */   implements Texture {
/*     */   private float alpha;
/*     */   protected String description;
/*     */   private Integer renderWidth;
/*     */   private Integer renderHeight;
/*  19 */   private final Float2ObjectMap<Texture> scaledImageMap = (Float2ObjectMap<Texture>)new Float2ObjectOpenHashMap();
/*     */   
/*     */   @Nullable
/*     */   private ResourceLocation resourceLocation;
/*     */ 
/*     */   
/*     */   public DynamicTextureImpl(NativeImage nativeImage) {
/*  26 */     super(nativeImage);
/*     */   }
/*     */ 
/*     */   
/*     */   public DynamicTextureImpl(NativeImage nativeImage, float scale) {
/*  31 */     super(nativeImage);
/*  32 */     this.scaledImageMap.put(scale, this);
/*     */   }
/*     */ 
/*     */   
/*     */   public DynamicTextureImpl(NativeImage nativeImage, ResourceLocation location) {
/*  37 */     this(nativeImage);
/*  38 */     this.resourceLocation = location;
/*     */   }
/*     */ 
/*     */   
/*     */   public DynamicTextureImpl(int width, int height, boolean useCalloc) {
/*  43 */     this(new NativeImage(width, height, useCalloc));
/*     */   }
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public ResourceLocation getLocation() {
/*  49 */     return this.resourceLocation;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void upload() {
/*     */     try {
/*  56 */       if (getPixels() != null)
/*     */       {
/*  58 */         bind();
/*  59 */         getPixels().upload(0, 0, 0, false);
/*     */       }
/*     */     
/*  62 */     } catch (Exception e) {
/*     */       
/*  64 */       Journeymap.getLogger().error("Error uploading image to framebuffer:", e);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getWidth() {
/*  72 */     return (this.renderWidth == null) ? getPixels().getWidth() : this.renderWidth.intValue();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public int getHeight() {
/*  78 */     return (this.renderHeight == null) ? getPixels().getHeight() : this.renderHeight.intValue();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void setDisplayWidth(int width) {
/*  84 */     this.renderWidth = Integer.valueOf(width);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void setDisplayHeight(int height) {
/*  90 */     this.renderHeight = Integer.valueOf(height);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Texture getScaledImage(float drawScale) {
/*  97 */     if (drawScale == 1.0F)
/*     */     {
/*  99 */       return this;
/*     */     }
/* 101 */     Texture scaledTexture = (Texture)this.scaledImageMap.get(drawScale);
/*     */     
/*     */     try {
/* 104 */       if (scaledTexture == null)
/*     */       {
/* 106 */         NativeImage img = ImageUtil.getScaledImage(drawScale, getPixels(), false);
/* 107 */         scaledTexture = new DynamicTextureImpl(img, drawScale);
/* 108 */         this.scaledImageMap.put(drawScale, scaledTexture);
/*     */       }
/*     */     
/* 111 */     } catch (Exception e) {
/*     */       
/* 113 */       throw new RuntimeException(e);
/*     */     } 
/* 115 */     return scaledTexture;
/*     */   }
/*     */ 
/*     */   
/*     */   public Integer getRGB(int x, int y) {
/* 120 */     int rgba = getNativeImage().getPixelRGBA(x, y);
/* 121 */     return Integer.valueOf(RGB.rgbaToRgb(rgba));
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public int getTextureId() {
/* 127 */     return this.id;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean hasImage() {
/* 133 */     return (getPixels() != null && (getPixels()).pixels > 0L);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void remove() {
/* 139 */     ImageUtil.closeSafely(getPixels());
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void setNativeImage(NativeImage image) {
/* 145 */     setPixels(image);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public NativeImage getNativeImage() {
/* 151 */     return getPixels();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public float getAlpha() {
/* 157 */     return this.alpha;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void setAlpha(float alpha) {
/* 163 */     this.alpha = alpha;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setDescription(String description) {
/* 168 */     this.description = description;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void release() {
/* 174 */     releaseId();
/*     */   }
/*     */ }


/* Location:              C:\Users\Administrator\Downloads\journeymap-forge-1.21-6.0.0-beta.18.jar!\journeymap\client\texture\DynamicTextureImpl.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */