/*     */ package journeymap.client.texture;
/*     */ 
/*     */ import com.mojang.authlib.GameProfile;
/*     */ import com.mojang.blaze3d.platform.NativeImage;
/*     */ import java.io.File;
/*     */ import java.io.FileNotFoundException;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.util.Arrays;
/*     */ import java.util.Collections;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import java.util.concurrent.ArrayBlockingQueue;
/*     */ import java.util.concurrent.Callable;
/*     */ import java.util.concurrent.Future;
/*     */ import java.util.concurrent.ThreadFactory;
/*     */ import java.util.concurrent.ThreadPoolExecutor;
/*     */ import java.util.concurrent.TimeUnit;
/*     */ import journeymap.client.io.FileHandler;
/*     */ import journeymap.client.io.IconSetFileHandler;
/*     */ import journeymap.client.io.ThemeLoader;
/*     */ import journeymap.client.task.main.ExpireTextureTask;
/*     */ import journeymap.client.ui.theme.Theme;
/*     */ import journeymap.client.waypoint.ClientWaypointImpl;
/*     */ import journeymap.common.Journeymap;
/*     */ import journeymap.common.thread.JMThreadFactory;
/*     */ import journeymap.common.waypoint.WaypointStore;
/*     */ import net.minecraft.client.Minecraft;
/*     */ import net.minecraft.client.renderer.texture.AbstractTexture;
/*     */ import net.minecraft.client.renderer.texture.TextureManager;
/*     */ import net.minecraft.resources.ResourceLocation;
/*     */ import net.minecraft.server.packs.resources.Resource;
/*     */ import net.minecraft.server.packs.resources.ResourceManager;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class TextureCache
/*     */ {
/*  50 */   public static final ResourceLocation TOGGLE_ON = uiImage("toggle-button-on.png");
/*  51 */   public static final ResourceLocation TOGGLE_OFF = uiImage("toggle-button-off.png");
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  56 */   public static final ResourceLocation GridSquares = uiImage("grid.png");
/*     */ 
/*     */ 
/*     */   
/*  60 */   public static final ResourceLocation GridRegionSquares = uiImage("grid-region.png");
/*     */ 
/*     */ 
/*     */   
/*  64 */   public static final ResourceLocation GridRegion = uiImage("region.png");
/*     */ 
/*     */ 
/*     */   
/*  68 */   public static final ResourceLocation ColorPicker = uiImage("colorpick.png");
/*     */ 
/*     */ 
/*     */   
/*  72 */   public static final ResourceLocation ColorPicker2 = uiImage("colorpick2.png");
/*     */ 
/*     */ 
/*     */   
/*  76 */   public static final ResourceLocation TileSampleDay = uiImage("tile-sample-day.png");
/*     */ 
/*     */ 
/*     */   
/*  80 */   public static final ResourceLocation TileSampleNight = uiImage("tile-sample-night.png");
/*     */ 
/*     */ 
/*     */   
/*  84 */   public static final ResourceLocation TileSampleUnderground = uiImage("tile-sample-underground.png");
/*     */ 
/*     */ 
/*     */   
/*  88 */   public static final ResourceLocation UnknownEntity = uiImage("unknown.png");
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  93 */   public static final ResourceLocation Deathpoint = uiImage("waypoint-death-icon.png");
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  98 */   public static final ResourceLocation MobDot = uiImage("marker-dot-160.png");
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 103 */   public static final ResourceLocation MobDotArrow = uiImage("marker-dot-arrow-160.png");
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 108 */   public static final ResourceLocation MobDotChevron = uiImage("marker-chevron-160.png");
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 113 */   public static final ResourceLocation MobIconArrow = uiImage("marker-icon-arrow-160.png");
/*     */   
/* 115 */   public static final ResourceLocation MobIconArrowBG = uiImage("marker-icon-arrow-bg-160.png");
/*     */   
/* 117 */   public static final ResourceLocation MobIcon = uiImage("marker-icon-160.png");
/*     */   
/* 119 */   public static final ResourceLocation MobIconBG = uiImage("marker-icon-bg-160.png");
/*     */   
/* 121 */   public static final ResourceLocation MobIconMask = uiImage("marker-icon-mask.png");
/*     */ 
/*     */ 
/*     */   
/* 125 */   public static final ResourceLocation PlayerArrow = uiImage("marker-player-160.png");
/*     */ 
/*     */ 
/*     */   
/* 129 */   public static final ResourceLocation PlayerArrowBG = uiImage("marker-player-bg-160.png");
/*     */   
/* 131 */   public static final ResourceLocation PlayerOutline = uiImage("marker-player-outline.png");
/*     */ 
/*     */ 
/*     */   
/* 135 */   public static final ResourceLocation Logo = uiImage("ico/journeymap.png");
/*     */ 
/*     */ 
/*     */   
/* 139 */   public static final ResourceLocation MinimapSquare128 = uiImage("minimap/minimap-square-128.png");
/*     */ 
/*     */ 
/*     */   
/* 143 */   public static final ResourceLocation MinimapSquare256 = uiImage("minimap/minimap-square-256.png");
/*     */ 
/*     */ 
/*     */   
/* 147 */   public static final ResourceLocation MinimapSquare512 = uiImage("minimap/minimap-square-512.png");
/*     */ 
/*     */ 
/*     */   
/* 151 */   public static final ResourceLocation Discord = uiImage("discord.png");
/*     */   
/* 153 */   public static final ResourceLocation CurseForge = uiImage("curseforge.png");
/*     */   
/* 155 */   public static final ResourceLocation Modrinth = uiImage("modrinth.png");
/*     */   
/* 157 */   public static final ResourceLocation ColorWheel = uiImage("colorwheel.png");
/*     */   
/* 159 */   public static final ResourceLocation ColorWheelHandler = uiImage("colorwheel-handler.png");
/*     */   
/* 161 */   public static final ResourceLocation ColorBox = uiImage("color-box.png");
/*     */   
/* 163 */   public static final ResourceLocation ColorVSlider = uiImage("color-v-slider.png");
/*     */   
/* 165 */   public static final ResourceLocation ColorVSliderHandler = uiImage("color-v-slider-handler.png");
/*     */   
/* 167 */   public static final ResourceLocation ColorHistoryButton = uiImage("color-history-button.png");
/*     */   
/* 169 */   public static final ResourceLocation Flag = uiImage("flag.png");
/*     */ 
/*     */ 
/*     */   
/* 173 */   public static final ResourceLocation Waypoint = uiImage("waypoint-icon.png");
/*     */ 
/*     */ 
/*     */   
/* 177 */   public static final ResourceLocation WaypointEdit = uiImage("waypoint-edit.png");
/*     */ 
/*     */ 
/*     */   
/* 181 */   public static final ResourceLocation WaypointOffscreen = uiImage("waypoint-offscreen.png");
/*     */   
/* 183 */   private static final Map<String, ResourceLocation> dynamicTextureMap = Collections.synchronizedMap(new HashMap<>());
/* 184 */   public static final Map<String, Texture> colorizedWPIconMap = Collections.synchronizedMap(new HashMap<>());
/*     */ 
/*     */ 
/*     */   
/* 188 */   public static final Map<ResourceLocation, ResourceLocation> modTextureMap = Collections.synchronizedMap(new HashMap<>());
/*     */ 
/*     */   
/*     */   public static ResourceLocation getTexture(String texturePath) {
/* 192 */     ResourceLocation tex = dynamicTextureMap.get(texturePath);
/* 193 */     if (tex == null) {
/*     */       
/* 195 */       tex = uiImage(texturePath);
/* 196 */       dynamicTextureMap.put(texturePath, tex);
/*     */     } 
/* 198 */     return tex;
/*     */   }
/*     */ 
/*     */   
/*     */   public static ResourceLocation uiImage(String fileName) {
/* 203 */     return ResourceLocation.fromNamespaceAndPath("journeymap", "ui/img/" + fileName);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 210 */   public static final Map<String, Texture> playerSkins = Collections.synchronizedMap(new HashMap<>());
/*     */ 
/*     */ 
/*     */   
/* 214 */   public static final Map<String, Texture> themeImages = Collections.synchronizedMap(new HashMap<>());
/*     */   
/* 216 */   private static ThreadPoolExecutor texExec = new ThreadPoolExecutor(2, 4, 15L, TimeUnit.SECONDS, new ArrayBlockingQueue<>(8), (ThreadFactory)new JMThreadFactory("texture"), new ThreadPoolExecutor.CallerRunsPolicy());
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Texture getTexture(ResourceLocation location) {
/*     */     SimpleTextureImpl simpleTextureImpl;
/* 223 */     if (location == null)
/*     */     {
/* 225 */       return null;
/*     */     }
/*     */     
/* 228 */     TextureManager textureManager = Minecraft.getInstance().getTextureManager();
/* 229 */     AbstractTexture textureObject = textureManager.getTexture(location, null);
/*     */     
/* 231 */     if (needsNewTexture(textureObject)) {
/*     */       
/* 233 */       simpleTextureImpl = new SimpleTextureImpl(location);
/* 234 */       textureManager.register(location, (AbstractTexture)simpleTextureImpl);
/*     */     } 
/*     */ 
/*     */     
/*     */     try {
/* 239 */       Texture tex = simpleTextureImpl;
/* 240 */       return tex;
/*     */     }
/* 242 */     catch (Exception e) {
/*     */       
/* 244 */       Journeymap.getLogger().error("Not a proper texture for Journeymap:{}", location);
/*     */       
/* 246 */       return simpleTextureImpl;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Texture getWaypointIcon(ResourceLocation location) {
/* 257 */     if (!"journeymap".equals(location.getNamespace())) {
/*     */       
/* 259 */       TextureManager manager = Minecraft.getInstance().getTextureManager();
/* 260 */       ResourceLocation fakeResource = modTextureMap.get(location);
/* 261 */       if (fakeResource == null || manager.getTexture(fakeResource, null) == null) {
/*     */ 
/*     */         
/* 264 */         fakeResource = ResourceLocation.fromNamespaceAndPath("fake", location.getPath());
/* 265 */         modTextureMap.put(location, fakeResource);
/* 266 */         SimpleTextureImpl simpleTexture = new SimpleTextureImpl(location);
/*     */ 
/*     */         
/* 269 */         try { NativeImage img = ImageUtil.getScaledImage(4.0F, simpleTexture.getNativeImage(), false);
/* 270 */           DynamicTextureImpl scaledTexture = new DynamicTextureImpl(img, fakeResource);
/* 271 */           manager.register(fakeResource, (AbstractTexture)scaledTexture);
/* 272 */           scaledTexture.setDisplayHeight(simpleTexture.getHeight());
/* 273 */           scaledTexture.setDisplayWidth(simpleTexture.getHeight());
/* 274 */           simpleTexture.close(); } catch (Throwable throwable) { try { simpleTexture.close(); } catch (Throwable throwable1) { throwable.addSuppressed(throwable1); }  throw throwable; }
/*     */       
/* 276 */       }  return (Texture)manager.getTexture(fakeResource, null);
/*     */     } 
/* 278 */     return getTexture(location);
/*     */   }
/*     */ 
/*     */   
/*     */   private static boolean needsNewTexture(AbstractTexture textureObject) {
/* 283 */     if (textureObject == null)
/*     */     {
/* 285 */       return true;
/*     */     }
/* 287 */     if (textureObject instanceof Texture)
/*     */     {
/* 289 */       return !((Texture)textureObject).hasImage();
/*     */     }
/*     */ 
/*     */     
/* 293 */     return textureObject instanceof net.minecraft.client.renderer.texture.SimpleTexture;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static <T extends Texture> Future<T> scheduleTextureTask(Callable<T> textureTask) {
/* 307 */     return texExec.submit(textureTask);
/*     */   }
/*     */ 
/*     */   
/* 311 */   public static final Map<String, ResourceLocation> waypointIconCache = Collections.synchronizedMap(new HashMap<String, ResourceLocation>()
/*     */       {
/*     */       
/*     */       });
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void reset() {
/* 323 */     playerSkins.clear();
/*     */     
/* 325 */     Arrays.<ResourceLocation>asList(new ResourceLocation[] { ColorPicker, ColorPicker2, Deathpoint, GridSquares, GridRegionSquares, GridRegion, Logo, MinimapSquare128, MinimapSquare256, MinimapSquare512, MobDot, MobDotArrow, MobDotChevron, PlayerArrow, PlayerArrowBG, PlayerArrowBG, TileSampleDay, TileSampleNight, TileSampleUnderground, UnknownEntity, Waypoint, WaypointEdit, WaypointOffscreen
/*     */ 
/*     */ 
/*     */         
/* 329 */         }).stream().map(TextureCache::getTexture);
/*     */     
/* 331 */     Arrays.<ResourceLocation>asList(new ResourceLocation[] { ColorPicker, ColorPicker2, GridSquares, GridRegion, GridRegionSquares, TileSampleDay, TileSampleNight, TileSampleUnderground, UnknownEntity
/* 332 */         }).stream().map(TextureCache::getTexture);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void purgeThemeImages(Map<String, Texture> themeImages) {
/* 342 */     synchronized (themeImages) {
/*     */       
/* 344 */       ExpireTextureTask.queue(themeImages.values());
/* 345 */       themeImages.clear();
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public static NativeImage resolveImage(ResourceLocation location) {
/* 351 */     if (location.getNamespace().equals("fake"))
/*     */     {
/* 353 */       return null;
/*     */     }
/*     */     
/* 356 */     ResourceManager resourceManager = Minecraft.getInstance().getResourceManager();
/*     */     
/*     */     try {
/* 359 */       Resource resource = resourceManager.getResource(location).orElse(null);
/* 360 */       InputStream is = resource.open();
/* 361 */       return NativeImage.read(is);
/*     */     }
/* 363 */     catch (FileNotFoundException e) {
/*     */ 
/*     */       
/*     */       try {
/* 367 */         if ("journeymap".equals(location.getNamespace()))
/*     */         {
/*     */ 
/*     */           
/* 371 */           Resource imgFile = Minecraft.getInstance().getResourceManager().getResource(ResourceLocation.parse("../src/main/resources/assets/journeymap/" + location.getPath())).orElse(null);
/* 372 */           if (imgFile != null)
/*     */           {
/* 374 */             return NativeImage.read(imgFile.open());
/*     */           }
/*     */         }
/*     */       
/* 378 */       } catch (IOException ioe) {
/*     */         
/* 380 */         Journeymap.getLogger().warn("Image not found: " + ioe.getMessage());
/*     */       } 
/* 382 */       return null;
/*     */     }
/* 384 */     catch (Exception e) {
/*     */ 
/*     */ 
/*     */       
/* 388 */       Journeymap.getLogger().warn("Resource not readable: {}", location);
/* 389 */       return null;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Texture getThemeTexture(Theme theme, String iconPath) {
/* 402 */     return getSizedThemeTexture(theme, iconPath, 0, 0, false, 1.0F);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Texture getThemeTextureFromResource(ResourceLocation icon) {
/* 414 */     synchronized (themeImages) {
/*     */       
/* 416 */       Texture tex = themeImages.get(icon.toString());
/* 417 */       if (tex == null || !tex.hasImage()) {
/*     */         
/* 419 */         if (tex != null)
/*     */         {
/*     */           
/* 422 */           tex.remove();
/*     */         }
/*     */         
/* 425 */         NativeImage nativeImage = resolveImage(icon);
/* 426 */         if (nativeImage != null && nativeImage.pixels > 0L) {
/*     */           
/* 428 */           tex = new DynamicTextureImpl(nativeImage);
/* 429 */           tex.setAlpha(1.0F);
/* 430 */           themeImages.put(icon.toString(), tex);
/*     */         }
/*     */         else {
/*     */           
/* 434 */           Journeymap.getLogger().error("Unknown theme image: {}", icon);
/* 435 */           IconSetFileHandler.ensureEntityIconSet("Default");
/* 436 */           return getTexture(UnknownEntity);
/*     */         } 
/*     */       } 
/* 439 */       return tex;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Texture getSizedThemeTexture(Theme theme, String iconPath, int width, int height, boolean resize, float alpha) {
/* 456 */     String texName = String.format("%s/%s", new Object[] { theme.directory, iconPath });
/* 457 */     synchronized (themeImages) {
/*     */       
/* 459 */       Texture tex = themeImages.get(texName);
/* 460 */       if (tex == null || !tex.hasImage() || (resize && (width != tex.getWidth() || height != tex.getHeight())) || tex.getAlpha() != alpha) {
/*     */         
/* 462 */         if (tex != null)
/*     */         {
/*     */           
/* 465 */           tex.remove();
/*     */         }
/* 467 */         File parentDir = ThemeLoader.getThemeIconDir();
/* 468 */         NativeImage nativeImage = FileHandler.getIconFromFile(parentDir, theme.directory, iconPath);
/* 469 */         if (nativeImage == null) {
/*     */           
/* 471 */           String resourcePath = String.format("theme/%s/%s", new Object[] { theme.directory, iconPath });
/* 472 */           nativeImage = resolveImage(ResourceLocation.fromNamespaceAndPath("journeymap", resourcePath));
/*     */         } 
/*     */         
/* 475 */         if (nativeImage != null && nativeImage.pixels > 0L) {
/*     */           
/* 477 */           if (resize || alpha < 1.0F)
/*     */           {
/* 479 */             if (alpha < 1.0F || nativeImage.getWidth() != width || nativeImage.getHeight() != height) {
/*     */               
/* 481 */               NativeImage tmp = ImageUtil.getSizedImage(width, height, nativeImage, false);
/* 482 */               nativeImage.close();
/* 483 */               nativeImage = tmp;
/*     */             } 
/*     */           }
/* 486 */           tex = new DynamicTextureImpl(nativeImage);
/* 487 */           tex.setAlpha(alpha);
/* 488 */           themeImages.put(texName, tex);
/*     */         }
/*     */         else {
/*     */           
/* 492 */           Journeymap.getLogger().error("Unknown theme image: " + texName);
/* 493 */           IconSetFileHandler.ensureEntityIconSet("Default");
/* 494 */           return getTexture(UnknownEntity);
/*     */         } 
/*     */       } 
/* 497 */       return tex;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Texture getScaledCopy(String texName, Texture original, int width, int height, float alpha) {
/* 513 */     synchronized (themeImages) {
/*     */ 
/*     */ 
/*     */       
/* 517 */       Texture tex = themeImages.get(texName);
/* 518 */       if (tex == null || !tex.hasImage() || width != tex.getWidth() || height != tex.getHeight() || tex.getAlpha() != alpha)
/*     */       {
/* 520 */         if (original != null) {
/*     */           
/* 522 */           if (alpha < 1.0F || original.getWidth() != width || original.getHeight() != height)
/*     */           {
/* 524 */             tex = new DynamicTextureImpl(ImageUtil.getSizedImage(width, height, original.getNativeImage(), true));
/* 525 */             tex.setAlpha(alpha);
/*     */             
/* 527 */             themeImages.put(texName, tex);
/*     */           }
/*     */           else
/*     */           {
/* 531 */             return original;
/*     */           }
/*     */         
/*     */         } else {
/*     */           
/* 536 */           Journeymap.getLogger().error("Unable to get scaled image: " + texName);
/* 537 */           return getTexture(UnknownEntity);
/*     */         } 
/*     */       }
/* 540 */       return tex;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Texture getColorizedWaypointIcon(String id) {
/* 560 */     ClientWaypointImpl holder = WaypointStore.getInstance().get(id);
/* 561 */     if (holder != null) {
/*     */       
/* 563 */       ResourceLocation location = holder.getTextureResource();
/* 564 */       int color = holder.getIconColor().intValue();
/* 565 */       TextureManager textureManager = Minecraft.getInstance().getTextureManager();
/*     */       
/* 567 */       if (holder.hasCustomIconColor() || "journeymap".equals(location.getNamespace())) {
/*     */         
/* 569 */         SimpleTextureImpl image = new SimpleTextureImpl(location);
/* 570 */         if (colorizedWPIconMap.get(id) == null && image.hasImage()) {
/*     */           
/* 572 */           NativeImage coloredImage = ImageUtil.recolorImage(image.getNativeImage(), color);
/* 573 */           DynamicTextureImpl texture = new DynamicTextureImpl(coloredImage);
/* 574 */           colorizedWPIconMap.put(id, texture);
/* 575 */           image.close();
/* 576 */           return texture;
/*     */         } 
/*     */ 
/*     */         
/* 580 */         return colorizedWPIconMap.get(id);
/*     */       } 
/*     */       
/* 583 */       return (Texture)textureManager.getTexture(location, null);
/*     */     } 
/* 585 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Texture getPlayerSkin(GameProfile profile) {
/* 596 */     Texture tex = null;
/* 597 */     synchronized (playerSkins) {
/*     */       
/* 599 */       tex = playerSkins.get(profile.getName());
/*     */       
/* 601 */       if (tex != null)
/*     */       {
/* 603 */         return tex;
/*     */       }
/*     */ 
/*     */ 
/*     */       
/* 608 */       NativeImage blank = new NativeImage(24, 24, false);
/* 609 */       tex = new DynamicTextureImpl(blank);
/* 610 */       playerSkins.put(profile.getName(), tex);
/*     */     } 
/*     */ 
/*     */     
/* 614 */     Texture playerSkinTex = tex;
/*     */     
/* 616 */     NativeImage img = IgnSkin.getFaceImage(profile);
/* 617 */     if (img != null) {
/*     */       
/* 619 */       playerSkins.put(profile.getName(), new DynamicTextureImpl(img));
/*     */     }
/*     */     else {
/*     */       
/* 623 */       playerSkins.remove(profile.getName());
/*     */     } 
/* 625 */     return playerSkinTex;
/*     */   }
/*     */ }


/* Location:              C:\Users\Administrator\Downloads\journeymap-forge-1.21-6.0.0-beta.18.jar!\journeymap\client\texture\TextureCache.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */