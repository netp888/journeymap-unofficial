/*     */ package journeymap.client.texture;
/*     */ 
/*     */ import com.mojang.blaze3d.platform.NativeImage;
/*     */ import it.unimi.dsi.fastutil.floats.Float2ObjectMap;
/*     */ import it.unimi.dsi.fastutil.floats.Float2ObjectOpenHashMap;
/*     */ import java.io.IOException;
/*     */ import journeymap.client.cartography.color.RGB;
/*     */ import net.minecraft.client.Minecraft;
/*     */ import net.minecraft.client.renderer.texture.SimpleTexture;
/*     */ import net.minecraft.client.resources.metadata.texture.TextureMetadataSection;
/*     */ import net.minecraft.resources.ResourceLocation;
/*     */ import net.minecraft.server.packs.metadata.MetadataSectionSerializer;
/*     */ import net.minecraft.server.packs.resources.Resource;
/*     */ import net.minecraft.server.packs.resources.ResourceManager;
/*     */ 
/*     */ public class SimpleTextureImpl
/*     */   extends SimpleTexture implements Texture {
/*     */   private final ResourceLocation location;
/*  19 */   private final Float2ObjectMap<Texture> scaledImageMap = (Float2ObjectMap<Texture>)new Float2ObjectOpenHashMap();
/*     */   
/*     */   private float alpha;
/*     */   
/*     */   private SimpleTexture.TextureImage textureData;
/*     */   private Integer renderWidth;
/*     */   private Integer renderHeight;
/*     */   
/*     */   public SimpleTextureImpl(ResourceLocation location) {
/*  28 */     super(location);
/*  29 */     this.location = location;
/*  30 */     this.textureData = getTextureImage(Minecraft.getInstance().getResourceManager());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getWidth() {
/*     */     try {
/*  38 */       return (this.renderWidth == null) ? this.textureData.getImage().getWidth() : this.renderWidth.intValue();
/*     */     }
/*  40 */     catch (IOException e) {
/*     */       
/*  42 */       throw new RuntimeException(e);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getHeight() {
/*     */     try {
/*  51 */       return (this.renderHeight == null) ? this.textureData.getImage().getHeight() : this.renderHeight.intValue();
/*     */     }
/*  53 */     catch (IOException e) {
/*     */       
/*  55 */       throw new RuntimeException(e);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void setDisplayWidth(int width) {
/*  62 */     this.renderWidth = Integer.valueOf(width);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void setDisplayHeight(int height) {
/*  68 */     this.renderHeight = Integer.valueOf(height);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void resize(float scale) {
/*     */     try {
/*  75 */       NativeImage newImg = ImageUtil.getScaledImage(scale, this.textureData.getImage(), false);
/*  76 */       setNativeImage(newImg);
/*     */     }
/*  78 */     catch (Exception e) {
/*     */       
/*  80 */       throw new RuntimeException(e);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Texture getScaledImage(float drawScale) {
/*  87 */     if (drawScale == 1.0F)
/*     */     {
/*  89 */       return this;
/*     */     }
/*  91 */     Texture scaledTexture = (Texture)this.scaledImageMap.get(drawScale);
/*     */     
/*     */     try {
/*  94 */       if (scaledTexture == null)
/*     */       {
/*  96 */         scaledTexture = new DynamicTextureImpl(ImageUtil.getScaledImage(drawScale, this.textureData.getImage(), false), drawScale);
/*  97 */         this.scaledImageMap.put(drawScale, scaledTexture);
/*     */       }
/*     */     
/* 100 */     } catch (Exception e) {
/*     */       
/* 102 */       throw new RuntimeException(e);
/*     */     } 
/* 104 */     return scaledTexture;
/*     */   }
/*     */ 
/*     */   
/*     */   public Integer getRGB(int x, int y) {
/* 109 */     int rgba = getNativeImage().getPixelRGBA(x, y);
/* 110 */     return Integer.valueOf(RGB.rgbaToRgb(rgba));
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public int getTextureId() {
/* 116 */     return getId();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean hasImage() {
/* 122 */     return (this.textureData != null);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void remove() {
/* 128 */     close();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void setNativeImage(NativeImage image) {
/* 134 */     this.textureData.close();
/* 135 */     this.textureData = updateImage(Minecraft.getInstance().getResourceManager(), image);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void close() {
/* 141 */     if (getNativeImage() != null) {
/*     */       
/* 143 */       this.scaledImageMap.values().forEach(Texture::remove);
/* 144 */       getNativeImage().close();
/* 145 */       this.textureData.close();
/* 146 */       releaseId();
/* 147 */       this.textureData = null;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public NativeImage getNativeImage() {
/*     */     try {
/* 156 */       return this.textureData.getImage();
/*     */     }
/* 158 */     catch (IOException e) {
/*     */       
/* 160 */       throw new RuntimeException(e);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public ResourceLocation getLocation() {
/* 166 */     return this.location;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public float getAlpha() {
/* 172 */     return this.alpha;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void setAlpha(float alpha) {
/* 178 */     this.alpha = alpha;
/*     */   }
/*     */ 
/*     */   
/*     */   private SimpleTexture.TextureImage updateImage(ResourceManager pResourceManager, NativeImage nativeimage) {
/*     */     try {
/*     */       SimpleTexture.TextureImage image;
/* 185 */       Resource resource = pResourceManager.getResource(this.location).get();
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       try {
/* 191 */         TextureMetadataSection texturemetadatasection = null;
/*     */ 
/*     */         
/*     */         try {
/* 195 */           texturemetadatasection = resource.metadata().getSection((MetadataSectionSerializer)TextureMetadataSection.SERIALIZER).orElse(null);
/*     */         }
/* 197 */         catch (RuntimeException runtimeException) {}
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 202 */         image = new SimpleTexture.TextureImage(texturemetadatasection, nativeimage);
/*     */       }
/* 204 */       catch (Throwable throwable1) {
/*     */ 
/*     */         
/* 207 */         throw throwable1;
/*     */       } 
/* 209 */       return image;
/*     */     }
/* 211 */     catch (IOException ioexception) {
/*     */       
/* 213 */       return new SimpleTexture.TextureImage(ioexception);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void release() {
/* 220 */     releaseId();
/*     */   }
/*     */ }


/* Location:              C:\Users\Administrator\Downloads\journeymap-forge-1.21-6.0.0-beta.18.jar!\journeymap\client\texture\SimpleTextureImpl.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */