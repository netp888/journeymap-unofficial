/*    */ package journeymap.client.texture;
/*    */ 
/*    */ import com.mojang.blaze3d.platform.NativeImage;
/*    */ import net.minecraft.resources.ResourceLocation;
/*    */ 
/*    */ 
/*    */ public interface Texture
/*    */ {
/*    */   int getWidth();
/*    */   
/*    */   int getHeight();
/*    */   
/*    */   void setDisplayWidth(int paramInt);
/*    */   
/*    */   void setDisplayHeight(int paramInt);
/*    */   
/*    */   Texture getScaledImage(float paramFloat);
/*    */   
/*    */   int getTextureId();
/*    */   
/*    */   boolean hasImage();
/*    */   
/*    */   void remove();
/*    */   
/*    */   void setNativeImage(NativeImage paramNativeImage);
/*    */   
/*    */   default void setNativeImage(NativeImage image, boolean retainImage) {
/* 28 */     setNativeImage(image);
/*    */   }
/*    */ 
/*    */   
/*    */   NativeImage getNativeImage();
/*    */   
/*    */   float getAlpha();
/*    */   
/*    */   void setAlpha(float paramFloat);
/*    */   
/*    */   default Integer getRGB(int x, int y) {
/* 39 */     return Integer.valueOf(0);
/*    */   }
/*    */ 
/*    */   
/*    */   default ResourceLocation getLocation() {
/* 44 */     return null;
/*    */   }
/*    */   
/*    */   void release();
/*    */ }


/* Location:              C:\Users\Administrator\Downloads\journeymap-forge-1.21-6.0.0-beta.18.jar!\journeymap\client\texture\Texture.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */