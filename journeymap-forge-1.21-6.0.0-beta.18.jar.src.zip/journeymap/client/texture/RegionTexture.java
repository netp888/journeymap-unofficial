/*     */ package journeymap.client.texture;
/*     */ 
/*     */ import com.google.common.base.MoreObjects;
/*     */ import com.mojang.blaze3d.platform.NativeImage;
/*     */ import java.lang.ref.WeakReference;
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashSet;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Set;
/*     */ import java.util.concurrent.locks.ReentrantLock;
/*     */ import journeymap.client.JourneymapClient;
/*     */ import journeymap.client.cartography.color.RGB;
/*     */ import journeymap.client.log.JMLogger;
/*     */ import journeymap.client.render.RenderWrapper;
/*     */ import journeymap.client.task.main.ExpireTextureTask;
/*     */ import journeymap.common.Journeymap;
/*     */ import net.minecraft.client.renderer.texture.AbstractTexture;
/*     */ import net.minecraft.server.packs.resources.ResourceManager;
/*     */ import net.minecraft.world.level.ChunkPos;
/*     */ 
/*     */ public class RegionTexture
/*     */   extends AbstractTexture
/*     */   implements Texture {
/*  25 */   protected final ReentrantLock bufferLock = new ReentrantLock();
/*  26 */   protected Set<ChunkPos> dirtyChunks = new HashSet<>();
/*  27 */   protected List<WeakReference<Listener>> listeners = new ArrayList<>(0);
/*     */   
/*     */   protected long lastImageUpdate;
/*     */   
/*     */   protected String description;
/*     */   
/*     */   protected boolean bindNeeded;
/*     */   
/*     */   protected long lastBound;
/*     */   protected NativeImage image;
/*     */   protected NativeImage[] mipmaps;
/*     */   protected int width;
/*     */   protected int height;
/*     */   protected final int mipmapLevels;
/*     */   
/*     */   public RegionTexture(NativeImage pixels, String description) {
/*  43 */     this.mipmapLevels = (JourneymapClient.getInstance().getCoreProperties()).mipmapLevels.get().intValue();
/*  44 */     setNativeImage(pixels, true);
/*  45 */     this.description = description;
/*  46 */     this.mipmaps = RegionMipmapGenerator.generateMipmaps(this.image, this.mipmapLevels);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void bind() {
/*  52 */     if (this.bindNeeded)
/*     */     {
/*  54 */       if (this.bufferLock.tryLock()) {
/*     */         
/*     */         try {
/*     */           
/*  58 */           if (this.id == -1)
/*     */           {
/*  60 */             this.id = getId();
/*     */           }
/*     */           
/*  63 */           super.bind();
/*     */           
/*  65 */           if (this.lastBound == 0L || this.dirtyChunks.isEmpty()) {
/*     */             
/*  67 */             if (this.mipmaps == null)
/*     */             {
/*  69 */               this.mipmaps = RegionMipmapGenerator.generateMipmaps(this.image, this.mipmapLevels);
/*     */             }
/*     */             
/*  72 */             RenderWrapper.texParameter(3553, 10241, 9984);
/*  73 */             RenderWrapper.texParameter(3553, 10240, 9728);
/*  74 */             RenderWrapper.texParameter(3553, 10242, 33071);
/*  75 */             RenderWrapper.texParameter(3553, 10243, 33071);
/*     */             
/*  77 */             RenderWrapper.texParameter(3553, 33085, this.mipmapLevels);
/*  78 */             RenderWrapper.texParameter(3553, 33082, 0);
/*  79 */             RenderWrapper.texParameter(3553, 33083, this.mipmapLevels);
/*  80 */             RenderWrapper.texParameter(3553, 34049, 0);
/*     */             int i;
/*  82 */             for (i = 0; i <= this.mipmapLevels; i++)
/*     */             {
/*  84 */               RenderWrapper.texImage2D(3553, i, this.image.format().glFormat(), this.mipmaps[i]
/*  85 */                   .getWidth(), this.mipmaps[i].getHeight(), 0, 6408, 5121, null);
/*     */             }
/*     */ 
/*     */             
/*  89 */             for (i = 0; i <= this.mipmapLevels; i++) {
/*     */               
/*  91 */               NativeImage image = this.mipmaps[i];
/*  92 */               if (image != null && image.pixels != 0L)
/*     */               {
/*  94 */                 image.upload(i, 0, 0, 0, 0, this.mipmaps[i].getWidth(), this.mipmaps[i].getHeight(), false, false, true, false);
/*     */               }
/*     */             } 
/*     */             
/*  98 */             this.bindNeeded = false;
/*  99 */             this.lastBound = System.currentTimeMillis();
/*     */             
/*     */             return;
/*     */           } 
/*     */           
/* 104 */           for (ChunkPos pos : this.dirtyChunks) {
/*     */             
/* 106 */             NativeImage chunkImage = ImageUtil.getSubImage(pos.x, pos.z, 16, 16, this.image, false);
/*     */             
/* 108 */             try { if (chunkImage.pixels != 0L) {
/*     */                 
/* 110 */                 chunkImage.copyRect(this.image, 0, 0, pos.x, pos.z, 16, 16, false, false);
/* 111 */                 chunkImage.upload(0, pos.x, pos.z, 0, 0, 16, 16, true, false);
/*     */               } 
/* 113 */               if (chunkImage != null) chunkImage.close();  } catch (Throwable throwable) { if (chunkImage != null)
/*     */                 try { chunkImage.close(); } catch (Throwable throwable1) { throwable.addSuppressed(throwable1); }   throw throwable; }
/*     */           
/* 116 */           }  RegionMipmapGenerator.updateMipmapsAndUpload(this.mipmaps, this.dirtyChunks);
/*     */           
/*     */           int err;
/* 119 */           while ((err = RenderWrapper.getError()) != 0)
/*     */           {
/* 121 */             JMLogger.logOnce("GL Error in RegionTexture after upload: " + err + " in " + String.valueOf(this));
/*     */           }
/*     */ 
/*     */           
/* 125 */           this.dirtyChunks.clear();
/* 126 */           this.lastBound = System.currentTimeMillis();
/* 127 */           this.bindNeeded = false;
/*     */         }
/* 129 */         catch (Throwable t) {
/*     */           
/* 131 */           Journeymap.getLogger().warn("Can't bind texture: ", t);
/*     */         }
/*     */         finally {
/*     */           
/* 135 */           this.bufferLock.unlock();
/*     */         } 
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public long getLastImageUpdate() {
/* 143 */     return this.lastImageUpdate;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isBound() {
/* 148 */     return (this.id != -1);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isDefunct() {
/* 153 */     return ((this.image == null && this.id == -1) || (this.image != null && this.image.pixels == 0L));
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void setNativeImage(NativeImage image, boolean retainImage) {
/* 159 */     if (image == null) {
/*     */       return;
/*     */     }
/*     */ 
/*     */     
/* 164 */     handleImage(image, retainImage);
/* 165 */     this.lastImageUpdate = System.currentTimeMillis();
/* 166 */     notifyListeners();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Integer getRGB(int x, int y) {
/* 172 */     int rgba = this.image.getPixelRGBA(x, y);
/* 173 */     return Integer.valueOf(RGB.rgbaToRgb(rgba));
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void release() {
/* 179 */     releaseId();
/*     */   }
/*     */ 
/*     */   
/*     */   public void setNativeImage(NativeImage image, boolean retainImage, HashSet<ChunkPos> updatedChunks) {
/* 184 */     if (image == null) {
/*     */       return;
/*     */     }
/*     */ 
/*     */     
/* 189 */     handleImage(image, retainImage);
/* 190 */     this.dirtyChunks.addAll(updatedChunks);
/* 191 */     this.lastImageUpdate = System.currentTimeMillis();
/* 192 */     notifyListeners();
/*     */   }
/*     */ 
/*     */   
/*     */   private void handleImage(NativeImage image, boolean retainImage) {
/* 197 */     this.bindNeeded = true;
/*     */     
/*     */     try {
/* 200 */       this.bufferLock.lock();
/* 201 */       this.width = image.getWidth();
/* 202 */       this.height = image.getHeight();
/* 203 */       if (retainImage)
/*     */       {
/* 205 */         if (this.image == null) {
/*     */           
/* 207 */           this.image = image;
/*     */         }
/* 209 */         else if (image.pixels != this.image.pixels) {
/*     */           
/* 211 */           this.image.copyFrom(image);
/*     */         } 
/*     */       }
/* 214 */       if (image.pixels != this.image.pixels)
/*     */       {
/*     */         
/* 217 */         clearMipmaps();
/* 218 */         image.close();
/*     */       }
/*     */     
/*     */     } finally {
/*     */       
/* 223 */       this.bufferLock.unlock();
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public Set<ChunkPos> getDirtyAreas() {
/* 229 */     return this.dirtyChunks;
/*     */   }
/*     */ 
/*     */   
/*     */   public void addListener(Listener addedListener) {
/* 234 */     Iterator<WeakReference<Listener>> iter = this.listeners.iterator();
/* 235 */     while (iter.hasNext()) {
/*     */       
/* 237 */       WeakReference<Listener> ref = iter.next();
/* 238 */       Listener listener = ref.get();
/* 239 */       if (listener == null) {
/*     */         
/* 241 */         iter.remove();
/*     */         
/*     */         continue;
/*     */       } 
/* 245 */       if (addedListener == listener) {
/*     */         return;
/*     */       }
/*     */     } 
/*     */ 
/*     */     
/* 251 */     this.listeners.add(new WeakReference<>(addedListener));
/*     */   }
/*     */ 
/*     */   
/*     */   protected void notifyListeners() {
/* 256 */     Iterator<WeakReference<Listener>> iter = this.listeners.iterator();
/* 257 */     while (iter.hasNext()) {
/*     */       
/* 259 */       WeakReference<Listener> ref = iter.next();
/* 260 */       Listener<RegionTexture> listener = ref.get();
/* 261 */       if (listener == null) {
/*     */         
/* 263 */         iter.remove();
/*     */         
/*     */         continue;
/*     */       } 
/* 267 */       listener.textureImageUpdated(this);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 275 */     return MoreObjects.toStringHelper(this).add("glid", this.id).add("description", this.description).add("lastImageUpdate", this.lastImageUpdate).toString();
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean bindNeeded() {
/* 280 */     return this.bindNeeded;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public int getWidth() {
/* 286 */     return this.image.getWidth();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public int getHeight() {
/* 292 */     return this.image.getHeight();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setDisplayWidth(int width) {}
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setDisplayHeight(int height) {}
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Texture getScaledImage(float drawScale) {
/* 310 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public int getTextureId() {
/* 316 */     return this.id;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean hasImage() {
/* 322 */     return (this.image != null && this.image.pixels > 0L);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void remove() {
/* 328 */     this.bufferLock.lock();
/*     */ 
/*     */     
/* 331 */     ImageUtil.closeSafely(this.image);
/* 332 */     this.bufferLock.unlock();
/* 333 */     this.bindNeeded = false;
/* 334 */     this.image = null;
/* 335 */     this.lastImageUpdate = 0L;
/* 336 */     this.lastBound = 0L;
/* 337 */     this.id = -1;
/* 338 */     clearMipmaps();
/*     */   }
/*     */ 
/*     */   
/*     */   private void clearMipmaps() {
/* 343 */     if (this.mipmaps != null) {
/*     */       
/* 345 */       for (int i = 1; i <= this.mipmapLevels; i++) {
/*     */         
/* 347 */         if (this.mipmaps[i] != null) {
/*     */           
/* 349 */           ImageUtil.closeSafely(this.mipmaps[i]);
/* 350 */           this.mipmaps[i] = null;
/*     */         } 
/*     */       } 
/* 353 */       this.mipmaps = null;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void close() {
/* 361 */     if (isBound())
/*     */     {
/* 363 */       ExpireTextureTask.queue(this.id);
/*     */     }
/* 365 */     this.image.close();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void setNativeImage(NativeImage image) {
/* 371 */     setNativeImage(image, true);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public NativeImage getNativeImage() {
/* 378 */     return this.image;
/*     */   }
/*     */ 
/*     */   
/*     */   public int getMipmapLevels() {
/* 383 */     return this.mipmapLevels;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public float getAlpha() {
/* 389 */     return 0.0F;
/*     */   }
/*     */   
/*     */   public void setAlpha(float alpha) {}
/*     */   
/*     */   public void load(ResourceManager pResourceManager) {}
/*     */   
/*     */   public static interface Listener<T extends Texture> {
/*     */     void textureImageUpdated(T param1T);
/*     */   }
/*     */ }


/* Location:              C:\Users\Administrator\Downloads\journeymap-forge-1.21-6.0.0-beta.18.jar!\journeymap\client\texture\RegionTexture.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */