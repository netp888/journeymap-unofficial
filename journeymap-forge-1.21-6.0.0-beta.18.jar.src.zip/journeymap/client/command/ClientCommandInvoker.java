/*     */ package journeymap.client.command;
/*     */ 
/*     */ import com.google.common.base.Joiner;
/*     */ import com.mojang.brigadier.exceptions.CommandSyntaxException;
/*     */ import java.util.Arrays;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import journeymap.client.Constants;
/*     */ import journeymap.common.Journeymap;
/*     */ import journeymap.common.log.LogFormatter;
/*     */ import net.minecraft.commands.CommandSource;
/*     */ import net.minecraft.network.chat.Component;
/*     */ import org.apache.logging.log4j.util.Strings;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ClientCommandInvoker
/*     */   implements JMCommand
/*     */ {
/*  25 */   Map<String, JMCommand> commandMap = new HashMap<>();
/*     */ 
/*     */ 
/*     */   
/*     */   public ClientCommandInvoker registerSub(JMCommand command) {
/*  30 */     this.commandMap.put(command.getName().toLowerCase(), command);
/*  31 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String getName() {
/*  37 */     return "jm";
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String getUsage(CommandSource sender) {
/*  43 */     StringBuffer sb = new StringBuffer();
/*  44 */     for (JMCommand command : this.commandMap.values()) {
/*     */       
/*  46 */       String usage = command.getUsage(sender);
/*  47 */       if (!Strings.isEmpty(usage)) {
/*     */         
/*  49 */         if (sb.length() > 0)
/*     */         {
/*  51 */           sb.append("\n");
/*     */         }
/*  53 */         sb.append("/jm ").append(usage);
/*     */       } 
/*     */     } 
/*  56 */     return sb.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int execute(CommandSource sender, String[] args) throws CommandSyntaxException {
/*     */     try {
/*  64 */       if (args.length > 0) {
/*     */         
/*  66 */         JMCommand command = getSubCommand(args);
/*  67 */         if (command != null)
/*     */         {
/*  69 */           String[] subArgs = Arrays.<String>copyOfRange(args, 1, args.length);
/*  70 */           command.execute(sender, subArgs);
/*     */         }
/*     */       
/*     */       } else {
/*     */         
/*  75 */         sender.sendSystemMessage((Component)Constants.getStringTextComponent(getUsage(sender)));
/*     */       }
/*     */     
/*  78 */     } catch (Throwable t) {
/*     */       
/*  80 */       Journeymap.getLogger().error(LogFormatter.toPartialString(t));
/*     */       
/*  82 */       exception("Error in /jm: ", t);
/*     */     } 
/*  84 */     return 0;
/*     */   }
/*     */ 
/*     */   
/*     */   public JMCommand getSubCommand(String[] args) {
/*  89 */     if (args.length > 0) {
/*     */       
/*  91 */       JMCommand command = this.commandMap.get(args[0].toLowerCase());
/*  92 */       if (command != null)
/*     */       {
/*  94 */         return command;
/*     */       }
/*     */     } 
/*  97 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   public String getPossibleCommands() {
/* 102 */     return Joiner.on(",").join(this.commandMap.keySet());
/*     */   }
/*     */ }


/* Location:              C:\Users\Administrator\Downloads\journeymap-forge-1.21-6.0.0-beta.18.jar!\journeymap\client\command\ClientCommandInvoker.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */