/*    */ package journeymap.client.command;
/*    */ 
/*    */ import com.mojang.brigadier.exceptions.CommandSyntaxException;
/*    */ import journeymap.client.Constants;
/*    */ import journeymap.client.waypoint.WaypointHandler;
/*    */ import net.minecraft.commands.CommandSource;
/*    */ import net.minecraft.network.chat.Component;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class CmdReloadWaypoint
/*    */   implements JMCommand
/*    */ {
/*    */   public String getName() {
/* 22 */     return "wpreload";
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public int execute(CommandSource sender, String[] args) throws CommandSyntaxException {
/* 28 */     WaypointHandler.getInstance().reset();
/* 29 */     String feedBack = Constants.getString("jm.common.chat_announcement", new Object[] { Constants.getString("jm.waypoint.command.reloaded") });
/* 30 */     sender.sendSystemMessage((Component)Component.translatable(feedBack));
/* 31 */     return 0;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public String getUsage(CommandSource sender) {
/* 38 */     return null;
/*    */   }
/*    */ }


/* Location:              C:\Users\Administrator\Downloads\journeymap-forge-1.21-6.0.0-beta.18.jar!\journeymap\client\command\CmdReloadWaypoint.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */