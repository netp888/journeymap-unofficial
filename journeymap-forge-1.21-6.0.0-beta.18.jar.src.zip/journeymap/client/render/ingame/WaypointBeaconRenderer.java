/*     */ package journeymap.client.render.ingame;
/*     */ 
/*     */ import com.mojang.blaze3d.vertex.PoseStack;
/*     */ import com.mojang.blaze3d.vertex.VertexConsumer;
/*     */ import com.mojang.math.Axis;
/*     */ import java.util.Collection;
/*     */ import journeymap.client.JourneymapClient;
/*     */ import journeymap.client.render.JMRenderTypes;
/*     */ import journeymap.client.render.draw.DrawStep;
/*     */ import journeymap.client.render.draw.DrawUtil;
/*     */ import journeymap.client.waypoint.ClientWaypointImpl;
/*     */ import journeymap.common.Journeymap;
/*     */ import journeymap.common.waypoint.WaypointStore;
/*     */ import net.minecraft.client.renderer.MultiBufferSource;
/*     */ import net.minecraft.util.Mth;
/*     */ import net.minecraft.world.phys.Vec3;
/*     */ 
/*     */ 
/*     */ 
/*     */ public class WaypointBeaconRenderer
/*     */   extends WaypointRenderer
/*     */ {
/*     */   public void render(PoseStack poseStack) {
/*  24 */     this.waypointProperties = JourneymapClient.getInstance().getWaypointProperties();
/*  25 */     String playerDim = this.minecraft.player.getCommandSenderWorld().dimension().location().toString();
/*  26 */     MultiBufferSource.BufferSource buffers = this.minecraft.renderBuffers().bufferSource();
/*  27 */     Collection<ClientWaypointImpl> waypoints = WaypointStore.getInstance().getAll();
/*     */     
/*  29 */     for (ClientWaypointImpl waypoint : waypoints) {
/*     */       
/*  31 */       if (canDrawWaypoint(waypoint, playerDim) && (
/*  32 */         !this.waypointProperties.shaderBeacon.get().booleanValue() || this.waypointProperties.showRotatingBeam
/*  33 */         .get().booleanValue() || this.waypointProperties.showStaticBeam
/*  34 */         .get().booleanValue())) {
/*     */         
/*     */         try {
/*     */           
/*  38 */           renderWaypoint(waypoint, poseStack, DrawStep.Pass.PreObject, (MultiBufferSource)buffers);
/*     */         }
/*  40 */         catch (Exception t) {
/*     */           
/*  42 */           Journeymap.getLogger().error("Waypoint beacon failed to render for " + waypoint.getName() + ": ", t);
/*     */         } 
/*     */       }
/*     */     } 
/*  46 */     buffers.endBatch();
/*     */   }
/*     */ 
/*     */   
/*     */   protected void render(PoseStack poseStack, DrawStep.Pass pass, MultiBufferSource buffers, ClientWaypointImpl waypoint, float partialTicks, long gameTime, float[] rgba, float fadeAlpha, double shiftX, double shiftY, double shiftZ, Vec3 playerVec, Vec3 waypointVec, double viewDistance, double actualDistance, double scale) {
/*  51 */     boolean showStaticInnerBeam = this.waypointProperties.showStaticBeam.get().booleanValue();
/*  52 */     boolean showRotatingOuterBeam = this.waypointProperties.showRotatingBeam.get().booleanValue();
/*     */     
/*  54 */     if (!showStaticInnerBeam && !showRotatingOuterBeam) {
/*     */       return;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*  60 */     poseStack.pushPose();
/*  61 */     poseStack.translate(shiftX, -180.0D, shiftZ);
/*  62 */     renderBeamSegment(poseStack, buffers, partialTicks, gameTime, 1, 360, rgba, 0.2F, 0.25F, showStaticInnerBeam, showRotatingOuterBeam);
/*  63 */     poseStack.popPose();
/*     */   }
/*     */ 
/*     */   
/*     */   public void renderBeamSegment(PoseStack poseStack, MultiBufferSource buffer, float partialTicks, long gameTime, int yOffset, int height, float[] colors, float beamRadius, float glowRadius, boolean showStaticInnerBeam, boolean showRotatingOuterBeam) {
/*  68 */     float texScale = 1.0F;
/*  69 */     int heightOffset = yOffset + height;
/*  70 */     float rotation = (float)Math.floorMod(gameTime, 40L) + partialTicks;
/*  71 */     float texOffset = -((float)-gameTime * 0.2F - Mth.floor((float)-gameTime * 0.1F)) * 0.6F;
/*     */     
/*  73 */     float red = colors[0];
/*  74 */     float blue = colors[1];
/*  75 */     float green = colors[2];
/*  76 */     float alpha = colors[3];
/*  77 */     VertexConsumer beamBuffer = buffer.getBuffer(JMRenderTypes.BEAM_RENDER_TYPE);
/*  78 */     poseStack.pushPose();
/*     */     
/*  80 */     if (!showStaticInnerBeam)
/*     */     {
/*  82 */       poseStack.mulPose(Axis.YP.rotationDegrees(rotation * 2.25F - 45.0F));
/*     */     }
/*  84 */     float V2 = -1.0F + texOffset;
/*  85 */     float innerV1 = height * texScale * 0.5F / beamRadius + V2;
/*     */     
/*  87 */     renderPart(poseStack, beamBuffer, red, blue, green, alpha, yOffset, heightOffset, 0.0F, beamRadius, beamRadius, 0.0F, -beamRadius, 0.0F, 0.0F, -beamRadius, 0.0F, 1.0F, innerV1, V2);
/*  88 */     poseStack.popPose();
/*  89 */     float outerV1 = height * texScale + V2;
/*     */     
/*  91 */     poseStack.pushPose();
/*     */     
/*  93 */     if (showRotatingOuterBeam)
/*     */     {
/*  95 */       poseStack.mulPose(Axis.YP.rotationDegrees(rotation * 2.25F - 45.0F));
/*     */     }
/*  97 */     renderPart(poseStack, beamBuffer, red, blue, green, alpha, yOffset, heightOffset, -glowRadius, -glowRadius, glowRadius, -glowRadius, -glowRadius, glowRadius, glowRadius, glowRadius, 0.0F, 1.0F, outerV1, V2);
/*  98 */     poseStack.popPose();
/*     */   }
/*     */ 
/*     */   
/*     */   private static void renderPart(PoseStack poseStack, VertexConsumer buffer, float red, float green, float blue, float alpha, int yMin, int yMax, float p1, float p2, float p3, float p4, float p5, float p6, float p7, float p8, float u1, float u2, float v1, float v2) {
/* 103 */     addQuad(poseStack, buffer, red, green, blue, alpha, yMin, yMax, p1, p2, p3, p4, u1, u2, v1, v2);
/* 104 */     addQuad(poseStack, buffer, red, green, blue, alpha, yMin, yMax, p7, p8, p5, p6, u1, u2, v1, v2);
/* 105 */     addQuad(poseStack, buffer, red, green, blue, alpha, yMin, yMax, p3, p4, p7, p8, u1, u2, v1, v2);
/* 106 */     addQuad(poseStack, buffer, red, green, blue, alpha, yMin, yMax, p5, p6, p1, p2, u1, u2, v1, v2);
/*     */   }
/*     */ 
/*     */   
/*     */   private static void addQuad(PoseStack poseStack, VertexConsumer bufferIn, float red, float green, float blue, float alpha, int yMin, int yMax, float x1, float z1, float x2, float z2, float u1, float u2, float v1, float v2) {
/* 111 */     DrawUtil.addVertexUV(poseStack, bufferIn, red, green, blue, alpha, yMax, x1, z1, u2, v1);
/* 112 */     DrawUtil.addVertexUV(poseStack, bufferIn, red, green, blue, alpha, yMin, x1, z1, u2, v2);
/* 113 */     DrawUtil.addVertexUV(poseStack, bufferIn, red, green, blue, alpha, yMin, x2, z2, u1, v2);
/* 114 */     DrawUtil.addVertexUV(poseStack, bufferIn, red, green, blue, alpha, yMax, x2, z2, u1, v1);
/*     */   }
/*     */ }


/* Location:              C:\Users\Administrator\Downloads\journeymap-forge-1.21-6.0.0-beta.18.jar!\journeymap\client\render\ingame\WaypointBeaconRenderer.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */