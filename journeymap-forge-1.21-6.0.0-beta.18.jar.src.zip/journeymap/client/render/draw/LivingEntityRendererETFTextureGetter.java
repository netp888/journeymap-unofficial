package journeymap.client.render.draw;

import net.minecraft.resources.ResourceLocation;

public interface LivingEntityRendererETFTextureGetter<T extends net.minecraft.world.entity.LivingEntity> {
  ResourceLocation getETFTextureLocation(T paramT);
}


/* Location:              C:\Users\Administrator\Downloads\journeymap-forge-1.21-6.0.0-beta.18.jar!\journeymap\client\render\draw\LivingEntityRendererETFTextureGetter.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */