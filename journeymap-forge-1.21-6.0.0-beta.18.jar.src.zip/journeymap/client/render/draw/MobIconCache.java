/*      */ package journeymap.client.render.draw;
/*      */ 
/*      */ import com.google.common.collect.ImmutableList;
/*      */ import com.mojang.blaze3d.platform.NativeImage;
/*      */ import com.mojang.blaze3d.vertex.PoseStack;
/*      */ import java.io.File;
/*      */ import java.io.FilenameFilter;
/*      */ import java.util.ArrayList;
/*      */ import java.util.HashMap;
/*      */ import java.util.List;
/*      */ import java.util.Map;
/*      */ import java.util.Set;
/*      */ import journeymap.api.services.Services;
/*      */ import journeymap.client.JourneymapClient;
/*      */ import journeymap.client.cartography.color.RGB;
/*      */ import journeymap.client.io.FileHandler;
/*      */ import journeymap.client.model.EntityDTO;
/*      */ import journeymap.client.texture.DynamicTextureImpl;
/*      */ import journeymap.client.texture.ImageUtil;
/*      */ import journeymap.client.texture.Texture;
/*      */ import journeymap.client.texture.TextureCache;
/*      */ import journeymap.common.Journeymap;
/*      */ import journeymap.common.log.LogFormatter;
/*      */ import journeymap.common.mixin.client.ModelPartMixin;
/*      */ import net.minecraft.client.Minecraft;
/*      */ import net.minecraft.client.model.geom.ModelPart;
/*      */ import net.minecraft.client.model.geom.PartPose;
/*      */ import net.minecraft.client.renderer.entity.EntityRenderer;
/*      */ import net.minecraft.client.renderer.entity.LivingEntityRenderer;
/*      */ import net.minecraft.resources.ResourceLocation;
/*      */ import net.minecraft.server.packs.resources.PreparableReloadListener;
/*      */ import net.minecraft.server.packs.resources.ReloadableResourceManager;
/*      */ import net.minecraft.server.packs.resources.Resource;
/*      */ import net.minecraft.server.packs.resources.ResourceManager;
/*      */ import net.minecraft.world.entity.Entity;
/*      */ import net.minecraft.world.entity.LivingEntity;
/*      */ import org.joml.Vector2f;
/*      */ import org.joml.Vector3f;
/*      */ import org.joml.Vector3fc;
/*      */ import org.joml.Vector4f;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class MobIconCache
/*      */ {
/*      */   private static final String MOB_ICON_FILE_SUFFIX = ".png";
/*      */   private static final String OUTLINED_SUFFIX = "_outlined";
/*   78 */   private static HashMap<ResourceLocation, IconTexture> mobsIcons = null;
/*      */   private static boolean listenerRegistered = false;
/*   80 */   private static NativeImage markerMask = null;
/*      */ 
/*      */ 
/*      */   
/*      */   public static Texture getMobIcon(EntityDTO dto, boolean outlined) {
/*   85 */     ensureMobIconsLoaded();
/*      */     
/*   87 */     ResourceLocation mobLocation = dto.entityTypeLocation;
/*   88 */     addIconIfMissing(dto, mobLocation);
/*      */     
/*   90 */     if (((JourneymapClient.getInstance().getCoreProperties()).legacyIcons.get().booleanValue() || dto.hasCustomIcon) && dto.entityIconLocation != null) {
/*      */       
/*      */       try {
/*      */         
/*   94 */         Texture tex = TextureCache.getTexture(dto.entityIconLocation);
/*   95 */         if (tex != null && tex.hasImage())
/*      */         {
/*   97 */           return tex;
/*      */         }
/*      */       }
/*  100 */       catch (Exception exception) {}
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*  105 */     IconTexture icon = mobsIcons.get(mobLocation);
/*  106 */     if (icon == null)
/*      */     {
/*  108 */       return null;
/*      */     }
/*  110 */     if (outlined)
/*      */     {
/*  112 */       return icon.outlined;
/*      */     }
/*      */ 
/*      */     
/*  116 */     return icon.solid;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static void ensureMobIconsLoaded() {
/*  123 */     if (mobsIcons == null) {
/*      */       
/*  125 */       mobsIcons = new HashMap<>();
/*  126 */       markerMask = TextureCache.getTexture(TextureCache.MobIconMask).getNativeImage();
/*      */       
/*  128 */       ResourceManager resourceManager = Minecraft.getInstance().getResourceManager();
/*      */ 
/*      */       
/*  131 */       Set<Map.Entry<ResourceLocation, List<Resource>>> resourceStacks = resourceManager.listResourceStacks("icon/entity", loc -> (loc.getPath().endsWith(".png") && loc.getNamespace().equals("journeymap"))).entrySet();
/*  132 */       for (Map.Entry<ResourceLocation, List<Resource>> resources : resourceStacks) {
/*      */         
/*  134 */         Map<ResourceLocation, IconTexture> map = new HashMap<>();
/*  135 */         for (Resource resource : resources.getValue()) {
/*      */ 
/*      */           
/*      */           try {
/*  139 */             NativeImage icon = FileHandler.getImageFromStream(resource.open());
/*  140 */             String[] path = ((ResourceLocation)resources.getKey()).getPath().split("/");
/*  141 */             if (path.length == 4)
/*      */             {
/*  143 */               String mobName = path[3];
/*  144 */               boolean outlined = mobName.endsWith("_outlined.png");
/*  145 */               if (outlined) {
/*      */                 
/*  147 */                 mobName = mobName.replaceAll("_outlined.png", "");
/*      */               }
/*      */               else {
/*      */                 
/*  151 */                 mobName = mobName.replaceAll(".png", "");
/*      */               } 
/*  153 */               ResourceLocation mobLoc = ResourceLocation.fromNamespaceAndPath(path[2], mobName);
/*  154 */               if (!mobsIcons.containsKey(mobLoc))
/*      */               {
/*  156 */                 addIcon(map, mobLoc, icon, outlined);
/*      */               }
/*      */             }
/*      */           
/*  160 */           } catch (Throwable t) {
/*      */             
/*  162 */             Journeymap.getLogger().error("Could not load Mob icon: " + LogFormatter.toString(t));
/*      */           } 
/*      */         } 
/*  165 */         addMissingSolidOrOutlined(map);
/*  166 */         mobsIcons.putAll(map);
/*      */       } 
/*      */       
/*  169 */       File[] domainsDirs = FileHandler.getMobIconsDomainsDirectories();
/*  170 */       Map<ResourceLocation, IconTexture> icons = new HashMap<>();
/*  171 */       for (File domainDir : domainsDirs) {
/*      */         
/*  173 */         File[] mobsFiles = domainDir.listFiles(new FilenameFilter()
/*      */             {
/*      */               
/*      */               public boolean accept(File dir, String name)
/*      */               {
/*  178 */                 return name.endsWith(".png");
/*      */               }
/*      */             });
/*      */         
/*  182 */         if (mobsFiles != null)
/*      */         {
/*  184 */           for (File mobFile : mobsFiles) {
/*      */ 
/*      */             
/*      */             try {
/*  188 */               String mobName = mobFile.getName();
/*  189 */               boolean outlined = mobName.endsWith("_outlined.png");
/*  190 */               if (outlined) {
/*      */                 
/*  192 */                 mobName = mobName.replaceAll("_outlined.png", "");
/*      */               }
/*      */               else {
/*      */                 
/*  196 */                 mobName = mobName.replaceAll(".png", "");
/*      */               } 
/*  198 */               NativeImage icon = FileHandler.getImageFromFile(mobFile);
/*  199 */               ResourceLocation mobLoc = ResourceLocation.fromNamespaceAndPath(domainDir.getName(), mobName);
/*  200 */               if (!mobsIcons.containsKey(mobLoc))
/*      */               {
/*  202 */                 addIcon(icons, mobLoc, icon, outlined);
/*      */               }
/*      */             }
/*  205 */             catch (Throwable t) {
/*      */               
/*  207 */               Journeymap.getLogger().error("Could not load Mob icon: " + LogFormatter.toString(t));
/*      */             } 
/*      */           } 
/*      */         }
/*      */       } 
/*  212 */       addMissingSolidOrOutlined(icons);
/*  213 */       mobsIcons.putAll(icons);
/*      */       
/*  215 */       if (!listenerRegistered) {
/*      */         
/*  217 */         listenerRegistered = true;
/*  218 */         ((ReloadableResourceManager)resourceManager).registerReloadListener((PreparableReloadListener)(rm -> clearCache()));
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static void clearCache() {
/*  227 */     if (mobsIcons != null && !mobsIcons.isEmpty())
/*      */     {
/*  229 */       mobsIcons.values().forEach(tex -> {
/*      */             if (tex != null) {
/*      */               tex.remove();
/*      */             }
/*      */           });
/*      */     }
/*      */     
/*  236 */     mobsIcons = null;
/*      */   }
/*      */ 
/*      */   
/*      */   private static void addIcon(Map<ResourceLocation, IconTexture> icons, ResourceLocation mob, NativeImage icon, boolean outlined) {
/*  241 */     IconTexture iconTexture = icons.computeIfAbsent(mob, m -> new IconTexture());
/*  242 */     DynamicTextureImpl dynamicTextureImpl = new DynamicTextureImpl(icon);
/*  243 */     if (outlined) {
/*      */       
/*  245 */       iconTexture.outlined = (Texture)dynamicTextureImpl;
/*      */     }
/*      */     else {
/*      */       
/*  249 */       iconTexture.solid = (Texture)dynamicTextureImpl;
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   private static void addMissingSolidOrOutlined(Map<ResourceLocation, IconTexture> icons) {
/*  255 */     for (IconTexture icon : icons.values()) {
/*      */       
/*  257 */       if (icon.solid == null) {
/*      */         
/*  259 */         icon.solid = icon.outlined; continue;
/*      */       } 
/*  261 */       if (icon.outlined == null)
/*      */       {
/*  263 */         icon.outlined = icon.solid;
/*      */       }
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static void addIconIfMissing(EntityDTO dto, ResourceLocation mobLocation) {
/*      */     // Byte code:
/*      */     //   0: getstatic journeymap/client/render/draw/MobIconCache.mobsIcons : Ljava/util/HashMap;
/*      */     //   3: aload_1
/*      */     //   4: invokevirtual containsKey : (Ljava/lang/Object;)Z
/*      */     //   7: ifne -> 1423
/*      */     //   10: aconst_null
/*      */     //   11: astore_2
/*      */     //   12: aload_0
/*      */     //   13: invokevirtual getEntityRef : ()Ljava/lang/ref/WeakReference;
/*      */     //   16: invokevirtual get : ()Ljava/lang/Object;
/*      */     //   19: checkcast net/minecraft/world/entity/Entity
/*      */     //   22: astore_3
/*      */     //   23: aload_3
/*      */     //   24: ifnull -> 1214
/*      */     //   27: invokestatic getInstance : ()Lnet/minecraft/client/Minecraft;
/*      */     //   30: invokevirtual getEntityRenderDispatcher : ()Lnet/minecraft/client/renderer/entity/EntityRenderDispatcher;
/*      */     //   33: astore #4
/*      */     //   35: aload #4
/*      */     //   37: aload_3
/*      */     //   38: invokevirtual getRenderer : (Lnet/minecraft/world/entity/Entity;)Lnet/minecraft/client/renderer/entity/EntityRenderer;
/*      */     //   41: astore #5
/*      */     //   43: aload #4
/*      */     //   45: aload_3
/*      */     //   46: invokevirtual getRenderer : (Lnet/minecraft/world/entity/Entity;)Lnet/minecraft/client/renderer/entity/EntityRenderer;
/*      */     //   49: aload_3
/*      */     //   50: invokestatic getTextureLocation : (Lnet/minecraft/client/renderer/entity/EntityRenderer;Lnet/minecraft/world/entity/Entity;)Lnet/minecraft/resources/ResourceLocation;
/*      */     //   53: astore #6
/*      */     //   55: aload #6
/*      */     //   57: invokestatic getTexture : (Lnet/minecraft/resources/ResourceLocation;)Ljourneymap/client/texture/Texture;
/*      */     //   60: astore #7
/*      */     //   62: aload #7
/*      */     //   64: ifnull -> 77
/*      */     //   67: aload #7
/*      */     //   69: invokeinterface hasImage : ()Z
/*      */     //   74: ifne -> 87
/*      */     //   77: getstatic journeymap/client/render/draw/MobIconCache.mobsIcons : Ljava/util/HashMap;
/*      */     //   80: aload_1
/*      */     //   81: aconst_null
/*      */     //   82: invokevirtual put : (Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
/*      */     //   85: pop
/*      */     //   86: return
/*      */     //   87: aload #7
/*      */     //   89: invokeinterface getNativeImage : ()Lcom/mojang/blaze3d/platform/NativeImage;
/*      */     //   94: astore #8
/*      */     //   96: aload #5
/*      */     //   98: instanceof net/minecraft/client/renderer/entity/PufferfishRenderer
/*      */     //   101: ifeq -> 168
/*      */     //   104: aload #5
/*      */     //   106: checkcast net/minecraft/client/renderer/entity/PufferfishRenderer
/*      */     //   109: astore #9
/*      */     //   111: aload #9
/*      */     //   113: checkcast journeymap/common/mixin/client/PufferfishRendererMixin
/*      */     //   116: invokeinterface getBigModel : ()Lnet/minecraft/client/model/EntityModel;
/*      */     //   121: astore #13
/*      */     //   123: aload #13
/*      */     //   125: instanceof net/minecraft/client/model/PufferfishBigModel
/*      */     //   128: ifeq -> 165
/*      */     //   131: aload #13
/*      */     //   133: checkcast net/minecraft/client/model/PufferfishBigModel
/*      */     //   136: astore #14
/*      */     //   138: aload #14
/*      */     //   140: ldc_w 'body'
/*      */     //   143: invokevirtual getAnyDescendantWithName : (Ljava/lang/String;)Ljava/util/Optional;
/*      */     //   146: aconst_null
/*      */     //   147: invokevirtual orElse : (Ljava/lang/Object;)Ljava/lang/Object;
/*      */     //   150: checkcast net/minecraft/client/model/geom/ModelPart
/*      */     //   153: astore #15
/*      */     //   155: aload #15
/*      */     //   157: aload #8
/*      */     //   159: aload_1
/*      */     //   160: iconst_0
/*      */     //   161: invokestatic getIconFromHead : (Lnet/minecraft/client/model/geom/ModelPart;Lcom/mojang/blaze3d/platform/NativeImage;Lnet/minecraft/resources/ResourceLocation;Z)Lcom/mojang/blaze3d/platform/NativeImage;
/*      */     //   164: astore_2
/*      */     //   165: goto -> 1214
/*      */     //   168: aload #5
/*      */     //   170: instanceof net/minecraft/client/renderer/entity/TropicalFishRenderer
/*      */     //   173: ifeq -> 317
/*      */     //   176: aload #5
/*      */     //   178: checkcast net/minecraft/client/renderer/entity/TropicalFishRenderer
/*      */     //   181: astore #10
/*      */     //   183: aload_3
/*      */     //   184: instanceof net/minecraft/world/entity/animal/TropicalFish
/*      */     //   187: ifeq -> 314
/*      */     //   190: aload_3
/*      */     //   191: checkcast net/minecraft/world/entity/animal/TropicalFish
/*      */     //   194: astore #13
/*      */     //   196: aload #13
/*      */     //   198: invokevirtual getVariant : ()Lnet/minecraft/world/entity/animal/TropicalFish$Pattern;
/*      */     //   201: invokevirtual base : ()Lnet/minecraft/world/entity/animal/TropicalFish$Base;
/*      */     //   204: getstatic net/minecraft/world/entity/animal/TropicalFish$Base.SMALL : Lnet/minecraft/world/entity/animal/TropicalFish$Base;
/*      */     //   207: if_acmpne -> 244
/*      */     //   210: aload #10
/*      */     //   212: checkcast journeymap/common/mixin/client/TropicalFishRendererMixin
/*      */     //   215: invokeinterface getModelA : ()Lnet/minecraft/client/model/ColorableHierarchicalModel;
/*      */     //   220: astore #14
/*      */     //   222: aload #8
/*      */     //   224: ldc_w 'textures/entity/fish/tropical_a_pattern_1.png'
/*      */     //   227: invokestatic parse : (Ljava/lang/String;)Lnet/minecraft/resources/ResourceLocation;
/*      */     //   230: ldc_w 16711680
/*      */     //   233: ldc_w 16777215
/*      */     //   236: invokestatic mergeImages : (Lcom/mojang/blaze3d/platform/NativeImage;Lnet/minecraft/resources/ResourceLocation;II)Lcom/mojang/blaze3d/platform/NativeImage;
/*      */     //   239: astore #15
/*      */     //   241: goto -> 275
/*      */     //   244: aload #10
/*      */     //   246: checkcast journeymap/common/mixin/client/TropicalFishRendererMixin
/*      */     //   249: invokeinterface getModelB : ()Lnet/minecraft/client/model/ColorableHierarchicalModel;
/*      */     //   254: astore #14
/*      */     //   256: aload #8
/*      */     //   258: ldc_w 'textures/entity/fish/tropical_b_pattern_4.png'
/*      */     //   261: invokestatic parse : (Ljava/lang/String;)Lnet/minecraft/resources/ResourceLocation;
/*      */     //   264: ldc_w 8991416
/*      */     //   267: ldc_w 16701501
/*      */     //   270: invokestatic mergeImages : (Lcom/mojang/blaze3d/platform/NativeImage;Lnet/minecraft/resources/ResourceLocation;II)Lcom/mojang/blaze3d/platform/NativeImage;
/*      */     //   273: astore #15
/*      */     //   275: aload #14
/*      */     //   277: ldc_w 'root'
/*      */     //   280: invokevirtual getAnyDescendantWithName : (Ljava/lang/String;)Ljava/util/Optional;
/*      */     //   283: aconst_null
/*      */     //   284: invokevirtual orElse : (Ljava/lang/Object;)Ljava/lang/Object;
/*      */     //   287: checkcast net/minecraft/client/model/geom/ModelPart
/*      */     //   290: astore #16
/*      */     //   292: aload #16
/*      */     //   294: aload #15
/*      */     //   296: aload_1
/*      */     //   297: iconst_1
/*      */     //   298: invokestatic getIconFromHead : (Lnet/minecraft/client/model/geom/ModelPart;Lcom/mojang/blaze3d/platform/NativeImage;Lnet/minecraft/resources/ResourceLocation;Z)Lcom/mojang/blaze3d/platform/NativeImage;
/*      */     //   301: astore_2
/*      */     //   302: aload #15
/*      */     //   304: aload #8
/*      */     //   306: if_acmpeq -> 314
/*      */     //   309: aload #15
/*      */     //   311: invokevirtual close : ()V
/*      */     //   314: goto -> 1214
/*      */     //   317: aload #5
/*      */     //   319: instanceof net/minecraft/client/renderer/entity/LivingEntityRenderer
/*      */     //   322: ifeq -> 1165
/*      */     //   325: aload #5
/*      */     //   327: checkcast net/minecraft/client/renderer/entity/LivingEntityRenderer
/*      */     //   330: astore #11
/*      */     //   332: aload #11
/*      */     //   334: invokevirtual getModel : ()Lnet/minecraft/client/model/EntityModel;
/*      */     //   337: instanceof net/minecraft/client/model/VillagerHeadModel
/*      */     //   340: ifeq -> 543
/*      */     //   343: aload #11
/*      */     //   345: invokevirtual getModel : ()Lnet/minecraft/client/model/EntityModel;
/*      */     //   348: astore #22
/*      */     //   350: aload #22
/*      */     //   352: instanceof net/minecraft/client/model/HeadedModel
/*      */     //   355: ifeq -> 543
/*      */     //   358: aload #22
/*      */     //   360: checkcast net/minecraft/client/model/HeadedModel
/*      */     //   363: astore #13
/*      */     //   365: aload_3
/*      */     //   366: instanceof net/minecraft/world/entity/npc/VillagerDataHolder
/*      */     //   369: ifeq -> 502
/*      */     //   372: aload_3
/*      */     //   373: checkcast net/minecraft/world/entity/npc/VillagerDataHolder
/*      */     //   376: astore #22
/*      */     //   378: aload_3
/*      */     //   379: instanceof net/minecraft/world/entity/npc/Villager
/*      */     //   382: ifeq -> 393
/*      */     //   385: ldc_w 'villager'
/*      */     //   388: astore #23
/*      */     //   390: goto -> 411
/*      */     //   393: aload_3
/*      */     //   394: instanceof net/minecraft/world/entity/monster/ZombieVillager
/*      */     //   397: ifeq -> 408
/*      */     //   400: ldc_w 'zombie_villager'
/*      */     //   403: astore #23
/*      */     //   405: goto -> 411
/*      */     //   408: aconst_null
/*      */     //   409: astore #23
/*      */     //   411: aload #23
/*      */     //   413: ifnull -> 502
/*      */     //   416: aload #22
/*      */     //   418: invokeinterface getVillagerData : ()Lnet/minecraft/world/entity/npc/VillagerData;
/*      */     //   423: astore #24
/*      */     //   425: aload #24
/*      */     //   427: invokevirtual getProfession : ()Lnet/minecraft/world/entity/npc/VillagerProfession;
/*      */     //   430: astore #25
/*      */     //   432: aload #25
/*      */     //   434: getstatic net/minecraft/world/entity/npc/VillagerProfession.NONE : Lnet/minecraft/world/entity/npc/VillagerProfession;
/*      */     //   437: if_acmpeq -> 502
/*      */     //   440: getstatic net/minecraft/core/registries/BuiltInRegistries.VILLAGER_PROFESSION : Lnet/minecraft/core/DefaultedRegistry;
/*      */     //   443: aload #25
/*      */     //   445: invokeinterface getKey : (Ljava/lang/Object;)Lnet/minecraft/resources/ResourceLocation;
/*      */     //   450: astore #26
/*      */     //   452: aload #26
/*      */     //   454: aload #23
/*      */     //   456: <illegal opcode> apply : (Ljava/lang/String;)Ljava/util/function/UnaryOperator;
/*      */     //   461: invokevirtual withPath : (Ljava/util/function/UnaryOperator;)Lnet/minecraft/resources/ResourceLocation;
/*      */     //   464: astore #27
/*      */     //   466: aload #8
/*      */     //   468: aload #27
/*      */     //   470: invokestatic mergeImages : (Lcom/mojang/blaze3d/platform/NativeImage;Lnet/minecraft/resources/ResourceLocation;)Lcom/mojang/blaze3d/platform/NativeImage;
/*      */     //   473: astore #28
/*      */     //   475: aload #13
/*      */     //   477: invokeinterface getHead : ()Lnet/minecraft/client/model/geom/ModelPart;
/*      */     //   482: aload #28
/*      */     //   484: aload_1
/*      */     //   485: iconst_0
/*      */     //   486: invokestatic getIconFromHead : (Lnet/minecraft/client/model/geom/ModelPart;Lcom/mojang/blaze3d/platform/NativeImage;Lnet/minecraft/resources/ResourceLocation;Z)Lcom/mojang/blaze3d/platform/NativeImage;
/*      */     //   489: astore_2
/*      */     //   490: aload #28
/*      */     //   492: aload #8
/*      */     //   494: if_acmpeq -> 502
/*      */     //   497: aload #28
/*      */     //   499: invokevirtual close : ()V
/*      */     //   502: aload_2
/*      */     //   503: ifnonnull -> 521
/*      */     //   506: aload #13
/*      */     //   508: invokeinterface getHead : ()Lnet/minecraft/client/model/geom/ModelPart;
/*      */     //   513: aload #8
/*      */     //   515: aload_1
/*      */     //   516: iconst_0
/*      */     //   517: invokestatic getIconFromHead : (Lnet/minecraft/client/model/geom/ModelPart;Lcom/mojang/blaze3d/platform/NativeImage;Lnet/minecraft/resources/ResourceLocation;Z)Lcom/mojang/blaze3d/platform/NativeImage;
/*      */     //   520: astore_2
/*      */     //   521: aload_2
/*      */     //   522: ifnonnull -> 1162
/*      */     //   525: aload #13
/*      */     //   527: invokeinterface getHead : ()Lnet/minecraft/client/model/geom/ModelPart;
/*      */     //   532: aload #8
/*      */     //   534: aload_1
/*      */     //   535: iconst_1
/*      */     //   536: invokestatic getIconFromHead : (Lnet/minecraft/client/model/geom/ModelPart;Lcom/mojang/blaze3d/platform/NativeImage;Lnet/minecraft/resources/ResourceLocation;Z)Lcom/mojang/blaze3d/platform/NativeImage;
/*      */     //   539: astore_2
/*      */     //   540: goto -> 1162
/*      */     //   543: aload #11
/*      */     //   545: invokevirtual getModel : ()Lnet/minecraft/client/model/EntityModel;
/*      */     //   548: astore #22
/*      */     //   550: aload #22
/*      */     //   552: instanceof net/minecraft/client/model/HumanoidModel
/*      */     //   555: ifeq -> 589
/*      */     //   558: aload #22
/*      */     //   560: checkcast net/minecraft/client/model/HumanoidModel
/*      */     //   563: astore #14
/*      */     //   565: aload #14
/*      */     //   567: getfield head : Lnet/minecraft/client/model/geom/ModelPart;
/*      */     //   570: aload #14
/*      */     //   572: getfield hat : Lnet/minecraft/client/model/geom/ModelPart;
/*      */     //   575: invokestatic of : (Ljava/lang/Object;Ljava/lang/Object;)Lcom/google/common/collect/ImmutableList;
/*      */     //   578: aload #8
/*      */     //   580: aload_1
/*      */     //   581: iconst_0
/*      */     //   582: invokestatic getIconFromHead : (Ljava/lang/Iterable;Lcom/mojang/blaze3d/platform/NativeImage;Lnet/minecraft/resources/ResourceLocation;Z)Lcom/mojang/blaze3d/platform/NativeImage;
/*      */     //   585: astore_2
/*      */     //   586: goto -> 1162
/*      */     //   589: aload #11
/*      */     //   591: invokevirtual getModel : ()Lnet/minecraft/client/model/EntityModel;
/*      */     //   594: astore #22
/*      */     //   596: aload #22
/*      */     //   598: instanceof net/minecraft/client/model/ListModel
/*      */     //   601: ifeq -> 627
/*      */     //   604: aload #22
/*      */     //   606: checkcast net/minecraft/client/model/ListModel
/*      */     //   609: astore #15
/*      */     //   611: aload #15
/*      */     //   613: invokevirtual parts : ()Ljava/lang/Iterable;
/*      */     //   616: aload #8
/*      */     //   618: aload_1
/*      */     //   619: iconst_0
/*      */     //   620: invokestatic getIconFromHead : (Ljava/lang/Iterable;Lcom/mojang/blaze3d/platform/NativeImage;Lnet/minecraft/resources/ResourceLocation;Z)Lcom/mojang/blaze3d/platform/NativeImage;
/*      */     //   623: astore_2
/*      */     //   624: goto -> 1162
/*      */     //   627: aload #11
/*      */     //   629: invokevirtual getModel : ()Lnet/minecraft/client/model/EntityModel;
/*      */     //   632: astore #22
/*      */     //   634: aload #22
/*      */     //   636: instanceof net/minecraft/client/model/LlamaModel
/*      */     //   639: ifeq -> 670
/*      */     //   642: aload #22
/*      */     //   644: checkcast net/minecraft/client/model/LlamaModel
/*      */     //   647: astore #16
/*      */     //   649: aload #16
/*      */     //   651: checkcast journeymap/common/mixin/client/LlamaModelMixin
/*      */     //   654: invokeinterface getHead : ()Lnet/minecraft/client/model/geom/ModelPart;
/*      */     //   659: aload #8
/*      */     //   661: aload_1
/*      */     //   662: iconst_1
/*      */     //   663: invokestatic getIconFromHead : (Lnet/minecraft/client/model/geom/ModelPart;Lcom/mojang/blaze3d/platform/NativeImage;Lnet/minecraft/resources/ResourceLocation;Z)Lcom/mojang/blaze3d/platform/NativeImage;
/*      */     //   666: astore_2
/*      */     //   667: goto -> 1162
/*      */     //   670: aload #11
/*      */     //   672: invokevirtual getModel : ()Lnet/minecraft/client/model/EntityModel;
/*      */     //   675: astore #22
/*      */     //   677: aload #22
/*      */     //   679: instanceof net/minecraft/client/model/RabbitModel
/*      */     //   682: ifeq -> 741
/*      */     //   685: aload #22
/*      */     //   687: checkcast net/minecraft/client/model/RabbitModel
/*      */     //   690: astore #17
/*      */     //   692: aload #17
/*      */     //   694: checkcast journeymap/common/mixin/client/RabbitModelMixin
/*      */     //   697: astore #22
/*      */     //   699: aload #22
/*      */     //   701: invokeinterface getHead : ()Lnet/minecraft/client/model/geom/ModelPart;
/*      */     //   706: aload #22
/*      */     //   708: invokeinterface getRightEar : ()Lnet/minecraft/client/model/geom/ModelPart;
/*      */     //   713: aload #22
/*      */     //   715: invokeinterface getLeftEar : ()Lnet/minecraft/client/model/geom/ModelPart;
/*      */     //   720: aload #22
/*      */     //   722: invokeinterface getNose : ()Lnet/minecraft/client/model/geom/ModelPart;
/*      */     //   727: invokestatic of : (Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)Lcom/google/common/collect/ImmutableList;
/*      */     //   730: aload #8
/*      */     //   732: aload_1
/*      */     //   733: iconst_0
/*      */     //   734: invokestatic getIconFromHead : (Ljava/lang/Iterable;Lcom/mojang/blaze3d/platform/NativeImage;Lnet/minecraft/resources/ResourceLocation;Z)Lcom/mojang/blaze3d/platform/NativeImage;
/*      */     //   737: astore_2
/*      */     //   738: goto -> 1162
/*      */     //   741: aload #11
/*      */     //   743: invokevirtual getModel : ()Lnet/minecraft/client/model/EntityModel;
/*      */     //   746: astore #22
/*      */     //   748: aload #22
/*      */     //   750: instanceof net/minecraft/client/model/HeadedModel
/*      */     //   753: ifeq -> 800
/*      */     //   756: aload #22
/*      */     //   758: checkcast net/minecraft/client/model/HeadedModel
/*      */     //   761: astore #18
/*      */     //   763: aload #18
/*      */     //   765: invokeinterface getHead : ()Lnet/minecraft/client/model/geom/ModelPart;
/*      */     //   770: aload #8
/*      */     //   772: aload_1
/*      */     //   773: iconst_0
/*      */     //   774: invokestatic getIconFromHead : (Lnet/minecraft/client/model/geom/ModelPart;Lcom/mojang/blaze3d/platform/NativeImage;Lnet/minecraft/resources/ResourceLocation;Z)Lcom/mojang/blaze3d/platform/NativeImage;
/*      */     //   777: astore_2
/*      */     //   778: aload_2
/*      */     //   779: ifnonnull -> 1162
/*      */     //   782: aload #18
/*      */     //   784: invokeinterface getHead : ()Lnet/minecraft/client/model/geom/ModelPart;
/*      */     //   789: aload #8
/*      */     //   791: aload_1
/*      */     //   792: iconst_1
/*      */     //   793: invokestatic getIconFromHead : (Lnet/minecraft/client/model/geom/ModelPart;Lcom/mojang/blaze3d/platform/NativeImage;Lnet/minecraft/resources/ResourceLocation;Z)Lcom/mojang/blaze3d/platform/NativeImage;
/*      */     //   796: astore_2
/*      */     //   797: goto -> 1162
/*      */     //   800: aload #11
/*      */     //   802: invokevirtual getModel : ()Lnet/minecraft/client/model/EntityModel;
/*      */     //   805: astore #22
/*      */     //   807: aload #22
/*      */     //   809: instanceof net/minecraft/client/model/HierarchicalModel
/*      */     //   812: ifeq -> 991
/*      */     //   815: aload #22
/*      */     //   817: checkcast net/minecraft/client/model/HierarchicalModel
/*      */     //   820: astore #19
/*      */     //   822: iconst_0
/*      */     //   823: istore #22
/*      */     //   825: iconst_0
/*      */     //   826: istore #23
/*      */     //   828: aload_3
/*      */     //   829: instanceof net/minecraft/world/entity/animal/AbstractFish
/*      */     //   832: ifeq -> 841
/*      */     //   835: iconst_1
/*      */     //   836: istore #22
/*      */     //   838: goto -> 851
/*      */     //   841: aload_3
/*      */     //   842: instanceof net/minecraft/world/entity/animal/Parrot
/*      */     //   845: ifeq -> 851
/*      */     //   848: iconst_1
/*      */     //   849: istore #23
/*      */     //   851: aload #19
/*      */     //   853: ldc_w 'head'
/*      */     //   856: invokevirtual getAnyDescendantWithName : (Ljava/lang/String;)Ljava/util/Optional;
/*      */     //   859: aconst_null
/*      */     //   860: invokevirtual orElse : (Ljava/lang/Object;)Ljava/lang/Object;
/*      */     //   863: checkcast net/minecraft/client/model/geom/ModelPart
/*      */     //   866: astore #24
/*      */     //   868: iload #22
/*      */     //   870: ifne -> 933
/*      */     //   873: iload #23
/*      */     //   875: ifne -> 933
/*      */     //   878: aload #24
/*      */     //   880: aload #8
/*      */     //   882: aload_1
/*      */     //   883: iconst_0
/*      */     //   884: invokestatic getIconFromHead : (Lnet/minecraft/client/model/geom/ModelPart;Lcom/mojang/blaze3d/platform/NativeImage;Lnet/minecraft/resources/ResourceLocation;Z)Lcom/mojang/blaze3d/platform/NativeImage;
/*      */     //   887: astore_2
/*      */     //   888: aload_2
/*      */     //   889: ifnonnull -> 902
/*      */     //   892: aload #24
/*      */     //   894: aload #8
/*      */     //   896: aload_1
/*      */     //   897: iconst_1
/*      */     //   898: invokestatic getIconFromHead : (Lnet/minecraft/client/model/geom/ModelPart;Lcom/mojang/blaze3d/platform/NativeImage;Lnet/minecraft/resources/ResourceLocation;Z)Lcom/mojang/blaze3d/platform/NativeImage;
/*      */     //   901: astore_2
/*      */     //   902: aload_2
/*      */     //   903: ifnonnull -> 933
/*      */     //   906: aload #19
/*      */     //   908: ldc_w 'body'
/*      */     //   911: invokevirtual getAnyDescendantWithName : (Ljava/lang/String;)Ljava/util/Optional;
/*      */     //   914: aconst_null
/*      */     //   915: invokevirtual orElse : (Ljava/lang/Object;)Ljava/lang/Object;
/*      */     //   918: checkcast net/minecraft/client/model/geom/ModelPart
/*      */     //   921: astore #25
/*      */     //   923: aload #25
/*      */     //   925: aload #8
/*      */     //   927: aload_1
/*      */     //   928: iconst_0
/*      */     //   929: invokestatic getIconFromHead : (Lnet/minecraft/client/model/geom/ModelPart;Lcom/mojang/blaze3d/platform/NativeImage;Lnet/minecraft/resources/ResourceLocation;Z)Lcom/mojang/blaze3d/platform/NativeImage;
/*      */     //   932: astore_2
/*      */     //   933: aload_2
/*      */     //   934: ifnonnull -> 988
/*      */     //   937: aload #19
/*      */     //   939: ldc_w 'root'
/*      */     //   942: invokevirtual getAnyDescendantWithName : (Ljava/lang/String;)Ljava/util/Optional;
/*      */     //   945: aconst_null
/*      */     //   946: invokevirtual orElse : (Ljava/lang/Object;)Ljava/lang/Object;
/*      */     //   949: checkcast net/minecraft/client/model/geom/ModelPart
/*      */     //   952: astore #25
/*      */     //   954: iload #22
/*      */     //   956: ifne -> 974
/*      */     //   959: iload #23
/*      */     //   961: ifne -> 974
/*      */     //   964: aload #25
/*      */     //   966: aload #8
/*      */     //   968: aload_1
/*      */     //   969: iconst_0
/*      */     //   970: invokestatic getIconFromHead : (Lnet/minecraft/client/model/geom/ModelPart;Lcom/mojang/blaze3d/platform/NativeImage;Lnet/minecraft/resources/ResourceLocation;Z)Lcom/mojang/blaze3d/platform/NativeImage;
/*      */     //   973: astore_2
/*      */     //   974: aload_2
/*      */     //   975: ifnonnull -> 988
/*      */     //   978: aload #25
/*      */     //   980: aload #8
/*      */     //   982: aload_1
/*      */     //   983: iconst_1
/*      */     //   984: invokestatic getIconFromHead : (Lnet/minecraft/client/model/geom/ModelPart;Lcom/mojang/blaze3d/platform/NativeImage;Lnet/minecraft/resources/ResourceLocation;Z)Lcom/mojang/blaze3d/platform/NativeImage;
/*      */     //   987: astore_2
/*      */     //   988: goto -> 1162
/*      */     //   991: aload #11
/*      */     //   993: invokevirtual getModel : ()Lnet/minecraft/client/model/EntityModel;
/*      */     //   996: astore #22
/*      */     //   998: aload #22
/*      */     //   1000: instanceof net/minecraft/client/model/HorseModel
/*      */     //   1003: ifeq -> 1064
/*      */     //   1006: aload #22
/*      */     //   1008: checkcast net/minecraft/client/model/HorseModel
/*      */     //   1011: astore #20
/*      */     //   1013: aload #20
/*      */     //   1015: checkcast journeymap/common/mixin/client/AgeableListModelInvoker
/*      */     //   1018: invokeinterface getHeadParts : ()Ljava/lang/Iterable;
/*      */     //   1023: astore #22
/*      */     //   1025: aload #22
/*      */     //   1027: aload #8
/*      */     //   1029: aload_1
/*      */     //   1030: iconst_1
/*      */     //   1031: invokestatic getIconFromHead : (Ljava/lang/Iterable;Lcom/mojang/blaze3d/platform/NativeImage;Lnet/minecraft/resources/ResourceLocation;Z)Lcom/mojang/blaze3d/platform/NativeImage;
/*      */     //   1034: astore_2
/*      */     //   1035: aload_2
/*      */     //   1036: ifnonnull -> 1061
/*      */     //   1039: aload #20
/*      */     //   1041: checkcast journeymap/common/mixin/client/AgeableListModelInvoker
/*      */     //   1044: invokeinterface getBodyParts : ()Ljava/lang/Iterable;
/*      */     //   1049: astore #23
/*      */     //   1051: aload #23
/*      */     //   1053: aload #8
/*      */     //   1055: aload_1
/*      */     //   1056: iconst_1
/*      */     //   1057: invokestatic getIconFromHead : (Ljava/lang/Iterable;Lcom/mojang/blaze3d/platform/NativeImage;Lnet/minecraft/resources/ResourceLocation;Z)Lcom/mojang/blaze3d/platform/NativeImage;
/*      */     //   1060: astore_2
/*      */     //   1061: goto -> 1162
/*      */     //   1064: aload #11
/*      */     //   1066: invokevirtual getModel : ()Lnet/minecraft/client/model/EntityModel;
/*      */     //   1069: astore #22
/*      */     //   1071: aload #22
/*      */     //   1073: instanceof net/minecraft/client/model/AgeableListModel
/*      */     //   1076: ifeq -> 1162
/*      */     //   1079: aload #22
/*      */     //   1081: checkcast net/minecraft/client/model/AgeableListModel
/*      */     //   1084: astore #21
/*      */     //   1086: aload #21
/*      */     //   1088: checkcast journeymap/common/mixin/client/AgeableListModelInvoker
/*      */     //   1091: invokeinterface getHeadParts : ()Ljava/lang/Iterable;
/*      */     //   1096: astore #22
/*      */     //   1098: aload #22
/*      */     //   1100: aload #8
/*      */     //   1102: aload_1
/*      */     //   1103: iconst_0
/*      */     //   1104: invokestatic getIconFromHead : (Ljava/lang/Iterable;Lcom/mojang/blaze3d/platform/NativeImage;Lnet/minecraft/resources/ResourceLocation;Z)Lcom/mojang/blaze3d/platform/NativeImage;
/*      */     //   1107: astore_2
/*      */     //   1108: aload_2
/*      */     //   1109: ifnonnull -> 1122
/*      */     //   1112: aload #22
/*      */     //   1114: aload #8
/*      */     //   1116: aload_1
/*      */     //   1117: iconst_1
/*      */     //   1118: invokestatic getIconFromHead : (Ljava/lang/Iterable;Lcom/mojang/blaze3d/platform/NativeImage;Lnet/minecraft/resources/ResourceLocation;Z)Lcom/mojang/blaze3d/platform/NativeImage;
/*      */     //   1121: astore_2
/*      */     //   1122: aload_2
/*      */     //   1123: ifnonnull -> 1162
/*      */     //   1126: aload #21
/*      */     //   1128: checkcast journeymap/common/mixin/client/AgeableListModelInvoker
/*      */     //   1131: invokeinterface getBodyParts : ()Ljava/lang/Iterable;
/*      */     //   1136: astore #23
/*      */     //   1138: aload #23
/*      */     //   1140: aload #8
/*      */     //   1142: aload_1
/*      */     //   1143: iconst_0
/*      */     //   1144: invokestatic getIconFromHead : (Ljava/lang/Iterable;Lcom/mojang/blaze3d/platform/NativeImage;Lnet/minecraft/resources/ResourceLocation;Z)Lcom/mojang/blaze3d/platform/NativeImage;
/*      */     //   1147: astore_2
/*      */     //   1148: aload_2
/*      */     //   1149: ifnonnull -> 1162
/*      */     //   1152: aload #23
/*      */     //   1154: aload #8
/*      */     //   1156: aload_1
/*      */     //   1157: iconst_1
/*      */     //   1158: invokestatic getIconFromHead : (Ljava/lang/Iterable;Lcom/mojang/blaze3d/platform/NativeImage;Lnet/minecraft/resources/ResourceLocation;Z)Lcom/mojang/blaze3d/platform/NativeImage;
/*      */     //   1161: astore_2
/*      */     //   1162: goto -> 1214
/*      */     //   1165: aload #5
/*      */     //   1167: instanceof net/minecraft/client/renderer/entity/EnderDragonRenderer
/*      */     //   1170: ifeq -> 1214
/*      */     //   1173: aload #5
/*      */     //   1175: checkcast net/minecraft/client/renderer/entity/EnderDragonRenderer
/*      */     //   1178: astore #12
/*      */     //   1180: aload #12
/*      */     //   1182: checkcast journeymap/common/mixin/client/EnderDragonRendererMixin
/*      */     //   1185: invokeinterface getModel : ()Lnet/minecraft/client/renderer/entity/EnderDragonRenderer$DragonModel;
/*      */     //   1190: astore #13
/*      */     //   1192: aload #13
/*      */     //   1194: checkcast journeymap/common/mixin/client/EnderDragonRendererMixin$EnderDragonModelMixin
/*      */     //   1197: astore #14
/*      */     //   1199: aload #14
/*      */     //   1201: invokeinterface getHead : ()Lnet/minecraft/client/model/geom/ModelPart;
/*      */     //   1206: aload #8
/*      */     //   1208: aload_1
/*      */     //   1209: iconst_0
/*      */     //   1210: invokestatic getIconFromHead : (Lnet/minecraft/client/model/geom/ModelPart;Lcom/mojang/blaze3d/platform/NativeImage;Lnet/minecraft/resources/ResourceLocation;Z)Lcom/mojang/blaze3d/platform/NativeImage;
/*      */     //   1213: astore_2
/*      */     //   1214: aload_2
/*      */     //   1215: ifnull -> 1414
/*      */     //   1218: aload_2
/*      */     //   1219: invokestatic generateOutlined : (Lcom/mojang/blaze3d/platform/NativeImage;)Lcom/mojang/blaze3d/platform/NativeImage;
/*      */     //   1222: astore #4
/*      */     //   1224: aload_1
/*      */     //   1225: aload_1
/*      */     //   1226: invokevirtual getPath : ()Ljava/lang/String;
/*      */     //   1229: <illegal opcode> makeConcatWithConstants : (Ljava/lang/String;)Ljava/lang/String;
/*      */     //   1234: invokevirtual withPath : (Ljava/lang/String;)Lnet/minecraft/resources/ResourceLocation;
/*      */     //   1237: astore #5
/*      */     //   1239: getstatic journeymap/client/render/draw/MobIconCache.mobsIcons : Ljava/util/HashMap;
/*      */     //   1242: aload_1
/*      */     //   1243: new journeymap/client/render/draw/MobIconCache$IconTexture
/*      */     //   1246: dup
/*      */     //   1247: new journeymap/client/texture/DynamicTextureImpl
/*      */     //   1250: dup
/*      */     //   1251: aload_2
/*      */     //   1252: invokespecial <init> : (Lcom/mojang/blaze3d/platform/NativeImage;)V
/*      */     //   1255: new journeymap/client/texture/DynamicTextureImpl
/*      */     //   1258: dup
/*      */     //   1259: aload #4
/*      */     //   1261: invokespecial <init> : (Lcom/mojang/blaze3d/platform/NativeImage;)V
/*      */     //   1264: invokespecial <init> : (Ljourneymap/client/texture/Texture;Ljourneymap/client/texture/Texture;)V
/*      */     //   1267: invokevirtual put : (Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
/*      */     //   1270: pop
/*      */     //   1271: aload_1
/*      */     //   1272: invokestatic getMobIconsDomainsDirectory : (Lnet/minecraft/resources/ResourceLocation;)Ljava/io/File;
/*      */     //   1275: astore #6
/*      */     //   1277: new java/io/File
/*      */     //   1280: dup
/*      */     //   1281: aload #6
/*      */     //   1283: aload_1
/*      */     //   1284: invokevirtual getPath : ()Ljava/lang/String;
/*      */     //   1287: <illegal opcode> makeConcatWithConstants : (Ljava/lang/String;)Ljava/lang/String;
/*      */     //   1292: invokespecial <init> : (Ljava/io/File;Ljava/lang/String;)V
/*      */     //   1295: astore #7
/*      */     //   1297: new java/io/File
/*      */     //   1300: dup
/*      */     //   1301: aload #6
/*      */     //   1303: aload #5
/*      */     //   1305: invokevirtual getPath : ()Ljava/lang/String;
/*      */     //   1308: <illegal opcode> makeConcatWithConstants : (Ljava/lang/String;)Ljava/lang/String;
/*      */     //   1313: invokespecial <init> : (Ljava/io/File;Ljava/lang/String;)V
/*      */     //   1316: astore #8
/*      */     //   1318: aload #7
/*      */     //   1320: invokevirtual exists : ()Z
/*      */     //   1323: ifne -> 1332
/*      */     //   1326: aload_2
/*      */     //   1327: aload #7
/*      */     //   1329: invokevirtual writeToFile : (Ljava/io/File;)V
/*      */     //   1332: goto -> 1364
/*      */     //   1335: astore #9
/*      */     //   1337: aload #7
/*      */     //   1339: invokestatic valueOf : (Ljava/lang/Object;)Ljava/lang/String;
/*      */     //   1342: aload #9
/*      */     //   1344: invokevirtual getMessage : ()Ljava/lang/String;
/*      */     //   1347: <illegal opcode> makeConcatWithConstants : (Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;
/*      */     //   1352: astore #10
/*      */     //   1354: invokestatic getLogger : ()Lorg/apache/logging/log4j/Logger;
/*      */     //   1357: aload #10
/*      */     //   1359: invokeinterface error : (Ljava/lang/String;)V
/*      */     //   1364: aload #8
/*      */     //   1366: invokevirtual exists : ()Z
/*      */     //   1369: ifne -> 1379
/*      */     //   1372: aload #4
/*      */     //   1374: aload #8
/*      */     //   1376: invokevirtual writeToFile : (Ljava/io/File;)V
/*      */     //   1379: goto -> 1411
/*      */     //   1382: astore #9
/*      */     //   1384: aload #8
/*      */     //   1386: invokestatic valueOf : (Ljava/lang/Object;)Ljava/lang/String;
/*      */     //   1389: aload #9
/*      */     //   1391: invokevirtual getMessage : ()Ljava/lang/String;
/*      */     //   1394: <illegal opcode> makeConcatWithConstants : (Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;
/*      */     //   1399: astore #10
/*      */     //   1401: invokestatic getLogger : ()Lorg/apache/logging/log4j/Logger;
/*      */     //   1404: aload #10
/*      */     //   1406: invokeinterface error : (Ljava/lang/String;)V
/*      */     //   1411: goto -> 1423
/*      */     //   1414: getstatic journeymap/client/render/draw/MobIconCache.mobsIcons : Ljava/util/HashMap;
/*      */     //   1417: aload_1
/*      */     //   1418: aconst_null
/*      */     //   1419: invokevirtual put : (Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
/*      */     //   1422: pop
/*      */     //   1423: return
/*      */     // Line number table:
/*      */     //   Java source line number -> byte code offset
/*      */     //   #270	-> 0
/*      */     //   #272	-> 10
/*      */     //   #273	-> 12
/*      */     //   #274	-> 23
/*      */     //   #276	-> 27
/*      */     //   #277	-> 35
/*      */     //   #280	-> 43
/*      */     //   #281	-> 55
/*      */     //   #282	-> 62
/*      */     //   #284	-> 77
/*      */     //   #285	-> 86
/*      */     //   #287	-> 87
/*      */     //   #295	-> 96
/*      */     //   #297	-> 111
/*      */     //   #298	-> 123
/*      */     //   #300	-> 138
/*      */     //   #301	-> 155
/*      */     //   #303	-> 165
/*      */     //   #304	-> 168
/*      */     //   #306	-> 183
/*      */     //   #310	-> 196
/*      */     //   #312	-> 210
/*      */     //   #313	-> 222
/*      */     //   #317	-> 244
/*      */     //   #318	-> 256
/*      */     //   #321	-> 275
/*      */     //   #322	-> 292
/*      */     //   #324	-> 302
/*      */     //   #326	-> 309
/*      */     //   #328	-> 314
/*      */     //   #330	-> 317
/*      */     //   #332	-> 332
/*      */     //   #334	-> 365
/*      */     //   #337	-> 378
/*      */     //   #339	-> 385
/*      */     //   #341	-> 393
/*      */     //   #343	-> 400
/*      */     //   #347	-> 408
/*      */     //   #349	-> 411
/*      */     //   #351	-> 416
/*      */     //   #352	-> 425
/*      */     //   #353	-> 432
/*      */     //   #355	-> 440
/*      */     //   #356	-> 452
/*      */     //   #357	-> 466
/*      */     //   #358	-> 475
/*      */     //   #359	-> 490
/*      */     //   #361	-> 497
/*      */     //   #366	-> 502
/*      */     //   #368	-> 506
/*      */     //   #370	-> 521
/*      */     //   #372	-> 525
/*      */     //   #375	-> 543
/*      */     //   #377	-> 565
/*      */     //   #379	-> 589
/*      */     //   #381	-> 611
/*      */     //   #383	-> 627
/*      */     //   #385	-> 649
/*      */     //   #387	-> 670
/*      */     //   #389	-> 692
/*      */     //   #390	-> 699
/*      */     //   #391	-> 738
/*      */     //   #392	-> 741
/*      */     //   #394	-> 763
/*      */     //   #395	-> 778
/*      */     //   #397	-> 782
/*      */     //   #400	-> 800
/*      */     //   #402	-> 822
/*      */     //   #403	-> 825
/*      */     //   #404	-> 828
/*      */     //   #406	-> 835
/*      */     //   #408	-> 841
/*      */     //   #410	-> 848
/*      */     //   #413	-> 851
/*      */     //   #415	-> 868
/*      */     //   #417	-> 878
/*      */     //   #418	-> 888
/*      */     //   #420	-> 892
/*      */     //   #423	-> 902
/*      */     //   #425	-> 906
/*      */     //   #426	-> 923
/*      */     //   #430	-> 933
/*      */     //   #432	-> 937
/*      */     //   #433	-> 954
/*      */     //   #435	-> 964
/*      */     //   #437	-> 974
/*      */     //   #439	-> 978
/*      */     //   #442	-> 988
/*      */     //   #443	-> 991
/*      */     //   #445	-> 1013
/*      */     //   #446	-> 1025
/*      */     //   #448	-> 1035
/*      */     //   #450	-> 1039
/*      */     //   #451	-> 1051
/*      */     //   #453	-> 1061
/*      */     //   #454	-> 1064
/*      */     //   #456	-> 1086
/*      */     //   #457	-> 1098
/*      */     //   #458	-> 1108
/*      */     //   #460	-> 1112
/*      */     //   #463	-> 1122
/*      */     //   #465	-> 1126
/*      */     //   #466	-> 1138
/*      */     //   #467	-> 1148
/*      */     //   #469	-> 1152
/*      */     //   #472	-> 1162
/*      */     //   #474	-> 1165
/*      */     //   #476	-> 1180
/*      */     //   #477	-> 1192
/*      */     //   #478	-> 1199
/*      */     //   #482	-> 1214
/*      */     //   #484	-> 1218
/*      */     //   #485	-> 1224
/*      */     //   #486	-> 1239
/*      */     //   #487	-> 1271
/*      */     //   #488	-> 1277
/*      */     //   #489	-> 1297
/*      */     //   #493	-> 1318
/*      */     //   #495	-> 1326
/*      */     //   #502	-> 1332
/*      */     //   #498	-> 1335
/*      */     //   #500	-> 1337
/*      */     //   #501	-> 1354
/*      */     //   #506	-> 1364
/*      */     //   #508	-> 1372
/*      */     //   #515	-> 1379
/*      */     //   #511	-> 1382
/*      */     //   #513	-> 1384
/*      */     //   #514	-> 1401
/*      */     //   #516	-> 1411
/*      */     //   #519	-> 1414
/*      */     //   #522	-> 1423
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	descriptor
/*      */     //   155	10	15	head	Lnet/minecraft/client/model/geom/ModelPart;
/*      */     //   138	27	14	model	Lnet/minecraft/client/model/PufferfishBigModel;
/*      */     //   123	42	13	pufferfishModel	Lnet/minecraft/client/model/EntityModel;
/*      */     //   111	57	9	pufferfishRenderer	Lnet/minecraft/client/renderer/entity/PufferfishRenderer;
/*      */     //   222	22	14	tropicalFishModel	Lnet/minecraft/client/model/HierarchicalModel;
/*      */     //   241	3	15	altEntityImage	Lcom/mojang/blaze3d/platform/NativeImage;
/*      */     //   256	58	14	tropicalFishModel	Lnet/minecraft/client/model/HierarchicalModel;
/*      */     //   275	39	15	altEntityImage	Lcom/mojang/blaze3d/platform/NativeImage;
/*      */     //   292	22	16	body	Lnet/minecraft/client/model/geom/ModelPart;
/*      */     //   196	118	13	tropicalFish	Lnet/minecraft/world/entity/animal/TropicalFish;
/*      */     //   183	134	10	tropicalFishRenderer	Lnet/minecraft/client/renderer/entity/TropicalFishRenderer;
/*      */     //   390	3	23	type	Ljava/lang/String;
/*      */     //   405	3	23	type	Ljava/lang/String;
/*      */     //   452	50	26	professionKey	Lnet/minecraft/resources/ResourceLocation;
/*      */     //   466	36	27	professionRes	Lnet/minecraft/resources/ResourceLocation;
/*      */     //   475	27	28	altEntityImage	Lcom/mojang/blaze3d/platform/NativeImage;
/*      */     //   425	77	24	data	Lnet/minecraft/world/entity/npc/VillagerData;
/*      */     //   432	70	25	profession	Lnet/minecraft/world/entity/npc/VillagerProfession;
/*      */     //   411	91	23	type	Ljava/lang/String;
/*      */     //   378	124	22	villager	Lnet/minecraft/world/entity/npc/VillagerDataHolder;
/*      */     //   365	178	13	model	Lnet/minecraft/client/model/HeadedModel;
/*      */     //   565	24	14	model	Lnet/minecraft/client/model/HumanoidModel;
/*      */     //   611	16	15	model	Lnet/minecraft/client/model/ListModel;
/*      */     //   649	21	16	model	Lnet/minecraft/client/model/LlamaModel;
/*      */     //   699	39	22	m	Ljourneymap/common/mixin/client/RabbitModelMixin;
/*      */     //   692	49	17	model	Lnet/minecraft/client/model/RabbitModel;
/*      */     //   763	37	18	model	Lnet/minecraft/client/model/HeadedModel;
/*      */     //   923	10	25	wholeBody	Lnet/minecraft/client/model/geom/ModelPart;
/*      */     //   954	34	25	wholeBody	Lnet/minecraft/client/model/geom/ModelPart;
/*      */     //   825	163	22	isFish	Z
/*      */     //   828	160	23	isParrot	Z
/*      */     //   868	120	24	head	Lnet/minecraft/client/model/geom/ModelPart;
/*      */     //   822	169	19	model	Lnet/minecraft/client/model/HierarchicalModel;
/*      */     //   1051	10	23	body	Ljava/lang/Iterable;
/*      */     //   1025	36	22	head	Ljava/lang/Iterable;
/*      */     //   1013	51	20	model	Lnet/minecraft/client/model/HorseModel;
/*      */     //   1138	24	23	body	Ljava/lang/Iterable;
/*      */     //   1098	64	22	head	Ljava/lang/Iterable;
/*      */     //   1086	76	21	model	Lnet/minecraft/client/model/AgeableListModel;
/*      */     //   332	833	11	mobRenderer	Lnet/minecraft/client/renderer/entity/LivingEntityRenderer;
/*      */     //   1192	22	13	model	Lnet/minecraft/client/renderer/entity/EnderDragonRenderer$DragonModel;
/*      */     //   1199	15	14	dragonModel	Ljourneymap/common/mixin/client/EnderDragonRendererMixin$EnderDragonModelMixin;
/*      */     //   1180	34	12	dragonRenderer	Lnet/minecraft/client/renderer/entity/EnderDragonRenderer;
/*      */     //   35	1179	4	renderManager	Lnet/minecraft/client/renderer/entity/EntityRenderDispatcher;
/*      */     //   43	1171	5	renderer	Lnet/minecraft/client/renderer/entity/EntityRenderer;
/*      */     //   55	1159	6	textureLocation	Lnet/minecraft/resources/ResourceLocation;
/*      */     //   62	1152	7	tex	Ljourneymap/client/texture/Texture;
/*      */     //   96	1118	8	entityImage	Lcom/mojang/blaze3d/platform/NativeImage;
/*      */     //   1354	10	10	error	Ljava/lang/String;
/*      */     //   1337	27	9	e	Ljava/io/IOException;
/*      */     //   1401	10	10	error	Ljava/lang/String;
/*      */     //   1384	27	9	e	Ljava/io/IOException;
/*      */     //   1224	187	4	outlined	Lcom/mojang/blaze3d/platform/NativeImage;
/*      */     //   1239	172	5	outlinedLocation	Lnet/minecraft/resources/ResourceLocation;
/*      */     //   1277	134	6	domainDir	Ljava/io/File;
/*      */     //   1297	114	7	iconFile	Ljava/io/File;
/*      */     //   1318	93	8	outlinedFile	Ljava/io/File;
/*      */     //   12	1411	2	entityIcon	Lcom/mojang/blaze3d/platform/NativeImage;
/*      */     //   23	1400	3	entity	Lnet/minecraft/world/entity/Entity;
/*      */     //   0	1424	0	dto	Ljourneymap/client/model/EntityDTO;
/*      */     //   0	1424	1	mobLocation	Lnet/minecraft/resources/ResourceLocation;
/*      */     // Local variable type table:
/*      */     //   start	length	slot	name	signature
/*      */     //   138	27	14	model	Lnet/minecraft/client/model/PufferfishBigModel<Lnet/minecraft/world/entity/animal/Pufferfish;>;
/*      */     //   123	42	13	pufferfishModel	Lnet/minecraft/client/model/EntityModel<Lnet/minecraft/world/entity/animal/Pufferfish;>;
/*      */     //   222	22	14	tropicalFishModel	Lnet/minecraft/client/model/HierarchicalModel<Lnet/minecraft/world/entity/animal/TropicalFish;>;
/*      */     //   256	58	14	tropicalFishModel	Lnet/minecraft/client/model/HierarchicalModel<Lnet/minecraft/world/entity/animal/TropicalFish;>;
/*      */     //   565	24	14	model	Lnet/minecraft/client/model/HumanoidModel<*>;
/*      */     //   611	16	15	model	Lnet/minecraft/client/model/ListModel<*>;
/*      */     //   649	21	16	model	Lnet/minecraft/client/model/LlamaModel<*>;
/*      */     //   692	49	17	model	Lnet/minecraft/client/model/RabbitModel<*>;
/*      */     //   822	169	19	model	Lnet/minecraft/client/model/HierarchicalModel<*>;
/*      */     //   1051	10	23	body	Ljava/lang/Iterable<Lnet/minecraft/client/model/geom/ModelPart;>;
/*      */     //   1025	36	22	head	Ljava/lang/Iterable<Lnet/minecraft/client/model/geom/ModelPart;>;
/*      */     //   1013	51	20	model	Lnet/minecraft/client/model/HorseModel<*>;
/*      */     //   1138	24	23	body	Ljava/lang/Iterable<Lnet/minecraft/client/model/geom/ModelPart;>;
/*      */     //   1098	64	22	head	Ljava/lang/Iterable<Lnet/minecraft/client/model/geom/ModelPart;>;
/*      */     //   1086	76	21	model	Lnet/minecraft/client/model/AgeableListModel<*>;
/*      */     //   332	833	11	mobRenderer	Lnet/minecraft/client/renderer/entity/LivingEntityRenderer<**>;
/*      */     // Exception table:
/*      */     //   from	to	target	type
/*      */     //   1318	1332	1335	java/io/IOException
/*      */     //   1364	1379	1382	java/io/IOException
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static NativeImage mergeImages(NativeImage bottomImage, ResourceLocation top) {
/*  526 */     return mergeImages(bottomImage, top, 16777215, 16777215);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private static NativeImage mergeImages(NativeImage bottomImage, ResourceLocation top, int bottomTint, int topTint) {
/*  532 */     NativeImage newImage = null;
/*      */     
/*      */     try {
/*  535 */       Texture topTex = TextureCache.getTexture(top);
/*  536 */       if (topTex == null || !topTex.hasImage())
/*      */       {
/*  538 */         return bottomImage;
/*      */       }
/*  540 */       NativeImage topImage = topTex.getNativeImage();
/*      */       
/*  542 */       if (bottomImage.getWidth() != topTex.getWidth() || bottomImage.getHeight() != topTex.getHeight())
/*      */       {
/*  544 */         return bottomImage;
/*      */       }
/*      */       
/*  547 */       newImage = ImageUtil.getNewBlankImage(bottomImage.getWidth(), bottomImage.getHeight());
/*  548 */       for (int y = 0; y < bottomImage.getHeight(); y++) {
/*      */         
/*  550 */         for (int x = 0; x < bottomImage.getWidth(); x++) {
/*      */           
/*  552 */           int color = topImage.getPixelRGBA(x, y);
/*  553 */           if ((color & 0xFF000000) == 0) {
/*      */             
/*  555 */             color = RGB.tintRgba(bottomImage.getPixelRGBA(x, y), bottomTint);
/*      */           }
/*      */           else {
/*      */             
/*  559 */             color = RGB.tintRgba(color, topTint);
/*      */           } 
/*  561 */           newImage.setPixelRGBA(x, y, color);
/*      */         } 
/*      */       } 
/*  564 */       return newImage;
/*      */     }
/*  566 */     catch (Exception e) {
/*      */       
/*  568 */       if (newImage != null)
/*      */       {
/*  570 */         newImage.close();
/*      */       }
/*      */ 
/*      */       
/*  574 */       return bottomImage;
/*      */     } 
/*      */   }
/*      */   
/*      */   private static <T extends Entity> ResourceLocation getTextureLocation(EntityRenderer<? super T> renderer, T entity) {
/*  579 */     if (Services.COMMON_SERVICE.isModLoaded("entity_texture_features"))
/*      */     {
/*  581 */       if (renderer instanceof LivingEntityRenderer) { LivingEntityRenderer<?, ?> mobRenderer = (LivingEntityRenderer)renderer;
/*      */         
/*  583 */         if (entity instanceof LivingEntity) { LivingEntity livingEntity = (LivingEntity)entity;
/*      */           
/*  585 */           return ((LivingEntityRendererETFTextureGetter)mobRenderer).getETFTextureLocation(livingEntity); }
/*      */          }
/*      */     
/*      */     }
/*  589 */     return renderer.getTextureLocation((Entity)entity);
/*      */   }
/*      */ 
/*      */   
/*      */   private static NativeImage getIconFromHead(ModelPart head, NativeImage entityImage, ResourceLocation mobLocation, boolean rotated) {
/*  594 */     if (head == null)
/*      */     {
/*  596 */       return null;
/*      */     }
/*      */     
/*  599 */     return getIconFromHead((Iterable<ModelPart>)ImmutableList.of(head), entityImage, mobLocation, rotated);
/*      */   }
/*      */ 
/*      */   
/*      */   private static NativeImage getIconFromHead(Iterable<ModelPart> heads, NativeImage entityImage, ResourceLocation mobLocation, boolean rotated) {
/*  604 */     if (heads == null)
/*      */     {
/*  606 */       return null;
/*      */     }
/*      */     
/*  609 */     List<ModelPart> CEMFixedHeads = new ArrayList<>();
/*  610 */     heads.forEach(head -> ((ModelPartMixin)head).getChildren().forEach(()));
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  617 */     if (!CEMFixedHeads.isEmpty())
/*      */     {
/*  619 */       heads = CEMFixedHeads;
/*      */     }
/*      */     
/*  622 */     Map<ModelPart, PartPose> headPoses = new HashMap<>();
/*  623 */     heads.forEach(head -> headPoses.put(head, head.storePose()));
/*  624 */     heads.forEach(ModelPart::resetPose);
/*      */     
/*  626 */     int scale = 4;
/*  627 */     List<HeadPolygon> facePolygons = new ArrayList<>();
/*  628 */     heads.forEach(head -> head.visit(new PoseStack(), ()));
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  640 */     heads.forEach(head -> head.loadPose((PartPose)headPoses.get(head)));
/*      */     
/*  642 */     if (facePolygons.isEmpty())
/*      */     {
/*  644 */       return null;
/*      */     }
/*      */     
/*  647 */     facePolygons.sort((p1, p2) -> {
/*      */           float p1AverageZ = ((p1.vertices[0]).pos.z + (p1.vertices[1]).pos.z + (p1.vertices[2]).pos.z + (p1.vertices[3]).pos.z) / 4.0F;
/*      */           
/*      */           float p2AverageZ = ((p2.vertices[0]).pos.z + (p2.vertices[1]).pos.z + (p2.vertices[2]).pos.z + (p2.vertices[3]).pos.z) / 4.0F;
/*      */           
/*      */           float comp = Math.signum(p2AverageZ - p1AverageZ);
/*      */           if (comp == 0.0F) {
/*      */             comp = Math.signum(p2.normal.z - p1.normal.z);
/*      */           }
/*      */           return (int)comp;
/*      */         });
/*  658 */     int minX = Integer.MAX_VALUE;
/*  659 */     int maxX = Integer.MIN_VALUE;
/*  660 */     int minY = Integer.MAX_VALUE;
/*  661 */     int maxY = Integer.MIN_VALUE;
/*  662 */     for (HeadPolygon p : facePolygons) {
/*      */       
/*  664 */       for (ModelPart.Vertex v : p.vertices) {
/*      */         
/*  666 */         minX = Math.min(minX, Math.round(v.pos.x));
/*  667 */         maxX = Math.max(maxX, Math.round(v.pos.x));
/*  668 */         minY = Math.min(minY, Math.round(v.pos.y));
/*  669 */         maxY = Math.max(maxY, Math.round(v.pos.y));
/*      */       } 
/*      */     } 
/*      */     
/*  673 */     int headWidth = maxX - minX;
/*  674 */     int headHeight = maxY - minY;
/*      */     
/*  676 */     NativeImage headImage = ImageUtil.getNewBlankImage((headWidth + 1) * 4, (headHeight + 1) * 4);
/*      */ 
/*      */     
/*      */     try {
/*  680 */       int step = 0;
/*  681 */       for (HeadPolygon p : facePolygons)
/*      */       {
/*  683 */         drawPolygonOnImage(p, minX, minY, entityImage, headImage);
/*      */       }
/*  685 */       headImage = cropImage(headImage);
/*  686 */       headImage = resizeImage(headImage, 4, rotated);
/*  687 */       headImage = maskImage(headImage);
/*      */     }
/*  689 */     catch (Exception e) {
/*      */       
/*  691 */       Journeymap.getLogger().error("Error creating icon for '{}': {}", mobLocation, e);
/*  692 */       return null;
/*      */     } 
/*      */ 
/*      */     
/*  696 */     return headImage;
/*      */   }
/*      */ 
/*      */   
/*      */   private static void drawPolygonOnImage(HeadPolygon polygon, int originX, int originY, NativeImage from, NativeImage to) {
/*  701 */     if (polygon.vertices.length != 4) {
/*      */       return;
/*      */     }
/*      */ 
/*      */     
/*  706 */     int texWidth = from.getWidth();
/*  707 */     int texHeight = from.getHeight();
/*  708 */     float minU = texWidth;
/*  709 */     float maxU = 0.0F;
/*  710 */     float minV = texHeight;
/*  711 */     float maxV = 0.0F;
/*  712 */     float minX = Float.MAX_VALUE;
/*  713 */     float maxX = Float.MIN_VALUE;
/*  714 */     float minY = Float.MAX_VALUE;
/*  715 */     float maxY = Float.MIN_VALUE;
/*  716 */     for (ModelPart.Vertex vertex : polygon.vertices) {
/*      */       
/*  718 */       minU = Math.min(minU, vertex.u * texWidth);
/*  719 */       maxU = Math.max(maxU, vertex.u * texWidth);
/*  720 */       minV = Math.min(minV, vertex.v * texHeight);
/*  721 */       maxV = Math.max(maxV, vertex.v * texHeight);
/*  722 */       minX = Math.min(minX, vertex.pos.x);
/*  723 */       maxX = Math.max(maxX, vertex.pos.x);
/*  724 */       minY = Math.min(minY, vertex.pos.y);
/*  725 */       maxY = Math.max(maxY, vertex.pos.y);
/*      */     } 
/*      */     float y;
/*  728 */     for (y = minY; y < maxY; y++) {
/*      */       float x;
/*  730 */       for (x = minX; x < maxX; x++) {
/*      */         
/*  732 */         Vector2f uv = getUVCoordinates(polygon, x, y);
/*  733 */         uv.x = (float)Math.floor((uv.x * texWidth));
/*  734 */         uv.y = (float)Math.floor((uv.y * texHeight));
/*  735 */         if (uv.x >= minU && uv.x < maxU && uv.y >= minV && uv.y < maxV) {
/*      */           
/*  737 */           int c = from.getPixelRGBA(
/*  738 */               Math.min(Math.max(0, (int)uv.x), texWidth - 1), 
/*  739 */               Math.min(Math.max(0, (int)uv.y), texHeight - 1));
/*      */           
/*  741 */           if ((c >> 24 & 0xFF) == 255) {
/*      */             
/*  743 */             to.setPixelRGBA(Math.round(x) - originX, Math.round(y) - originY, c);
/*      */           }
/*  745 */           else if ((c >> 24 & 0xFF) > 0) {
/*      */             
/*  747 */             to.blendPixel(Math.round(x) - originX, Math.round(y) - originY, c);
/*      */           } 
/*      */         } 
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   private static Vector2f getUVCoordinates(HeadPolygon polygon, float x, float y) {
/*  756 */     Vector3f p0 = (polygon.vertices[0]).pos;
/*  757 */     Vector3f p1 = (polygon.vertices[1]).pos;
/*  758 */     Vector3f p2 = (polygon.vertices[2]).pos;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  764 */     Vector2f v0 = new Vector2f(p0.x - p2.x, p0.y - p2.y);
/*  765 */     Vector2f v1 = new Vector2f(p1.x - p2.x, p1.y - p2.y);
/*  766 */     Vector2f v2 = new Vector2f(x + 0.5F - p2.x, y + 0.5F - p2.y);
/*  767 */     float den = v0.x * v1.y - v1.x * v0.y;
/*  768 */     float a = (v2.x * v1.y - v1.x * v2.y) / den;
/*  769 */     float b = (v0.x * v2.y - v2.x * v0.y) / den;
/*  770 */     float c = 1.0F - b - a;
/*      */     
/*  772 */     return new Vector2f(a * (polygon.vertices[0]).u + b * (polygon.vertices[1]).u + c * (polygon.vertices[2]).u, a * (polygon.vertices[0]).v + b * (polygon.vertices[1]).v + c * (polygon.vertices[2]).v);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static NativeImage cropImage(NativeImage image) {
/*  780 */     int width = image.getWidth();
/*  781 */     int height = image.getHeight();
/*  782 */     int left = width;
/*  783 */     int top = height;
/*  784 */     int right = width;
/*  785 */     int bottom = height;
/*      */     
/*  787 */     for (int y = 0; y < height; y++) {
/*      */       
/*  789 */       for (int x = 0; x < width; x++) {
/*      */         
/*  791 */         int c = image.getPixelRGBA(x, y);
/*  792 */         if ((c >> 24 & 0xFF) > 0) {
/*      */           
/*  794 */           left = Math.min(left, x);
/*  795 */           top = Math.min(top, y);
/*  796 */           right = Math.min(right, width - x - 1);
/*  797 */           bottom = Math.min(bottom, height - y - 1);
/*      */         } 
/*      */       } 
/*      */     } 
/*      */     
/*  802 */     int newWidth = width - left - right;
/*  803 */     int newHeight = height - top - bottom;
/*  804 */     boolean extraLeft = (newWidth % 2 == 1);
/*  805 */     boolean extraBottom = (newHeight % 2 == 1);
/*  806 */     NativeImage result = new NativeImage(newWidth + (extraLeft ? 1 : 0), newHeight + (extraBottom ? 1 : 0), false);
/*  807 */     image.copyRect(result, left, top, 0, 0, newWidth, newHeight, false, false);
/*  808 */     image.close();
/*      */     
/*  810 */     if (extraLeft)
/*      */     {
/*  812 */       result.copyRect(result, newWidth - 1, 0, newWidth, 0, 1, newHeight, false, false);
/*      */     }
/*  814 */     if (extraBottom)
/*      */     {
/*  816 */       result.copyRect(result, 0, newHeight - 1, 0, newHeight, newWidth + (extraLeft ? 1 : 0), 1, false, false);
/*      */     }
/*  818 */     return result;
/*      */   }
/*      */ 
/*      */   
/*      */   private static NativeImage resizeImage(NativeImage image, int scale, boolean rotated) {
/*  823 */     int width = image.getWidth();
/*  824 */     int height = image.getHeight();
/*  825 */     SizeInfo sizeInfo = getClosestValidSize(width, height, scale);
/*  826 */     CropInfo crop = new CropInfo(0, 0, 0, 0);
/*      */     
/*  828 */     if (!sizeInfo.exact) {
/*      */       
/*  830 */       List<CropInfo> cropsToTry = getSizesToTry(image, scale, rotated);
/*  831 */       for (CropInfo c : cropsToTry) {
/*      */         
/*  833 */         SizeInfo size = getClosestValidSize(width - c.left - c.right, height - c.top - c.bottom, scale);
/*  834 */         if (size.exact) {
/*      */           
/*  836 */           sizeInfo = size;
/*  837 */           crop = c;
/*      */           
/*      */           break;
/*      */         } 
/*      */       } 
/*      */     } 
/*  843 */     NativeImage result = ImageUtil.getNewBlankImage(sizeInfo.width, sizeInfo.height);
/*  844 */     float finalScale = Math.min(sizeInfo.width / (width - crop.left - crop.right), sizeInfo.height / (height - crop.top - crop.bottom));
/*  845 */     for (int y = 0; y < result.getHeight(); y++) {
/*      */       
/*  847 */       for (int x = 0; x < result.getWidth(); x++) {
/*      */         
/*  849 */         int fromX = Math.round(x / finalScale) + crop.left;
/*  850 */         int fromY = Math.round(y / finalScale) + crop.top;
/*  851 */         if (fromX >= 0 && fromX < image.getWidth() && fromY >= 0 && fromY < image.getHeight())
/*      */         {
/*      */ 
/*      */           
/*  855 */           result.setPixelRGBA(x, y, image.getPixelRGBA(fromX, fromY));
/*      */         }
/*      */       } 
/*      */     } 
/*  859 */     return result;
/*      */   }
/*      */ 
/*      */   
/*      */   private static SizeInfo getClosestValidSize(int width, int height, int scale) {
/*  864 */     if (width == 16 * scale && height == 16 * scale)
/*      */     {
/*  866 */       return new SizeInfo(16, 16, true);
/*      */     }
/*      */     
/*  869 */     boolean portrait = (height > width);
/*  870 */     int longest = portrait ? height : width;
/*  871 */     int shortest = portrait ? width : height;
/*  872 */     float ratio = longest / shortest;
/*      */     
/*  874 */     int closestL = 16;
/*  875 */     int closestS = 16;
/*  876 */     float closestDist = Math.abs(ratio - 1.0F);
/*  877 */     boolean exact = false;
/*  878 */     for (int l = 14; l <= 22; l++) {
/*      */       
/*  880 */       int s = Math.round(l / ratio);
/*  881 */       int diag = l * l + s * s;
/*  882 */       if (diag >= 390 && diag <= 650) {
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  887 */         boolean e = (l % longest / scale == 0 && s % shortest / scale == 0);
/*  888 */         float dist = Math.abs(ratio - l / s);
/*      */         
/*  890 */         if (e || !exact)
/*      */         {
/*  892 */           if (e || dist < closestDist) {
/*      */             
/*  894 */             closestL = l;
/*  895 */             closestS = s;
/*  896 */             exact = e;
/*      */           } 
/*      */         }
/*      */       } 
/*      */     } 
/*  901 */     if (portrait)
/*      */     {
/*  903 */       return new SizeInfo(closestS, closestL, exact);
/*      */     }
/*      */ 
/*      */     
/*  907 */     return new SizeInfo(closestL, closestS, exact);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private static List<CropInfo> getSizesToTry(NativeImage image, int scale, boolean rotated) {
/*  913 */     int width = image.getWidth();
/*  914 */     int height = image.getHeight();
/*  915 */     boolean portrait = (height > width);
/*  916 */     List<CropInfo> crops = new ArrayList<>();
/*      */     
/*  918 */     for (int y = -1; y < 4; y++) {
/*      */       
/*  920 */       for (int x = -1; x < 4; x++) {
/*      */         
/*  922 */         if (x != 0 || y != 0)
/*      */         {
/*      */ 
/*      */ 
/*      */           
/*  927 */           if (rotated) {
/*      */             
/*  929 */             crops.add(new CropInfo(
/*  930 */                   (x < 0) ? (scale * x) : 0, 
/*  931 */                   (y < 0) ? (scale * y) : 0, 
/*  932 */                   (x > 0) ? (scale * x) : 0, 
/*  933 */                   (y > 0) ? (scale * y) : 0));
/*      */           }
/*      */           else {
/*      */             
/*  937 */             crops.add(new CropInfo(scale * x / 2, scale * y / 2, scale * x / 2, scale * y / 2));
/*      */           } 
/*      */         }
/*      */       } 
/*      */     } 
/*  942 */     crops.sort((c1, c2) -> {
/*      */           int c1H = c1.left + c1.right;
/*      */           
/*      */           int c1V = c1.top + c1.bottom;
/*      */           
/*      */           int c2H = c2.left + c2.right;
/*      */           
/*      */           int c2V = c2.top + c2.bottom;
/*      */           
/*      */           int d = c1H + c1V - c2H - c2V;
/*      */           if (d == 0) {
/*      */             if (portrait && c1V > c1H) {
/*      */               return -1;
/*      */             }
/*      */             if (!portrait && c1V < c1H) {
/*      */               return 1;
/*      */             }
/*      */           } 
/*      */           return d;
/*      */         });
/*  962 */     return crops;
/*      */   }
/*      */ 
/*      */   
/*      */   private static NativeImage maskImage(NativeImage image) {
/*  967 */     if (markerMask == null)
/*      */     {
/*  969 */       return image;
/*      */     }
/*      */     
/*  972 */     int cornerX = markerMask.getWidth() / 2 - image.getWidth() / 2;
/*  973 */     int cornerY = markerMask.getHeight() / 2 - image.getHeight() / 2;
/*  974 */     for (int y = 0; y < image.getHeight(); y++) {
/*      */       
/*  976 */       for (int x = 0; x < image.getWidth(); x++) {
/*      */         
/*  978 */         if ((markerMask.getPixelRGBA(cornerX + x, cornerY + y) & 0xFF000000) == 0)
/*      */         {
/*  980 */           image.setPixelRGBA(x, y, 0);
/*      */         }
/*      */       } 
/*      */     } 
/*  984 */     return image;
/*      */   }
/*      */ 
/*      */   
/*      */   private static NativeImage generateOutlined(NativeImage image) {
/*  989 */     NativeImage outline = ImageUtil.getNewBlankImage(image.getWidth() + 2, image.getHeight() + 2);
/*  990 */     for (int y = -1; y < image.getHeight() + 1; y++) {
/*      */       
/*  992 */       for (int x = -1; x < image.getWidth() + 1; x++) {
/*      */         
/*  994 */         if (!isOpaque(image, x, y)) {
/*      */           
/*  996 */           boolean opaque = false;
/*  997 */           opaque = (opaque || isOpaque(image, x - 1, y - 1));
/*  998 */           opaque = (opaque || isOpaque(image, x + 0, y - 1));
/*  999 */           opaque = (opaque || isOpaque(image, x + 1, y - 1));
/* 1000 */           opaque = (opaque || isOpaque(image, x - 1, y + 0));
/* 1001 */           opaque = (opaque || isOpaque(image, x + 1, y + 0));
/* 1002 */           opaque = (opaque || isOpaque(image, x - 1, y + 1));
/* 1003 */           opaque = (opaque || isOpaque(image, x + 0, y + 1));
/* 1004 */           opaque = (opaque || isOpaque(image, x + 1, y + 1));
/* 1005 */           if (opaque) {
/*      */             
/* 1007 */             outline.setPixelRGBA(x + 1, y + 1, -16777216);
/*      */             
/*      */             continue;
/*      */           } 
/*      */         } 
/* 1012 */         if (x >= 0 && x < image.getWidth() && y >= 0 && y < image.getHeight())
/*      */         {
/*      */ 
/*      */ 
/*      */           
/* 1017 */           outline.setPixelRGBA(x + 1, y + 1, image.getPixelRGBA(x, y)); } 
/*      */         continue;
/*      */       } 
/*      */     } 
/* 1021 */     return outline;
/*      */   }
/*      */ 
/*      */   
/*      */   private static boolean isOpaque(NativeImage image, int x, int y) {
/* 1026 */     if (x < 0 || x >= image.getWidth() || y < 0 || y >= image.getHeight())
/*      */     {
/* 1028 */       return false;
/*      */     }
/* 1030 */     return ((image.getPixelRGBA(x, y) & 0xFF000000) != 0);
/*      */   }
/*      */ 
/*      */   
/*      */   private static class IconTexture
/*      */   {
/*      */     public Texture solid;
/*      */     
/*      */     public Texture outlined;
/*      */     
/*      */     public IconTexture() {
/* 1041 */       this.solid = null;
/* 1042 */       this.outlined = null;
/*      */     }
/*      */ 
/*      */     
/*      */     public IconTexture(Texture solid, Texture outlined) {
/* 1047 */       this.solid = solid;
/* 1048 */       this.outlined = outlined;
/*      */     }
/*      */ 
/*      */     
/*      */     public void remove() {
/* 1053 */       if (this.solid != null && this.solid.hasImage())
/*      */       {
/* 1055 */         this.solid.remove();
/*      */       }
/* 1057 */       if (this.outlined != null && this.outlined.hasImage())
/*      */       {
/* 1059 */         this.outlined.remove();
/*      */       }
/*      */     }
/*      */   }
/*      */ 
/*      */   
/*      */   private static class SizeInfo
/*      */   {
/*      */     public int width;
/*      */     public int height;
/*      */     public boolean exact;
/*      */     
/*      */     public SizeInfo(int width, int height, boolean exact) {
/* 1072 */       this.width = width;
/* 1073 */       this.height = height;
/* 1074 */       this.exact = exact;
/*      */     }
/*      */   }
/*      */ 
/*      */   
/*      */   private static class CropInfo
/*      */   {
/*      */     public int left;
/*      */     public int top;
/*      */     public int right;
/*      */     public int bottom;
/*      */     
/*      */     public CropInfo(int left, int top, int right, int bottom) {
/* 1087 */       this.left = left;
/* 1088 */       this.top = top;
/* 1089 */       this.right = right;
/* 1090 */       this.bottom = bottom;
/*      */     }
/*      */   }
/*      */ 
/*      */   
/*      */   private static class HeadPolygon
/*      */   {
/*      */     private static final float PIXEL_TO_BLOCK = 0.0625F;
/*      */     
/*      */     private static final float BLOCK_TO_PIXEL = 16.0F;
/*      */     
/*      */     public final ModelPart.Vertex[] vertices;
/*      */     
/*      */     public final Vector3f normal;
/*      */     
/*      */     public HeadPolygon(PoseStack.Pose pose, ModelPart.Polygon polygon, boolean rotated, int scale) {
/* 1106 */       int s = scale / 2;
/* 1107 */       this.vertices = (ModelPart.Vertex[])polygon.vertices.clone();
/* 1108 */       for (int i = 0; i < this.vertices.length; i++) {
/*      */         
/* 1110 */         ModelPart.Vertex v = this.vertices[i];
/* 1111 */         Vector4f pos = pose.pose().transform(new Vector4f(v.pos.x * 0.0625F, v.pos.y * 0.0625F, v.pos.z * 0.0625F, 1.0F));
/* 1112 */         if (rotated) {
/*      */           
/* 1114 */           this.vertices[i] = new ModelPart.Vertex((Math.round(pos.z * 16.0F * s) * s), (Math.round(pos.y * 16.0F * s) * s), pos.x * 16.0F * scale, v.u, v.v);
/*      */         }
/*      */         else {
/*      */           
/* 1118 */           this.vertices[i] = new ModelPart.Vertex((Math.round(pos.x * 16.0F * s) * s), (Math.round(pos.y * 16.0F * s) * s), pos.z * 16.0F * scale, v.u, v.v);
/*      */         } 
/*      */       } 
/*      */       
/* 1122 */       Vector3f r1 = new Vector3f();
/* 1123 */       Vector3f r2 = new Vector3f();
/* 1124 */       (this.vertices[0]).pos.sub((Vector3fc)(this.vertices[1]).pos, r1);
/* 1125 */       (this.vertices[0]).pos.sub((Vector3fc)(this.vertices[2]).pos, r2);
/* 1126 */       this.normal = r1.cross((Vector3fc)r2).normalize();
/*      */     }
/*      */   }
/*      */ }


/* Location:              C:\Users\Administrator\Downloads\journeymap-forge-1.21-6.0.0-beta.18.jar!\journeymap\client\render\draw\MobIconCache.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */