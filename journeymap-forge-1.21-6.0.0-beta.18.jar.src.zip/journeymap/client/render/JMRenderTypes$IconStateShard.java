/*     */ package journeymap.client.render;
/*     */ 
/*     */ import net.minecraft.client.renderer.RenderStateShard;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class IconStateShard
/*     */   extends RenderStateShard.EmptyTextureStateShard
/*     */ {
/*     */   private final int textureId;
/*     */   
/*     */   public IconStateShard(int textureId) {
/* 148 */     super(() -> {
/*     */           RenderWrapper.bindTexture(textureId); RenderWrapper.texParameter(3553, 10241, 9729);
/*     */           RenderWrapper.texParameter(3553, 10240, 9729);
/*     */           RenderWrapper.texParameter(3553, 10242, 10497);
/*     */           RenderWrapper.texParameter(3553, 10243, 10497);
/*     */           RenderWrapper.setShaderTexture(0, textureId);
/*     */         }() -> {
/*     */         
/*     */         });
/* 157 */     this.textureId = textureId;
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 162 */     return this.name + "[" + this.name + ")]";
/*     */   }
/*     */ }


/* Location:              C:\Users\Administrator\Downloads\journeymap-forge-1.21-6.0.0-beta.18.jar!\journeymap\client\render\JMRenderTypes$IconStateShard.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */