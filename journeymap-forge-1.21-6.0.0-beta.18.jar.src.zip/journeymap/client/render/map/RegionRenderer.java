/*     */ package journeymap.client.render.map;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.List;
/*     */ import java.util.Stack;
/*     */ import journeymap.api.client.impl.ClientAPI;
/*     */ import journeymap.api.v2.client.display.Context;
/*     */ import journeymap.api.v2.client.display.DisplayType;
/*     */ import journeymap.api.v2.client.display.Displayable;
/*     */ import journeymap.api.v2.client.display.PolygonOverlay;
/*     */ import journeymap.api.v2.client.model.MapPolygon;
/*     */ import journeymap.api.v2.client.model.ShapeProperties;
/*     */ import journeymap.api.v2.client.model.TextProperties;
/*     */ import journeymap.api.v2.client.util.PolygonHelper;
/*     */ import journeymap.client.io.nbt.RegionLoader;
/*     */ import journeymap.client.model.RegionCoord;
/*     */ import journeymap.client.texture.TextureCache;
/*     */ import journeymap.client.ui.fullscreen.Fullscreen;
/*     */ import net.minecraft.client.Minecraft;
/*     */ import net.minecraft.core.BlockPos;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class RegionRenderer
/*     */ {
/*     */   private static RegionRenderer instance;
/*     */   public static boolean TOGGLED = false;
/*     */   
/*     */   public static void render(boolean toggled) {
/*  41 */     if (instance == null)
/*     */     {
/*  43 */       instance = new RegionRenderer();
/*     */     }
/*  45 */     TOGGLED = toggled;
/*  46 */     if (toggled) {
/*     */       
/*  48 */       ClientAPI.INSTANCE.flagOverlaysForRerender();
/*     */ 
/*     */       
/*  51 */       PolygonOverlay overlay = instance.createTexturedOverlay(instance.getRegions().get(0));
/*  52 */       ClientAPI.INSTANCE.show((Displayable)overlay);
/*     */     
/*     */     }
/*     */     else {
/*     */       
/*  57 */       ClientAPI.INSTANCE.removeAll("journeymap", DisplayType.Polygon);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private Stack<RegionCoord> getRegions() {
/*     */     try {
/*  65 */       Minecraft minecraft = Minecraft.getInstance();
/*  66 */       RegionLoader regionLoader = new RegionLoader(minecraft, Fullscreen.state().getMapType(), true);
/*  67 */       return regionLoader.getRegions();
/*     */     }
/*  69 */     catch (Exception e) {
/*     */       
/*  71 */       throw new RuntimeException("Unable to load regions", e);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   protected PolygonOverlay createOverlay(RegionCoord rCoord) {
/*  77 */     String groupName = "Region";
/*  78 */     String label = "x:" + rCoord.regionX + ", z:" + rCoord.regionZ;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  85 */     ShapeProperties shapeProps = (new ShapeProperties()).setStrokeWidth(2.0F).setStrokeColor(16711680).setStrokeOpacity(0.7F).setFillOpacity(0.2F);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  93 */     TextProperties textProps = (new TextProperties()).setBackgroundColor(34).setBackgroundOpacity(0.5F).setColor(65280).setOpacity(1.0F).setFontShadow(true);
/*     */ 
/*     */     
/*  96 */     int x = rCoord.getMinChunkX() << 4;
/*  97 */     int y = 70;
/*  98 */     int z = rCoord.getMinChunkZ() << 4;
/*  99 */     int maxX = (rCoord.getMaxChunkX() << 4) + 15;
/* 100 */     int maxZ = (rCoord.getMaxChunkZ() << 4) + 15;
/* 101 */     BlockPos sw = new BlockPos(x + 1, y, maxZ + 1);
/* 102 */     BlockPos se = new BlockPos(maxX + 1, y, maxZ + 1);
/* 103 */     BlockPos ne = new BlockPos(maxX + 1, y, z + 1);
/* 104 */     BlockPos nw = new BlockPos(x + 1, y, z + 1);
/* 105 */     MapPolygon regionPolygon = new MapPolygon(new BlockPos[] { sw, se, ne, nw });
/*     */ 
/*     */     
/* 108 */     PolygonOverlay overlay = new PolygonOverlay("journeymap", rCoord.dimension, shapeProps, regionPolygon);
/*     */ 
/*     */     
/* 111 */     overlay.setOverlayGroupName(groupName)
/* 112 */       .setLabel(label)
/* 113 */       .setTextProperties(textProps)
/* 114 */       .setActiveUIs(new Context.UI[] { Context.UI.Fullscreen, Context.UI.Webmap
/* 115 */         }).setActiveMapTypes(Context.MapType.all());
/*     */     
/* 117 */     return overlay;
/*     */   }
/*     */ 
/*     */   
/*     */   protected PolygonOverlay createTexturedOverlay(RegionCoord rCoord) {
/* 122 */     String displayId = "Region Display" + String.valueOf(rCoord);
/* 123 */     String groupName = "Region";
/* 124 */     String label = "x:" + rCoord.regionX + ", z:" + rCoord.regionZ;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 137 */     ShapeProperties shapeProps = (new ShapeProperties()).setStrokeWidth(5.0F).setStrokeColor(16711680).setStrokeOpacity(0.7F).setFillOpacity(0.2F).setImageLocation(TextureCache.Logo).setTexturePositionX(-20.0D).setTexturePositionY(8.0D).setTextureScaleX(0.8D).setTextureScaleY(0.4D).setFillColor(65280);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 145 */     TextProperties textProps = (new TextProperties()).setBackgroundColor(34).setBackgroundOpacity(0.5F).setColor(65280).setOpacity(1.0F).setFontShadow(true);
/*     */ 
/*     */     
/* 148 */     int x = rCoord.getMinChunkX() << 4;
/* 149 */     int y = 70;
/* 150 */     int z = rCoord.getMinChunkZ() << 4;
/* 151 */     int maxX = (rCoord.getMaxChunkX() << 4) + 15;
/* 152 */     int maxZ = (rCoord.getMaxChunkZ() << 4) + 15;
/* 153 */     List<BlockPos> blockPosList = new ArrayList<>();
/* 154 */     blockPosList.add(new BlockPos(384, 256, 128));
/*     */     
/* 156 */     blockPosList.add(new BlockPos(144, 256, 304));
/* 157 */     blockPosList.add(new BlockPos(144, 256, 224));
/* 158 */     blockPosList.add(new BlockPos(160, 256, 224));
/* 159 */     blockPosList.add(new BlockPos(160, 256, 128));
/* 160 */     blockPosList.add(new BlockPos(272, 256, 128));
/* 161 */     blockPosList.add(new BlockPos(272, 256, 144));
/* 162 */     blockPosList.add(new BlockPos(288, 256, 144));
/* 163 */     blockPosList.add(new BlockPos(288, 256, 128));
/* 164 */     blockPosList.add(new BlockPos(368, 256, 128));
/*     */     
/* 166 */     MapPolygon hole = PolygonHelper.createChunkPolygonForWorldCoords(284, 70, 197);
/*     */ 
/*     */     
/* 169 */     PolygonOverlay overlay = new PolygonOverlay("journeymap", rCoord.dimension, shapeProps, new MapPolygon(blockPosList), Collections.singletonList(hole));
/*     */ 
/*     */     
/* 172 */     overlay.setOverlayGroupName(groupName)
/* 173 */       .setTitle("Test Title")
/* 174 */       .setLabel(label)
/* 175 */       .setTextProperties(textProps)
/* 176 */       .setActiveUIs(new Context.UI[] { Context.UI.Fullscreen, Context.UI.Minimap, Context.UI.Webmap
/* 177 */         }).setActiveMapTypes(Context.MapType.all());
/*     */     
/* 179 */     return overlay;
/*     */   }
/*     */ }


/* Location:              C:\Users\Administrator\Downloads\journeymap-forge-1.21-6.0.0-beta.18.jar!\journeymap\client\render\map\RegionRenderer.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */