/*     */ package journeymap.client.render;
/*     */ 
/*     */ import journeymap.client.JourneymapClient;
/*     */ import net.minecraft.client.renderer.RenderStateShard;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class RegionTileStateShard
/*     */   extends RenderStateShard.EmptyTextureStateShard
/*     */ {
/*     */   private final int textureId;
/*     */   
/*     */   public RegionTileStateShard(int textureId) {
/* 118 */     super(() -> {
/*     */           RenderWrapper.bindTexture(textureId);
/*     */           RenderWrapper.texParameter(3553, 10241, 9984);
/*     */           RenderWrapper.texParameter(3553, 10240, 9728);
/*     */           RenderWrapper.texParameter(3553, 10242, 33071);
/*     */           RenderWrapper.texParameter(3553, 10243, 33071);
/*     */           int mipmapLevels = (JourneymapClient.getInstance().getCoreProperties()).mipmapLevels.get().intValue();
/*     */           RenderWrapper.texParameter(3553, 33085, mipmapLevels);
/*     */           RenderWrapper.texParameter(3553, 33082, 0);
/*     */           RenderWrapper.texParameter(3553, 33083, mipmapLevels);
/*     */           RenderWrapper.texParameter(3553, 34049, 0);
/*     */           RenderWrapper.setShaderTexture(0, textureId);
/*     */         }() -> {
/*     */         
/*     */         });
/* 133 */     this.textureId = textureId;
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 138 */     return this.name + "[" + this.name + ")]";
/*     */   }
/*     */ }


/* Location:              C:\Users\Administrator\Downloads\journeymap-forge-1.21-6.0.0-beta.18.jar!\journeymap\client\render\JMRenderTypes$RegionTileStateShard.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */