/*     */ package journeymap.client.render;
/*     */ 
/*     */ import com.mojang.blaze3d.platform.GlStateManager;
/*     */ import com.mojang.blaze3d.systems.RenderSystem;
/*     */ import com.mojang.blaze3d.vertex.VertexSorting;
/*     */ import java.nio.IntBuffer;
/*     */ import java.util.function.Supplier;
/*     */ import journeymap.client.JourneymapClient;
/*     */ import journeymap.client.log.JMLogger;
/*     */ import net.minecraft.client.Minecraft;
/*     */ import net.minecraft.client.renderer.ShaderInstance;
/*     */ import net.minecraft.resources.ResourceLocation;
/*     */ import org.joml.Matrix4f;
/*     */ import org.joml.Matrix4fStack;
/*     */ import org.lwjgl.opengl.GL11C;
/*     */ import org.lwjgl.opengl.GL30C;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class RenderWrapper
/*     */ {
/*     */   public static final int GL_TEXTURE_2D = 3553;
/*     */   public static final int GL_NEAREST = 9728;
/*     */   public static final int GL_LINEAR = 9729;
/*     */   public static final int GL_TEXTURE_MAG_FILTER = 10240;
/*     */   public static final int GL_TEXTURE_MIN_FILTER = 10241;
/*     */   public static final int GL_NEAREST_MIPMAP_NEAREST = 9984;
/*     */   public static final int GL_NEAREST_MIPMAP_LINEAR = 9986;
/*     */   public static final int GL_LINEAR_MIPMAP_LINEAR = 9987;
/*     */   public static final int GL_TEXTURE_WRAP_S = 10242;
/*     */   public static final int GL_TEXTURE_WRAP_T = 10243;
/*     */   public static final int GL_REPEAT = 10497;
/*     */   public static final int GL_SRC_ALPHA = 770;
/*     */   public static final int GL_ONE_MINUS_SRC_ALPHA = 771;
/*     */   public static final int GL_ZERO = 0;
/*     */   public static final int GL_DEPTH_BUFFER_BIT = 256;
/*     */   public static final int GL_LEQUAL = 515;
/*     */   public static final int GL_GREATER = 516;
/*     */   public static final int GL_GEQUAL = 518;
/*     */   public static final int GL_NO_ERROR = 0;
/*     */   public static final int GL_VIEWPORT = 2978;
/*     */   public static final int UNSIGNED_INT_8_8_8_8_REV = 33639;
/*     */   public static final int GL_UNSIGNED_BYTE = 5121;
/*     */   public static final int GL_BGRA = 32993;
/*     */   public static final int GL_RGBA = 6408;
/*     */   public static final int GL_CLAMP_TO_EDGE = 33071;
/*     */   public static final int GL_TEXTURE_MAX_LEVEL = 33085;
/*     */   public static final int GL_TEXTURE_MAX_LOD = 33083;
/*     */   public static final int GL_TEXTURE_MIN_LOD = 33082;
/*     */   public static final int GL_MIRRORED_REPEAT = 33648;
/*     */   public static final int GL_TEXTURE_LOD_BIAS = 34049;
/*  62 */   public static final boolean errorCheck = (JourneymapClient.getInstance().getCoreProperties()).glErrorChecking.get().booleanValue();
/*     */ 
/*     */ 
/*     */   
/*     */   public static void setColor4f(float red, float green, float blue, float alpha) {
/*  67 */     RenderSystem.setShaderColor(red, green, blue, alpha);
/*  68 */     checkGLError("setColor4f");
/*     */   }
/*     */ 
/*     */   
/*     */   public static void clearColor(float red, float green, float blue, float alpha) {
/*  73 */     RenderSystem.clearColor(red, green, blue, alpha);
/*  74 */     checkGLError("clearColor");
/*     */   }
/*     */ 
/*     */   
/*     */   public static void enableBlend() {
/*  79 */     RenderSystem.enableBlend();
/*  80 */     checkGLError("enableBlend");
/*     */   }
/*     */ 
/*     */   
/*     */   public static void disableBlend() {
/*  85 */     RenderSystem.disableBlend();
/*  86 */     checkGLError("disableBlend");
/*     */   }
/*     */ 
/*     */   
/*     */   public static void defaultBlendFunc() {
/*  91 */     RenderSystem.defaultBlendFunc();
/*  92 */     checkGLError("defaultBlendFunc");
/*     */   }
/*     */ 
/*     */   
/*     */   public static void enableDepthTest() {
/*  97 */     RenderSystem.enableDepthTest();
/*  98 */     checkGLError("enableDepthTest");
/*     */   }
/*     */ 
/*     */   
/*     */   public static void disableDepthTest() {
/* 103 */     RenderSystem.disableDepthTest();
/* 104 */     checkGLError("disableDepthTest");
/*     */   }
/*     */ 
/*     */   
/*     */   public static Matrix4f getProjectionMatrix() {
/* 109 */     Matrix4f projectionMatrix = RenderSystem.getProjectionMatrix();
/* 110 */     checkGLError("getProjectionMatrix");
/* 111 */     return projectionMatrix;
/*     */   }
/*     */ 
/*     */   
/*     */   public static void enableCull() {
/* 116 */     RenderSystem.enableCull();
/* 117 */     checkGLError("enableCull");
/*     */   }
/*     */ 
/*     */   
/*     */   public static void disableCull() {
/* 122 */     RenderSystem.disableCull();
/* 123 */     checkGLError("disableCull");
/*     */   }
/*     */ 
/*     */   
/*     */   public static int getError() {
/* 128 */     return GlStateManager._getError();
/*     */   }
/*     */ 
/*     */   
/*     */   public static void depthMask(boolean flag) {
/* 133 */     RenderSystem.depthMask(flag);
/* 134 */     checkGLError("depthMask");
/*     */   }
/*     */ 
/*     */   
/*     */   public static void getIntegerv(int pname, IntBuffer params) {
/* 139 */     GL11C.glGetIntegerv(pname, params);
/* 140 */     checkGLError("getIntegerv");
/*     */   }
/*     */ 
/*     */   
/*     */   public static void texParameter(int target, int pname, int param) {
/* 145 */     RenderSystem.texParameter(target, pname, param);
/* 146 */     checkGLError("texParameter");
/*     */   }
/*     */ 
/*     */   
/*     */   public static void blendFuncSeparate(int sfactorRGB, int dfactorRGB, int sfactorAlpha, int dfactorAlpha) {
/* 151 */     RenderSystem.blendFuncSeparate(sfactorRGB, dfactorRGB, sfactorAlpha, dfactorAlpha);
/* 152 */     checkGLError("blendFuncSeparate");
/*     */   }
/*     */ 
/*     */   
/*     */   public static void blendFunc(int sfactor, int dfactor) {
/* 157 */     RenderSystem.blendFunc(sfactor, dfactor);
/* 158 */     checkGLError("blendFunc");
/*     */   }
/*     */ 
/*     */   
/*     */   public static void bindFramebuffer(int target, int framebuffer) {
/* 163 */     GlStateManager._glBindFramebuffer(target, framebuffer);
/* 164 */     checkGLError("bindFramebuffer");
/*     */   }
/*     */ 
/*     */   
/*     */   public static void blitFramebuffer(int srcX0, int srcY0, int srcX1, int srcY1, int dstX0, int dstY0, int dstX1, int dstY1, int mask, int filter) {
/* 169 */     GlStateManager._glBlitFrameBuffer(srcX0, srcY0, srcX1, srcY1, dstX0, dstY0, dstX1, dstY1, mask, filter);
/* 170 */     checkGLError("blitFramebuffer");
/*     */   }
/*     */ 
/*     */   
/*     */   public static void setShader(Supplier<ShaderInstance> shaderInstanceSupplier) {
/* 175 */     RenderSystem.setShader(shaderInstanceSupplier);
/* 176 */     checkGLError("setShader");
/*     */   }
/*     */ 
/*     */   
/*     */   public static void generateMipmap(int target) {
/* 181 */     GL30C.glGenerateMipmap(target);
/* 182 */     checkGLError("generateMipmap");
/*     */   }
/*     */ 
/*     */   
/*     */   public static void setShaderTexture(int index, int id) {
/* 187 */     RenderSystem.setShaderTexture(index, id);
/* 188 */     checkGLError("setShaderTexture");
/*     */   }
/*     */ 
/*     */   
/*     */   public static void setShaderTexture(int index, ResourceLocation resourceLocation) {
/* 193 */     RenderSystem.setShaderTexture(index, resourceLocation);
/* 194 */     checkGLError("setShaderTexture");
/*     */   }
/*     */ 
/*     */   
/*     */   public static void activeTexture(int texture) {
/* 199 */     RenderSystem.activeTexture(texture);
/* 200 */     checkGLError("activeTexture");
/*     */   }
/*     */ 
/*     */   
/*     */   public static void bindTextureForSetup(int id) {
/* 205 */     RenderSystem.bindTextureForSetup(id);
/* 206 */     checkGLError("bindTextureForSetup");
/*     */   }
/*     */ 
/*     */   
/*     */   public static void bindTexture(int id) {
/* 211 */     RenderSystem.bindTexture(id);
/* 212 */     checkGLError("bindTexture");
/*     */   }
/*     */ 
/*     */   
/*     */   public static void clear(int mask) {
/* 217 */     RenderSystem.clear(mask, Minecraft.ON_OSX);
/* 218 */     checkGLError("clear");
/*     */   }
/*     */ 
/*     */   
/*     */   public static void depthFunc(int func) {
/* 223 */     RenderSystem.depthFunc(func);
/* 224 */     checkGLError("depthFunc");
/*     */   }
/*     */ 
/*     */   
/*     */   public static void colorMask(boolean red, boolean green, boolean blue, boolean alpha) {
/* 229 */     RenderSystem.colorMask(red, green, blue, alpha);
/* 230 */     checkGLError("colorMask");
/*     */   }
/*     */ 
/*     */   
/*     */   public static void setProjectionMatrix(Matrix4f matrix4f, VertexSorting sorting) {
/* 235 */     RenderSystem.setProjectionMatrix(matrix4f, sorting);
/* 236 */     checkGLError("setProjectionMatrix");
/*     */   }
/*     */ 
/*     */   
/*     */   public static Matrix4fStack getModelViewStack() {
/* 241 */     Matrix4fStack stack = RenderSystem.getModelViewStack();
/* 242 */     checkGLError("getModelViewStack");
/* 243 */     return stack;
/*     */   }
/*     */ 
/*     */   
/*     */   public static void lineWidth(float stroke) {
/* 248 */     RenderSystem.lineWidth(stroke);
/* 249 */     checkGLError("lineWidth");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void pixelStore(int pname, int param) {
/* 261 */     RenderSystem.pixelStore(pname, param);
/* 262 */     checkGLError("pixelStore");
/*     */   }
/*     */ 
/*     */   
/*     */   public static void texImage2D(int target, int level, int internalFormat, int width, int height, int border, int format, int type, IntBuffer pixels) {
/* 267 */     GlStateManager._texImage2D(target, level, internalFormat, width, height, border, format, type, pixels);
/* 268 */     checkGLError("texImage2D");
/*     */   }
/*     */ 
/*     */   
/*     */   public static void applyModelViewMatrix() {
/* 273 */     RenderSystem.applyModelViewMatrix();
/* 274 */     checkGLError("applyModelViewMatrix");
/*     */   }
/*     */ 
/*     */   
/*     */   public static void texSubImage2D(int target, int level, int xoffset, int yoffset, int width, int height, int format, int type, long pixels) {
/* 279 */     GlStateManager._texSubImage2D(target, level, xoffset, yoffset, width, height, format, type, pixels);
/* 280 */     checkGLError("texSubImage2D");
/*     */   }
/*     */ 
/*     */   
/*     */   public static boolean checkGLError(String method) {
/* 285 */     if (errorCheck) {
/*     */       
/* 287 */       boolean hasError = false;
/*     */       int err;
/* 289 */       while ((err = getError()) != 0) {
/*     */         
/* 291 */         hasError = true;
/* 292 */         JMLogger.logOnce("GL Error in method: " + method + " ERROR: " + err);
/*     */       } 
/* 294 */       return hasError;
/*     */     } 
/* 296 */     return false;
/*     */   }
/*     */ }


/* Location:              C:\Users\Administrator\Downloads\journeymap-forge-1.21-6.0.0-beta.18.jar!\journeymap\client\render\RenderWrapper.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */