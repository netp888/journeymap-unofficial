/*    */ package journeymap.client.render;
/*    */ 
/*    */ import java.util.HashMap;
/*    */ import java.util.List;
/*    */ import java.util.Map;
/*    */ import journeymap.client.Constants;
/*    */ import journeymap.common.properties.config.StringField;
/*    */ 
/*    */ public class RegionTileShaders
/*    */   implements StringField.ValuesProvider
/*    */ {
/* 12 */   public static final List<String> REGION_SHADERS = List.of("default", "grayscale", "sepia_1", "sepia_2", "sepia_3");
/* 13 */   private static final Map<String, ShaderKeys> idMap = new HashMap<>();
/* 14 */   private static final Map<String, ShaderKeys> keyMap = new HashMap<>();
/*    */ 
/*    */   
/*    */   static {
/* 18 */     for (String id : REGION_SHADERS) {
/*    */       
/* 20 */       ShaderKeys shader = new ShaderKeys(id);
/* 21 */       idMap.put(id, shader);
/* 22 */       keyMap.put(shader.key(), shader);
/*    */     } 
/*    */   }
/*    */   public static final class ShaderKeys extends Record { private final String id;
/* 26 */     public ShaderKeys(String id) { this.id = id; } public final String toString() { // Byte code:
/*    */       //   0: aload_0
/*    */       //   1: <illegal opcode> toString : (Ljourneymap/client/render/RegionTileShaders$ShaderKeys;)Ljava/lang/String;
/*    */       //   6: areturn
/*    */       // Line number table:
/*    */       //   Java source line number -> byte code offset
/*    */       //   #26	-> 0
/*    */       // Local variable table:
/*    */       //   start	length	slot	name	descriptor
/* 26 */       //   0	7	0	this	Ljourneymap/client/render/RegionTileShaders$ShaderKeys; } public String id() { return this.id; }
/*    */     public final int hashCode() { // Byte code:
/*    */       //   0: aload_0
/*    */       //   1: <illegal opcode> hashCode : (Ljourneymap/client/render/RegionTileShaders$ShaderKeys;)I
/*    */       //   6: ireturn
/*    */       // Line number table:
/*    */       //   Java source line number -> byte code offset
/*    */       //   #26	-> 0
/*    */       // Local variable table:
/*    */       //   start	length	slot	name	descriptor
/*    */       //   0	7	0	this	Ljourneymap/client/render/RegionTileShaders$ShaderKeys; } public final boolean equals(Object o) {
/*    */       // Byte code:
/*    */       //   0: aload_0
/*    */       //   1: aload_1
/*    */       //   2: <illegal opcode> equals : (Ljourneymap/client/render/RegionTileShaders$ShaderKeys;Ljava/lang/Object;)Z
/*    */       //   7: ireturn
/*    */       // Line number table:
/*    */       //   Java source line number -> byte code offset
/*    */       //   #26	-> 0
/*    */       // Local variable table:
/*    */       //   start	length	slot	name	descriptor
/*    */       //   0	8	0	this	Ljourneymap/client/render/RegionTileShaders$ShaderKeys;
/*    */       //   0	8	1	o	Ljava/lang/Object;
/*    */     } public String key() {
/* 30 */       return String.format("jm.common.map_filter.%s", new Object[] { id() });
/*    */     }
/*    */ 
/*    */     
/*    */     public String name() {
/* 35 */       return Constants.getString("jm.common.map_filter.%s", new Object[] { id() });
/*    */     }
/*    */ 
/*    */     
/*    */     public String tooltip() {
/* 40 */       return Constants.getString("jm.common.map_filter.%s.tooltip", new Object[] { id() });
/*    */     } }
/*    */ 
/*    */ 
/*    */   
/*    */   public static String from(String key) {
/* 46 */     return ((ShaderKeys)keyMap.get(key)).id();
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public List<String> getStrings() {
/* 53 */     return REGION_SHADERS.stream().map(value -> ((ShaderKeys)idMap.get(value)).name()).toList();
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public String getDefaultString() {
/* 59 */     return ((ShaderKeys)idMap.get(REGION_SHADERS.get(0))).name();
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public String getTooltip(String value) {
/* 65 */     return ((ShaderKeys)keyMap.get(value)).tooltip();
/*    */   }
/*    */ }


/* Location:              C:\Users\Administrator\Downloads\journeymap-forge-1.21-6.0.0-beta.18.jar!\journeymap\client\render\RegionTileShaders.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */