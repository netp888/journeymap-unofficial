/*     */ package journeymap.client.task.multi;
/*     */ 
/*     */ import com.google.common.cache.Cache;
/*     */ import com.google.common.cache.CacheBuilder;
/*     */ import java.io.File;
/*     */ import java.text.DecimalFormat;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.Collection;
/*     */ import java.util.List;
/*     */ import java.util.concurrent.TimeUnit;
/*     */ import journeymap.client.Constants;
/*     */ import journeymap.client.JourneymapClient;
/*     */ import journeymap.client.cartography.ChunkRenderController;
/*     */ import journeymap.client.data.DataCache;
/*     */ import journeymap.client.feature.Feature;
/*     */ import journeymap.client.feature.FeatureManager;
/*     */ import journeymap.client.model.ChunkMD;
/*     */ import journeymap.client.model.EntityDTO;
/*     */ import journeymap.client.model.MapType;
/*     */ import journeymap.client.properties.CoreProperties;
/*     */ import journeymap.common.Journeymap;
/*     */ import net.minecraft.client.Minecraft;
/*     */ import net.minecraft.world.entity.Entity;
/*     */ import net.minecraft.world.level.ChunkPos;
/*     */ import net.minecraft.world.level.Level;
/*     */ import net.minecraft.world.level.entity.EntityInLevelCallback;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MapPlayerTask
/*     */   extends BaseMapTask
/*     */ {
/*  40 */   private static int MAX_STALE_MILLISECONDS = 30000;
/*  41 */   private static int MAX_BATCH_SIZE = 32;
/*  42 */   private static final DecimalFormat decFormat = new DecimalFormat("##.#");
/*     */   private static volatile long lastTaskCompleted;
/*     */   private static long lastTaskTime;
/*     */   private static double lastTaskAvgChunkTime;
/*  46 */   private static final Cache<String, String> tempDebugLines = CacheBuilder.newBuilder()
/*  47 */     .maximumSize(20L)
/*  48 */     .expireAfterWrite(1500L, TimeUnit.MILLISECONDS)
/*  49 */     .build();
/*     */   
/*  51 */   private final int maxRuntime = (JourneymapClient.getInstance().getCoreProperties()).renderDelay.get().intValue() * 3000;
/*  52 */   private int scheduledChunks = 0;
/*     */   
/*     */   private long startNs;
/*     */   private long elapsedNs;
/*     */   
/*     */   private MapPlayerTask(ChunkRenderController chunkRenderController, Level world, MapType mapType, Collection<ChunkPos> chunkCoords) {
/*  58 */     super(chunkRenderController, world, mapType, chunkCoords, false, true, 10000);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void forceNearbyRemap() {
/*  66 */     synchronized (MapPlayerTask.class) {
/*     */       
/*  68 */       DataCache.INSTANCE.invalidateChunkMDCache();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static MapPlayerTaskBatch create(ChunkRenderController chunkRenderController, EntityDTO player) {
/*     */     MapType mapType;
/*  81 */     boolean surfaceAllowed = FeatureManager.getInstance().isAllowed(Feature.MapSurface);
/*  82 */     boolean cavesAllowed = FeatureManager.getInstance().isAllowed(Feature.MapCaves);
/*  83 */     boolean topoAllowed = FeatureManager.getInstance().isAllowed(Feature.MapTopo);
/*  84 */     boolean biomeAllowed = FeatureManager.getInstance().isAllowed(Feature.MapBiome);
/*  85 */     if (!surfaceAllowed && !cavesAllowed && !topoAllowed && !biomeAllowed)
/*     */     {
/*  87 */       return null;
/*     */     }
/*     */     
/*  90 */     Entity playerEntity = player.entityRef.get();
/*  91 */     if (playerEntity == null)
/*     */     {
/*  93 */       return null;
/*     */     }
/*  95 */     boolean underground = player.underground.booleanValue();
/*     */ 
/*     */     
/*  98 */     if (underground) {
/*     */       
/* 100 */       mapType = MapType.underground(player);
/*     */     }
/*     */     else {
/*     */       
/* 104 */       long time = playerEntity.getCommandSenderWorld().getLevelData().getDayTime() % 24000L;
/* 105 */       mapType = (time < 13800L) ? MapType.day(player) : MapType.night(player);
/*     */     } 
/*     */     
/* 108 */     List<ITask> tasks = new ArrayList<>(2);
/* 109 */     tasks.add(new MapPlayerTask(chunkRenderController, playerEntity.getCommandSenderWorld(), mapType, new ArrayList<>()));
/*     */     
/* 111 */     if (underground) {
/*     */       
/* 113 */       if (surfaceAllowed && (JourneymapClient.getInstance().getCoreProperties()).alwaysMapSurface.get().booleanValue())
/*     */       {
/* 115 */         tasks.add(new MapPlayerTask(chunkRenderController, playerEntity.getCommandSenderWorld(), MapType.day(player), new ArrayList<>()));
/*     */       
/*     */       }
/*     */     
/*     */     }
/* 120 */     else if (cavesAllowed && (JourneymapClient.getInstance().getCoreProperties()).alwaysMapCaves.get().booleanValue()) {
/*     */       
/* 122 */       tasks.add(new MapPlayerTask(chunkRenderController, playerEntity.getCommandSenderWorld(), MapType.underground(player), new ArrayList<>()));
/*     */     } 
/*     */ 
/*     */     
/* 126 */     if (topoAllowed && (JourneymapClient.getInstance().getCoreProperties()).mapTopography.get().booleanValue())
/*     */     {
/* 128 */       tasks.add(new MapPlayerTask(chunkRenderController, playerEntity.getCommandSenderWorld(), MapType.topo(player), new ArrayList<>()));
/*     */     }
/*     */     
/* 131 */     if (biomeAllowed && (JourneymapClient.getInstance().getCoreProperties()).mapBiome.get().booleanValue())
/*     */     {
/* 133 */       tasks.add(new MapPlayerTask(chunkRenderController, playerEntity.getCommandSenderWorld(), MapType.biome(player), new ArrayList<>()));
/*     */     }
/*     */     
/* 136 */     return new MapPlayerTaskBatch(tasks);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String[] getDebugStats() {
/*     */     try {
/* 148 */       CoreProperties coreProperties = JourneymapClient.getInstance().getCoreProperties();
/* 149 */       boolean underground = (DataCache.getPlayer()).underground.booleanValue();
/* 150 */       ArrayList<String> lines = new ArrayList<>(tempDebugLines.asMap().values());
/*     */       
/* 152 */       if (underground || coreProperties.alwaysMapCaves.get().booleanValue())
/*     */       {
/* 154 */         lines.add(RenderSpec.getUndergroundSpec().getDebugStats());
/*     */       }
/*     */       
/* 157 */       if (!underground || coreProperties.alwaysMapSurface.get().booleanValue())
/*     */       {
/* 159 */         lines.add(RenderSpec.getSurfaceSpec().getDebugStats());
/*     */       }
/*     */       
/* 162 */       if (!underground && coreProperties.mapTopography.get().booleanValue())
/*     */       {
/* 164 */         lines.add(RenderSpec.getTopoSpec().getDebugStats());
/*     */       }
/*     */       
/* 167 */       return lines.<String>toArray(new String[lines.size()]);
/*     */     }
/* 169 */     catch (Throwable t) {
/*     */       
/* 171 */       logger.error(t);
/* 172 */       return new String[0];
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void addTempDebugMessage(String key, String message) {
/* 184 */     if (Minecraft.getInstance().getDebugOverlay().showProfilerChart())
/*     */     {
/* 186 */       tempDebugLines.put(key, message);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void removeTempDebugMessage(String key) {
/* 197 */     tempDebugLines.invalidate(key);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String getSimpleStats() {
/* 207 */     int primaryRenderSize = 0;
/* 208 */     int secondaryRenderSize = 0;
/* 209 */     int totalChunks = 0;
/*     */     
/* 211 */     if ((DataCache.getPlayer()).underground.booleanValue() || (JourneymapClient.getInstance().getCoreProperties()).alwaysMapCaves.get().booleanValue()) {
/*     */       
/* 213 */       RenderSpec spec = RenderSpec.getUndergroundSpec();
/* 214 */       if (spec != null) {
/*     */         
/* 216 */         primaryRenderSize += spec.getPrimaryRenderSize();
/* 217 */         secondaryRenderSize += spec.getLastSecondaryRenderSize();
/* 218 */         totalChunks += spec.getLastTaskChunks();
/*     */       } 
/*     */     } 
/*     */     
/* 222 */     if (!(DataCache.getPlayer()).underground.booleanValue() || (JourneymapClient.getInstance().getCoreProperties()).alwaysMapSurface.get().booleanValue()) {
/*     */       
/* 224 */       RenderSpec spec = RenderSpec.getSurfaceSpec();
/* 225 */       if (spec != null) {
/*     */         
/* 227 */         primaryRenderSize += spec.getPrimaryRenderSize();
/* 228 */         secondaryRenderSize += spec.getLastSecondaryRenderSize();
/* 229 */         totalChunks += spec.getLastTaskChunks();
/*     */       } 
/*     */     } 
/*     */     
/* 233 */     return Constants.getString("jm.common.renderstats", new Object[] {
/* 234 */           Integer.valueOf(totalChunks), 
/* 235 */           Integer.valueOf(primaryRenderSize), 
/* 236 */           Integer.valueOf(secondaryRenderSize), 
/* 237 */           Long.valueOf(lastTaskTime), decFormat
/* 238 */           .format(lastTaskAvgChunkTime)
/*     */         });
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static long getlastTaskCompleted() {
/* 248 */     return lastTaskCompleted;
/*     */   }
/*     */ 
/*     */   
/*     */   public void initTask(Minecraft minecraft, JourneymapClient jm, File jmWorldDir, boolean threadLogging) {
/*     */     RenderSpec renderSpec;
/* 254 */     this.startNs = System.nanoTime();
/*     */ 
/*     */ 
/*     */     
/* 258 */     if (this.mapType.isUnderground()) {
/*     */       
/* 260 */       renderSpec = RenderSpec.getUndergroundSpec();
/*     */     }
/* 262 */     else if (this.mapType.isTopo()) {
/*     */       
/* 264 */       renderSpec = RenderSpec.getTopoSpec();
/*     */     }
/*     */     else {
/*     */       
/* 268 */       renderSpec = RenderSpec.getSurfaceSpec();
/*     */     } 
/*     */     
/* 271 */     long now = System.currentTimeMillis();
/* 272 */     List<ChunkPos> renderArea = renderSpec.getRenderAreaCoords();
/* 273 */     int maxBatchSize = renderArea.size() / 4;
/*     */ 
/*     */     
/* 276 */     renderArea.removeIf(chunkPos -> {
/*     */           ChunkMD chunkMD = DataCache.INSTANCE.getChunkMD(chunkPos.toLong());
/*     */ 
/*     */ 
/*     */           
/*     */           if (chunkMD == null || !chunkMD.hasChunk() || now - chunkMD.getLastRendered(this.mapType) < 30000L) {
/*     */             return true;
/*     */           }
/*     */ 
/*     */ 
/*     */           
/*     */           if (!chunkMD.getDimension().equals(this.mapType.dimension)) {
/*     */             return true;
/*     */           }
/*     */ 
/*     */           
/*     */           chunkMD.resetBlockData(this.mapType);
/*     */ 
/*     */           
/*     */           return false;
/*     */         });
/*     */ 
/*     */     
/* 299 */     if (renderArea.size() <= maxBatchSize) {
/*     */       
/* 301 */       this.chunkCoords.addAll(renderArea);
/*     */     }
/*     */     else {
/*     */       
/* 305 */       List<ChunkPos> list = Arrays.asList(renderArea.<ChunkPos>toArray(new ChunkPos[renderArea.size()]));
/* 306 */       this.chunkCoords.addAll(list.subList(0, maxBatchSize));
/*     */     } 
/*     */     
/* 309 */     this.scheduledChunks = this.chunkCoords.size();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected void complete(int mappedChunks, boolean cancelled, boolean hadError) {
/* 315 */     this.elapsedNs = System.nanoTime() - this.startNs;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public int getMaxRuntime() {
/* 321 */     return this.maxRuntime;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static class Manager
/*     */     implements ITaskManager
/*     */   {
/* 334 */     final int mapTaskDelay = (JourneymapClient.getInstance().getCoreProperties()).renderDelay.get().intValue() * 1000;
/*     */ 
/*     */ 
/*     */     
/*     */     boolean enabled;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Class<? extends BaseMapTask> getTaskClass() {
/* 344 */       return (Class)MapPlayerTask.class;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public boolean enableTask(Minecraft minecraft, Object params) {
/* 350 */       this.enabled = true;
/* 351 */       return this.enabled;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public boolean isEnabled(Minecraft minecraft) {
/* 357 */       return this.enabled;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public void disableTask(Minecraft minecraft) {
/* 363 */       this.enabled = false;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public ITask getTask(Minecraft minecraft) {
/* 370 */       if (this.enabled && minecraft.player.levelCallback != EntityInLevelCallback.NULL)
/*     */       {
/* 372 */         if (System.currentTimeMillis() - MapPlayerTask.lastTaskCompleted >= this.mapTaskDelay) {
/*     */           
/* 374 */           ChunkRenderController chunkRenderController = JourneymapClient.getInstance().getChunkRenderController();
/* 375 */           return MapPlayerTask.create(chunkRenderController, DataCache.getPlayer());
/*     */         } 
/*     */       }
/*     */       
/* 379 */       return null;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public void taskAccepted(ITask task, boolean accepted) {}
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static class MapPlayerTaskBatch
/*     */     extends TaskBatch
/*     */   {
/*     */     public MapPlayerTaskBatch(List<ITask> tasks) {
/* 402 */       super(tasks);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public void performTask(Minecraft mc, JourneymapClient jm, File jmWorldDir, boolean threadLogging) throws InterruptedException {
/* 408 */       if (mc.player == null) {
/*     */         return;
/*     */       }
/*     */ 
/*     */       
/* 413 */       this.startNs = System.nanoTime();
/* 414 */       List<ITask> tasks = new ArrayList<>(this.taskList);
/* 415 */       super.performTask(mc, jm, jmWorldDir, threadLogging);
/*     */       
/* 417 */       this.elapsedNs = System.nanoTime() - this.startNs;
/* 418 */       MapPlayerTask.lastTaskTime = TimeUnit.NANOSECONDS.toMillis(this.elapsedNs);
/* 419 */       MapPlayerTask.lastTaskCompleted = System.currentTimeMillis();
/*     */ 
/*     */       
/* 422 */       int chunkCount = 0;
/* 423 */       for (ITask task : tasks) {
/*     */         
/* 425 */         if (task instanceof MapPlayerTask) {
/*     */           
/* 427 */           MapPlayerTask mapPlayerTask = (MapPlayerTask)task;
/* 428 */           chunkCount += mapPlayerTask.scheduledChunks;
/* 429 */           if (mapPlayerTask.mapType.isUnderground()) {
/*     */             
/* 431 */             RenderSpec.getUndergroundSpec().setLastTaskInfo(mapPlayerTask.scheduledChunks, mapPlayerTask.elapsedNs); continue;
/*     */           } 
/* 433 */           if (mapPlayerTask.mapType.isTopo()) {
/*     */             
/* 435 */             RenderSpec.getTopoSpec().setLastTaskInfo(mapPlayerTask.scheduledChunks, mapPlayerTask.elapsedNs);
/*     */             
/*     */             continue;
/*     */           } 
/* 439 */           RenderSpec.getSurfaceSpec().setLastTaskInfo(mapPlayerTask.scheduledChunks, mapPlayerTask.elapsedNs);
/*     */           
/*     */           continue;
/*     */         } 
/*     */         
/* 444 */         Journeymap.getLogger().warn("Unexpected task in batch: " + String.valueOf(task));
/*     */       } 
/*     */       
/* 447 */       MapPlayerTask.lastTaskAvgChunkTime = (this.elapsedNs / Math.max(1, chunkCount)) / 1000000.0D;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\Administrator\Downloads\journeymap-forge-1.21-6.0.0-beta.18.jar!\journeymap\client\task\multi\MapPlayerTask.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */