package journeymap.client.task.multi;

import net.minecraft.client.Minecraft;

public interface ITaskManager {
  Class<? extends ITask> getTaskClass();
  
  boolean enableTask(Minecraft paramMinecraft, Object paramObject);
  
  boolean isEnabled(Minecraft paramMinecraft);
  
  ITask getTask(Minecraft paramMinecraft);
  
  void taskAccepted(ITask paramITask, boolean paramBoolean);
  
  void disableTask(Minecraft paramMinecraft);
}


/* Location:              C:\Users\Administrator\Downloads\journeymap-forge-1.21-6.0.0-beta.18.jar!\journeymap\client\task\multi\ITaskManager.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */