package journeymap.client.task.multi;

import java.io.File;
import journeymap.client.JourneymapClient;
import net.minecraft.client.Minecraft;

public interface ITask {
  int getMaxRuntime();
  
  void performTask(Minecraft paramMinecraft, JourneymapClient paramJourneymapClient, File paramFile, boolean paramBoolean) throws InterruptedException;
}


/* Location:              C:\Users\Administrator\Downloads\journeymap-forge-1.21-6.0.0-beta.18.jar!\journeymap\client\task\multi\ITask.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */