/*    */ package journeymap.client.task.multi;
/*    */ 
/*    */ import com.mojang.blaze3d.platform.NativeImage;
/*    */ import java.io.File;
/*    */ import java.util.function.Consumer;
/*    */ import journeymap.api.v2.client.display.Context;
/*    */ import journeymap.client.io.FileHandler;
/*    */ import journeymap.client.model.MapType;
/*    */ import journeymap.common.Journeymap;
/*    */ import journeymap.common.log.LogFormatter;
/*    */ import net.minecraft.client.Minecraft;
/*    */ import net.minecraft.resources.ResourceKey;
/*    */ import net.minecraft.world.level.ChunkPos;
/*    */ import net.minecraft.world.level.Level;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ApiImageTask
/*    */   implements Runnable
/*    */ {
/*    */   final String modId;
/*    */   final ResourceKey<Level> dimension;
/*    */   final MapType mapType;
/*    */   final ChunkPos startChunk;
/*    */   final ChunkPos endChunk;
/*    */   final Integer vSlice;
/*    */   final int zoom;
/*    */   final boolean showGrid;
/*    */   final File jmWorldDir;
/*    */   final Consumer<NativeImage> callback;
/*    */   
/*    */   public ApiImageTask(String modId, ResourceKey<Level> dimension, Context.MapType apiMapType, ChunkPos startChunk, ChunkPos endChunk, Integer vSlice, int zoom, boolean showGrid, Consumer<NativeImage> callback) {
/* 42 */     this.modId = modId;
/* 43 */     this.dimension = dimension;
/* 44 */     this.startChunk = startChunk;
/* 45 */     this.endChunk = endChunk;
/* 46 */     this.zoom = zoom;
/* 47 */     this.showGrid = showGrid;
/* 48 */     this.callback = callback;
/* 49 */     this.vSlice = vSlice;
/* 50 */     this.mapType = MapType.fromApiContextMapType(apiMapType, vSlice, dimension);
/* 51 */     this.jmWorldDir = FileHandler.getJMWorldDir(Minecraft.getInstance());
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public void run() {
/* 57 */     NativeImage image = null;
/*    */ 
/*    */     
/*    */     try {
/* 61 */       int i = (int)Math.pow(2.0D, this.zoom);
/*    */     
/*    */     }
/* 64 */     catch (Throwable t) {
/*    */       
/* 66 */       Journeymap.getLogger().error("Error in ApiImageTask: {}" + String.valueOf(t), LogFormatter.toString(t));
/*    */     } 
/*    */ 
/*    */     
/* 70 */     NativeImage finalImage = image;
/* 71 */     Minecraft.getInstance().submit(() -> this.callback.accept(finalImage));
/*    */   }
/*    */ }


/* Location:              C:\Users\Administrator\Downloads\journeymap-forge-1.21-6.0.0-beta.18.jar!\journeymap\client\task\multi\ApiImageTask.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */