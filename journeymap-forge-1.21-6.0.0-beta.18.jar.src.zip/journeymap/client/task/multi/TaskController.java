/*     */ package journeymap.client.task.multi;
/*     */ 
/*     */ import java.util.LinkedList;
/*     */ import java.util.List;
/*     */ import java.util.concurrent.ArrayBlockingQueue;
/*     */ import java.util.concurrent.Executors;
/*     */ import java.util.concurrent.Future;
/*     */ import java.util.concurrent.ScheduledExecutorService;
/*     */ import java.util.concurrent.ThreadFactory;
/*     */ import java.util.concurrent.TimeUnit;
/*     */ import java.util.concurrent.locks.ReentrantLock;
/*     */ import journeymap.client.log.StatTimer;
/*     */ import journeymap.client.thread.RunnableTask;
/*     */ import journeymap.common.Journeymap;
/*     */ import journeymap.common.log.LogFormatter;
/*     */ import journeymap.common.thread.JMThreadFactory;
/*     */ import net.minecraft.client.Minecraft;
/*     */ import net.minecraft.util.profiling.ProfilerFiller;
/*     */ import org.apache.logging.log4j.Logger;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class TaskController
/*     */ {
/*  28 */   static final Logger logger = Journeymap.getLogger();
/*  29 */   final ArrayBlockingQueue<Future> queue = new ArrayBlockingQueue<>(1);
/*  30 */   final List<ITaskManager> managers = new LinkedList<>();
/*  31 */   final Minecraft minecraft = Minecraft.getInstance();
/*  32 */   final ReentrantLock lock = new ReentrantLock();
/*     */ 
/*     */   
/*     */   private volatile ScheduledExecutorService taskExecutor;
/*     */ 
/*     */   
/*     */   public TaskController() {
/*  39 */     this.managers.add(new MapRegionTask.Manager());
/*  40 */     this.managers.add(new SaveMapTask.Manager());
/*  41 */     this.managers.add(new MapPlayerTask.Manager());
/*     */   }
/*     */ 
/*     */   
/*     */   private void ensureExecutor() {
/*  46 */     if (this.taskExecutor == null || this.taskExecutor.isShutdown()) {
/*     */       
/*  48 */       this.taskExecutor = Executors.newScheduledThreadPool(1, (ThreadFactory)new JMThreadFactory("task"));
/*  49 */       this.queue.clear();
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public Boolean isActive() {
/*  55 */     return Boolean.valueOf((this.taskExecutor != null && !this.taskExecutor.isShutdown()));
/*     */   }
/*     */ 
/*     */   
/*     */   public void enableTasks() {
/*  60 */     this.queue.clear();
/*  61 */     ensureExecutor();
/*     */     
/*  63 */     List<ITaskManager> list = new LinkedList<>(this.managers);
/*  64 */     for (ITaskManager manager : this.managers) {
/*     */       
/*  66 */       boolean enabled = manager.enableTask(this.minecraft, (Object)null);
/*  67 */       if (!enabled) {
/*     */         
/*  69 */         logger.debug("Task not initially enabled: " + manager.getTaskClass().getSimpleName());
/*     */         
/*     */         continue;
/*     */       } 
/*  73 */       logger.debug("Task ready: " + manager.getTaskClass().getSimpleName());
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void clear() {
/*  81 */     this.managers.clear();
/*  82 */     this.queue.clear();
/*     */     
/*  84 */     if (this.taskExecutor != null && !this.taskExecutor.isShutdown()) {
/*     */       
/*  86 */       this.taskExecutor.shutdownNow();
/*     */       
/*     */       try {
/*  89 */         this.taskExecutor.awaitTermination(5L, TimeUnit.SECONDS);
/*     */       }
/*  91 */       catch (InterruptedException e) {
/*     */         
/*  93 */         e.printStackTrace();
/*     */       } 
/*  95 */       this.taskExecutor = null;
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   private ITaskManager getManager(Class<? extends ITaskManager> managerClass) {
/* 101 */     ITaskManager taskManager = null;
/* 102 */     for (ITaskManager manager : this.managers) {
/*     */       
/* 104 */       if (manager.getClass() == managerClass) {
/*     */         
/* 106 */         taskManager = manager;
/*     */         break;
/*     */       } 
/*     */     } 
/* 110 */     return taskManager;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isTaskManagerEnabled(Class<? extends ITaskManager> managerClass) {
/* 115 */     ITaskManager taskManager = getManager(managerClass);
/* 116 */     if (taskManager != null)
/*     */     {
/* 118 */       return taskManager.isEnabled(Minecraft.getInstance());
/*     */     }
/*     */ 
/*     */     
/* 122 */     logger.warn("1 Couldn't toggle task; manager not in controller: " + managerClass.getClass().getName());
/* 123 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void toggleTask(Class<? extends ITaskManager> managerClass, boolean enable, Object params) {
/* 130 */     ITaskManager taskManager = null;
/* 131 */     for (ITaskManager manager : this.managers) {
/*     */       
/* 133 */       if (manager.getClass() == managerClass) {
/*     */         
/* 135 */         taskManager = manager;
/*     */         break;
/*     */       } 
/*     */     } 
/* 139 */     if (taskManager != null) {
/*     */       
/* 141 */       toggleTask(taskManager, enable, params);
/*     */     }
/*     */     else {
/*     */       
/* 145 */       logger.warn("1 Couldn't toggle task; manager not in controller: " + managerClass.getClass().getName());
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void toggleTask(ITaskManager manager, boolean enable, Object params) {
/* 151 */     Minecraft minecraft = Minecraft.getInstance();
/* 152 */     if (manager.isEnabled(minecraft)) {
/*     */       
/* 154 */       if (!enable)
/*     */       {
/* 156 */         logger.debug("Disabling task: " + manager.getTaskClass().getSimpleName());
/* 157 */         manager.disableTask(minecraft);
/*     */       }
/*     */       else
/*     */       {
/* 161 */         logger.debug("Task already enabled: " + manager.getTaskClass().getSimpleName());
/*     */       
/*     */       }
/*     */     
/*     */     }
/* 166 */     else if (enable) {
/*     */       
/* 168 */       logger.debug("Enabling task: " + manager.getTaskClass().getSimpleName());
/* 169 */       manager.enableTask(minecraft, params);
/*     */     }
/*     */     else {
/*     */       
/* 173 */       logger.debug("Task already disabled: " + manager.getTaskClass().getSimpleName());
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void disableTasks() {
/* 180 */     for (ITaskManager manager : this.managers) {
/*     */       
/* 182 */       if (manager.isEnabled(this.minecraft)) {
/*     */         
/* 184 */         manager.disableTask(this.minecraft);
/* 185 */         logger.debug("Task disabled: " + manager.getTaskClass().getSimpleName());
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean hasRunningTask() {
/* 192 */     return !this.queue.isEmpty();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void queueOneOff(Runnable runnable) throws Exception {
/*     */     try {
/* 199 */       ensureExecutor();
/* 200 */       if (this.taskExecutor != null && !this.taskExecutor.isShutdown())
/*     */       {
/* 202 */         this.taskExecutor.submit(runnable);
/*     */       }
/*     */       else
/*     */       {
/* 206 */         throw new IllegalStateException("TaskExecutor isn't running");
/*     */       }
/*     */     
/* 209 */     } catch (Exception e) {
/*     */       
/* 211 */       logger.error("TaskController couldn't queueOneOff(): " + LogFormatter.toString(e));
/* 212 */       throw e;
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void performTasks() {
/* 218 */     ProfilerFiller profiler = Minecraft.getInstance().getProfiler();
/* 219 */     profiler.push("journeymapTask");
/* 220 */     StatTimer totalTimer = StatTimer.get("TaskController.performMultithreadTasks", 1, 500).start();
/*     */ 
/*     */     
/*     */     try {
/* 224 */       if (this.lock.tryLock())
/*     */       {
/* 226 */         if (!this.queue.isEmpty())
/*     */         {
/* 228 */           if (((Future)this.queue.peek()).isDone()) {
/*     */             
/*     */             try {
/*     */               
/* 232 */               this.queue.take();
/*     */             }
/* 234 */             catch (InterruptedException e) {
/*     */               
/* 236 */               logger.warn("Interrupted" + e.getMessage());
/*     */             } 
/*     */           }
/*     */         }
/*     */         
/* 241 */         if (this.queue.isEmpty()) {
/*     */           
/* 243 */           ITask task = null;
/* 244 */           ITaskManager manager = getNextManager(this.minecraft);
/* 245 */           if (manager == null) {
/*     */             
/* 247 */             logger.warn("No task managers enabled!");
/*     */             return;
/*     */           } 
/* 250 */           boolean accepted = false;
/*     */           
/* 252 */           StatTimer timer = StatTimer.get(manager.getTaskClass().getSimpleName() + ".Manager.getTask").start();
/* 253 */           task = manager.getTask(this.minecraft);
/*     */           
/* 255 */           if (task == null) {
/*     */             
/* 257 */             timer.cancel();
/*     */           }
/*     */           else {
/*     */             
/* 261 */             timer.stop();
/*     */             
/* 263 */             ensureExecutor();
/*     */             
/* 265 */             if (this.taskExecutor != null && !this.taskExecutor.isShutdown()) {
/*     */ 
/*     */               
/* 268 */               RunnableTask runnableTask = new RunnableTask(this.taskExecutor, task);
/* 269 */               this.queue.add(this.taskExecutor.submit((Runnable)runnableTask));
/* 270 */               accepted = true;
/*     */               
/* 272 */               if (logger.isTraceEnabled())
/*     */               {
/* 274 */                 logger.debug("Scheduled " + manager.getTaskClass().getSimpleName());
/*     */               }
/*     */             }
/*     */             else {
/*     */               
/* 279 */               logger.warn("TaskExecutor isn't running");
/*     */             } 
/*     */             
/* 282 */             manager.taskAccepted(task, accepted);
/*     */           } 
/*     */         } 
/* 285 */         this.lock.unlock();
/*     */       }
/*     */       else
/*     */       {
/* 289 */         logger.warn("TaskController appears to have multiple threads trying to use it");
/*     */       }
/*     */     
/*     */     } finally {
/*     */       
/* 294 */       totalTimer.stop();
/* 295 */       profiler.pop();
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   private ITaskManager getNextManager(Minecraft minecraft) {
/* 301 */     for (ITaskManager manager : this.managers) {
/*     */       
/* 303 */       if (manager.isEnabled(minecraft))
/*     */       {
/* 305 */         return manager;
/*     */       }
/*     */     } 
/* 308 */     return null;
/*     */   }
/*     */ }


/* Location:              C:\Users\Administrator\Downloads\journeymap-forge-1.21-6.0.0-beta.18.jar!\journeymap\client\task\multi\TaskController.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */