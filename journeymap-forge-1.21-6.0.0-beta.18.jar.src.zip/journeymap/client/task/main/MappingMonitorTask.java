/*     */ package journeymap.client.task.main;
/*     */ 
/*     */ import journeymap.client.JourneymapClient;
/*     */ import journeymap.client.log.ChatLog;
/*     */ import journeymap.common.Journeymap;
/*     */ import journeymap.common.log.LogFormatter;
/*     */ import net.minecraft.client.Minecraft;
/*     */ import net.minecraft.client.gui.screens.Screen;
/*     */ import net.minecraft.core.Holder;
/*     */ import net.minecraft.world.level.dimension.DimensionType;
/*     */ import org.apache.logging.log4j.Logger;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MappingMonitorTask
/*     */   implements IMainThreadTask
/*     */ {
/*  28 */   private static String NAME = "Tick." + MappingMonitorTask.class.getSimpleName();
/*  29 */   Logger logger = Journeymap.getLogger();
/*  30 */   private Holder<DimensionType> lastDimension = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public IMainThreadTask perform(Minecraft mc, JourneymapClient jm) {
/*     */     try {
/*  38 */       Screen guiScreen = mc.screen;
/*  39 */       boolean inMainMenu = (guiScreen instanceof net.minecraft.client.gui.screens.TitleScreen || guiScreen instanceof net.minecraft.client.gui.screens.worldselection.SelectWorldScreen || guiScreen instanceof net.minecraft.client.gui.screens.multiplayer.JoinMultiplayerScreen);
/*     */ 
/*     */       
/*  42 */       if (inMainMenu)
/*     */       {
/*  44 */         jm.setEnable();
/*     */       }
/*  46 */       if (!jm.isInitialized().booleanValue())
/*     */       {
/*  48 */         return this;
/*     */       }
/*     */       
/*  51 */       boolean isDead = (mc.screen != null && mc.screen instanceof net.minecraft.client.gui.screens.DeathScreen);
/*     */       
/*  53 */       if (mc.level == null) {
/*     */         
/*  55 */         if (jm.isMapping().booleanValue())
/*     */         {
/*  57 */           jm.stopMapping();
/*     */         }
/*     */         
/*  60 */         if (inMainMenu)
/*     */         {
/*  62 */           if (jm.getCurrentWorldId() != null) {
/*     */             
/*  64 */             this.logger.info("World ID has been reset.");
/*  65 */             jm.setCurrentWorldId(null);
/*     */           } 
/*     */         }
/*     */         
/*  69 */         return this;
/*     */       } 
/*  71 */       if (this.lastDimension == null || (this.lastDimension.unwrapKey().isPresent() && !mc.player.getCommandSenderWorld().dimensionTypeRegistration().is(this.lastDimension.unwrapKey().get()))) {
/*     */         
/*  73 */         this.lastDimension = mc.player.getCommandSenderWorld().dimensionTypeRegistration();
/*  74 */         if (jm.isMapping().booleanValue())
/*     */         {
/*  76 */           jm.stopMapping();
/*     */         
/*     */         }
/*     */       
/*     */       }
/*  81 */       else if (!jm.isMapping().booleanValue() && !isDead && (JourneymapClient.getInstance().getCoreProperties()).mappingEnabled.get().booleanValue()) {
/*     */         
/*  83 */         jm.startMapping();
/*     */       } 
/*     */ 
/*     */       
/*  87 */       boolean isGamePaused = (mc.screen != null && !(mc.screen instanceof journeymap.client.ui.fullscreen.Fullscreen));
/*  88 */       if (isGamePaused)
/*     */       {
/*  90 */         if (!jm.isMapping().booleanValue())
/*     */         {
/*  92 */           return this;
/*     */         }
/*     */       }
/*     */ 
/*     */       
/*  97 */       if (!isGamePaused)
/*     */       {
/*  99 */         ChatLog.showChatAnnouncements(mc);
/*     */       }
/*     */ 
/*     */       
/* 103 */       if (!jm.isMapping().booleanValue() && (JourneymapClient.getInstance().getCoreProperties()).mappingEnabled.get().booleanValue())
/*     */       {
/* 105 */         jm.startMapping();
/*     */       }
/*     */     }
/* 108 */     catch (Throwable t) {
/*     */       
/* 110 */       this.logger.error("Error in JourneyMap.performMainThreadTasks(): " + LogFormatter.toString(t));
/*     */     } 
/* 112 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String getName() {
/* 118 */     return NAME;
/*     */   }
/*     */ }


/* Location:              C:\Users\Administrator\Downloads\journeymap-forge-1.21-6.0.0-beta.18.jar!\journeymap\client\task\main\MappingMonitorTask.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */