package journeymap.client.task.main;

import journeymap.client.JourneymapClient;
import net.minecraft.client.Minecraft;

public interface IMainThreadTask {
  IMainThreadTask perform(Minecraft paramMinecraft, JourneymapClient paramJourneymapClient);
  
  String getName();
}


/* Location:              C:\Users\Administrator\Downloads\journeymap-forge-1.21-6.0.0-beta.18.jar!\journeymap\client\task\main\IMainThreadTask.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */