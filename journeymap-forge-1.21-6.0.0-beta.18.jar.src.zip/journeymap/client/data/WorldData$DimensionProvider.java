package journeymap.client.data;

import net.minecraft.resources.ResourceKey;
import net.minecraft.world.level.Level;

public interface DimensionProvider {
  String getDimensionId();
  
  ResourceKey<Level> getDimension();
  
  String getName();
}


/* Location:              C:\Users\Administrator\Downloads\journeymap-forge-1.21-6.0.0-beta.18.jar!\journeymap\client\data\WorldData$DimensionProvider.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */