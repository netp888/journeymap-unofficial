/*     */ package journeymap.client.ui.option;
/*     */ 
/*     */ import java.util.Comparator;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.stream.Collectors;
/*     */ import journeymap.client.Constants;
/*     */ import journeymap.client.feature.Feature;
/*     */ import journeymap.client.feature.FeatureManager;
/*     */ import journeymap.client.model.MapType;
/*     */ import journeymap.common.properties.config.StringField;
/*     */ 
/*     */ public class MapTypeProvider
/*     */   implements StringField.ValuesProvider
/*     */ {
/*  17 */   private static final Map<MapType.Name, Source> values = new HashMap<>();
/*     */   
/*  19 */   public static Source ANY = create(MapType.Name.any, "jm.common.map_type.auto");
/*  20 */   public static Source DAY = create(MapType.Name.day, MapType.Name.day.getKey());
/*  21 */   public static Source NIGHT = create(MapType.Name.night, MapType.Name.night.getKey());
/*  22 */   public static Source UNDERGROUND = create(MapType.Name.underground, MapType.Name.underground.getKey());
/*  23 */   public static Source BIOME = create(MapType.Name.biome, MapType.Name.biome.getKey());
/*  24 */   public static Source TOPO = create(MapType.Name.topo, MapType.Name.topo.getKey());
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static Source create(MapType.Name name, String key) {
/*  32 */     Source src = new Source(key, name);
/*  33 */     values.put(name, src);
/*  34 */     return src;
/*     */   }
/*     */ 
/*     */   
/*     */   public static String from(MapType.Name name) {
/*  39 */     return ((Source)values.get(name)).key();
/*     */   }
/*     */ 
/*     */   
/*     */   public static MapType.Name from(String name) {
/*  44 */     return values.values().stream().filter(source -> source.key().equals(name)).map(source -> source.name).findFirst().orElse(MapType.Name.any);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public List<String> getStrings() {
/*  50 */     return (List<String>)values.values().stream().filter(src -> isAllowed(src.name)).map(source -> source.key).sorted(Comparator.naturalOrder()).collect(Collectors.toList());
/*     */   }
/*     */ 
/*     */   
/*     */   boolean isAllowed(MapType.Name name) {
/*  55 */     if (name == MapType.Name.any)
/*     */     {
/*  57 */       return true;
/*     */     }
/*  59 */     if (name == MapType.Name.underground)
/*     */     {
/*  61 */       return FeatureManager.getInstance().isAllowed(Feature.MapCaves);
/*     */     }
/*  63 */     if (name == MapType.Name.topo)
/*     */     {
/*  65 */       return (FeatureManager.getInstance().isAllowed(Feature.MapTopo) && FeatureManager.getInstance().isAllowed(Feature.MapSurface));
/*     */     }
/*  67 */     if (name == MapType.Name.day || name == MapType.Name.night)
/*     */     {
/*  69 */       return FeatureManager.getInstance().isAllowed(Feature.MapSurface);
/*     */     }
/*  71 */     if (name == MapType.Name.biome)
/*     */     {
/*  73 */       return (FeatureManager.getInstance().isAllowed(Feature.MapBiome) && FeatureManager.getInstance().isAllowed(Feature.MapSurface));
/*     */     }
/*     */ 
/*     */     
/*  77 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getDefaultString() {
/*  84 */     return ANY.key();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String getTooltip(String value) {
/*  90 */     for (Source source : values.values()) {
/*     */       
/*  92 */       String tooltipKey = null;
/*     */       
/*  94 */       if (source.name.getKey().equals(value)) {
/*     */         
/*  96 */         tooltipKey = source.name.getKey() + ".tooltip";
/*     */       }
/*  98 */       else if (source.key().equals(value)) {
/*     */         
/* 100 */         tooltipKey = source.key() + ".tooltip";
/*     */       } 
/*     */       
/* 103 */       if (tooltipKey != null) {
/*     */         
/* 105 */         String tooltip = Constants.getString(tooltipKey);
/* 106 */         if (!tooltipKey.equals(tooltip))
/*     */         {
/* 108 */           return tooltip;
/*     */         }
/*     */       } 
/*     */     } 
/*     */     
/* 113 */     return null;
/*     */   }
/*     */   public static final class Source extends Record { private final String key; private final MapType.Name name;
/* 116 */     public Source(String key, MapType.Name name) { this.key = key; this.name = name; } public final String toString() { // Byte code:
/*     */       //   0: aload_0
/*     */       //   1: <illegal opcode> toString : (Ljourneymap/client/ui/option/MapTypeProvider$Source;)Ljava/lang/String;
/*     */       //   6: areturn
/*     */       // Line number table:
/*     */       //   Java source line number -> byte code offset
/*     */       //   #116	-> 0
/*     */       // Local variable table:
/*     */       //   start	length	slot	name	descriptor
/* 116 */       //   0	7	0	this	Ljourneymap/client/ui/option/MapTypeProvider$Source; } public String key() { return this.key; } public final int hashCode() { // Byte code:
/*     */       //   0: aload_0
/*     */       //   1: <illegal opcode> hashCode : (Ljourneymap/client/ui/option/MapTypeProvider$Source;)I
/*     */       //   6: ireturn
/*     */       // Line number table:
/*     */       //   Java source line number -> byte code offset
/*     */       //   #116	-> 0
/*     */       // Local variable table:
/*     */       //   start	length	slot	name	descriptor
/*     */       //   0	7	0	this	Ljourneymap/client/ui/option/MapTypeProvider$Source; } public final boolean equals(Object o) { // Byte code:
/*     */       //   0: aload_0
/*     */       //   1: aload_1
/*     */       //   2: <illegal opcode> equals : (Ljourneymap/client/ui/option/MapTypeProvider$Source;Ljava/lang/Object;)Z
/*     */       //   7: ireturn
/*     */       // Line number table:
/*     */       //   Java source line number -> byte code offset
/*     */       //   #116	-> 0
/*     */       // Local variable table:
/*     */       //   start	length	slot	name	descriptor
/*     */       //   0	8	0	this	Ljourneymap/client/ui/option/MapTypeProvider$Source;
/* 116 */       //   0	8	1	o	Ljava/lang/Object; } public MapType.Name name() { return this.name; }
/*     */      }
/*     */ 
/*     */ }


/* Location:              C:\Users\Administrator\Downloads\journeymap-forge-1.21-6.0.0-beta.18.jar!\journeymap\clien\\ui\option\MapTypeProvider.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */