/*     */ package journeymap.client.ui.option;
/*     */ 
/*     */ import com.google.common.collect.Lists;
/*     */ import java.util.Arrays;
/*     */ import java.util.Collection;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import journeymap.client.Constants;
/*     */ import journeymap.client.ui.component.DropDownItem;
/*     */ import journeymap.client.ui.component.SelectableParent;
/*     */ import journeymap.client.ui.component.buttons.DropDownButton;
/*     */ import journeymap.client.ui.component.buttons.PropertyDropdownButton;
/*     */ import journeymap.common.Journeymap;
/*     */ import journeymap.common.properties.config.ConfigField;
/*     */ import journeymap.common.properties.config.StringField;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class LocationFormat
/*     */ {
/*  27 */   private static final String[] locationFormatIds = new String[] { "xzyv", "xyvz", "xzy", "xyz", "xz" };
/*  28 */   private final Map<String, LocationFormatKeys> idToFormat = new HashMap<>();
/*     */ 
/*     */   
/*     */   public LocationFormat() {
/*  32 */     for (String id : locationFormatIds)
/*     */     {
/*  34 */       this.idToFormat.put(id, new LocationFormatKeys(id));
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public LocationFormatKeys getFormatKeys(String id) {
/*  40 */     LocationFormatKeys locationLocationFormatKeys = this.idToFormat.get(id);
/*  41 */     if (locationLocationFormatKeys == null) {
/*     */       
/*  43 */       Journeymap.getLogger().warn("Invalid location format id: " + id);
/*  44 */       locationLocationFormatKeys = this.idToFormat.get(locationFormatIds[0]);
/*     */     } 
/*     */     
/*  47 */     return locationLocationFormatKeys;
/*     */   }
/*     */ 
/*     */   
/*     */   public String getLabel(String id) {
/*  52 */     return Constants.getString((getFormatKeys(id)).label_key);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static class IdProvider
/*     */     implements StringField.ValuesProvider
/*     */   {
/*     */     public List<String> getStrings() {
/*  64 */       return Arrays.asList(LocationFormat.locationFormatIds);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public String getDefaultString() {
/*  70 */       return LocationFormat.locationFormatIds[0];
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public static class LocationFormatKeys
/*     */   {
/*     */     final String id;
/*     */     final String label_key;
/*     */     final String verbose_key;
/*     */     final String plain_key;
/*     */     
/*     */     LocationFormatKeys(String id) {
/*  83 */       this.id = id;
/*  84 */       this.label_key = String.format("jm.common.location_%s_label", new Object[] { id });
/*  85 */       this.verbose_key = String.format("jm.common.location_%s_verbose", new Object[] { id });
/*  86 */       this.plain_key = String.format("jm.common.location_%s_plain", new Object[] { id });
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public String format(boolean verbose, int x, int z, int y, int vslice) {
/*  92 */       if (verbose)
/*     */       {
/*  94 */         return Constants.getString(this.verbose_key, new Object[] { Integer.valueOf(x), Integer.valueOf(z), Integer.valueOf(y), Integer.valueOf(vslice) });
/*     */       }
/*     */ 
/*     */       
/*  98 */       return Constants.getString(this.plain_key, new Object[] { Integer.valueOf(x), Integer.valueOf(z), Integer.valueOf(y), Integer.valueOf(vslice) });
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public static class Button
/*     */     extends PropertyDropdownButton<String>
/*     */   {
/*     */     LocationFormat locationFormat;
/*     */     
/*     */     public Button(StringField valueHolder) {
/* 109 */       super(Arrays.asList(LocationFormat.locationFormatIds), Constants.getString("jm.common.location_format"), (ConfigField)valueHolder);
/* 110 */       this.buttonBuffer = 50;
/* 111 */       if (this.locationFormat == null)
/*     */       {
/* 113 */         this.locationFormat = new LocationFormat();
/*     */       }
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public String getFormattedLabel(String id) {
/* 120 */       if (this.locationFormat == null)
/*     */       {
/* 122 */         this.locationFormat = new LocationFormat();
/*     */       }
/* 124 */       return String.format("%1$s : %2$s %3$s %2$s", new Object[] { this.baseLabel, "⇕", this.locationFormat.getLabel(id) });
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     protected String getLabel(DropDownItem item) {
/* 130 */       return getFormattedLabel(item.getLabel());
/*     */     }
/*     */ 
/*     */     
/*     */     public String getLabel(String id) {
/* 135 */       return this.locationFormat.getLabel(id);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     protected List<DropDownItem> setItems(Collection<String> values) {
/* 141 */       List<DropDownItem> items = Lists.newArrayList();
/* 142 */       values.forEach(value -> items.add(new LocationFormat.LocationDropDownItem((DropDownButton)this, value, getLabel(value))));
/* 143 */       return items;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   static class LocationDropDownItem
/*     */     extends DropDownItem
/*     */   {
/*     */     public LocationDropDownItem(DropDownButton parent, Object id, String label) {
/* 153 */       super((SelectableParent)parent, id, label);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public String getLabel() {
/* 159 */       return getId().toString();
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\Administrator\Downloads\journeymap-forge-1.21-6.0.0-beta.18.jar!\journeymap\clien\\ui\option\LocationFormat.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */