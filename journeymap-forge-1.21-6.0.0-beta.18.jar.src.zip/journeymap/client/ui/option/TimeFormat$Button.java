/*    */ package journeymap.client.ui.option;
/*    */ 
/*    */ import java.util.Arrays;
/*    */ import journeymap.client.Constants;
/*    */ import journeymap.client.ui.component.buttons.PropertyDropdownButton;
/*    */ import journeymap.common.properties.config.ConfigField;
/*    */ import journeymap.common.properties.config.StringField;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Button
/*    */   extends PropertyDropdownButton<String>
/*    */ {
/*    */   TimeFormat timeFormat;
/*    */   
/*    */   public Button(StringField valueHolder) {
/* 42 */     super(Arrays.asList(TimeFormat.timeFormatValues), Constants.getString("jm.common.time_format"), (ConfigField)valueHolder);
/* 43 */     if (this.timeFormat == null)
/*    */     {
/* 45 */       this.timeFormat = new TimeFormat();
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Users\Administrator\Downloads\journeymap-forge-1.21-6.0.0-beta.18.jar!\journeymap\clien\\ui\option\TimeFormat$Button.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */