/*    */ package journeymap.client.ui.option;
/*    */ 
/*    */ import java.util.ArrayList;
/*    */ import java.util.List;
/*    */ import journeymap.client.Constants;
/*    */ import journeymap.client.JourneymapClient;
/*    */ import journeymap.common.Journeymap;
/*    */ import journeymap.common.properties.MultiplayerCategory;
/*    */ import journeymap.common.properties.MultiplayerProperties;
/*    */ import journeymap.common.properties.ServerCategory;
/*    */ import journeymap.common.properties.catagory.Category;
/*    */ import net.minecraft.ChatFormatting;
/*    */ import net.minecraft.client.gui.screens.Screen;
/*    */ 
/*    */ 
/*    */ public class MultiplayerOptionsManager
/*    */   extends ServerOptionsManager
/*    */ {
/*    */   MultiplayerProperties multiplayerProperties;
/*    */   
/*    */   public MultiplayerOptionsManager(Screen returnDisplay) {
/* 22 */     super(returnDisplay, Constants.getString("jm.options.multiplayer.title"), new ArrayList<>(ServerCategory.values));
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public void init() {
/* 28 */     super.init();
/*    */     
/* 30 */     if (!this.buttonServer.getMessage().getString().contains(ChatFormatting.STRIKETHROUGH.toString()))
/*    */     {
/* 32 */       this.buttonServer.setEnabled(true);
/*    */     }
/* 34 */     this.buttonMultiplayer.setEnabled(false);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   protected void requestInitData() {
/* 40 */     JourneymapClient.getInstance().getDispatcher().sendMultiplayerOptionsRequest();
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void setData(String payload) {
/*    */     try {
/* 48 */       this.multiplayerProperties = (MultiplayerProperties)(new MultiplayerProperties()).loadForClient(payload, false);
/* 49 */       this.slotMap.put(MultiplayerCategory.Multiplayer, this.multiplayerProperties);
/*    */       
/* 51 */       init();
/*    */     }
/* 53 */     catch (Exception e) {
/*    */       
/* 55 */       Journeymap.getLogger().error("Error getting data", e);
/*    */     } 
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   protected void save() {
/* 62 */     JourneymapClient.getInstance().getDispatcher().sendMultiplayerOptionsSaveRequest(this.multiplayerProperties.toJsonString(false));
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   protected List<CategorySlot> getCategorySlotList() {
/* 68 */     return OptionSlotFactory.getOptionSlots(getToolbars(), this.slotMap, 
/*    */ 
/*    */         
/* 71 */         !JourneymapClient.getInstance().getStateHandler().isExpandedRadarEnabled(), false);
/*    */   }
/*    */ }


/* Location:              C:\Users\Administrator\Downloads\journeymap-forge-1.21-6.0.0-beta.18.jar!\journeymap\clien\\ui\option\MultiplayerOptionsManager.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */