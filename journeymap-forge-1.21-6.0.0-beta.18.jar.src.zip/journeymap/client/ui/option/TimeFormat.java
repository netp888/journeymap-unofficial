/*    */ package journeymap.client.ui.option;
/*    */ 
/*    */ import java.util.Arrays;
/*    */ import java.util.List;
/*    */ import journeymap.client.Constants;
/*    */ import journeymap.client.ui.component.buttons.PropertyDropdownButton;
/*    */ import journeymap.common.properties.config.ConfigField;
/*    */ import journeymap.common.properties.config.StringField;
/*    */ 
/*    */ public class TimeFormat
/*    */ {
/* 12 */   private static String[] timeFormatValues = new String[] { "HH:mm:ss", "H:mm:ss", "HH:mm", "H:mm", "hh:mm:ss a", "h:mm:ss a", "hh:mm:ss ", "h:mm:ss", "hh:mm a", "h:mm a", "hh:mm", "h:mm" };
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static class Provider
/*    */     implements StringField.ValuesProvider
/*    */   {
/*    */     public List<String> getStrings() {
/* 26 */       return Arrays.asList(TimeFormat.timeFormatValues);
/*    */     }
/*    */ 
/*    */ 
/*    */     
/*    */     public String getDefaultString() {
/* 32 */       return TimeFormat.timeFormatValues[0];
/*    */     }
/*    */   }
/*    */   
/*    */   public static class Button
/*    */     extends PropertyDropdownButton<String>
/*    */   {
/*    */     TimeFormat timeFormat;
/*    */     
/*    */     public Button(StringField valueHolder) {
/* 42 */       super(Arrays.asList(TimeFormat.timeFormatValues), Constants.getString("jm.common.time_format"), (ConfigField)valueHolder);
/* 43 */       if (this.timeFormat == null)
/*    */       {
/* 45 */         this.timeFormat = new TimeFormat();
/*    */       }
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Users\Administrator\Downloads\journeymap-forge-1.21-6.0.0-beta.18.jar!\journeymap\clien\\ui\option\TimeFormat.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */