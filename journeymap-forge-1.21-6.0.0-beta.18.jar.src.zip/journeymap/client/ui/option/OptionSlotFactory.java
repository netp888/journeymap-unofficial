/*     */ package journeymap.client.ui.option;
/*     */ 
/*     */ import com.google.common.base.Joiner;
/*     */ import com.google.common.io.Files;
/*     */ import java.io.BufferedWriter;
/*     */ import java.io.File;
/*     */ import java.io.IOException;
/*     */ import java.nio.charset.Charset;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.Collections;
/*     */ import java.util.Date;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import journeymap.api.v2.client.option.KeyedEnum;
/*     */ import journeymap.client.Constants;
/*     */ import journeymap.client.JourneymapClient;
/*     */ import journeymap.client.properties.ClientCategory;
/*     */ import journeymap.client.ui.component.Slot;
/*     */ import journeymap.client.ui.component.buttons.Button;
/*     */ import journeymap.client.ui.component.buttons.CheckBox;
/*     */ import journeymap.client.ui.component.buttons.FloatSliderButton;
/*     */ import journeymap.client.ui.component.buttons.IntSliderButton;
/*     */ import journeymap.client.ui.component.buttons.PropertyDropdownButton;
/*     */ import journeymap.client.ui.component.buttons.TextFieldButton;
/*     */ import journeymap.common.Journeymap;
/*     */ import journeymap.common.properties.PropertiesBase;
/*     */ import journeymap.common.properties.catagory.Category;
/*     */ import journeymap.common.properties.config.BooleanField;
/*     */ import journeymap.common.properties.config.ConfigField;
/*     */ import journeymap.common.properties.config.CustomField;
/*     */ import journeymap.common.properties.config.EnumField;
/*     */ import journeymap.common.properties.config.FloatField;
/*     */ import journeymap.common.properties.config.IntegerField;
/*     */ import journeymap.common.properties.config.StringField;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class OptionSlotFactory
/*     */ {
/*  54 */   protected static final Charset UTF8 = Charset.forName("UTF-8");
/*     */   
/*     */   protected static BufferedWriter docWriter;
/*     */   
/*     */   protected static File docFile;
/*     */   protected static boolean generateDocs = false;
/*     */   
/*     */   public static List<CategorySlot> getOptionSlots(Map<Category, List<SlotMetadata>> toolbars, Map<Category, PropertiesBase> slotMap) {
/*  62 */     return getOptionSlots(toolbars, slotMap, false, false);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static List<CategorySlot> getOptionSlots(Map<Category, List<SlotMetadata>> toolbars, Map<Category, PropertiesBase> slotMap, boolean viewOnly, boolean useTargetCategory) {
/*  76 */     HashMap<Category, List<SlotMetadata>> mergedMap = new HashMap<>();
/*     */     
/*  78 */     slotMap.forEach((category, propertiesBase) -> addSlots(mergedMap, category, propertiesBase, useTargetCategory));
/*     */     
/*  80 */     List<CategorySlot> categories = new ArrayList<>();
/*  81 */     for (Map.Entry<Category, List<SlotMetadata>> entry : mergedMap.entrySet()) {
/*     */       
/*  83 */       Category category = entry.getKey();
/*  84 */       CategorySlot categorySlot = new CategorySlot(category);
/*     */       
/*  86 */       if (ClientCategory.WebMap.equals(category) && JourneymapClient.getInstance().getWebMap() == null) {
/*     */         
/*  88 */         categorySlot.setEnabled(false);
/*  89 */         categorySlot.metadata.tooltip = Constants.getString("jm.config.category.webmap.download");
/*     */       } 
/*  91 */       for (SlotMetadata val : entry.getValue())
/*     */       {
/*  93 */         categorySlot.add((new ButtonListSlot(categorySlot)).add(val));
/*     */       }
/*     */       
/*  96 */       if (toolbars.containsKey(category)) {
/*     */         
/*  98 */         ButtonListSlot toolbarSlot = new ButtonListSlot(categorySlot);
/*  99 */         for (SlotMetadata toolbar : toolbars.get(category))
/*     */         {
/* 101 */           toolbarSlot.add(toolbar);
/*     */         }
/* 103 */         categorySlot.add(toolbarSlot);
/*     */       } 
/*     */       
/* 106 */       categories.add(categorySlot);
/*     */     } 
/*     */ 
/*     */     
/* 110 */     if (viewOnly)
/*     */     {
/* 112 */       mergedMap.values().forEach(slotList -> slotList.forEach(()));
/*     */     }
/*     */     
/* 115 */     Collections.sort(categories);
/*     */     
/* 117 */     int count = 0;
/* 118 */     for (CategorySlot categorySlot : categories)
/*     */     {
/* 120 */       count += categorySlot.size();
/*     */     }
/*     */     
/* 123 */     if (generateDocs) {
/*     */       
/* 125 */       ensureDocFile();
/*     */       
/* 127 */       for (Slot rootSlot : categories) {
/*     */         
/* 129 */         CategorySlot categorySlot = (CategorySlot)rootSlot;
/*     */         
/* 131 */         if (categorySlot.category == ClientCategory.MiniMap2) {
/*     */           continue;
/*     */         }
/*     */         
/* 135 */         doc(categorySlot);
/* 136 */         docTable(true);
/*     */         
/* 138 */         categorySlot.sort();
/* 139 */         for (SlotMetadata childSlot : categorySlot.getAllChildMetadata())
/*     */         {
/* 141 */           doc(childSlot, (categorySlot.getCategory() == ClientCategory.Advanced || categorySlot.getCategory() == ClientCategory.AdvancedMapRendering));
/*     */         }
/* 143 */         docTable(false);
/*     */       } 
/*     */       
/* 146 */       endDoc();
/*     */     } 
/*     */     
/* 149 */     return categories;
/*     */   }
/*     */ 
/*     */   
/*     */   protected static void addSlots(HashMap<Category, List<SlotMetadata>> mergedMap, Category inheritedCategory, PropertiesBase properties, boolean useTargetCategory) {
/* 154 */     Class<? extends PropertiesBase> propertiesClass = (Class)properties.getClass();
/* 155 */     HashMap<Category, List<SlotMetadata>> slots = buildSlots(null, inheritedCategory, propertiesClass, properties, useTargetCategory);
/* 156 */     for (Map.Entry<Category, List<SlotMetadata>> entry : slots.entrySet()) {
/*     */       
/* 158 */       Category category = entry.getKey();
/* 159 */       if (category == Category.Inherit) {
/*     */ 
/*     */         
/* 162 */         if (useTargetCategory) {
/*     */           continue;
/*     */         }
/*     */         
/* 166 */         category = inheritedCategory;
/*     */       
/*     */       }
/* 169 */       else if (category != inheritedCategory && !useTargetCategory && category.isUnique()) {
/*     */         continue;
/*     */       } 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 176 */       List<SlotMetadata> slotMetadataList = null;
/* 177 */       if (mergedMap.containsKey(category)) {
/*     */         
/* 179 */         slotMetadataList = mergedMap.get(category);
/*     */       }
/*     */       else {
/*     */         
/* 183 */         slotMetadataList = new ArrayList<>();
/* 184 */         mergedMap.put(category, slotMetadataList);
/*     */       } 
/* 186 */       slotMetadataList.addAll(entry.getValue());
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   protected static HashMap<Category, List<SlotMetadata>> buildSlots(HashMap<Category, List<SlotMetadata>> map, Category inheritedCategory, Class<? extends PropertiesBase> propertiesClass, PropertiesBase properties, boolean useTargetCategory) {
/* 192 */     if (map == null)
/*     */     {
/* 194 */       map = new HashMap<>();
/*     */     }
/*     */     
/* 197 */     for (ConfigField configField : properties.getConfigFields().values()) {
/*     */       
/* 199 */       if (configField.getCategory() == Category.Hidden || (useTargetCategory && configField.getCategory() != inheritedCategory)) {
/*     */         continue;
/*     */       }
/*     */ 
/*     */       
/* 204 */       SlotMetadata<Boolean> slotMetadata = null;
/*     */       
/* 206 */       if (configField instanceof BooleanField) {
/*     */         
/* 208 */         slotMetadata = getBooleanSlotMetadata((BooleanField)configField);
/*     */       }
/* 210 */       else if (configField instanceof IntegerField) {
/*     */         
/* 212 */         slotMetadata = (SlotMetadata)getIntegerSlotMetadata((IntegerField)configField);
/*     */       }
/* 214 */       else if (configField instanceof StringField) {
/*     */         
/* 216 */         slotMetadata = (SlotMetadata)getStringSlotMetadata((StringField)configField);
/*     */       }
/* 218 */       else if (configField instanceof EnumField) {
/*     */         
/* 220 */         slotMetadata = (SlotMetadata)getEnumSlotMetadata((EnumField)configField);
/*     */       }
/* 222 */       else if (configField instanceof CustomField) {
/*     */         
/* 224 */         slotMetadata = getTextSlotMetadata((CustomField)configField);
/*     */       }
/* 226 */       else if (configField instanceof FloatField) {
/*     */         
/* 228 */         slotMetadata = (SlotMetadata)getFloatSlotMetadata((FloatField)configField);
/*     */       } 
/*     */       
/* 231 */       if (slotMetadata != null) {
/*     */ 
/*     */         
/* 234 */         slotMetadata.setOrder(configField.getSortOrder());
/*     */ 
/*     */         
/* 237 */         Category category = configField.getCategory();
/* 238 */         if (Category.Inherit.equals(category))
/*     */         {
/* 240 */           category = inheritedCategory;
/*     */         }
/*     */         
/* 243 */         List<SlotMetadata> list = map.get(category);
/* 244 */         if (list == null) {
/*     */           
/* 246 */           list = new ArrayList<>();
/* 247 */           map.put(category, list);
/*     */         } 
/* 249 */         list.add(slotMetadata);
/*     */         
/*     */         continue;
/*     */       } 
/* 253 */       Journeymap.getLogger().warn(String.format("Unable to create config gui for %s in %s", new Object[] { properties.getClass().getSimpleName(), configField }));
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 258 */     return map;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   static String getTooltip(ConfigField configField) {
/* 264 */     String tooltipKey = configField.getKey() + ".tooltip";
/* 265 */     String tooltip = Constants.getString(tooltipKey);
/* 266 */     if (tooltipKey.equals(tooltip))
/*     */     {
/* 268 */       tooltip = null;
/*     */     }
/* 270 */     return tooltip;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static SlotMetadata<Boolean> getBooleanSlotMetadata(BooleanField field) {
/* 281 */     String name = Constants.getString(field.getKey());
/* 282 */     String tooltip = getTooltip((ConfigField)field);
/* 283 */     String defaultTip = Constants.getString("jm.config.default", new Object[] { field.getDefaultValue() });
/* 284 */     boolean advanced = (field.getCategory() == ClientCategory.Advanced || field.getCategory() == ClientCategory.AdvancedMapRendering);
/*     */     
/* 286 */     CheckBox button = new CheckBox(name, field);
/* 287 */     SlotMetadata<Boolean> slotMetadata = new SlotMetadata<>((Button)button, name, tooltip, defaultTip, field.getDefaultValue(), advanced);
/* 288 */     slotMetadata.setMasterPropertyForCategory(field.isCategoryMaster());
/* 289 */     if (field.isCategoryMaster())
/*     */     {
/* 291 */       button.setLabelColors(Integer.valueOf(65535), null, null);
/*     */     }
/* 293 */     return slotMetadata;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static SlotMetadata<Integer> getIntegerSlotMetadata(IntegerField field) {
/* 304 */     String name = Constants.getString(field.getKey());
/* 305 */     String tooltip = getTooltip((ConfigField)field);
/* 306 */     String defaultTip = Constants.getString("jm.config.default_numeric", new Object[] { Integer.valueOf(field.getMinValue()), Integer.valueOf(field.getMaxValue()), Integer.valueOf(field.getDefaultValue().intValue()) });
/* 307 */     boolean advanced = (field.getCategory() == ClientCategory.Advanced || field.getCategory() == ClientCategory.AdvancedMapRendering);
/*     */     
/* 309 */     IntSliderButton button = new IntSliderButton(field, name + " : ", "", true);
/* 310 */     button.setDefaultStyle(false);
/* 311 */     button.setDrawBackground(false);
/* 312 */     SlotMetadata<Integer> slotMetadata = new SlotMetadata<>((Button)button, name, tooltip, defaultTip, Integer.valueOf(field.getDefaultValue().intValue()), advanced);
/* 313 */     return slotMetadata;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static SlotMetadata<Float> getFloatSlotMetadata(FloatField field) {
/* 324 */     String name = Constants.getString(field.getKey());
/* 325 */     String tooltip = getTooltip((ConfigField)field);
/* 326 */     String defaultTip = Constants.getString("jm.config.default_numeric", new Object[] { Float.valueOf(field.getMinValue()), Float.valueOf(field.getMaxValue()), field.getDefaultValue() });
/* 327 */     boolean advanced = (field.getCategory() == ClientCategory.Advanced || field.getCategory() == ClientCategory.AdvancedMapRendering);
/*     */     
/* 329 */     FloatSliderButton button = new FloatSliderButton(field, name + " : ", "", field.getMinValue(), field.getMaxValue());
/* 330 */     button.setDefaultStyle(false);
/* 331 */     button.setDrawBackground(false);
/* 332 */     SlotMetadata<Float> slotMetadata = new SlotMetadata<>((Button)button, name, tooltip, defaultTip, field.getDefaultValue(), advanced);
/* 333 */     return slotMetadata;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static SlotMetadata<String> getStringSlotMetadata(StringField field) {
/*     */     try {
/* 346 */       String name = Constants.getString(field.getKey());
/* 347 */       String tooltip = getTooltip((ConfigField)field);
/* 348 */       boolean advanced = (field.getCategory() == ClientCategory.Advanced || field.getCategory() == ClientCategory.AdvancedMapRendering);
/*     */       
/* 350 */       PropertyDropdownButton<String> button = null;
/* 351 */       String defaultTip = null;
/*     */ 
/*     */       
/* 354 */       if (LocationFormat.IdProvider.class.isAssignableFrom(field.getValuesProviderClass())) {
/*     */         
/* 356 */         button = new LocationFormat.Button(field);
/* 357 */         defaultTip = Constants.getString("jm.config.default", new Object[] { ((LocationFormat.Button)button).getLabel(field.getDefaultValue()) });
/*     */       }
/*     */       else {
/*     */         
/* 361 */         button = new PropertyDropdownButton(field.getValidValues(), name, (ConfigField)field);
/* 362 */         defaultTip = Constants.getString("jm.config.default", new Object[] { Constants.getString(field.getDefaultValue()) });
/*     */       } 
/* 364 */       button.setDefaultStyle(false);
/* 365 */       button.setDrawBackground(false);
/* 366 */       SlotMetadata<String> slotMetadata = new SlotMetadata<>((Button)button, name, tooltip, defaultTip, field.getDefaultValue(), advanced);
/* 367 */       slotMetadata.setValueList(field.getValidValues());
/* 368 */       return slotMetadata;
/*     */     }
/* 370 */     catch (Exception e) {
/*     */       
/* 372 */       e.printStackTrace();
/* 373 */       return null;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private static SlotMetadata getTextSlotMetadata(CustomField field) {
/*     */     try {
/* 381 */       String name = Constants.getString(field.getKey());
/* 382 */       String tooltip = getTooltip((ConfigField)field);
/* 383 */       boolean advanced = (field.getCategory() == ClientCategory.Advanced || field.getCategory() == ClientCategory.AdvancedMapRendering);
/*     */       
/* 385 */       TextFieldButton button = null;
/* 386 */       String defaultTip = null;
/*     */       
/* 388 */       button = new TextFieldButton(field);
/* 389 */       defaultTip = Constants.getString("jm.config.default", new Object[] { field.getDefaultValue() });
/*     */ 
/*     */ 
/*     */       
/* 393 */       SlotMetadata<Object> slotMetadata = new SlotMetadata((Button)button, name, tooltip, defaultTip, field.getDefaultValue(), advanced);
/*     */       
/* 395 */       return slotMetadata;
/*     */     }
/* 397 */     catch (Exception e) {
/*     */       
/* 399 */       e.printStackTrace();
/* 400 */       return null;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static SlotMetadata<Enum> getEnumSlotMetadata(EnumField field) {
/*     */     try {
/* 414 */       String name = Constants.getString(field.getKey());
/* 415 */       String tooltip = getTooltip((ConfigField)field);
/* 416 */       boolean advanced = (field.getCategory() == ClientCategory.Advanced || field.getCategory() == ClientCategory.AdvancedMapRendering);
/*     */ 
/*     */       
/* 419 */       PropertyDropdownButton<Enum> button = new PropertyDropdownButton(field.getValidValues(), name, (ConfigField)field);
/* 420 */       String defaultValue = Constants.getString(((KeyedEnum)field.getDefaultValue()).getKey());
/* 421 */       String defaultTip = Constants.getString("jm.config.default", new Object[] { defaultValue });
/*     */       
/* 423 */       button.setDefaultStyle(false);
/* 424 */       button.setDrawBackground(false);
/* 425 */       SlotMetadata<Enum> slotMetadata = new SlotMetadata<>((Button)button, name, tooltip, defaultTip, field.getDefaultValue(), advanced);
/* 426 */       slotMetadata.setValueList(Arrays.asList(new Set[] { field.getValidValues() }));
/* 427 */       return slotMetadata;
/*     */     }
/* 429 */     catch (Exception e) {
/*     */       
/* 431 */       e.printStackTrace();
/* 432 */       return null;
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   static void ensureDocFile() {
/* 438 */     if (docFile == null) {
/*     */       
/* 440 */       docFile = new File(Constants.JOURNEYMAP_DIR, "journeymap-options-wiki.txt");
/*     */ 
/*     */       
/*     */       try {
/* 444 */         if (docFile.exists())
/*     */         {
/* 446 */           docFile.delete();
/*     */         }
/* 448 */         Files.createParentDirs(docFile);
/*     */         
/* 450 */         docWriter = Files.newWriter(docFile, UTF8);
/* 451 */         docWriter.append(String.format("<!-- Generated %s -->", new Object[] { new Date() }));
/* 452 */         docWriter.newLine();
/* 453 */         docWriter.append("=== Overview ===");
/* 454 */         docWriter.newLine();
/* 455 */         docWriter.append("{{version|5.0.0|page}}");
/* 456 */         docWriter.newLine();
/* 457 */         docWriter.append("This page lists all of the available options which can be configured in-game using the JourneyMap [[Options Manager]].");
/* 458 */         docWriter.append("(Note: All of this information can also be obtained from the tooltips within the [[Options Manager]] itself.) <br clear/> <br clear/>");
/* 459 */         docWriter.newLine();
/*     */       }
/* 461 */       catch (IOException e) {
/*     */         
/* 463 */         e.printStackTrace();
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   static void doc(CategorySlot categorySlot) {
/*     */     try {
/* 472 */       docWriter.newLine();
/* 473 */       docWriter.append(String.format("==%s==", new Object[] { categorySlot.getCategory().getName().replace("Preset 1", "Preset (1 and 2)") }));
/* 474 */       docWriter.newLine();
/* 475 */       docWriter.append(String.format("''%s''", new Object[] { ((SlotMetadata)categorySlot.getMetadata().iterator().next()).tooltip.replace("Preset 1", "Preset (1 and 2)") }));
/* 476 */       docWriter.newLine();
/* 477 */       docWriter.newLine();
/*     */     }
/* 479 */     catch (IOException e) {
/*     */       
/* 481 */       e.printStackTrace();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   static void docTable(boolean start) {
/*     */     try {
/* 489 */       if (start)
/*     */       {
/* 491 */         docWriter.append("{| class=\"wikitable\" style=\"cellpadding=\"4\"");
/* 492 */         docWriter.newLine();
/* 493 */         docWriter.append("! scope=\"col\" | Option");
/* 494 */         docWriter.newLine();
/* 495 */         docWriter.append("! scope=\"col\" | Purpose");
/* 496 */         docWriter.newLine();
/* 497 */         docWriter.append("! scope=\"col\" | Range / Default Value");
/* 498 */         docWriter.newLine();
/* 499 */         docWriter.append("|-");
/* 500 */         docWriter.newLine();
/*     */       }
/*     */       else
/*     */       {
/* 504 */         docWriter.append("|}");
/* 505 */         docWriter.newLine();
/*     */       }
/*     */     
/*     */     }
/* 509 */     catch (IOException e) {
/*     */       
/* 511 */       e.printStackTrace();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   static void doc(SlotMetadata slotMetadata, boolean advanced) {
/*     */     try {
/* 519 */       String color = advanced ? "red" : "black";
/* 520 */       docWriter.append(String.format("| style=\"text-align:right; white-space: nowrap; font-weight:bold; padding:6px; color:%s\" | %s", new Object[] { color, slotMetadata.getName() }));
/* 521 */       docWriter.newLine();
/* 522 */       docWriter.append(String.format("| %s ", new Object[] { slotMetadata.tooltip }));
/* 523 */       if (slotMetadata.getValueList() != null)
/*     */       {
/* 525 */         docWriter.append(String.format("<br/><em>Choices available:</em> <code>%s</code>", new Object[] { Joiner.on(", ").join(slotMetadata.getValueList()) }));
/*     */       }
/* 527 */       docWriter.newLine();
/* 528 */       docWriter.append(String.format("| <code>%s</code>", new Object[] { slotMetadata.range.replace("[", "").replace("]", "").trim() }));
/* 529 */       docWriter.newLine();
/* 530 */       docWriter.append("|-");
/* 531 */       docWriter.newLine();
/*     */     }
/* 533 */     catch (IOException e) {
/*     */       
/* 535 */       e.printStackTrace();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   static void endDoc() {
/*     */     try {
/* 543 */       docFile = null;
/* 544 */       docWriter.flush();
/* 545 */       docWriter.close();
/*     */     }
/* 547 */     catch (IOException e) {
/*     */       
/* 549 */       e.printStackTrace();
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\Administrator\Downloads\journeymap-forge-1.21-6.0.0-beta.18.jar!\journeymap\clien\\ui\option\OptionSlotFactory.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */