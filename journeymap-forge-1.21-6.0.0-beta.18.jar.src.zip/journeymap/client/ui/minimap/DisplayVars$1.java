/*     */ package journeymap.client.ui.minimap;


/* Location:              C:\Users\Administrator\Downloads\journeymap-forge-1.21-6.0.0-beta.18.jar!\journeymap\clien\\ui\minimap\DisplayVars$1.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */