/*     */ package journeymap.client.ui.minimap;
/*     */ 
/*     */ import com.mojang.blaze3d.platform.InputConstants;
/*     */ import com.mojang.blaze3d.platform.Window;
/*     */ import journeymap.client.JourneymapClient;
/*     */ import journeymap.client.properties.MiniMapProperties;
/*     */ import journeymap.client.ui.UIManager;
/*     */ import journeymap.client.ui.theme.ThemeLabelSource;
/*     */ import net.minecraft.client.Minecraft;
/*     */ import net.minecraft.client.gui.GuiGraphics;
/*     */ import net.minecraft.world.effect.MobEffect;
/*     */ import net.minecraft.world.phys.Vec2;
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Effect
/*     */   implements Selectable
/*     */ {
/*     */   private static Effect INSTANCE;
/*     */   private int x;
/*     */   private int y;
/*     */   private int height;
/*     */   private int width;
/*  24 */   private int dragOffsetX = 0;
/*  25 */   private int dragOffsetY = 0;
/*     */   
/*     */   private boolean dragging = false;
/*     */ 
/*     */   
/*     */   public static Effect getInstance() {
/*  31 */     if (INSTANCE == null)
/*     */     {
/*  33 */       INSTANCE = new Effect();
/*     */     }
/*  35 */     return INSTANCE;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static int[] effectProcessor(int k, int l, int j, int i, MobEffect mobEffect) {
/*  56 */     MiniMapProperties prop = JourneymapClient.getInstance().getActiveMiniMapProperties();
/*  57 */     int x = k;
/*  58 */     int y = l;
/*  59 */     if (prop.moveEffectIcons.get().booleanValue()) {
/*     */       
/*  61 */       boolean vertical = prop.effectVertical.get().booleanValue();
/*  62 */       boolean reversed = prop.effectReversed.get().booleanValue();
/*     */       
/*  64 */       x = Minecraft.getInstance().getWindow().getGuiScaledWidth() - 25;
/*  65 */       y = 1;
/*  66 */       boolean beneficial = mobEffect.isBeneficial();
/*  67 */       int multi = 25 * (beneficial ? (j - 1) : (i - 1));
/*     */       
/*  69 */       if (vertical) {
/*     */         
/*  71 */         x = beneficial ? x : (x - 26);
/*  72 */         y = reversed ? (y - multi) : (y + multi);
/*     */       }
/*  74 */       else if (reversed) {
/*     */         
/*  76 */         y = beneficial ? y : (y + 26);
/*  77 */         x += multi;
/*     */       }
/*     */       else {
/*     */         
/*  81 */         return new int[] { k, l };
/*     */       } 
/*     */     } 
/*  84 */     return new int[] { x, y };
/*     */   }
/*     */ 
/*     */   
/*     */   public void renderBorder(GuiGraphics graphics, int color) {
/*  89 */     MiniMapProperties prop = JourneymapClient.getInstance().getActiveMiniMapProperties();
/*     */     
/*  91 */     boolean vertical = prop.moveEffectIcons.get().booleanValue() ? prop.effectVertical.get().booleanValue() : false;
/*  92 */     boolean reversed = prop.moveEffectIcons.get().booleanValue() ? prop.effectReversed.get().booleanValue() : false;
/*  93 */     color = prop.moveEffectIcons.get().booleanValue() ? color : -65536;
/*  94 */     Window window = Minecraft.getInstance().getWindow();
/*  95 */     this.width = vertical ? 51 : 100;
/*  96 */     this.x = (reversed && !vertical) ? (window.getGuiScaledWidth() + 75) : window.getGuiScaledWidth();
/*  97 */     int endX = this.x - this.width - 2;
/*  98 */     this.height = vertical ? (reversed ? -74 : 102) : 52;
/*  99 */     this.y = (reversed && vertical) ? 26 : 0;
/* 100 */     Vec2 location = getPotionEffectsLocation();
/* 101 */     graphics.pose().pushPose();
/* 102 */     graphics.pose().translate(location.x, location.y - 1.0F, 0.0F);
/*     */     
/* 104 */     int bottomOffset = (reversed && vertical) ? -1 : 1;
/* 105 */     int topOffset = (reversed && vertical) ? 2 : 0;
/*     */     
/* 107 */     graphics.fill(this.x, this.height - 1, endX + 1, this.height + 1, color);
/* 108 */     graphics.fill(this.x - 1, this.height + bottomOffset, this.x + 1, this.y + topOffset, color);
/* 109 */     graphics.fill(this.x, this.y, endX + 1, this.y + 2, color);
/* 110 */     graphics.fill(endX, this.height + bottomOffset, endX + 2, this.y + topOffset, color);
/* 111 */     graphics.pose().popPose();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isDragging() {
/* 117 */     return this.dragging;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean withinBounds(double mouseX, double mouseY) {
/*     */     // Byte code:
/*     */     //   0: invokestatic getInstance : ()Lnet/minecraft/client/Minecraft;
/*     */     //   3: invokevirtual getWindow : ()Lcom/mojang/blaze3d/platform/Window;
/*     */     //   6: invokevirtual getGuiScaledWidth : ()I
/*     */     //   9: istore #5
/*     */     //   11: invokestatic getInstance : ()Ljourneymap/client/JourneymapClient;
/*     */     //   14: invokevirtual getActiveMiniMapProperties : ()Ljourneymap/client/properties/MiniMapProperties;
/*     */     //   17: astore #6
/*     */     //   19: aload #6
/*     */     //   21: getfield effectVertical : Ljourneymap/common/properties/config/BooleanField;
/*     */     //   24: invokevirtual get : ()Ljava/lang/Boolean;
/*     */     //   27: invokevirtual booleanValue : ()Z
/*     */     //   30: istore #7
/*     */     //   32: aload #6
/*     */     //   34: getfield effectReversed : Ljourneymap/common/properties/config/BooleanField;
/*     */     //   37: invokevirtual get : ()Ljava/lang/Boolean;
/*     */     //   40: invokevirtual booleanValue : ()Z
/*     */     //   43: istore #8
/*     */     //   45: aload_0
/*     */     //   46: invokevirtual getPotionEffectsLocation : ()Lnet/minecraft/world/phys/Vec2;
/*     */     //   49: astore #9
/*     */     //   51: iload #5
/*     */     //   53: i2f
/*     */     //   54: aload_0
/*     */     //   55: getfield width : I
/*     */     //   58: iconst_2
/*     */     //   59: isub
/*     */     //   60: i2f
/*     */     //   61: aload #9
/*     */     //   63: getfield x : F
/*     */     //   66: fsub
/*     */     //   67: fsub
/*     */     //   68: f2i
/*     */     //   69: istore #10
/*     */     //   71: aload_0
/*     */     //   72: getfield y : I
/*     */     //   75: i2f
/*     */     //   76: aload #9
/*     */     //   78: getfield y : F
/*     */     //   81: fadd
/*     */     //   82: f2i
/*     */     //   83: istore #11
/*     */     //   85: iload #5
/*     */     //   87: i2f
/*     */     //   88: aload #9
/*     */     //   90: getfield x : F
/*     */     //   93: fadd
/*     */     //   94: f2i
/*     */     //   95: istore #12
/*     */     //   97: aload_0
/*     */     //   98: getfield height : I
/*     */     //   101: i2f
/*     */     //   102: aload #9
/*     */     //   104: getfield y : F
/*     */     //   107: fadd
/*     */     //   108: f2i
/*     */     //   109: istore #13
/*     */     //   111: iload #8
/*     */     //   113: ifeq -> 157
/*     */     //   116: iload #7
/*     */     //   118: ifne -> 157
/*     */     //   121: aload_0
/*     */     //   122: getfield x : I
/*     */     //   125: i2f
/*     */     //   126: aload_0
/*     */     //   127: getfield width : I
/*     */     //   130: iconst_2
/*     */     //   131: isub
/*     */     //   132: i2f
/*     */     //   133: aload #9
/*     */     //   135: getfield x : F
/*     */     //   138: fsub
/*     */     //   139: fsub
/*     */     //   140: f2i
/*     */     //   141: istore #10
/*     */     //   143: aload_0
/*     */     //   144: getfield x : I
/*     */     //   147: i2f
/*     */     //   148: aload #9
/*     */     //   150: getfield x : F
/*     */     //   153: fadd
/*     */     //   154: f2i
/*     */     //   155: istore #12
/*     */     //   157: dload_1
/*     */     //   158: iload #12
/*     */     //   160: i2d
/*     */     //   161: dcmpg
/*     */     //   162: ifge -> 235
/*     */     //   165: dload_1
/*     */     //   166: iload #10
/*     */     //   168: i2d
/*     */     //   169: dcmpl
/*     */     //   170: ifle -> 235
/*     */     //   173: iload #8
/*     */     //   175: ifeq -> 194
/*     */     //   178: iload #7
/*     */     //   180: ifeq -> 194
/*     */     //   183: dload_3
/*     */     //   184: iload #11
/*     */     //   186: i2d
/*     */     //   187: dcmpg
/*     */     //   188: ifge -> 235
/*     */     //   191: goto -> 202
/*     */     //   194: dload_3
/*     */     //   195: iload #11
/*     */     //   197: i2d
/*     */     //   198: dcmpl
/*     */     //   199: ifle -> 235
/*     */     //   202: iload #8
/*     */     //   204: ifeq -> 223
/*     */     //   207: iload #7
/*     */     //   209: ifeq -> 223
/*     */     //   212: dload_3
/*     */     //   213: iload #13
/*     */     //   215: i2d
/*     */     //   216: dcmpl
/*     */     //   217: ifle -> 235
/*     */     //   220: goto -> 231
/*     */     //   223: dload_3
/*     */     //   224: iload #13
/*     */     //   226: i2d
/*     */     //   227: dcmpg
/*     */     //   228: ifge -> 235
/*     */     //   231: iconst_1
/*     */     //   232: goto -> 236
/*     */     //   235: iconst_0
/*     */     //   236: ireturn
/*     */     // Line number table:
/*     */     //   Java source line number -> byte code offset
/*     */     //   #122	-> 0
/*     */     //   #123	-> 11
/*     */     //   #124	-> 19
/*     */     //   #125	-> 32
/*     */     //   #126	-> 45
/*     */     //   #127	-> 51
/*     */     //   #128	-> 71
/*     */     //   #129	-> 85
/*     */     //   #130	-> 97
/*     */     //   #132	-> 111
/*     */     //   #134	-> 121
/*     */     //   #135	-> 143
/*     */     //   #138	-> 157
/*     */     // Local variable table:
/*     */     //   start	length	slot	name	descriptor
/*     */     //   0	237	0	this	Ljourneymap/client/ui/minimap/Effect;
/*     */     //   0	237	1	mouseX	D
/*     */     //   0	237	3	mouseY	D
/*     */     //   11	226	5	screenWidth	I
/*     */     //   19	218	6	prop	Ljourneymap/client/properties/MiniMapProperties;
/*     */     //   32	205	7	vertical	Z
/*     */     //   45	192	8	reversed	Z
/*     */     //   51	186	9	location	Lnet/minecraft/world/phys/Vec2;
/*     */     //   71	166	10	leftX	I
/*     */     //   85	152	11	topY	I
/*     */     //   97	140	12	rightX	I
/*     */     //   111	126	13	bottomY	I
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean mouseClicked(double mouseX, double mouseY, int pButton) {
/* 146 */     if (withinBounds(mouseX, mouseY) && !this.dragging) {
/*     */       
/* 148 */       MiniMapProperties prop = JourneymapClient.getInstance().getActiveMiniMapProperties();
/* 149 */       int screenWidth = Minecraft.getInstance().getWindow().getGuiScaledWidth();
/* 150 */       this.dragging = true;
/* 151 */       this.dragOffsetX = (int)(mouseX - (prop.effectTranslateX.get().intValue() + screenWidth));
/* 152 */       this.dragOffsetY = (int)(mouseY - prop.effectTranslateY.get().intValue());
/* 153 */       return true;
/*     */     } 
/*     */     
/* 156 */     this.dragging = false;
/* 157 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean mouseDragged(double pMouseX, double pMouseY, int pButton, double pDragX, double pDragY) {
/* 163 */     if (this.dragging) {
/*     */       
/* 165 */       int screenWidth = Minecraft.getInstance().getWindow().getGuiScaledWidth();
/* 166 */       MiniMapProperties prop = JourneymapClient.getInstance().getActiveMiniMapProperties();
/* 167 */       int posX = (int)(pMouseX - this.dragOffsetX) - screenWidth;
/* 168 */       int posY = (int)(pMouseY - this.dragOffsetY);
/*     */       
/* 170 */       Vec2 loc = withinScreenBounds(posX, posY);
/* 171 */       prop.effectTranslateX.set(Integer.valueOf((int)loc.x));
/* 172 */       prop.effectTranslateY.set(Integer.valueOf((int)loc.y));
/* 173 */       return true;
/*     */     } 
/* 175 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Vec2 withinScreenBounds(double pMouseX, double pMouseY) {
/* 181 */     int screenHeight = Minecraft.getInstance().getWindow().getGuiScaledHeight();
/* 182 */     int screenWidth = Minecraft.getInstance().getWindow().getGuiScaledWidth();
/* 183 */     MiniMapProperties prop = JourneymapClient.getInstance().getActiveMiniMapProperties();
/* 184 */     boolean vertical = prop.effectVertical.get().booleanValue();
/* 185 */     boolean reversed = prop.effectReversed.get().booleanValue();
/* 186 */     double x = (pMouseX > 0.0D) ? 0.0D : ((pMouseX - this.width < -screenWidth) ? (-screenWidth + this.width) : pMouseX);
/* 187 */     double y = (pMouseY < 0.0D) ? 0.0D : ((pMouseY + this.height > screenHeight) ? (screenHeight - this.height) : pMouseY);
/*     */     
/* 189 */     if (reversed && !vertical) {
/*     */       
/* 191 */       x = (pMouseX + 75.0D > 0.0D) ? -75.0D : ((pMouseX - 26.0D < -screenWidth) ? (-screenWidth + 26) : pMouseX);
/*     */     
/*     */     }
/* 194 */     else if (reversed) {
/*     */       
/* 196 */       y = (pMouseY - 75.0D < 0.0D) ? 75.0D : ((pMouseY + 26.0D > screenHeight) ? (screenHeight - 26) : pMouseY);
/*     */     } 
/*     */     
/* 199 */     return new Vec2((float)x, (float)y);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean mouseReleased(double mouseX, double mouseY, int mouseButton) {
/* 205 */     if (this.dragging) {
/*     */       
/* 207 */       this.dragOffsetX = 0;
/* 208 */       this.dragOffsetY = 0;
/* 209 */       this.dragging = false;
/* 210 */       return true;
/*     */     } 
/* 212 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void tick() {
/* 218 */     long windowId = Minecraft.getInstance().getWindow().getWindow();
/* 219 */     int speed = (int)((JourneymapClient.getInstance().getActiveMiniMapProperties()).minimapKeyMovementSpeed.get().floatValue() * 1000.0F);
/*     */     
/* 221 */     if (InputConstants.isKeyDown(windowId, 265)) {
/*     */       
/* 223 */       moveOnKey(0, -speed);
/*     */     }
/* 225 */     else if (InputConstants.isKeyDown(windowId, 264)) {
/*     */       
/* 227 */       moveOnKey(0, speed);
/*     */     }
/* 229 */     else if (InputConstants.isKeyDown(windowId, 263)) {
/*     */       
/* 231 */       moveOnKey(-speed, 0);
/*     */     }
/* 233 */     else if (InputConstants.isKeyDown(windowId, 262)) {
/*     */       
/* 235 */       moveOnKey(speed, 0);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   private void moveOnKey(int incX, int incY) {
/* 241 */     MiniMapProperties prop = JourneymapClient.getInstance().getActiveMiniMapProperties();
/* 242 */     int posX = prop.effectTranslateX.get().intValue();
/* 243 */     int posY = prop.effectTranslateY.get().intValue();
/*     */     
/* 245 */     Vec2 loc = withinScreenBounds((posX + incX), (posY + incY));
/*     */     
/* 247 */     prop.effectTranslateX.set(Integer.valueOf((int)loc.x));
/* 248 */     prop.effectTranslateY.set(Integer.valueOf((int)loc.y));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Vec2 getPotionEffectsLocation() {
/* 258 */     int x = 0;
/* 259 */     int y = 0;
/* 260 */     Window window = Minecraft.getInstance().getWindow();
/* 261 */     DisplayVars vars = UIManager.INSTANCE.getMiniMap().getDisplayVars();
/* 262 */     MiniMapProperties prop = JourneymapClient.getInstance().getActiveMiniMapProperties();
/* 263 */     if (canPotionShift()) {
/*     */       
/* 265 */       x = prop.effectTranslateX.get().intValue();
/* 266 */       y = prop.effectTranslateY.get().intValue();
/*     */       
/* 268 */       if (x == 0 && y == 0) {
/*     */         
/* 270 */         x = -(window.getGuiScaledWidth() - (int)(vars.textureX / window.getGuiScale()));
/*     */         
/* 272 */         prop.effectTranslateX.set(Integer.valueOf(x));
/*     */       }
/*     */       else {
/*     */         
/* 276 */         return withinScreenBounds(x, y);
/*     */       } 
/*     */     } 
/*     */ 
/*     */     
/* 281 */     return new Vec2(x, y);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean canPotionShift() {
/* 286 */     DisplayVars vars = UIManager.INSTANCE.getMiniMap().getDisplayVars();
/* 287 */     MiniMapProperties prop = JourneymapClient.getInstance().getActiveMiniMapProperties();
/* 288 */     return (prop.moveEffectIcons.get().booleanValue() || Position.Custom.equals(vars.position));
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean inDefaultPotionArea() {
/* 294 */     Window window = Minecraft.getInstance().getWindow();
/* 295 */     DisplayVars vars = UIManager.INSTANCE.getMiniMap().getDisplayVars();
/* 296 */     MiniMapProperties miniMapProperties = JourneymapClient.getInstance().getActiveMiniMapProperties();
/* 297 */     int topInfoLabelsHeight = vars.getInfoLabelAreaHeight((Minecraft.getInstance()).font, vars.minimapSpec.labelTop, new ThemeLabelSource.InfoSlot[] { (ThemeLabelSource.InfoSlot)ThemeLabelSource.values.get(miniMapProperties.info1Label.get()), (ThemeLabelSource.InfoSlot)ThemeLabelSource.values.get(miniMapProperties.info2Label.get()) });
/* 298 */     double scale = window.getGuiScale();
/* 299 */     int zoneTop = (int)(50.0D * scale) + 10;
/* 300 */     int zoneRight = window.getGuiScaledWidth() - (int)(window.getGuiScaledWidth() * 0.05D * scale);
/* 301 */     int right = (int)((vars.textureX + vars.minimapWidth) / scale);
/* 302 */     int top = vars.textureY - topInfoLabelsHeight;
/*     */     
/* 304 */     return (right > zoneRight && top < zoneTop);
/*     */   }
/*     */ }


/* Location:              C:\Users\Administrator\Downloads\journeymap-forge-1.21-6.0.0-beta.18.jar!\journeymap\clien\\ui\minimap\Effect.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */