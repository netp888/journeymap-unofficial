/*     */ package journeymap.client.ui.component;
/*     */ 
/*     */ import journeymap.client.render.draw.DrawUtil;
/*     */ import journeymap.client.ui.component.buttons.Button;
/*     */ import net.minecraft.client.gui.GuiGraphics;
/*     */ import net.minecraft.client.gui.components.Button;
/*     */ 
/*     */ public class DropDownItem
/*     */   extends Button
/*     */ {
/*     */   private Object id;
/*     */   private String label;
/*     */   private SelectableParent parent;
/*     */   private Button.OnPress onPress;
/*     */   private boolean autoClose = true;
/*     */   
/*     */   public DropDownItem(SelectableParent parent, Object id, String label, Button.OnPress onPress, String... toolTip) {
/*  18 */     this(parent, id, label, onPress);
/*  19 */     setTooltip(toolTip);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public DropDownItem(SelectableParent parent, Object id, String label, Button.OnPress onPress) {
/*  25 */     super(label);
/*  26 */     this.onPress = onPress;
/*  27 */     this.label = label;
/*  28 */     this.id = id;
/*  29 */     this.parent = parent;
/*  30 */     setTextOnly(this.fontRenderer);
/*     */   }
/*     */ 
/*     */   
/*     */   public DropDownItem(SelectableParent parent, Object id, String label, String... toolTip) {
/*  35 */     this(parent, id, label);
/*  36 */     setTooltip(toolTip);
/*     */   }
/*     */ 
/*     */   
/*     */   public DropDownItem(SelectableParent parent, Object id, String label) {
/*  41 */     super(label);
/*  42 */     this.label = label;
/*  43 */     this.id = id;
/*  44 */     this.parent = parent;
/*  45 */     setTextOnly(this.fontRenderer);
/*     */   }
/*     */ 
/*     */   
/*     */   public DropDownItem(SelectableParent parent, Object id, boolean autoClose, String label, Button.OnPress onPress) {
/*  50 */     this(parent, id, label, onPress);
/*  51 */     this.autoClose = autoClose;
/*     */   }
/*     */ 
/*     */   
/*     */   public void press() {
/*  56 */     this.onPress.onPress((Button)this);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void renderSpecialDecoration(GuiGraphics graphics, int mouseX, int mouseY, int x, int y, int width, int height) {
/*  62 */     if (!this.autoClose) {
/*     */       
/*  64 */       graphics.pose().pushPose();
/*  65 */       DrawUtil.drawCenteredLabel(graphics, ">", (x + width - 10), getMiddleY(), null, 0.0F, this.varLabelColor, 1.0F, 1.0D, this.drawLabelShadow);
/*  66 */       graphics.pose().popPose();
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public Object getId() {
/*  72 */     return this.id;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String getLabel() {
/*  78 */     return this.label;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isAutoClose() {
/*  83 */     return this.autoClose;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean mouseClicked(double mouseX, double mouseY, int button) {
/*  89 */     if (isHovered()) {
/*     */       
/*  91 */       this.parent.setSelected(this);
/*  92 */       return true;
/*     */     } 
/*  94 */     return super.mouseClicked(mouseX, mouseY, button);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isMouseOver(double mouseX, double mouseY) {
/* 100 */     return super.isMouseOver(mouseX, mouseY);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isHovered() {
/* 106 */     return super.isHovered();
/*     */   }
/*     */ }


/* Location:              C:\Users\Administrator\Downloads\journeymap-forge-1.21-6.0.0-beta.18.jar!\journeymap\clien\\ui\component\DropDownItem.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */