/*    */ package journeymap.client.ui.component;
/*    */ 
/*    */ import java.util.function.DoubleSupplier;
/*    */ import journeymap.client.texture.TextureCache;
/*    */ import net.minecraft.client.gui.ComponentPath;
/*    */ import net.minecraft.client.gui.GuiGraphics;
/*    */ import net.minecraft.client.gui.components.AbstractWidget;
/*    */ import net.minecraft.client.gui.narration.NarrationElementOutput;
/*    */ import net.minecraft.client.gui.navigation.FocusNavigationEvent;
/*    */ import net.minecraft.client.sounds.SoundManager;
/*    */ import net.minecraft.network.chat.CommonComponents;
/*    */ 
/*    */ 
/*    */ 
/*    */ public class LogoWidget
/*    */   extends AbstractWidget
/*    */ {
/*    */   private static final int TEX_WIDTH = 60;
/*    */   private static final int PADDING = 3;
/*    */   private final DoubleSupplier scaleFactorSupplier;
/*    */   
/*    */   public LogoWidget(DoubleSupplier scaleFactorSupplier) {
/* 23 */     super(0, 0, calculateWidth(scaleFactorSupplier) + 6, calculateWidth(scaleFactorSupplier) + 6, CommonComponents.EMPTY);
/* 24 */     this.scaleFactorSupplier = scaleFactorSupplier;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   protected void updateWidgetNarration(NarrationElementOutput narrationElementOutput) {}
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void playDownSound(SoundManager soundHandler) {}
/*    */ 
/*    */ 
/*    */   
/*    */   public boolean isActive() {
/* 40 */     return false;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public ComponentPath nextFocusPath(FocusNavigationEvent focusNavigationEvent) {
/* 46 */     return null;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public int getWidth() {
/* 52 */     return calculateWidth(this.scaleFactorSupplier) + 6;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public int getHeight() {
/* 58 */     return calculateWidth(this.scaleFactorSupplier) + 6;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   protected void renderWidget(GuiGraphics graphics, int mouseX, int mouseY, float partialTicks) {
/* 64 */     int texWidth = calculateWidth(this.scaleFactorSupplier);
/* 65 */     graphics.blit(TextureCache.Logo, getX() + 3, getY() + 3, texWidth, texWidth, 0.0F, 0.0F, 60, 60, 60, 60);
/*    */   }
/*    */ 
/*    */   
/*    */   private static int calculateWidth(DoubleSupplier scaleFactorSupplier) {
/* 70 */     return (int)(60.0D / scaleFactorSupplier.getAsDouble() / 2.0D);
/*    */   }
/*    */ }


/* Location:              C:\Users\Administrator\Downloads\journeymap-forge-1.21-6.0.0-beta.18.jar!\journeymap\clien\\ui\component\LogoWidget.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */