/*     */ package journeymap.client.ui.component.buttons;
/*     */ 
/*     */ import journeymap.client.Constants;
/*     */ import journeymap.client.ui.component.IConfigFieldHolder;
/*     */ import journeymap.common.properties.config.ConfigField;
/*     */ import journeymap.common.properties.config.IntegerField;
/*     */ import net.minecraft.client.Minecraft;
/*     */ import net.minecraft.client.gui.Font;
/*     */ import net.minecraft.client.gui.GuiGraphics;
/*     */ import net.minecraft.network.chat.Component;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class IntSliderButton
/*     */   extends AbstractSliderButton
/*     */   implements IConfigFieldHolder<IntegerField>, SliderButton
/*     */ {
/*  25 */   public String prefix = "";
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean dragging = false;
/*     */ 
/*     */ 
/*     */   
/*  33 */   public int minValue = 0;
/*     */ 
/*     */ 
/*     */   
/*  37 */   public int maxValue = 0;
/*     */ 
/*     */ 
/*     */   
/*  41 */   public String suffix = "";
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean drawString = true;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   IntegerField field;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public IntSliderButton(IntegerField field, String prefix, String suf) {
/*  60 */     this(field, prefix, suf, true);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public IntSliderButton(IntegerField field, String prefix, String suf, boolean drawStr) {
/*  73 */     super((ConfigField<?>)field, prefix);
/*  74 */     this.minValue = field.getMinValue();
/*  75 */     this.maxValue = field.getMaxValue();
/*  76 */     this.prefix = prefix;
/*  77 */     this.suffix = suf;
/*  78 */     this.field = field;
/*  79 */     setValue(field.get().intValue());
/*  80 */     this.disabledLabelColor = Integer.valueOf(4210752);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected void renderBg(GuiGraphics graphics, Minecraft mc, int mouseX, int mouseY) {
/*  86 */     super.renderBg(graphics, mc, mouseX, mouseY);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean mouseDragged(double mouseX, double mouseY, int button, double mouseDX, double mouseDY) {
/*  92 */     if (this.visible && isEnabled() && isMouseOver(mouseX, mouseY) && this.dragging) {
/*     */       
/*  94 */       setSliderValue((mouseX - (getX() + 4)) / (this.width - 8));
/*     */       
/*  96 */       if (this.clickListeners != null)
/*     */       {
/*  98 */         checkClickListeners();
/*     */       }
/* 100 */       return true;
/*     */     } 
/* 102 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   private void setValueFromMouse(double mouseX) {
/* 107 */     setSliderValue((mouseX - (getX() + 4)) / (this.width - 8));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean mouseClicked(double mouseX, double mouseY, int button) {
/* 114 */     if (mouseOver(mouseX, mouseY) && isEnabled()) {
/*     */       
/* 116 */       this.dragging = true;
/* 117 */       setValueFromMouse(mouseX);
/* 118 */       checkClickListeners();
/* 119 */       return true;
/*     */     } 
/* 121 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public double getSliderValue() {
/* 132 */     return (this.field.get().intValue() - this.minValue * 1.0D) / (this.maxValue - this.minValue);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setSliderValue(double sliderValue) {
/* 142 */     if (sliderValue < 0.0D)
/*     */     {
/* 144 */       sliderValue = 0.0D;
/*     */     }
/*     */     
/* 147 */     if (sliderValue > 1.0D)
/*     */     {
/* 149 */       sliderValue = 1.0D;
/*     */     }
/*     */     
/* 152 */     int intVal = (int)Math.round(sliderValue * (this.maxValue - this.minValue) + this.minValue);
/* 153 */     setValue(intVal);
/*     */   }
/*     */ 
/*     */   
/*     */   public void updateLabel() {
/* 158 */     if (this.drawString)
/*     */     {
/* 160 */       if (this.field.hasCustomMessage()) {
/*     */         
/* 162 */         setMessage((Component)Constants.getStringTextComponent(this.field.getCustomMessage()));
/*     */       }
/*     */       else {
/*     */         
/* 166 */         setMessage((Component)Constants.getStringTextComponent(this.prefix + this.prefix + this.field.get()));
/*     */       } 
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean mouseReleased(double mouseX, double mouseY, int mouseButton) {
/* 177 */     if (this.dragging) {
/*     */       
/* 179 */       this.dragging = false;
/* 180 */       this.field.save();
/* 181 */       checkClickListeners();
/*     */     } 
/* 183 */     return super.mouseReleased(mouseX, mouseY, mouseButton);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public int getFitWidth(Font fr) {
/* 189 */     int max = fr.width(this.prefix + this.prefix + this.minValue);
/* 190 */     max = Math.max(max, fr.width(this.prefix + this.prefix + this.maxValue));
/* 191 */     return max + this.WIDTH_PAD;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean keyPressed(int key, int value, int modifier) {
/* 197 */     if (isEnabled()) {
/*     */       
/* 199 */       if (key == 263 || key == 45) {
/*     */         
/* 201 */         setValue(Math.max(this.minValue, getValue() - 1));
/* 202 */         if (this.clickListeners != null)
/*     */         {
/* 204 */           checkClickListeners();
/*     */         }
/* 206 */         return true;
/*     */       } 
/*     */       
/* 209 */       if (key == 262 || key == 61) {
/*     */         
/* 211 */         setValue(Math.min(this.maxValue, getValue() + 1));
/* 212 */         if (this.clickListeners != null)
/*     */         {
/* 214 */           checkClickListeners();
/*     */         }
/* 216 */         return true;
/*     */       } 
/*     */     } 
/* 219 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getValue() {
/* 229 */     return this.field.get().intValue();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setValue(int value) {
/* 239 */     value = Math.min(value, this.field.getMaxValue());
/* 240 */     value = Math.max(value, this.field.getMinValue());
/* 241 */     if (this.field.get().intValue() != value) {
/*     */       
/* 243 */       this.field.set(Integer.valueOf(value));
/* 244 */       if (!this.dragging)
/*     */       {
/* 246 */         this.field.save();
/*     */       }
/*     */     } 
/* 249 */     updateLabel();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void refresh() {
/* 255 */     setValue(this.field.get().intValue());
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public IntegerField getConfigField() {
/* 261 */     return this.field;
/*     */   }
/*     */ }


/* Location:              C:\Users\Administrator\Downloads\journeymap-forge-1.21-6.0.0-beta.18.jar!\journeymap\clien\\ui\component\buttons\IntSliderButton.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */