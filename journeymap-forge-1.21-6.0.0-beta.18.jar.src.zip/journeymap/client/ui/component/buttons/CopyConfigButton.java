/*    */ package journeymap.client.ui.component.buttons;
/*    */ 
/*    */ import journeymap.client.ui.component.popupscreenbutton.PopupButton;
/*    */ import journeymap.client.ui.component.popupscreenbutton.PopupButtonScreen;
/*    */ import journeymap.client.ui.component.popupscreenbutton.copyconfig.CopyConfigScreen;
/*    */ import journeymap.common.properties.catagory.Category;
/*    */ 
/*    */ public class CopyConfigButton
/*    */   extends PopupButton<Category>
/*    */ {
/*    */   private final Category[] toCategories;
/*    */   private final Category categoryFrom;
/*    */   
/*    */   public CopyConfigButton(String label, Category categoryFrom, Category[] toCategories, PopupButtonScreen.OnClose<Category> onClose) {
/* 15 */     super(0, 0, label, () -> new CopyConfigScreen(categoryFrom, toCategories), onClose);
/* 16 */     this.categoryFrom = categoryFrom;
/* 17 */     this.toCategories = toCategories;
/*    */   }
/*    */ }


/* Location:              C:\Users\Administrator\Downloads\journeymap-forge-1.21-6.0.0-beta.18.jar!\journeymap\clien\\ui\component\buttons\CopyConfigButton.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */