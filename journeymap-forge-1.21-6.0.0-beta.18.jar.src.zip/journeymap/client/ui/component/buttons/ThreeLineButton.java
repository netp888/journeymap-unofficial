/*    */ package journeymap.client.ui.component.buttons;
/*    */ 
/*    */ import java.awt.Color;
/*    */ import journeymap.client.render.draw.DrawUtil;
/*    */ import net.minecraft.client.gui.GuiGraphics;
/*    */ import net.minecraft.client.gui.components.Button;
/*    */ 
/*    */ public class ThreeLineButton
/*    */   extends Button
/*    */ {
/*    */   final int gap;
/* 12 */   protected static Integer background = Integer.valueOf((new Color(20, 20, 20)).getRGB());
/*    */ 
/*    */   
/*    */   public ThreeLineButton(int gap, int width, int height, Button.OnPress onPress) {
/* 16 */     super("", onPress);
/* 17 */     this.gap = gap;
/* 18 */     setWidth(width);
/* 19 */     setHeight(height);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void renderWidget(GuiGraphics graphics, int mouseX, int mouseY, float partialTicks) {
/* 26 */     DrawUtil.drawRectangle(graphics, getX(), getY(), this.width, this.height, background.intValue(), 1.0F);
/* 27 */     for (int i = 0; i < 3; i++)
/*    */     {
/* 29 */       DrawUtil.drawRectangle(graphics, (getX() + 2), (getY() + 2 + i * this.gap), (this.width - 4), 1.0D, -1, 0.3F);
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Users\Administrator\Downloads\journeymap-forge-1.21-6.0.0-beta.18.jar!\journeymap\clien\\ui\component\buttons\ThreeLineButton.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */