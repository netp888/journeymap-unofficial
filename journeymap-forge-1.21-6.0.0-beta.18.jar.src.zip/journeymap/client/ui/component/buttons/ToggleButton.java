/*    */ package journeymap.client.ui.component.buttons;
/*    */ 
/*    */ import journeymap.client.render.draw.DrawUtil;
/*    */ import journeymap.client.texture.Texture;
/*    */ import journeymap.client.texture.TextureCache;
/*    */ import net.minecraft.client.gui.GuiGraphics;
/*    */ import net.minecraft.client.gui.components.Button;
/*    */ 
/*    */ 
/*    */ public class ToggleButton
/*    */   extends Button
/*    */ {
/* 13 */   private static final Texture ON = TextureCache.getTexture(TextureCache.TOGGLE_ON);
/* 14 */   private static final Texture OFF = TextureCache.getTexture(TextureCache.TOGGLE_OFF);
/*    */   
/*    */   private static boolean toggled = true;
/*    */   
/*    */   public ToggleButton() {
/* 19 */     super("");
/*    */   }
/*    */ 
/*    */   
/*    */   public ToggleButton(String label, Button.OnPress onPress) {
/* 24 */     super(label, onPress);
/*    */   }
/*    */ 
/*    */   
/*    */   public ToggleButton(int width, int height, String label, Button.OnPress onPress) {
/* 29 */     super(width, height, label, onPress);
/*    */   }
/*    */ 
/*    */   
/*    */   private Texture getHandleSprite() {
/* 34 */     return toggled ? ON : OFF;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void renderWidget(GuiGraphics graphics, int mouseX, int mouseY, float partialTicks) {
/* 41 */     setSize(40, 20);
/*    */     
/* 43 */     DrawUtil.drawQuad(graphics.pose(), getHandleSprite(), getX(), (getY() - 7), 40.0D, 35.0D, false, 0.0D);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public boolean mouseClicked(double x, double y, int button) {
/* 49 */     boolean clicked = super.mouseClicked(x, y, button);
/* 50 */     if (clicked)
/*    */     {
/* 52 */       toggled = !toggled;
/*    */     }
/* 54 */     return clicked;
/*    */   }
/*    */ }


/* Location:              C:\Users\Administrator\Downloads\journeymap-forge-1.21-6.0.0-beta.18.jar!\journeymap\clien\\ui\component\buttons\ToggleButton.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */