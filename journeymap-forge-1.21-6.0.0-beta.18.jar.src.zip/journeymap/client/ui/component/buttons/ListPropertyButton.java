/*     */ package journeymap.client.ui.component.buttons;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.List;
/*     */ import journeymap.api.v2.client.option.KeyedEnum;
/*     */ import journeymap.client.Constants;
/*     */ import journeymap.client.ui.component.IConfigFieldHolder;
/*     */ import journeymap.common.properties.config.ConfigField;
/*     */ import net.minecraft.client.gui.Font;
/*     */ import net.minecraft.client.gui.components.Button;
/*     */ import net.minecraft.network.chat.Component;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ListPropertyButton<T>
/*     */   extends Button
/*     */   implements IConfigFieldHolder<ConfigField<T>>
/*     */ {
/*     */   protected final ConfigField<T> field;
/*     */   protected final List<T> values;
/*     */   protected final String baseLabel;
/*  28 */   protected final String glyph = "⇕";
/*  29 */   protected final String labelPattern = "%1$s : %2$s %3$s %2$s";
/*     */ 
/*     */   
/*     */   public ListPropertyButton(Collection<T> values, String label, ConfigField<T> field, Button.OnPress pressable) {
/*  33 */     super("", pressable);
/*  34 */     this.field = field;
/*  35 */     this.values = new ArrayList<>(values);
/*  36 */     this.baseLabel = label;
/*  37 */     setValue((T)field.get());
/*  38 */     this.disabledLabelColor = Integer.valueOf(4210752);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public ListPropertyButton(Collection<T> values, String label, ConfigField<T> field) {
/*  44 */     this(values, label, field, emptyPressable());
/*     */   }
/*     */   
/*     */   public void setValue(T value) {
/*     */     String label;
/*  49 */     if (!this.field.get().equals(value)) {
/*     */       
/*  51 */       this.field.set(value);
/*  52 */       this.field.save();
/*     */     } 
/*     */     
/*  55 */     if (value instanceof KeyedEnum) {
/*     */       
/*  57 */       label = Constants.getString(((KeyedEnum)value).getKey());
/*     */     }
/*     */     else {
/*     */       
/*  61 */       label = Constants.getString(value.toString());
/*     */     } 
/*     */     
/*  64 */     setMessage((Component)Constants.getStringTextComponent(getFormattedLabel(label)));
/*     */   }
/*     */ 
/*     */   
/*     */   public ConfigField<T> getField() {
/*  69 */     return this.field;
/*     */   }
/*     */ 
/*     */   
/*     */   public void nextOption() {
/*  74 */     int index = this.values.indexOf(this.field.get()) + 1;
/*  75 */     if (index == this.values.size())
/*     */     {
/*  77 */       index = 0;
/*     */     }
/*  79 */     setValue(this.values.get(index));
/*     */   }
/*     */ 
/*     */   
/*     */   public void prevOption() {
/*  84 */     int index = this.values.indexOf(this.field.get()) - 1;
/*  85 */     if (index == -1)
/*     */     {
/*  87 */       index = this.values.size() - 1;
/*     */     }
/*  89 */     setValue(this.values.get(index));
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean mouseClicked(double mouseX, double mouseY, int button) {
/*  95 */     if (mouseOver(mouseX, mouseY))
/*     */     {
/*  97 */       if (button == 0) {
/*     */         
/*  99 */         nextOption();
/*     */       }
/* 101 */       else if (button == 1) {
/*     */         
/* 103 */         prevOption();
/* 104 */         this.onPress.onPress(this);
/*     */       } 
/*     */     }
/* 107 */     return super.mouseClicked(mouseX, mouseY, button);
/*     */   }
/*     */ 
/*     */   
/*     */   protected String getFormattedLabel(String value) {
/* 112 */     return String.format("%1$s : %2$s %3$s %2$s", new Object[] { this.baseLabel, "⇕", value });
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public int getFitWidth(Font fr) {
/* 118 */     int max = fr.width(getMessage().getString());
/* 119 */     for (T value : this.values)
/*     */     {
/* 121 */       max = Math.max(max, fr.width(getFormattedLabel(value.toString())));
/*     */     }
/* 123 */     return max + this.WIDTH_PAD;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean keyTyped(char c, int i) {
/* 128 */     if (isMouseOver()) {
/*     */       
/* 130 */       if (i == 263 || i == 264 || i == 45) {
/*     */         
/* 132 */         prevOption();
/* 133 */         return true;
/*     */       } 
/* 135 */       if (i == 262 || i == 265 || i == 61) {
/*     */         
/* 137 */         nextOption();
/* 138 */         return true;
/*     */       } 
/*     */     } 
/* 141 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void refresh() {
/* 147 */     setValue((T)this.field.get());
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public ConfigField<T> getConfigField() {
/* 153 */     return this.field;
/*     */   }
/*     */ }


/* Location:              C:\Users\Administrator\Downloads\journeymap-forge-1.21-6.0.0-beta.18.jar!\journeymap\clien\\ui\component\buttons\ListPropertyButton.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */