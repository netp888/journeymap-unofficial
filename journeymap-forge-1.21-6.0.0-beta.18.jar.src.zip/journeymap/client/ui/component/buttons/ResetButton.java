/*    */ package journeymap.client.ui.component.buttons;
/*    */ 
/*    */ import journeymap.client.Constants;
/*    */ import journeymap.common.properties.catagory.Category;
/*    */ import net.minecraft.client.gui.components.Button;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ResetButton
/*    */   extends Button
/*    */ {
/*    */   public final Category category;
/*    */   
/*    */   public ResetButton(Category category) {
/* 24 */     super(Constants.getString("jm.config.reset"));
/* 25 */     this.category = category;
/* 26 */     setTooltip(new String[] { Constants.getString("jm.config.reset.tooltip") });
/* 27 */     setDrawBackground(false);
/* 28 */     setLabelColors(Integer.valueOf(16711680), Integer.valueOf(16711680), null);
/*    */   }
/*    */ 
/*    */   
/*    */   public ResetButton(Category category, Button.OnPress onPress) {
/* 33 */     super(Constants.getString("jm.config.reset"), onPress);
/* 34 */     this.category = category;
/* 35 */     setTooltip(new String[] { Constants.getString("jm.config.reset.tooltip") });
/* 36 */     setDrawBackground(false);
/* 37 */     setLabelColors(Integer.valueOf(16711680), Integer.valueOf(16711680), null);
/*    */   }
/*    */ }


/* Location:              C:\Users\Administrator\Downloads\journeymap-forge-1.21-6.0.0-beta.18.jar!\journeymap\clien\\ui\component\buttons\ResetButton.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */