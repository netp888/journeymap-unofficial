package journeymap.client.ui.component.buttons;

public interface ToggleListener {
  boolean onToggle(OnOffButton paramOnOffButton, boolean paramBoolean);
}


/* Location:              C:\Users\Administrator\Downloads\journeymap-forge-1.21-6.0.0-beta.18.jar!\journeymap\clien\\ui\component\buttons\OnOffButton$ToggleListener.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */