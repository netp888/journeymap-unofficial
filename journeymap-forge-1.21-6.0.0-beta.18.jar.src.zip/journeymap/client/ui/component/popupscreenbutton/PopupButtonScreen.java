/*    */ package journeymap.client.ui.component.popupscreenbutton;
/*    */ 
/*    */ import journeymap.client.ui.component.screens.LayeredScreen;
/*    */ import net.minecraft.network.chat.Component;
/*    */ import net.minecraft.resources.ResourceLocation;
/*    */ 
/*    */ public abstract class PopupButtonScreen<T>
/*    */   extends LayeredScreen {
/*  9 */   protected static final ResourceLocation BACKGROUND_SPRITE = ResourceLocation.parse("popup/background");
/*    */   
/*    */   protected OnClose<T> onClose;
/*    */   protected T response;
/*    */   
/*    */   protected PopupButtonScreen(Component title) {
/* 15 */     super(title);
/*    */   }
/*    */ 
/*    */   
/*    */   protected void setOnClosed(OnClose<T> onClose) {
/* 20 */     this.onClose = onClose;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   protected void onClosed() {
/* 26 */     this.onClose.closed(this.response);
/* 27 */     onClose();
/*    */   }
/*    */ 
/*    */   
/*    */   protected void setResponseAndClose(T response) {
/* 32 */     this.response = response;
/* 33 */     onClosed();
/*    */   }
/*    */   
/*    */   @FunctionalInterface
/*    */   public static interface OnClose<T> {
/*    */     void closed(T param1T);
/*    */   }
/*    */ }


/* Location:              C:\Users\Administrator\Downloads\journeymap-forge-1.21-6.0.0-beta.18.jar!\journeymap\clien\\ui\component\popupscreenbutton\PopupButtonScreen.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */