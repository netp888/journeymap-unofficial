/*     */ package journeymap.client.ui.component.popupscreenbutton;
/*     */ 
/*     */ import java.util.List;
/*     */ import journeymap.client.render.draw.DrawUtil;
/*     */ import journeymap.client.ui.component.DropDownItem;
/*     */ import journeymap.client.ui.component.Removable;
/*     */ import journeymap.client.ui.component.SelectableParent;
/*     */ import journeymap.client.ui.component.screens.ScrollPaneScreen;
/*     */ import net.minecraft.client.Minecraft;
/*     */ import net.minecraft.client.gui.Font;
/*     */ import net.minecraft.client.gui.GuiGraphics;
/*     */ import net.minecraft.client.gui.screens.Screen;
/*     */ 
/*     */ public class PopupMenu
/*     */   extends ScrollPaneScreen
/*     */   implements Removable, SelectableParent
/*     */ {
/*     */   private static final int MAX_DISPLAY_SIZE = 6;
/*     */   protected int mouseX;
/*     */   protected int mouseY;
/*     */   protected final Screen parent;
/*     */   protected DropDownItem selected;
/*     */   protected boolean pass = false;
/*     */   protected boolean isSub = false;
/*     */   protected boolean mouseOver = false;
/*     */   
/*     */   public PopupMenu(PopupMenu parent) {
/*  28 */     this((Screen)parent);
/*  29 */     this.isSub = true;
/*     */   }
/*     */ 
/*     */   
/*     */   public PopupMenu(Screen parent) {
/*  34 */     super(null, null, 0, 0, 0, 0);
/*  35 */     this.parent = parent;
/*  36 */     setParent(this);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void display(List<DropDownItem> items) {
/*  42 */     if (!this.pass) {
/*     */       
/*  44 */       for (DropDownItem item : items)
/*     */       {
/*  46 */         item.setHorizontalAlignment(DrawUtil.HAlign.Right);
/*     */       }
/*  48 */       this.pass = true;
/*  49 */       setRenderDecorations(false);
/*  50 */       setRenderSolidBackground(true);
/*  51 */       setItems(items);
/*  52 */       setPaneWidth(getPaneWidth(items));
/*  53 */       setPaneHeight(getPaneHeight(items));
/*  54 */       setPointsInScreenBounds();
/*  55 */       display();
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   private void setPointsInScreenBounds() {
/*  61 */     int x, screenWidth = Minecraft.getInstance().getWindow().getGuiScaledWidth();
/*  62 */     int screenHeight = Minecraft.getInstance().getWindow().getGuiScaledHeight();
/*     */ 
/*     */     
/*  65 */     boolean inBoundsX = (this.mouseX + getPaneWidth() < screenWidth);
/*  66 */     boolean inBoundsY = (this.mouseY + getPaneHeight() < screenHeight);
/*  67 */     if (this.parent instanceof PopupMenu) {
/*     */       
/*  69 */       int width = (this.scrollPane != null) ? getPaneWidth() : (getPaneWidth() - 6);
/*  70 */       x = inBoundsX ? this.mouseX : (((PopupMenu)this.parent).getPaneX() - width);
/*     */     }
/*     */     else {
/*     */       
/*  74 */       x = inBoundsX ? this.mouseX : (screenWidth - getPaneWidth() - 4);
/*     */     } 
/*  76 */     int y = inBoundsY ? this.mouseY : (screenHeight - getPaneHeight() - 2);
/*  77 */     this.mouseX = x;
/*  78 */     this.mouseY = y;
/*  79 */     setPaneX(x);
/*  80 */     setPaneY(y);
/*     */   }
/*     */ 
/*     */   
/*     */   public void resetPass() {
/*  85 */     this.pass = false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void renderPopupScreen(GuiGraphics graphics, int mouseX, int mouseY, float partialTicks) {
/*  92 */     this.mouseOver = mouseOverPane(mouseX, mouseY);
/*  93 */     int x = (int)((Minecraft.getInstance()).mouseHandler.xpos() * Minecraft.getInstance().getWindow().getGuiScaledWidth() / Minecraft.getInstance().getWindow().getScreenWidth());
/*  94 */     int y = (int)((Minecraft.getInstance()).mouseHandler.ypos() * Minecraft.getInstance().getWindow().getGuiScaledHeight() / Minecraft.getInstance().getWindow().getScreenHeight());
/*  95 */     super.renderPopupScreen(graphics, x, y, partialTicks);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean mouseClicked(double mouseX, double mouseY, int button) {
/* 101 */     boolean clicked = super.mouseClicked(mouseX, mouseY, button);
/* 102 */     if (!clicked && !mouseOverPane(mouseX, mouseY)) {
/*     */       
/* 104 */       resetPass();
/* 105 */       return this.parent.mouseClicked(mouseX, mouseY, button);
/*     */     } 
/* 107 */     return clicked;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isMouseOver() {
/* 112 */     return this.mouseOver;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void mouseMoved(double mouseX, double mouseY) {
/* 118 */     if (!mouseOverPane(mouseX, mouseY))
/*     */     {
/* 120 */       this.parent.mouseMoved(mouseX, mouseY);
/*     */     }
/* 122 */     super.mouseMoved(mouseX, mouseY);
/*     */   }
/*     */ 
/*     */   
/*     */   private int getPaneHeight(List<DropDownItem> items) {
/* 127 */     int size = Math.min(items.size(), 6);
/* 128 */     return size * (((DropDownItem)items.get(0)).getHeight() + ((size == 1) ? 7 : 5));
/*     */   }
/*     */ 
/*     */   
/*     */   private int getPaneWidth(List<DropDownItem> items) {
/* 133 */     int width = 0;
/* 134 */     if (items != null) {
/*     */       
/* 136 */       Font fontRenderer = (Minecraft.getInstance()).font;
/* 137 */       for (DropDownItem item : items)
/*     */       {
/* 139 */         width = Math.max(width, fontRenderer.width(item.getLabel()));
/*     */       }
/* 141 */       this.width = width + 40;
/*     */     } 
/*     */     
/* 144 */     return this.width;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setClickLoc(int mouseX, int mouseY) {
/* 149 */     this.mouseX = mouseX;
/* 150 */     this.mouseY = mouseY;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void setSelected(DropDownItem button) {
/* 156 */     this.selected = button;
/*     */   }
/*     */ 
/*     */   
/*     */   public void closeStack() {
/* 161 */     if (this.isSub) {
/*     */       
/* 163 */       this.visible = false;
/* 164 */       popLayer();
/* 165 */       ((PopupMenu)this.parent).closeStack();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void onClick(DropDownItem pressed) {
/* 172 */     if (pressed.isAutoClose())
/*     */     {
/* 174 */       popLayer();
/*     */     }
/* 176 */     this.removable.onRemove();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void onRemove() {
/* 182 */     if (this.selected != null) {
/*     */       
/* 184 */       this.selected.press();
/* 185 */       this.selected = null;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isPauseScreen() {
/* 192 */     return this.parent.isPauseScreen();
/*     */   }
/*     */ }


/* Location:              C:\Users\Administrator\Downloads\journeymap-forge-1.21-6.0.0-beta.18.jar!\journeymap\clien\\ui\component\popupscreenbutton\PopupMenu.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */