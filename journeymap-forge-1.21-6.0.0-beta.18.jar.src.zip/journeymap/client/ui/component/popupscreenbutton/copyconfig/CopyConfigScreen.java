/*     */ package journeymap.client.ui.component.popupscreenbutton.copyconfig;
/*     */ import journeymap.client.Constants;
/*     */ import journeymap.client.JourneymapClient;
/*     */ import journeymap.client.properties.ClientCategory;
/*     */ import journeymap.client.properties.ClientPropertiesBase;
/*     */ import journeymap.client.properties.InGameMapProperties;
/*     */ import journeymap.client.ui.component.popupscreenbutton.PopupButtonScreen;
/*     */ import journeymap.common.Journeymap;
/*     */ import journeymap.common.properties.PropertiesBase;
/*     */ import journeymap.common.properties.catagory.Category;
/*     */ import net.minecraft.client.gui.GuiGraphics;
/*     */ import net.minecraft.client.gui.components.AbstractWidget;
/*     */ import net.minecraft.client.gui.components.Button;
/*     */ import net.minecraft.client.gui.components.Tooltip;
/*     */ import net.minecraft.client.gui.components.events.GuiEventListener;
/*     */ import net.minecraft.client.gui.layouts.FrameLayout;
/*     */ import net.minecraft.client.gui.layouts.LayoutElement;
/*     */ import net.minecraft.client.gui.layouts.LinearLayout;
/*     */ import net.minecraft.network.chat.CommonComponents;
/*     */ import net.minecraft.network.chat.Component;
/*     */ import net.minecraft.network.chat.FormattedText;
/*     */ import net.minecraft.resources.ResourceLocation;
/*     */ 
/*     */ public class CopyConfigScreen extends PopupButtonScreen<Category> {
/*  25 */   private final LinearLayout layout = LinearLayout.vertical();
/*  26 */   private static final ResourceLocation BACKGROUND_SPRITE = ResourceLocation.parse("popup/background");
/*  27 */   private final Component labelCancel = (Component)Component.translatable("jm.common.cancel");
/*     */   
/*     */   private final Category[] to;
/*     */   private final Category from;
/*     */   
/*     */   public CopyConfigScreen(Category from, Category[] to) {
/*  33 */     super((Component)Component.translatable("jm.common.options.copy_to"));
/*  34 */     this.to = to;
/*  35 */     this.from = from;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void init() {
/*  41 */     LinearLayout bottomButtons = LinearLayout.vertical();
/*  42 */     this.layout.spacing(6).defaultCellSetting().alignHorizontallyCenter();
/*  43 */     this.layout.addChild((LayoutElement)getButton(this.to[0], b -> respond(0)));
/*  44 */     this.layout.addChild((LayoutElement)getButton(this.to[1], b -> respond(1)));
/*  45 */     this.layout.addChild((LayoutElement)Button.builder(CommonComponents.GUI_CANCEL, b -> onClose()).width(this.font.width((FormattedText)CommonComponents.GUI_CANCEL) + 10).build());
/*  46 */     this.layout.addChild((LayoutElement)bottomButtons);
/*  47 */     this.layout.visitWidgets(x$0 -> (AbstractWidget)rec$.addRenderableWidget(x$0));
/*  48 */     repositionElements();
/*     */   }
/*     */ 
/*     */   
/*     */   private void respond(int index) {
/*  53 */     copy(this.to[index]);
/*  54 */     setResponseAndClose(this.to[index]);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private Button getButton(Category category, Button.OnPress onPress) {
/*  60 */     String tooltip = "";
/*  61 */     String name = "";
/*  62 */     if (ClientCategory.MiniMap1.equals(category)) {
/*     */       
/*  64 */       name = Constants.getString("jm.common.copy_config.minimap1");
/*  65 */       tooltip = Constants.getString("jm.common.copy_config.minimap1.tooltip");
/*     */     } 
/*  67 */     if (ClientCategory.FullMap.equals(category)) {
/*     */       
/*  69 */       name = Constants.getString("jm.common.copy_config.fullscreen");
/*  70 */       tooltip = Constants.getString("jm.common.copy_config.fullscreen.tooltip");
/*     */     } 
/*  72 */     if (ClientCategory.MiniMap2.equals(category)) {
/*     */       
/*  74 */       name = Constants.getString("jm.common.copy_config.minimap2");
/*  75 */       tooltip = Constants.getString("jm.common.copy_config.minimap2.tooltip");
/*     */     } 
/*     */     
/*  78 */     return Button.builder((Component)Component.literal(name), onPress)
/*  79 */       .tooltip(Tooltip.create((Component)Component.literal(tooltip)))
/*  80 */       .width(this.font.width(name) + 10)
/*  81 */       .build();
/*     */   }
/*     */ 
/*     */   
/*     */   public void copy(Category categoryTo) {
/*  86 */     ClientPropertiesBase from = getProperties(this.from);
/*  87 */     ClientPropertiesBase to = getProperties(categoryTo);
/*     */     
/*  89 */     if (to != null && from != null) {
/*     */       
/*  91 */       Integer id = null;
/*     */ 
/*     */       
/*  94 */       if (to instanceof InGameMapProperties) { InGameMapProperties properties = (InGameMapProperties)to;
/*     */         
/*  96 */         id = properties.getPropertiesId(); }
/*     */ 
/*     */ 
/*     */       
/* 100 */       to.updateFrom((PropertiesBase)from);
/*     */ 
/*     */       
/* 103 */       if (to instanceof InGameMapProperties) { InGameMapProperties properties = (InGameMapProperties)to;
/*     */         
/* 105 */         properties.setPropertiesId(id); }
/*     */ 
/*     */ 
/*     */       
/* 109 */       to.save();
/* 110 */       Journeymap.getLogger().info("Copied common options from {} to {}.", from.getFileName(), to.getFileName());
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   private ClientPropertiesBase getProperties(Category category) {
/* 116 */     if (ClientCategory.FullMap.equals(category))
/*     */     {
/* 118 */       return (ClientPropertiesBase)JourneymapClient.getInstance().getFullMapProperties();
/*     */     }
/* 120 */     if (ClientCategory.MiniMap1.equals(category))
/*     */     {
/* 122 */       return (ClientPropertiesBase)JourneymapClient.getInstance().getMiniMapProperties1();
/*     */     }
/* 124 */     if (ClientCategory.MiniMap2.equals(category))
/*     */     {
/* 126 */       return (ClientPropertiesBase)JourneymapClient.getInstance().getMiniMapProperties2();
/*     */     }
/* 128 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void renderPopupScreenBackground(GuiGraphics graphics, int mouseX, int mouseY, float partialTick) {
/* 134 */     renderTransparentBackground(graphics);
/* 135 */     graphics.blitSprite(BACKGROUND_SPRITE, this.layout.getX() - 18, this.layout.getY() - 18, this.layout.getWidth() + 36, this.layout.getHeight() + 36);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected void repositionElements() {
/* 141 */     this.layout.arrangeElements();
/* 142 */     FrameLayout.centerInRectangle((LayoutElement)this.layout, getRectangle());
/*     */   }
/*     */ }


/* Location:              C:\Users\Administrator\Downloads\journeymap-forge-1.21-6.0.0-beta.18.jar!\journeymap\clien\\ui\component\popupscreenbutton\copyconfig\CopyConfigScreen.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */