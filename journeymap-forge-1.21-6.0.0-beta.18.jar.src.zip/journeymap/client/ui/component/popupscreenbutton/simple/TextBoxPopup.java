/*    */ package journeymap.client.ui.component.popupscreenbutton.simple;
/*    */ import journeymap.client.ui.component.TextBox;
/*    */ import journeymap.client.ui.component.popupscreenbutton.PopupButtonScreen;
/*    */ import net.minecraft.ChatFormatting;
/*    */ import net.minecraft.client.gui.GuiGraphics;
/*    */ import net.minecraft.client.gui.components.AbstractWidget;
/*    */ import net.minecraft.client.gui.components.Button;
/*    */ import net.minecraft.client.gui.components.MultiLineTextWidget;
/*    */ import net.minecraft.client.gui.components.events.GuiEventListener;
/*    */ import net.minecraft.client.gui.layouts.FrameLayout;
/*    */ import net.minecraft.client.gui.layouts.LayoutElement;
/*    */ import net.minecraft.client.gui.layouts.LinearLayout;
/*    */ import net.minecraft.network.chat.CommonComponents;
/*    */ import net.minecraft.network.chat.Component;
/*    */ import net.minecraft.network.chat.FormattedText;
/*    */ import net.minecraft.resources.ResourceLocation;
/*    */ 
/*    */ public class TextBoxPopup extends PopupButtonScreen<String> {
/* 19 */   private final LinearLayout layout = LinearLayout.vertical();
/*    */   private TextBox textBox;
/* 21 */   private static final ResourceLocation BACKGROUND_SPRITE = ResourceLocation.parse("popup/background");
/*    */ 
/*    */   
/*    */   public TextBoxPopup(Component title) {
/* 25 */     super(title);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   protected void init() {
/* 31 */     this.textBox = new TextBox("", this.font, 120, 20);
/* 32 */     this.layout.spacing(12).defaultCellSetting().alignHorizontallyCenter();
/* 33 */     this.layout.addChild((LayoutElement)(new MultiLineTextWidget((Component)this.title.copy().withStyle(ChatFormatting.BOLD), this.font)).setMaxWidth(150).setCentered(true));
/* 34 */     LinearLayout bottomButtons = LinearLayout.horizontal();
/* 35 */     bottomButtons.spacing(6);
/* 36 */     bottomButtons.addChild((LayoutElement)Button.builder(CommonComponents.GUI_CONTINUE, b -> setResponseAndClose(this.textBox.getValue())).width(this.font.width((FormattedText)CommonComponents.GUI_CONTINUE) + 10).build());
/* 37 */     bottomButtons.addChild((LayoutElement)Button.builder(CommonComponents.GUI_CANCEL, b -> setResponseAndClose(null)).width(this.font.width((FormattedText)CommonComponents.GUI_CANCEL) + 10).build());
/* 38 */     this.layout.addChild(LinearLayout.horizontal().addChild((LayoutElement)this.textBox));
/* 39 */     this.layout.addChild((LayoutElement)bottomButtons);
/* 40 */     this.layout.visitWidgets(x$0 -> (AbstractWidget)rec$.addRenderableWidget(x$0));
/* 41 */     repositionElements();
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void renderPopupScreenBackground(GuiGraphics guiGraphics, int mouseX, int mouseY, float partialTick) {
/* 48 */     renderTransparentBackground(guiGraphics);
/* 49 */     guiGraphics.blitSprite(BACKGROUND_SPRITE, this.layout.getX() - 18, this.layout.getY() - 18, this.layout.getWidth() + 36, this.layout.getHeight() + 36);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   protected void repositionElements() {
/* 56 */     this.layout.arrangeElements();
/* 57 */     FrameLayout.centerInRectangle((LayoutElement)this.layout, getRectangle());
/*    */   }
/*    */ }


/* Location:              C:\Users\Administrator\Downloads\journeymap-forge-1.21-6.0.0-beta.18.jar!\journeymap\clien\\ui\component\popupscreenbutton\simple\TextBoxPopup.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */