/*     */ package journeymap.client.ui.component.popupscreenbutton.colorpicker;
/*     */ import java.awt.Color;
/*     */ import java.awt.geom.Rectangle2D;
/*     */ import java.util.List;
/*     */ import java.util.function.Function;
/*     */ import journeymap.client.Constants;
/*     */ import journeymap.client.JourneymapClient;
/*     */ import journeymap.client.cartography.color.RGB;
/*     */ import journeymap.client.properties.CoreProperties;
/*     */ import journeymap.client.render.draw.DrawUtil;
/*     */ import journeymap.client.texture.Texture;
/*     */ import journeymap.client.texture.TextureCache;
/*     */ import journeymap.client.ui.component.TextBox;
/*     */ import journeymap.client.ui.component.buttons.Button;
/*     */ import journeymap.client.ui.component.buttons.IntSliderButton;
/*     */ import journeymap.client.ui.component.popupscreenbutton.PopupButtonScreen;
/*     */ import journeymap.common.properties.catagory.Category;
/*     */ import journeymap.common.properties.config.IntegerField;
/*     */ import journeymap.common.properties.config.StringField;
/*     */ import net.minecraft.client.gui.Font;
/*     */ import net.minecraft.client.gui.GuiGraphics;
/*     */ import net.minecraft.client.gui.components.AbstractWidget;
/*     */ import net.minecraft.client.gui.components.Button;
/*     */ import net.minecraft.client.gui.components.StringWidget;
/*     */ import net.minecraft.client.gui.components.events.GuiEventListener;
/*     */ import net.minecraft.client.gui.layouts.FrameLayout;
/*     */ import net.minecraft.client.gui.layouts.GridLayout;
/*     */ import net.minecraft.client.gui.layouts.LayoutElement;
/*     */ import net.minecraft.client.gui.layouts.LayoutSettings;
/*     */ import net.minecraft.client.gui.layouts.LinearLayout;
/*     */ import net.minecraft.network.chat.Component;
/*     */ import net.minecraft.network.chat.FormattedText;
/*     */ import net.minecraft.resources.ResourceLocation;
/*     */ 
/*     */ public class ColorPickerScreen extends PopupButtonScreen<ColorPickerScreen.ColorPickerResponse> {
/*  36 */   private static final ResourceLocation BACKGROUND_SPRITE = ResourceLocation.parse("popup/background");
/*     */   
/*     */   private static final int SLIDERS_WIDTH = 265;
/*  39 */   private final LinearLayout layout = LinearLayout.vertical();
/*     */   
/*     */   private LinearLayout historyLayout;
/*     */   
/*     */   private final Texture colorwheelTexture;
/*     */   private final Texture colorwheelHandlerTexture;
/*     */   private final Texture colorBoxTexture;
/*     */   private final Texture colorVSliderTexture;
/*     */   private final Texture colorVSliderHandlerTexture;
/*     */   private final Texture colorHistoryButtonTexture;
/*  49 */   private final String labelOld = Constants.getString("jm.color.old");
/*  50 */   private final String labelNew = Constants.getString("jm.color.new");
/*  51 */   private final Component labelHistory = (Component)Component.translatable("jm.color.history");
/*     */   
/*  53 */   private final Component labelHex = (Component)Component.translatable("jm.color.hex");
/*  54 */   private final Component labelDec = (Component)Component.translatable("jm.color.dec");
/*  55 */   private final String prefixR = Constants.getString("jm.color.red_abbreviated");
/*  56 */   private final String prefixG = Constants.getString("jm.color.green_abbreviated");
/*  57 */   private final String prefixB = Constants.getString("jm.color.blue_abbreviated");
/*  58 */   private final String prefixH = Constants.getString("jm.color.hue_abbreviated");
/*  59 */   private final String prefixS = Constants.getString("jm.color.saturation_abbreviated");
/*  60 */   private final String prefixV = Constants.getString("jm.color.value_abbreviated");
/*  61 */   private final String prefixA = Constants.getString("jm.color.alpha_abbreviated");
/*     */   
/*  63 */   private final Component labelSubmit = (Component)Component.translatable("jm.common.submit");
/*  64 */   private final Component labelReset = (Component)Component.translatable("jm.common.reset");
/*  65 */   private final Component labelCancel = (Component)Component.translatable("jm.common.cancel");
/*     */   
/*  67 */   private final String formatHexNoAlpha = "%06X";
/*  68 */   private final String formatHexAlpha = "%08X";
/*     */   
/*  70 */   private final int maxHistory = 18;
/*     */   
/*     */   private TextBox fieldHex;
/*     */   private TextBox fieldDec;
/*  74 */   private final IntegerField fieldH = new IntegerField(Category.Hidden, "", 0, 255, 0);
/*  75 */   private final IntegerField fieldS = new IntegerField(Category.Hidden, "", 0, 255, 0);
/*  76 */   private final IntegerField fieldV = new IntegerField(Category.Hidden, "", 0, 255, 0);
/*  77 */   private final IntegerField fieldR = new IntegerField(Category.Hidden, "", 0, 255, 0);
/*  78 */   private final IntegerField fieldG = new IntegerField(Category.Hidden, "", 0, 255, 0);
/*  79 */   private final IntegerField fieldB = new IntegerField(Category.Hidden, "", 0, 255, 0);
/*  80 */   private final IntegerField fieldA = new IntegerField(Category.Hidden, "", 0, 255, 0);
/*     */   
/*     */   private IntSliderButton sliderH;
/*     */   private IntSliderButton sliderS;
/*     */   private IntSliderButton sliderV;
/*     */   private IntSliderButton sliderR;
/*     */   private IntSliderButton sliderG;
/*     */   private IntSliderButton sliderB;
/*     */   private IntSliderButton sliderA;
/*  89 */   private double colorwheelHandlerX = 0.0D;
/*  90 */   private double colorwheelHandlerY = 0.0D;
/*     */   
/*     */   private boolean draggingCWHandler = false;
/*     */   private final Rectangle2D.Double colorWheelRect;
/*  94 */   private double vSliderHandler = 0.0D;
/*     */   
/*     */   private boolean draggingVSHandler = false;
/*     */   private final Rectangle2D.Double vSliderRect;
/*  98 */   private double aSliderHandler = 0.0D;
/*     */   
/*     */   private boolean draggingASHandler = false;
/*     */   
/*     */   private final Rectangle2D.Double aSliderRect;
/*     */   
/*     */   private final int originalColor;
/*     */   private int currentColor;
/*     */   private int currentColorFullBrightness;
/*     */   private boolean withAlpha;
/*     */   
/*     */   protected ColorPickerScreen(Component title, Integer color, boolean withAlpha) {
/* 110 */     super(title);
/* 111 */     this.response = new ColorPickerResponse(0, true);
/* 112 */     this.colorwheelTexture = TextureCache.getTexture(TextureCache.ColorWheel);
/* 113 */     this.colorwheelHandlerTexture = TextureCache.getTexture(TextureCache.ColorWheelHandler);
/* 114 */     this.colorBoxTexture = TextureCache.getTexture(TextureCache.ColorBox);
/* 115 */     this.colorVSliderTexture = TextureCache.getTexture(TextureCache.ColorVSlider);
/* 116 */     this.colorVSliderHandlerTexture = TextureCache.getTexture(TextureCache.ColorVSliderHandler);
/* 117 */     this.colorHistoryButtonTexture = TextureCache.getTexture(TextureCache.ColorHistoryButton);
/* 118 */     this.colorWheelRect = new Rectangle2D.Double();
/* 119 */     this.vSliderRect = new Rectangle2D.Double();
/* 120 */     this.aSliderRect = new Rectangle2D.Double();
/*     */     
/* 122 */     this.originalColor = color.intValue();
/* 123 */     this.currentColor = color.intValue();
/* 124 */     this.withAlpha = withAlpha;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void init() {
/* 130 */     this.layout.spacing(4).defaultCellSetting().alignHorizontallyLeft();
/* 131 */     this.layout.addChild((LayoutElement)new SpacerElement(265, 69));
/*     */     
/* 133 */     this.fieldHex = new TextBox("", this.font, 76, 20, false, false);
/* 134 */     this.fieldHex.setMaxLength(this.withAlpha ? 8 : 6);
/* 135 */     this.fieldDec = new TextBox("", this.font, 76, 20, true, true);
/* 136 */     this.fieldDec.setMaxLength(this.withAlpha ? 11 : 9);
/* 137 */     addTextBoxWithLabel(this.layout, this.font, this.labelHex, this.fieldHex);
/* 138 */     addTextBoxWithLabel(this.layout, this.font, this.labelDec, this.fieldDec);
/*     */     
/* 140 */     this.sliderH = createCenteredSlider(this.fieldH, this.prefixH, this::listenerHSV);
/* 141 */     this.sliderS = createCenteredSlider(this.fieldS, this.prefixS, this::listenerHSV);
/* 142 */     this.sliderV = createCenteredSlider(this.fieldV, this.prefixV, this::listenerHSV);
/* 143 */     this.sliderR = createCenteredSlider(this.fieldR, this.prefixR, this::listenerRGB);
/* 144 */     this.sliderG = createCenteredSlider(this.fieldG, this.prefixG, this::listenerRGB);
/* 145 */     this.sliderB = createCenteredSlider(this.fieldB, this.prefixB, this::listenerRGB);
/* 146 */     addSliderGroup(this.layout, this.sliderH, this.sliderS, this.sliderV);
/* 147 */     addSliderGroup(this.layout, this.sliderR, this.sliderG, this.sliderB);
/*     */     
/* 149 */     if (this.withAlpha) {
/*     */       
/* 151 */       this.sliderA = createCenteredSlider(this.fieldA, this.prefixA, this::listenerAlpha);
/* 152 */       this.layout.addChild((LayoutElement)this.sliderA);
/*     */     } 
/*     */     
/* 155 */     FrameLayout bottomButtomsFrame = new FrameLayout();
/* 156 */     bottomButtomsFrame.setMinWidth(265);
/* 157 */     LinearLayout bottomButtons = LinearLayout.horizontal();
/* 158 */     bottomButtons.spacing(12);
/* 159 */     bottomButtons.addChild((LayoutElement)Button.builder(this.labelSubmit, b -> submit()).width(this.font.width((FormattedText)this.labelSubmit) + 10).build());
/* 160 */     bottomButtons.addChild((LayoutElement)Button.builder(this.labelReset, b -> reset()).width(this.font.width((FormattedText)this.labelReset) + 10).build());
/* 161 */     bottomButtons.addChild((LayoutElement)Button.builder(this.labelCancel, b -> setResponseAndClose(new ColorPickerResponse(0, true))).width(this.font.width((FormattedText)this.labelCancel) + 10).build());
/* 162 */     bottomButtomsFrame.addChild((LayoutElement)bottomButtons);
/* 163 */     this.layout.addChild((LayoutElement)bottomButtomsFrame);
/*     */ 
/*     */     
/* 166 */     CoreProperties properties = JourneymapClient.getInstance().getCoreProperties();
/* 167 */     List<StringField> history = properties.colorPickerHistory;
/* 168 */     if (!history.isEmpty()) {
/*     */       
/* 170 */       this.historyLayout = LinearLayout.vertical();
/* 171 */       this.historyLayout.defaultCellSetting().alignHorizontallyCenter();
/* 172 */       this.historyLayout.addChild((LayoutElement)(new StringWidget(this.labelHistory, this.font)).setColor(Color.cyan.getRGB()));
/*     */       
/* 174 */       for (int i = 0; i < history.size(); i++)
/*     */       {
/* 176 */         this.historyLayout.addChild((LayoutElement)new HistoryButton(this.colorHistoryButtonTexture, RGB.hexToInt(((StringField)history.get(i)).get()), b -> historySelected((HistoryButton)b)));
/*     */       }
/*     */       
/* 179 */       this.historyLayout.visitWidgets(x$0 -> (AbstractWidget)rec$.addRenderableWidget(x$0));
/*     */     } 
/*     */ 
/*     */     
/* 183 */     this.layout.visitWidgets(x$0 -> (AbstractWidget)rec$.addRenderableWidget(x$0));
/* 184 */     repositionElements();
/*     */     
/* 186 */     updateHSVfields();
/* 187 */     updateFullBrightness();
/* 188 */     updateRGBfields();
/* 189 */     updateHexField();
/* 190 */     updateDecField();
/* 191 */     updateColorWheelHandler();
/* 192 */     updateAlphaField();
/* 193 */     updateVSliderHandler();
/* 194 */     updateASliderHandler();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void renderPopupScreenBackground(GuiGraphics graphics, int mouseX, int mouseY, float partialTick) {
/* 200 */     renderTransparentBackground(graphics);
/* 201 */     graphics.blitSprite(BACKGROUND_SPRITE, this.layout.getX() - 18, this.layout.getY() - 18, this.layout.getWidth() + 36, this.layout.getHeight() + 36);
/* 202 */     if (this.historyLayout != null)
/*     */     {
/* 204 */       graphics.blitSprite(BACKGROUND_SPRITE, this.historyLayout.getX() - 18, this.historyLayout.getY() - 15, this.historyLayout.getWidth() + 36, this.historyLayout.getHeight() + 33);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected void repositionElements() {
/* 211 */     this.layout.arrangeElements();
/* 212 */     FrameLayout.centerInRectangle((LayoutElement)this.layout, getRectangle());
/* 213 */     if (this.historyLayout != null) {
/*     */       
/* 215 */       this.historyLayout.arrangeElements();
/* 216 */       this.historyLayout.setPosition(this.layout.getX() + this.layout.getWidth() + 48, this.layout.getY() - 3);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   private static void addTextBoxWithLabel(LinearLayout layout, Font font, Component label, TextBox textBox) {
/* 222 */     GridLayout gridLayout = new GridLayout();
/* 223 */     gridLayout.newCellSettings().alignVerticallyMiddle();
/* 224 */     gridLayout.spacing(4);
/* 225 */     gridLayout.addChild((LayoutElement)(new StringWidget(label, font)).alignLeft().setColor(Color.cyan.getRGB()), 0, 0, LayoutSettings.defaults().alignVerticallyMiddle());
/* 226 */     gridLayout.addChild((LayoutElement)textBox, 0, 1);
/* 227 */     layout.addChild((LayoutElement)gridLayout);
/*     */   }
/*     */ 
/*     */   
/*     */   private static void addSliderGroup(LinearLayout layout, IntSliderButton slider1, IntSliderButton slider2, IntSliderButton slider3) {
/* 232 */     LinearLayout linearLayout = LinearLayout.vertical();
/* 233 */     linearLayout.addChild((LayoutElement)slider1);
/* 234 */     linearLayout.addChild((LayoutElement)slider2);
/* 235 */     linearLayout.addChild((LayoutElement)slider3);
/* 236 */     layout.addChild((LayoutElement)linearLayout);
/*     */   }
/*     */ 
/*     */   
/*     */   private void submit() {
/* 241 */     StringField field = new StringField(Category.Hidden, "");
/* 242 */     field.set(RGB.toHexStringRGBA(Integer.valueOf(this.currentColor)));
/*     */     
/* 244 */     CoreProperties properties = JourneymapClient.getInstance().getCoreProperties();
/* 245 */     properties.colorPickerHistory.removeIf(f -> f.get().equals(field.get()));
/* 246 */     properties.colorPickerHistory.add(0, field);
/* 247 */     if (properties.colorPickerHistory.size() > 18)
/*     */     {
/* 249 */       properties.colorPickerHistory.remove(18);
/*     */     }
/* 251 */     properties.save();
/*     */     
/* 253 */     setResponseAndClose(new ColorPickerResponse(this.currentColor, false));
/*     */   }
/*     */ 
/*     */   
/*     */   private void reset() {
/* 258 */     this.currentColor = this.originalColor;
/* 259 */     updateHSVfields();
/* 260 */     updateFullBrightness();
/* 261 */     updateRGBfields();
/* 262 */     updateHexField();
/* 263 */     updateDecField();
/* 264 */     updateColorWheelHandler();
/* 265 */     updateAlphaField();
/* 266 */     updateVSliderHandler();
/* 267 */     updateASliderHandler();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void renderPopupScreen(GuiGraphics graphics, int x, int y, float partialTicks) {
/* 274 */     super.renderPopupScreen(graphics, x, y, partialTicks);
/*     */     
/* 276 */     renderColorBoxes(graphics, this.layout.getX() + 1, this.layout.getY() + 20);
/* 277 */     renderColorWheel(graphics, this.layout.getX() + 121, this.layout.getY() - 6);
/* 278 */     renderSlider(graphics, this.layout.getX() + 249, this.layout.getY(), this.vSliderRect, this.vSliderHandler, this.currentColorFullBrightness, -16777216);
/*     */     
/* 280 */     if (this.withAlpha)
/*     */     {
/* 282 */       renderSlider(graphics, this.layout.getX() + 109, this.layout.getY(), this.aSliderRect, this.aSliderHandler, this.currentColor | 0xFF000000, this.currentColor & 0xFFFFFF);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   private IntSliderButton createCenteredSlider(IntegerField field, String prefix, Function<Button, Boolean> listener) {
/* 288 */     IntSliderButton slider = new IntSliderButton(field, prefix + " ", "");
/*     */ 
/*     */     
/* 291 */     slider.setWidth(265);
/* 292 */     slider.setHeight(15);
/* 293 */     slider.setDefaultStyle(false);
/* 294 */     slider.setDrawBackground(false);
/* 295 */     slider.addClickListener(listener);
/* 296 */     return slider;
/*     */   }
/*     */ 
/*     */   
/*     */   private void renderColorBoxes(GuiGraphics graphics, int x, int y) {
/* 301 */     int texWidth = this.colorBoxTexture.getWidth();
/* 302 */     int texHeight = this.colorBoxTexture.getHeight();
/* 303 */     int colorWidth = (texWidth - 2) / 2;
/* 304 */     int colorHeight = (texHeight - 2) / 2;
/*     */     
/* 306 */     int x2 = x + colorWidth;
/* 307 */     int y2 = y + colorHeight;
/*     */     
/* 309 */     DrawUtil.drawImage(graphics.pose(), this.colorBoxTexture, (x - 1), (y - 1), false, 1.0F, 0.0D, false);
/* 310 */     graphics.fill(x, y, x + colorWidth, y + colorHeight, this.originalColor | 0xFF000000);
/* 311 */     graphics.fill(x2, y, x2 + colorWidth, y + colorHeight, this.currentColor | 0xFF000000);
/* 312 */     graphics.fill(x, y2, x + colorWidth, y2 + colorHeight, this.originalColor);
/* 313 */     graphics.fill(x2, y2, x2 + colorWidth, y2 + colorHeight, this.currentColor);
/*     */     
/* 315 */     graphics.drawString(this.font, this.labelOld, x + 2, y - 10, Color.cyan.getRGB());
/* 316 */     graphics.drawString(this.font, this.labelNew, x + texWidth - 1 - this.font.width(this.labelNew), y - 10, Color.cyan.getRGB());
/*     */   }
/*     */ 
/*     */   
/*     */   private void renderColorWheel(GuiGraphics graphics, int x, int y) {
/* 321 */     int cwWidth = this.colorwheelTexture.getWidth();
/* 322 */     int cwHeight = this.colorwheelTexture.getHeight();
/* 323 */     DrawUtil.drawImage(graphics.pose(), this.colorwheelTexture, x, y, false, 1.0F, 0.0D);
/* 324 */     this.colorWheelRect.setRect((x + 6), (y + 6), (cwWidth - 12), (cwHeight - 12));
/*     */     
/* 326 */     int handlerX = (int)((x + (cwWidth >> 1)) + this.colorwheelHandlerX - 2.0D);
/* 327 */     int handlerY = (int)((y + (cwHeight >> 1)) + this.colorwheelHandlerY - 2.0D);
/* 328 */     graphics.fill(handlerX + 2, handlerY + 2, handlerX + 3, handlerY + 3, this.currentColorFullBrightness);
/* 329 */     DrawUtil.drawImage(graphics.pose(), this.colorwheelHandlerTexture, handlerX, handlerY, false, 1.0F, 0.0D, false);
/*     */   }
/*     */ 
/*     */   
/*     */   private void renderSlider(GuiGraphics graphics, int x, int y, Rectangle2D.Double rect, double handler, int colorTop, int colorBottom) {
/* 334 */     int vSliderWidth = this.colorVSliderTexture.getWidth();
/* 335 */     int vSliderHeight = this.colorVSliderTexture.getHeight();
/* 336 */     DrawUtil.drawImage(graphics.pose(), this.colorVSliderTexture, x, y, false, 1.0F, 0.0D, false);
/* 337 */     graphics.fillGradient(x + 1, y + 1, x + vSliderWidth - 1, y + vSliderHeight - 1, colorTop, colorBottom);
/* 338 */     rect.setRect(x, y, vSliderWidth, vSliderHeight);
/*     */     
/* 340 */     int handlerX = x + 1;
/* 341 */     int handlerY = (int)(y + handler + 1.5D);
/* 342 */     graphics.fill(handlerX + 2, handlerY + 2, handlerX + 9, handlerY + 3, colorTop);
/* 343 */     DrawUtil.drawImage(graphics.pose(), this.colorVSliderHandlerTexture, handlerX, handlerY, false, 1.0F, 0.0D, false);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean keyPressed(int keyCode, int scanCode, int modifiers) {
/* 349 */     if (this.fieldHex.keyPressed(keyCode, scanCode, modifiers)) {
/*     */       
/* 351 */       listenerHex();
/* 352 */       return true;
/*     */     } 
/*     */     
/* 355 */     if (this.fieldDec.keyPressed(keyCode, scanCode, modifiers)) {
/*     */       
/* 357 */       listenerDec();
/* 358 */       return true;
/*     */     } 
/*     */     
/* 361 */     return super.keyPressed(keyCode, scanCode, modifiers);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean charTyped(char typedChar, int keyCode) {
/* 367 */     if (this.fieldHex.charTyped(typedChar, keyCode)) {
/*     */       
/* 369 */       listenerHex();
/* 370 */       return true;
/*     */     } 
/*     */     
/* 373 */     if (this.fieldDec.charTyped(typedChar, keyCode)) {
/*     */       
/* 375 */       listenerDec();
/* 376 */       return true;
/*     */     } 
/*     */     
/* 379 */     return super.charTyped(typedChar, keyCode);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean mouseClicked(double mouseX, double mouseY, int button) {
/* 385 */     if (button == 0) {
/*     */       
/* 387 */       clearFocus();
/*     */       
/* 389 */       if (this.colorWheelRect.contains(mouseX, mouseY))
/*     */       {
/* 391 */         return updateCWHandler(mouseX, mouseY);
/*     */       }
/* 393 */       if (this.vSliderRect.contains(mouseX, mouseY))
/*     */       {
/* 395 */         return updateVSHandler(mouseX, mouseY);
/*     */       }
/* 397 */       if (this.withAlpha && this.aSliderRect.contains(mouseX, mouseY))
/*     */       {
/* 399 */         return updateASHandler(mouseX, mouseY);
/*     */       }
/*     */     } 
/*     */     
/* 403 */     return super.mouseClicked(mouseX, mouseY, button);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean mouseReleased(double mouseX, double mouseY, int button) {
/* 409 */     if (button == 0) {
/*     */       
/* 411 */       this.draggingCWHandler = false;
/* 412 */       this.draggingVSHandler = false;
/* 413 */       this.draggingASHandler = false;
/*     */     } 
/*     */     
/* 416 */     return super.mouseReleased(mouseX, mouseY, button);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean mouseDragged(double mouseX, double mouseY, int button, double dragX, double dragY) {
/* 422 */     if (button == 0) {
/*     */       
/* 424 */       if (this.draggingCWHandler)
/*     */       {
/* 426 */         return updateCWHandler(mouseX, mouseY);
/*     */       }
/* 428 */       if (this.draggingVSHandler)
/*     */       {
/* 430 */         return updateVSHandler(mouseX, mouseY);
/*     */       }
/* 432 */       if (this.draggingASHandler)
/*     */       {
/* 434 */         return updateASHandler(mouseX, mouseY);
/*     */       }
/*     */     } 
/*     */     
/* 438 */     return super.mouseDragged(mouseX, mouseY, button, dragX, dragY);
/*     */   }
/*     */ 
/*     */   
/*     */   private boolean updateCWHandler(double mouseX, double mouseY) {
/* 443 */     double localX = mouseX - this.colorWheelRect.getCenterX();
/* 444 */     double localY = mouseY - this.colorWheelRect.getCenterY();
/* 445 */     double dist = Math.sqrt(localX * localX + localY * localY);
/*     */     
/* 447 */     if (dist < 57.0D)
/*     */     {
/* 449 */       this.draggingCWHandler = true;
/*     */     }
/*     */     
/* 452 */     if (this.draggingCWHandler) {
/*     */       
/* 454 */       if (dist >= 57.0D) {
/*     */         
/* 456 */         localX = localX / dist * 57.0D;
/* 457 */         localY = localY / dist * 57.0D;
/*     */       } 
/* 459 */       this.colorwheelHandlerX = localX;
/* 460 */       this.colorwheelHandlerY = localY;
/*     */       
/* 462 */       double angle = Math.atan2(this.colorwheelHandlerX, -this.colorwheelHandlerY) / 6.283185307179586D;
/* 463 */       angle = (angle < 0.0D) ? (angle + 1.0D) : angle;
/* 464 */       this.sliderH.setValue((int)(angle * 255.0D));
/* 465 */       this.sliderS.setValue((int)(dist / 57.0D * 255.0D));
/* 466 */       this.currentColor = Color.HSBtoRGB(this.fieldH.get().intValue() / 255.0F, this.fieldS.get().intValue() / 255.0F, this.fieldV.get().intValue() / 255.0F);
/* 467 */       this.currentColor = this.currentColor & 0xFFFFFF | this.fieldA.get().intValue() << 24;
/* 468 */       updateFullBrightness();
/* 469 */       updateRGBfields();
/* 470 */       updateHexField();
/* 471 */       updateDecField();
/* 472 */       return true;
/*     */     } 
/*     */     
/* 475 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   private boolean updateVSHandler(double mouseX, double mouseY) {
/* 480 */     this.draggingVSHandler = true;
/* 481 */     double localY = mouseY - this.vSliderRect.getY() - 3.0D;
/*     */     
/* 483 */     if (localY < 0.0D) {
/*     */       
/* 485 */       localY = 0.0D;
/*     */     }
/* 487 */     else if (localY > 110.0D) {
/*     */       
/* 489 */       localY = 110.0D;
/*     */     } 
/*     */     
/* 492 */     this.vSliderHandler = localY;
/*     */     
/* 494 */     this.sliderV.setValue((int)((1.0D - this.vSliderHandler / 110.0D) * 255.0D));
/* 495 */     this.currentColor = Color.HSBtoRGB(this.fieldH.get().intValue() / 255.0F, this.fieldS.get().intValue() / 255.0F, this.fieldV.get().intValue() / 255.0F);
/* 496 */     this.currentColor = this.currentColor & 0xFFFFFF | this.fieldA.get().intValue() << 24;
/* 497 */     updateFullBrightness();
/* 498 */     updateRGBfields();
/* 499 */     updateHexField();
/* 500 */     updateDecField();
/* 501 */     return true;
/*     */   }
/*     */ 
/*     */   
/*     */   private boolean updateASHandler(double mouseX, double mouseY) {
/* 506 */     this.draggingASHandler = true;
/* 507 */     double localY = mouseY - this.aSliderRect.getY() - 3.0D;
/*     */     
/* 509 */     if (localY < 0.0D) {
/*     */       
/* 511 */       localY = 0.0D;
/*     */     }
/* 513 */     else if (localY > 110.0D) {
/*     */       
/* 515 */       localY = 110.0D;
/*     */     } 
/*     */     
/* 518 */     this.aSliderHandler = localY;
/*     */     
/* 520 */     this.sliderA.setValue((int)((1.0D - this.aSliderHandler / 110.0D) * 255.0D));
/* 521 */     this.currentColor = this.currentColor & 0xFFFFFF | this.fieldA.get().intValue() << 24;
/* 522 */     updateHexField();
/* 523 */     updateDecField();
/* 524 */     return true;
/*     */   }
/*     */ 
/*     */   
/*     */   private boolean historySelected(HistoryButton button) {
/* 529 */     int color = button.getColor();
/* 530 */     if (!this.withAlpha)
/*     */     {
/* 532 */       color = color & 0xFFFFFF | this.currentColor & 0xFF000000;
/*     */     }
/*     */     
/* 535 */     this.currentColor = color;
/* 536 */     updateHSVfields();
/* 537 */     updateFullBrightness();
/* 538 */     updateRGBfields();
/* 539 */     updateColorWheelHandler();
/* 540 */     updateAlphaField();
/* 541 */     updateVSliderHandler();
/* 542 */     updateASliderHandler();
/* 543 */     updateHexField();
/* 544 */     updateDecField();
/*     */     
/* 546 */     return true;
/*     */   }
/*     */ 
/*     */   
/*     */   private void updateColorWheelHandler() {
/* 551 */     double angle = this.fieldH.get().intValue() / 255.0D * Math.PI * 2.0D;
/* 552 */     double dist = this.fieldS.get().intValue() / 255.0D * 57.0D;
/* 553 */     this.colorwheelHandlerX = dist * Math.sin(angle);
/* 554 */     this.colorwheelHandlerY = dist * -Math.cos(angle);
/*     */   }
/*     */ 
/*     */   
/*     */   private void updateVSliderHandler() {
/* 559 */     this.vSliderHandler = (1.0D - this.fieldV.get().intValue() / 255.0D) * 110.0D;
/*     */   }
/*     */ 
/*     */   
/*     */   private void updateASliderHandler() {
/* 564 */     if (this.withAlpha)
/*     */     {
/* 566 */       this.aSliderHandler = (1.0D - this.fieldA.get().intValue() / 255.0D) * 110.0D;
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   private boolean listenerHSV(Button button) {
/* 572 */     this.currentColor = Color.HSBtoRGB(this.fieldH.get().intValue() / 255.0F, this.fieldS.get().intValue() / 255.0F, this.fieldV.get().intValue() / 255.0F);
/* 573 */     this.currentColor = this.currentColor & 0xFFFFFF | this.fieldA.get().intValue() << 24;
/* 574 */     updateFullBrightness();
/* 575 */     updateRGBfields();
/* 576 */     updateColorWheelHandler();
/* 577 */     updateVSliderHandler();
/* 578 */     updateHexField();
/* 579 */     updateDecField();
/* 580 */     return true;
/*     */   }
/*     */ 
/*     */   
/*     */   private boolean listenerRGB(Button button) {
/* 585 */     this.currentColor = this.fieldA.get().intValue() << 24 | this.fieldR.get().intValue() << 16 | this.fieldG.get().intValue() << 8 | this.fieldB.get().intValue();
/* 586 */     updateHSVfields();
/* 587 */     updateFullBrightness();
/* 588 */     updateColorWheelHandler();
/* 589 */     updateVSliderHandler();
/* 590 */     updateHexField();
/* 591 */     updateDecField();
/* 592 */     return true;
/*     */   }
/*     */ 
/*     */   
/*     */   private boolean listenerAlpha(Button button) {
/* 597 */     this.currentColor = this.currentColor & 0xFFFFFF | this.fieldA.get().intValue() << 24;
/* 598 */     updateASliderHandler();
/* 599 */     updateHexField();
/* 600 */     updateDecField();
/* 601 */     return true;
/*     */   }
/*     */ 
/*     */   
/*     */   private boolean listenerHex() {
/* 606 */     this.currentColor = getSafeColorHex(this.fieldHex);
/* 607 */     updateHSVfields();
/* 608 */     updateFullBrightness();
/* 609 */     updateRGBfields();
/* 610 */     updateColorWheelHandler();
/* 611 */     updateAlphaField();
/* 612 */     updateVSliderHandler();
/* 613 */     updateASliderHandler();
/* 614 */     updateDecField();
/* 615 */     return true;
/*     */   }
/*     */ 
/*     */   
/*     */   private boolean listenerDec() {
/* 620 */     this.currentColor = getSafeColorDec(this.fieldDec);
/* 621 */     updateHSVfields();
/* 622 */     updateFullBrightness();
/* 623 */     updateRGBfields();
/* 624 */     updateColorWheelHandler();
/* 625 */     updateAlphaField();
/* 626 */     updateVSliderHandler();
/* 627 */     updateASliderHandler();
/* 628 */     updateHexField();
/* 629 */     return true;
/*     */   }
/*     */ 
/*     */   
/*     */   private void updateRGBfields() {
/* 634 */     this.sliderR.setValue(this.currentColor >> 16 & 0xFF);
/* 635 */     this.sliderG.setValue(this.currentColor >> 8 & 0xFF);
/* 636 */     this.sliderB.setValue(this.currentColor & 0xFF);
/*     */   }
/*     */ 
/*     */   
/*     */   private void updateHSVfields() {
/* 641 */     float[] hsv = Color.RGBtoHSB(this.currentColor >> 16 & 0xFF, this.currentColor >> 8 & 0xFF, this.currentColor & 0xFF, null);
/* 642 */     this.sliderH.setValue((int)(hsv[0] * 255.0F));
/* 643 */     this.sliderS.setValue((int)(hsv[1] * 255.0F));
/* 644 */     this.sliderV.setValue((int)(hsv[2] * 255.0F));
/*     */   }
/*     */ 
/*     */   
/*     */   private void updateHexField() {
/* 649 */     String format = this.withAlpha ? "%08X" : "%06X";
/* 650 */     int color = this.withAlpha ? this.currentColor : (this.currentColor & 0xFFFFFF);
/* 651 */     this.fieldHex.setText(String.format(format, new Object[] { Integer.valueOf(color) }));
/*     */   }
/*     */ 
/*     */   
/*     */   private void updateDecField() {
/* 656 */     int color = this.withAlpha ? this.currentColor : (this.currentColor & 0xFFFFFF);
/* 657 */     this.fieldDec.setText(String.valueOf(color));
/*     */   }
/*     */ 
/*     */   
/*     */   private void updateAlphaField() {
/* 662 */     if (this.withAlpha) {
/*     */       
/* 664 */       this.sliderA.setValue(this.currentColor >> 24 & 0xFF);
/*     */     }
/*     */     else {
/*     */       
/* 668 */       this.fieldA.set(Integer.valueOf(this.currentColor >> 24 & 0xFF));
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   private void updateFullBrightness() {
/* 674 */     this.currentColorFullBrightness = Color.HSBtoRGB(this.fieldH.get().intValue() / 255.0F, this.fieldS.get().intValue() / 255.0F, 1.0F);
/*     */   }
/*     */ 
/*     */   
/*     */   private int getSafeColorHex(TextBox field) {
/* 679 */     field.clamp();
/* 680 */     String text = field.getValue();
/* 681 */     int color = RGB.hexToInt(text);
/*     */     
/* 683 */     if (this.withAlpha)
/*     */     {
/* 685 */       return color;
/*     */     }
/*     */ 
/*     */     
/* 689 */     return color & 0xFFFFFF | this.fieldA.get().intValue() << 24;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private int getSafeColorDec(TextBox field) {
/* 695 */     field.clamp();
/* 696 */     String text = field.getValue();
/* 697 */     if (text.isEmpty())
/*     */     {
/* 699 */       return 0;
/*     */     }
/*     */     
/* 702 */     int val = 0;
/*     */     
/*     */     try {
/* 705 */       val = Integer.parseInt(text);
/*     */     }
/* 707 */     catch (NumberFormatException numberFormatException) {}
/*     */ 
/*     */ 
/*     */     
/* 711 */     if (!this.withAlpha)
/*     */     {
/* 713 */       val = val & 0xFFFFFF | this.fieldA.get().intValue() << 24;
/*     */     }
/*     */     
/* 716 */     return val;
/*     */   }
/*     */ 
/*     */   
/*     */   private static class HistoryButton
/*     */     extends Button
/*     */   {
/*     */     private final Texture texture;
/*     */     private final int color;
/*     */     
/*     */     public HistoryButton(Texture texture, int color, Button.OnPress onPress) {
/* 727 */       super(texture.getWidth(), texture.getHeight(), "", onPress);
/* 728 */       this.color = color;
/* 729 */       this.texture = texture;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public void renderWidget(GuiGraphics graphics, int mouseX, int mouseY, float partialTicks) {
/* 735 */       int colorWidth = (this.width - 4) / 2;
/* 736 */       int colorHeight = this.height - 4;
/* 737 */       DrawUtil.drawImage(graphics.pose(), this.texture, getX(), getY(), false, 1.0F, 0.0D, false);
/* 738 */       int colorX = getX() + 2;
/* 739 */       int colorY = getY() + 2;
/* 740 */       graphics.fill(colorX, colorY, colorX + colorWidth, colorY + colorHeight, this.color | 0xFF000000);
/* 741 */       graphics.fill(colorX + colorWidth, colorY, colorX + colorWidth * 2, colorY + colorHeight, this.color);
/*     */       
/* 743 */       if (isHoveredOrFocused()) {
/*     */         
/* 745 */         DrawUtil.drawRectangle(graphics, getX(), getY(), this.width, 1.0D, 16777215, 1.0F);
/* 746 */         DrawUtil.drawRectangle(graphics, getX(), getY(), 1.0D, this.height, 16777215, 1.0F);
/*     */         
/* 748 */         DrawUtil.drawRectangle(graphics, getX(), (getY() + this.height - 1), (this.width - 1), 1.0D, 16777215, 1.0F);
/* 749 */         DrawUtil.drawRectangle(graphics, (getX() + this.width - 1), (getY() + 1), 1.0D, (this.height - 1), 16777215, 1.0F);
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     public int getColor() {
/* 755 */       return this.color;
/*     */     } }
/*     */   public static final class ColorPickerResponse extends Record { private final int color;
/*     */     private final boolean canceled;
/*     */     
/* 760 */     public ColorPickerResponse(int color, boolean canceled) { this.color = color; this.canceled = canceled; } public final String toString() { // Byte code:
/*     */       //   0: aload_0
/*     */       //   1: <illegal opcode> toString : (Ljourneymap/client/ui/component/popupscreenbutton/colorpicker/ColorPickerScreen$ColorPickerResponse;)Ljava/lang/String;
/*     */       //   6: areturn
/*     */       // Line number table:
/*     */       //   Java source line number -> byte code offset
/*     */       //   #760	-> 0
/*     */       // Local variable table:
/*     */       //   start	length	slot	name	descriptor
/* 760 */       //   0	7	0	this	Ljourneymap/client/ui/component/popupscreenbutton/colorpicker/ColorPickerScreen$ColorPickerResponse; } public int color() { return this.color; } public final int hashCode() { // Byte code:
/*     */       //   0: aload_0
/*     */       //   1: <illegal opcode> hashCode : (Ljourneymap/client/ui/component/popupscreenbutton/colorpicker/ColorPickerScreen$ColorPickerResponse;)I
/*     */       //   6: ireturn
/*     */       // Line number table:
/*     */       //   Java source line number -> byte code offset
/*     */       //   #760	-> 0
/*     */       // Local variable table:
/*     */       //   start	length	slot	name	descriptor
/*     */       //   0	7	0	this	Ljourneymap/client/ui/component/popupscreenbutton/colorpicker/ColorPickerScreen$ColorPickerResponse; } public final boolean equals(Object o) { // Byte code:
/*     */       //   0: aload_0
/*     */       //   1: aload_1
/*     */       //   2: <illegal opcode> equals : (Ljourneymap/client/ui/component/popupscreenbutton/colorpicker/ColorPickerScreen$ColorPickerResponse;Ljava/lang/Object;)Z
/*     */       //   7: ireturn
/*     */       // Line number table:
/*     */       //   Java source line number -> byte code offset
/*     */       //   #760	-> 0
/*     */       // Local variable table:
/*     */       //   start	length	slot	name	descriptor
/*     */       //   0	8	0	this	Ljourneymap/client/ui/component/popupscreenbutton/colorpicker/ColorPickerScreen$ColorPickerResponse;
/* 760 */       //   0	8	1	o	Ljava/lang/Object; } public boolean canceled() { return this.canceled; }
/*     */      }
/*     */ 
/*     */ }


/* Location:              C:\Users\Administrator\Downloads\journeymap-forge-1.21-6.0.0-beta.18.jar!\journeymap\clien\\ui\component\popupscreenbutton\colorpicker\ColorPickerScreen.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */