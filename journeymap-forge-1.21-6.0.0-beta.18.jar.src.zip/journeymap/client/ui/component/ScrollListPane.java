/*     */ package journeymap.client.ui.component;
/*     */ 
/*     */ import java.util.List;
/*     */ import javax.annotation.Nullable;
/*     */ import journeymap.client.ui.option.SlotMetadata;
/*     */ import net.minecraft.client.Minecraft;
/*     */ import net.minecraft.client.gui.ComponentPath;
/*     */ import net.minecraft.client.gui.GuiGraphics;
/*     */ import net.minecraft.client.gui.components.AbstractSelectionList;
/*     */ import net.minecraft.client.gui.components.ObjectSelectionList;
/*     */ import net.minecraft.client.gui.components.events.ContainerEventHandler;
/*     */ import net.minecraft.client.gui.components.events.GuiEventListener;
/*     */ import net.minecraft.client.gui.narration.NarrationElementOutput;
/*     */ import net.minecraft.client.gui.navigation.FocusNavigationEvent;
/*     */ import net.minecraft.client.gui.navigation.ScreenAxis;
/*     */ import net.minecraft.client.gui.navigation.ScreenDirection;
/*     */ import net.minecraft.util.FormattedCharSequence;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ScrollListPane<T extends Slot>
/*     */   extends ObjectSelectionList<Slot>
/*     */ {
/*     */   public SlotMetadata lastTooltipMetadata;
/*     */   public List<FormattedCharSequence> lastTooltip;
/*     */   public long lastTooltipTime;
/*  31 */   public long hoverDelay = 400L;
/*  32 */   protected int hpad = 12;
/*     */   
/*     */   private List<T> rootSlots;
/*     */   private SlotMetadata lastPressed;
/*     */   protected int lastClickedIndex;
/*     */   protected int scrollbarX;
/*     */   protected int listWidth;
/*     */   private boolean alignTop;
/*     */   
/*     */   public ScrollListPane(Minecraft mc, int x, int y, int width, int height, int slotHeight) {
/*  42 */     super(mc, y, width, height, slotHeight);
/*  43 */     updateSize(width, height, x, y);
/*     */   }
/*     */ 
/*     */   
/*     */   public void updateSize(int width, int height, int x, int y) {
/*  48 */     setRectangle(width, height, x, y);
/*  49 */     this.scrollbarX = this.width - this.hpad;
/*  50 */     this.listWidth = this.width - this.hpad * 4;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setListWidth(int width) {
/*  55 */     this.scrollbarX = (this.width + width) / 2 - this.hpad;
/*  56 */     this.listWidth = width - this.hpad * 4;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setSlots(List<T> slots) {
/*  61 */     this.rootSlots = slots;
/*  62 */     updateSlots();
/*     */   }
/*     */ 
/*     */   
/*     */   public List<T> getRootSlots() {
/*  67 */     return this.rootSlots;
/*     */   }
/*     */ 
/*     */   
/*     */   public void updateSlots() {
/*  72 */     int sizeBefore = getItemCount();
/*  73 */     children().clear();
/*     */     
/*  75 */     int columnWidth = 0;
/*  76 */     for (Slot slot : this.rootSlots) {
/*     */       
/*  78 */       columnWidth = Math.max(columnWidth, slot.getColumnWidth());
/*  79 */       addEntry((AbstractSelectionList.Entry)slot);
/*     */       
/*  81 */       List<? extends Slot> childSlots = slot.getChildSlots(this.listWidth, columnWidth);
/*  82 */       if (childSlots != null && !childSlots.isEmpty())
/*     */       {
/*  84 */         for (Slot child : childSlots)
/*     */         {
/*  86 */           addEntry((AbstractSelectionList.Entry)child);
/*     */         }
/*     */       }
/*     */     } 
/*  90 */     int sizeAfter = getItemCount();
/*     */     
/*  92 */     if (sizeBefore < sizeAfter) {
/*     */ 
/*     */       
/*  95 */       scroll(-(sizeAfter * getItemHeight()));
/*  96 */       scroll(this.lastClickedIndex * getItemHeight());
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void scrollTo(Slot slot) {
/* 102 */     scroll(-(children().size() * this.itemHeight));
/* 103 */     scroll(children().indexOf(slot) * this.itemHeight);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isSelectedItem(int index) {
/* 109 */     return super.isSelectedItem(index);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected int getRowTop(int slotIndex) {
/* 115 */     return super.getRowTop(slotIndex);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void renderWidget(GuiGraphics graphics, int mouseX, int mouseY, float partialTicks) {
/*     */     try {
/* 123 */       Slot slot = (Slot)getEntryAtPosition(mouseX, mouseY);
/* 124 */       if (slot != null) {
/*     */         
/* 126 */         SlotMetadata tooltipMetadata = slot.getCurrentTooltip();
/* 127 */         if (tooltipMetadata != null && !tooltipMetadata.getTooltip().equals(this.lastTooltip))
/*     */         {
/* 129 */           this.lastTooltipMetadata = tooltipMetadata;
/* 130 */           this.lastTooltip = tooltipMetadata.getTooltip();
/* 131 */           this.lastTooltipTime = System.currentTimeMillis();
/*     */         }
/*     */       
/*     */       } 
/* 135 */     } catch (Throwable throwable) {}
/*     */ 
/*     */ 
/*     */     
/* 139 */     renderBackground(graphics, mouseX, mouseY, partialTicks);
/* 140 */     super.renderWidget(graphics, mouseX, mouseY, partialTicks);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void renderListSeparators(GuiGraphics graphics) {}
/*     */ 
/*     */ 
/*     */   
/*     */   protected void enableScissor(GuiGraphics graphics) {
/* 151 */     super.enableScissor(graphics);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected void renderListBackground(GuiGraphics graphics) {}
/*     */ 
/*     */ 
/*     */   
/*     */   public void renderListItems(GuiGraphics graphics, int mouseX, int mouseY, float partialTicks) {
/* 161 */     super.renderListItems(graphics, mouseX, mouseY, partialTicks);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getRowWidth() {
/* 171 */     return this.listWidth;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean mouseClicked(double mouseX, double mouseY, int button) {
/* 177 */     boolean clicked = super.mouseClicked(mouseX, mouseY, button);
/*     */     
/* 179 */     if (isMouseOver(mouseX, mouseY)) {
/*     */       
/* 181 */       Slot slot = (Slot)getEntryAtPosition(mouseX, mouseY);
/* 182 */       if (slot == null)
/*     */       {
/*     */         
/* 185 */         return clicked;
/*     */       }
/* 187 */       this.lastClickedIndex = children().indexOf(slot);
/* 188 */       this.lastPressed = slot.getLastPressed();
/*     */       
/* 190 */       if (slot instanceof journeymap.client.ui.option.CategorySlot)
/*     */       {
/* 192 */         updateSlots();
/*     */       }
/*     */     } 
/* 195 */     return clicked;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean mouseReleased(double mouseX, double mouseY, int mouseButton) {
/* 202 */     for (int slotIndex = 0; slotIndex < getItemCount(); slotIndex++) {
/*     */       
/* 204 */       if (slotIndex == this.lastClickedIndex) {
/*     */         
/* 206 */         Slot slot = getSlot(this.lastClickedIndex);
/* 207 */         if (slot.mouseReleased(mouseX, mouseY, mouseButton)) {
/*     */           
/* 209 */           this.lastPressed = null;
/* 210 */           return true;
/*     */         } 
/*     */       } 
/*     */     } 
/* 214 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean mouseDragged(double mouseX, double mouseY, int button, double mouseDX, double mouseDY) {
/* 220 */     if (children().isEmpty())
/*     */     {
/* 222 */       return false;
/*     */     }
/*     */     
/* 225 */     if (this.lastClickedIndex > -1 && 
/* 226 */       getSlot(this.lastClickedIndex) != null && 
/* 227 */       getSlot(this.lastClickedIndex).mouseDragged(mouseX, mouseY, button, mouseDX, mouseDY))
/*     */     {
/* 229 */       return true;
/*     */     }
/*     */     
/* 232 */     return super.mouseDragged(mouseX, mouseY, button, mouseDX, mouseDY);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public ComponentPath nextFocusPath(FocusNavigationEvent focusNavigationEvent) {
/* 238 */     if (getItemCount() == 0)
/*     */     {
/* 240 */       return null;
/*     */     }
/* 242 */     if (focusNavigationEvent instanceof FocusNavigationEvent.ArrowNavigation) { ComponentPath path; FocusNavigationEvent.ArrowNavigation arrowNavigation = (FocusNavigationEvent.ArrowNavigation)focusNavigationEvent;
/*     */       
/* 244 */       Slot focused = (Slot)getFocused();
/* 245 */       if (arrowNavigation.direction().getAxis() == ScreenAxis.HORIZONTAL && focused != null)
/*     */       {
/* 247 */         return ComponentPath.path((ContainerEventHandler)this, focused.nextFocusPath(focusNavigationEvent));
/*     */       }
/*     */ 
/*     */       
/* 251 */       int index = -1;
/* 252 */       ScreenDirection direction = arrowNavigation.direction();
/* 253 */       if (isFocused() && focused != null)
/*     */       {
/* 255 */         index = focused.children().indexOf(focused.getFocused());
/*     */       }
/*     */       
/* 258 */       if (index == -1)
/*     */       {
/* 260 */         switch (direction) {
/*     */           
/*     */           case LEFT:
/* 263 */             index = Integer.MAX_VALUE;
/* 264 */             direction = ScreenDirection.DOWN;
/*     */             break;
/*     */           case RIGHT:
/* 267 */             index = 0;
/* 268 */             direction = ScreenDirection.DOWN;
/*     */             break;
/*     */           default:
/* 271 */             index = 0;
/*     */             break;
/*     */         } 
/*     */ 
/*     */       
/*     */       }
/*     */       do {
/* 278 */         focused = (Slot)nextEntry(direction, s -> true, (AbstractSelectionList.Entry)focused);
/* 279 */         if (focused == null)
/*     */         {
/* 281 */           return null;
/*     */         }
/*     */         
/* 284 */         if (focused.children().isEmpty()) {
/*     */           
/* 286 */           path = ComponentPath.leaf((GuiEventListener)focused);
/*     */         }
/*     */         else {
/*     */           
/* 290 */           path = focused.focusPathAtIndex((FocusNavigationEvent)arrowNavigation, index);
/*     */         } 
/* 292 */       } while (path == null);
/*     */       
/* 294 */       return ComponentPath.path((ContainerEventHandler)this, path); }
/*     */ 
/*     */     
/* 297 */     if (!isFocused() && focusNavigationEvent instanceof FocusNavigationEvent.TabNavigation) { ComponentPath path; FocusNavigationEvent.TabNavigation tabNavigation = (FocusNavigationEvent.TabNavigation)focusNavigationEvent;
/*     */       
/* 299 */       Slot selected = (Slot)getSelected();
/* 300 */       if (selected == null)
/*     */       {
/* 302 */         selected = getSlot(0);
/*     */       }
/*     */ 
/*     */       
/* 306 */       if (selected.children().isEmpty()) {
/*     */         
/* 308 */         path = ComponentPath.leaf((GuiEventListener)selected);
/*     */       }
/*     */       else {
/*     */         
/* 312 */         path = selected.focusPathAtIndex((FocusNavigationEvent)tabNavigation, 0);
/*     */       } 
/* 314 */       return ComponentPath.path((ContainerEventHandler)this, path); }
/*     */ 
/*     */     
/* 317 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Slot getSlot(int index) {
/* 325 */     if (getItemCount() > index)
/*     */     {
/* 327 */       return children().get(index);
/*     */     }
/*     */     
/* 330 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   public SlotMetadata getLastPressed() {
/* 335 */     return this.lastPressed;
/*     */   }
/*     */ 
/*     */   
/*     */   public void resetLastPressed() {
/* 340 */     this.lastPressed = null;
/*     */   }
/*     */ 
/*     */   
/*     */   public Slot getLastPressedParentSlot() {
/* 345 */     if (this.lastPressed != null)
/*     */     {
/* 347 */       for (Slot slot : this.rootSlots) {
/*     */         
/* 349 */         if (slot.contains(this.lastPressed))
/*     */         {
/* 351 */           return slot;
/*     */         }
/*     */       } 
/*     */     }
/* 355 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean charTyped(char typedChar, int keyCode) {
/* 361 */     for (int slotIndex = 0; slotIndex < getItemCount(); slotIndex++) {
/*     */       
/* 363 */       if (slotIndex == this.lastClickedIndex)
/*     */       {
/* 365 */         return getSlot(this.lastClickedIndex).charTyped(typedChar, keyCode);
/*     */       }
/*     */     } 
/* 368 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean keyPressed(int key, int value, int modifier) {
/* 374 */     if (getSelected() != null)
/*     */     {
/* 376 */       return ((Slot)getSelected()).keyPressed(key, value, modifier);
/*     */     }
/* 378 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected int getScrollbarPosition() {
/* 384 */     return this.scrollbarX;
/*     */   }
/*     */ 
/*     */   
/*     */   protected void renderBackground(GuiGraphics graphics, int i, int j, float f) {
/* 389 */     graphics.fillGradient(0, getY(), this.width, this.height + getY(), -1072689136, -804253680);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected int getMaxPosition() {
/* 395 */     int contentHeight = super.getMaxPosition();
/* 396 */     if (this.alignTop)
/*     */     {
/* 398 */       contentHeight = Math.max(getBottom() - getTop() - 4, contentHeight);
/*     */     }
/* 400 */     return contentHeight;
/*     */   }
/*     */ 
/*     */   
/*     */   public int getTop() {
/* 405 */     return getY();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public int getHeight() {
/* 411 */     return this.height;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setAlignTop(boolean alignTop) {
/* 416 */     this.alignTop = alignTop;
/*     */   }
/*     */ 
/*     */   
/*     */   public int getItemHeight() {
/* 421 */     return this.itemHeight;
/*     */   }
/*     */   
/*     */   public void updateWidgetNarration(NarrationElementOutput narrationElementOutput) {}
/*     */ }


/* Location:              C:\Users\Administrator\Downloads\journeymap-forge-1.21-6.0.0-beta.18.jar!\journeymap\clien\\ui\component\ScrollListPane.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */