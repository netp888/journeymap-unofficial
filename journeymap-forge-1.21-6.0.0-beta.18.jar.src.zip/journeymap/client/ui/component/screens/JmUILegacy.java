/*     */ package journeymap.client.ui.component.screens;
/*     */ 
/*     */ import java.awt.Color;
/*     */ import java.util.Arrays;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Stack;
/*     */ import java.util.stream.Collectors;
/*     */ import journeymap.client.Constants;
/*     */ import journeymap.client.render.RenderWrapper;
/*     */ import journeymap.client.render.draw.DrawUtil;
/*     */ import journeymap.client.texture.Texture;
/*     */ import journeymap.client.texture.TextureCache;
/*     */ import journeymap.client.ui.UIManager;
/*     */ import journeymap.client.ui.component.buttons.Button;
/*     */ import journeymap.common.Journeymap;
/*     */ import journeymap.common.log.LogFormatter;
/*     */ import net.minecraft.client.Minecraft;
/*     */ import net.minecraft.client.gui.Font;
/*     */ import net.minecraft.client.gui.GuiGraphics;
/*     */ import net.minecraft.client.gui.components.Button;
/*     */ import net.minecraft.client.gui.components.Renderable;
/*     */ import net.minecraft.client.gui.screens.Screen;
/*     */ import net.minecraft.client.renderer.MultiBufferSource;
/*     */ import net.minecraft.client.renderer.RenderType;
/*     */ import net.minecraft.network.chat.Component;
/*     */ import net.minecraft.network.chat.Style;
/*     */ import net.minecraft.util.FormattedCharSequence;
/*     */ import org.apache.logging.log4j.Logger;
/*     */ import org.joml.Matrix4f;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class JmUILegacy
/*     */   extends Screen
/*     */ {
/*     */   protected final String title;
/*  43 */   protected final int headerHeight = 36;
/*  44 */   protected final int footerHeight = 30;
/*  45 */   protected final Logger logger = Journeymap.getLogger();
/*  46 */   protected double scaleFactor = 1.0D;
/*  47 */   protected static Stack<Screen> returnDisplayStack = JmUI.returnDisplayStack;
/*  48 */   protected Texture logo = TextureCache.getTexture(TextureCache.Logo);
/*     */   
/*     */   protected boolean renderBottomBar = false;
/*     */   
/*     */   public JmUILegacy(String title) {
/*  53 */     this(title, (Screen)null);
/*     */   }
/*     */ 
/*     */   
/*     */   public JmUILegacy(String title, Screen returnDisplay) {
/*  58 */     super((Component)Constants.getStringTextComponent(title));
/*  59 */     this.title = title;
/*  60 */     returnDisplayStack.push(returnDisplay);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Minecraft getMinecraft() {
/*  66 */     return this.minecraft = Minecraft.getInstance();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void init(Minecraft minecraft, int width, int height) {
/*  73 */     super.init(minecraft, width, height);
/*  74 */     this.scaleFactor = JmUI.calculateScaleFactor();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isPauseScreen() {
/*  81 */     return true;
/*     */   }
/*     */ 
/*     */   
/*     */   public Font getFontRenderer() {
/*  86 */     return this.font;
/*     */   }
/*     */ 
/*     */   
/*     */   public void sizeDisplay(boolean scaled) {
/*  91 */     int glwidth = scaled ? this.width : this.minecraft.getWindow().getScreenWidth();
/*  92 */     int glheight = scaled ? this.height : this.minecraft.getWindow().getScreenHeight();
/*  93 */     DrawUtil.sizeDisplay(glwidth, glheight);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected boolean isMouseOverButton(double mouseX, double mouseY) {
/*  99 */     for (int k = 0; k < getRenderables().size(); k++) {
/*     */       
/* 101 */       Button guibutton = (Button)getRenderables().get(k);
/* 102 */       if (guibutton instanceof Button) {
/*     */         
/* 104 */         Button button = (Button)guibutton;
/* 105 */         if (button.mouseOver(mouseX, mouseY))
/*     */         {
/* 107 */           return true;
/*     */         }
/*     */       } 
/*     */     } 
/* 111 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean mouseReleased(double mouseX, double mouseY, int mouseEvent) {
/* 117 */     return super.mouseReleased(mouseX, mouseY, mouseEvent);
/*     */   }
/*     */ 
/*     */   
/*     */   protected void drawLogo(GuiGraphics graphics) {
/* 122 */     if (!this.logo.hasImage())
/*     */     {
/* 124 */       this.logo = TextureCache.getTexture(TextureCache.Logo);
/*     */     }
/* 126 */     DrawUtil.sizeDisplay(this.minecraft.getWindow().getScreenWidth(), this.minecraft.getWindow().getScreenHeight());
/* 127 */     DrawUtil.drawImage(graphics.pose(), this.logo, 8.0D, 8.0D, false, 0.5F, 0.0D);
/* 128 */     DrawUtil.sizeDisplay(this.width, this.height);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected void renderBottomBar(GuiGraphics graphics) {
/* 134 */     if (this.renderBottomBar)
/*     */     {
/* 136 */       DrawUtil.drawRectangle(graphics, 0.0D, (this.height - 30), this.width, this.height, 0, 0.6F);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   protected void drawTitle(GuiGraphics graphics) {
/* 142 */     DrawUtil.drawRectangle(graphics, 0.0D, 0.0D, this.width, 36.0D, 0, 0.9F);
/* 143 */     DrawUtil.drawLabel(graphics, this.title, (this.width / 2), 18.0D, DrawUtil.HAlign.Center, DrawUtil.VAlign.Middle, 
/* 144 */         Integer.valueOf(0), 0.0F, Integer.valueOf(Color.CYAN.getRGB()), 1.0F, 1.0D, true, 0.0D);
/*     */ 
/*     */     
/* 147 */     String apiVersion = "API v2.0.0-SNAPSHOT";
/* 148 */     DrawUtil.drawLabel(graphics, apiVersion, (this.width - 10), 18.0D, DrawUtil.HAlign.Left, DrawUtil.VAlign.Middle, 
/* 149 */         Integer.valueOf(0), 0.0F, Integer.valueOf(13421772), 1.0F, 0.5D, true, 0.0D);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void init() {
/* 155 */     getRenderables().clear();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void renderBackground(GuiGraphics graphics, int i, int j, float f) {
/* 162 */     if ((Minecraft.getInstance()).level == null) {
/*     */       
/* 164 */       drawGradientRect(graphics, 0, 0, this.width, this.height, -1072689136, -804253680, 0);
/*     */     }
/*     */     else {
/*     */       
/* 168 */       super.renderBackground(graphics, i, j, f);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List getButtonList() {
/* 176 */     return getRenderables();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void render(GuiGraphics graphics, int x, int y, float partialTicks) {
/*     */     try {
/* 184 */       renderBackground(graphics, x, y, partialTicks);
/* 185 */       renderBottomBar(graphics);
/* 186 */       layoutButtons(graphics);
/*     */       
/* 188 */       drawTitle(graphics);
/* 189 */       drawLogo(graphics);
/*     */       
/* 191 */       List<FormattedCharSequence> tooltip = null;
/* 192 */       for (int k = 0; k < getRenderables().size(); k++) {
/*     */         
/* 194 */         Renderable guibutton = getRenderables().get(k);
/* 195 */         guibutton.render(graphics, x, y, 0.0F);
/* 196 */         if (tooltip == null)
/*     */         {
/* 198 */           if (guibutton instanceof Button) {
/*     */             
/* 200 */             Button button = (Button)guibutton;
/* 201 */             if (button.mouseOver(x, y))
/*     */             {
/* 203 */               tooltip = button.getWrappedTooltip();
/*     */             }
/*     */           } 
/*     */         }
/*     */       } 
/*     */       
/* 209 */       if (tooltip != null && !tooltip.isEmpty())
/*     */       {
/* 211 */         renderWrappedToolTip(graphics, tooltip, x, y, getFontRenderer());
/*     */       
/*     */       }
/*     */     
/*     */     }
/* 216 */     catch (Throwable t) {
/*     */       
/* 218 */       Journeymap.getLogger().error("Error in UI: " + LogFormatter.toString(t));
/* 219 */       closeAndReturn();
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void drawGradientRect(GuiGraphics graphics, int pX1, int pY1, int pX2, int pY2, int pColorFrom, int pColorTo, int pBlitOffset) {
/* 225 */     graphics.fillGradient(RenderType.guiOverlay(), pX1, pY1, pX2, pY2, pColorFrom, pColorTo, pBlitOffset);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void close() {}
/*     */ 
/*     */ 
/*     */   
/*     */   protected void closeAndReturn() {
/* 235 */     if (returnDisplayStack == null || returnDisplayStack.peek() == null) {
/*     */       
/* 237 */       UIManager.INSTANCE.closeAll();
/*     */     }
/*     */     else {
/*     */       
/* 241 */       UIManager.INSTANCE.open(returnDisplayStack.pop());
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void closeWithKeyBind() {
/* 247 */     closeAndReturn();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean charTyped(char c, int i) {
/* 253 */     return super.charTyped(c, i);
/*     */   }
/*     */ 
/*     */   
/*     */   public void setRenderBottomBar(boolean renderBottomBar) {
/* 258 */     this.renderBottomBar = renderBottomBar;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean keyPressed(int key, int value, int modifier) {
/* 265 */     switch (key) {
/*     */ 
/*     */       
/*     */       case 256:
/* 269 */         closeAndReturn();
/* 270 */         return true;
/*     */     } 
/*     */     
/* 273 */     return super.keyPressed(key, value, modifier);
/*     */   }
/*     */ 
/*     */   
/*     */   public void renderTooltip(GuiGraphics graphics, String[] tooltip, int mouseX, int mouseY) {
/* 278 */     List<FormattedCharSequence> tooltips = (List<FormattedCharSequence>)Arrays.<String>stream(tooltip).map(e -> FormattedCharSequence.forward(e, Style.EMPTY)).collect(Collectors.toList());
/* 279 */     renderWrappedToolTip(graphics, tooltips, mouseX, mouseY, getFontRenderer());
/*     */   }
/*     */ 
/*     */   
/*     */   public Screen getReturnDisplay() {
/* 284 */     return returnDisplayStack.peek();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void renderWrappedToolTip(GuiGraphics graphics, List<FormattedCharSequence> tooltip, int mouseX, int mouseY, Font fontRenderer) {
/* 291 */     if (!tooltip.isEmpty() && tooltip.get(0) instanceof FormattedCharSequence && (Minecraft.getInstance()).screen == this) {
/*     */       
/* 293 */       RenderWrapper.disableDepthTest();
/* 294 */       int maxLineWidth = 0;
/* 295 */       Iterator<FormattedCharSequence> iterator = tooltip.iterator();
/*     */       
/* 297 */       while (iterator.hasNext()) {
/*     */         
/* 299 */         FormattedCharSequence line = iterator.next();
/* 300 */         int lineWidth = fontRenderer.width(line);
/* 301 */         if (fontRenderer.isBidirectional())
/*     */         {
/* 303 */           lineWidth = (int)Math.ceil(lineWidth * 1.25D);
/*     */         }
/*     */         
/* 306 */         if (lineWidth > maxLineWidth)
/*     */         {
/* 308 */           maxLineWidth = lineWidth;
/*     */         }
/*     */       } 
/*     */       
/* 312 */       int drawX = mouseX + 12;
/* 313 */       int drawY = mouseY - 12;
/* 314 */       int boxHeight = 8;
/*     */       
/* 316 */       if (tooltip.size() > 1)
/*     */       {
/* 318 */         boxHeight += 2 + (tooltip.size() - 1) * 10;
/*     */       }
/*     */       
/* 321 */       if (drawX + maxLineWidth > this.width)
/*     */       {
/* 323 */         drawX -= 28 + maxLineWidth;
/*     */       }
/*     */       
/* 326 */       if (drawY + boxHeight + 6 > this.height)
/*     */       {
/* 328 */         drawY = this.height - boxHeight - 6;
/*     */       }
/*     */       
/* 331 */       int j1 = -267386864;
/* 332 */       drawGradientRect(graphics, drawX - 3, drawY - 4, drawX + maxLineWidth + 3, drawY - 3, j1, j1, 300);
/* 333 */       drawGradientRect(graphics, drawX - 3, drawY + boxHeight + 3, drawX + maxLineWidth + 3, drawY + boxHeight + 4, j1, j1, 300);
/* 334 */       drawGradientRect(graphics, drawX - 3, drawY - 3, drawX + maxLineWidth + 3, drawY + boxHeight + 3, j1, j1, 300);
/* 335 */       drawGradientRect(graphics, drawX - 4, drawY - 3, drawX - 3, drawY + boxHeight + 3, j1, j1, 300);
/* 336 */       drawGradientRect(graphics, drawX + maxLineWidth + 3, drawY - 3, drawX + maxLineWidth + 4, drawY + boxHeight + 3, j1, j1, 300);
/* 337 */       int k1 = 1347420415;
/* 338 */       int l1 = (k1 & 0xFEFEFE) >> 1 | k1 & 0xFF000000;
/* 339 */       drawGradientRect(graphics, drawX - 3, drawY - 3 + 1, drawX - 3 + 1, drawY + boxHeight + 3 - 1, k1, l1, 300);
/* 340 */       drawGradientRect(graphics, drawX + maxLineWidth + 2, drawY - 3 + 1, drawX + maxLineWidth + 3, drawY + boxHeight + 3 - 1, k1, l1, 300);
/* 341 */       drawGradientRect(graphics, drawX - 3, drawY - 3, drawX + maxLineWidth + 3, drawY - 3 + 1, k1, k1, 300);
/* 342 */       drawGradientRect(graphics, drawX - 3, drawY + boxHeight + 2, drawX + maxLineWidth + 3, drawY + boxHeight + 3, l1, l1, 300);
/*     */ 
/*     */       
/* 345 */       for (int i2 = 0; i2 < tooltip.size(); i2++) {
/*     */         
/* 347 */         FormattedCharSequence line = tooltip.get(i2);
/* 348 */         Matrix4f matrixPos = graphics.pose().last().pose();
/* 349 */         if (fontRenderer.isBidirectional()) {
/*     */           
/* 351 */           int lineWidth = (int)Math.ceil(fontRenderer.width(line) * 1.1D);
/* 352 */           fontRenderer.drawInBatch(line, (drawX + maxLineWidth - lineWidth), drawY, -1, true, matrixPos, (MultiBufferSource)graphics.bufferSource(), Font.DisplayMode.NORMAL, 0, 15728880);
/*     */         }
/*     */         else {
/*     */           
/* 356 */           fontRenderer.drawInBatch(line, drawX, drawY, -1, true, matrixPos, (MultiBufferSource)graphics.bufferSource(), Font.DisplayMode.NORMAL, 0, 15728880);
/*     */         } 
/*     */         
/* 359 */         if (i2 == 0)
/*     */         {
/* 361 */           drawY += 2;
/*     */         }
/*     */         
/* 364 */         drawY += 10;
/*     */       } 
/* 366 */       RenderWrapper.enableDepthTest();
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public List<Renderable> getRenderables() {
/* 372 */     return this.renderables;
/*     */   }
/*     */   
/*     */   protected abstract void layoutButtons(GuiGraphics paramGuiGraphics);
/*     */ }


/* Location:              C:\Users\Administrator\Downloads\journeymap-forge-1.21-6.0.0-beta.18.jar!\journeymap\clien\\ui\component\screens\JmUILegacy.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */