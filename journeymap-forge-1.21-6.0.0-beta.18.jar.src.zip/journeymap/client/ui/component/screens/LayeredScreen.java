/*    */ package journeymap.client.ui.component.screens;
/*    */ 
/*    */ import net.minecraft.client.Minecraft;
/*    */ import net.minecraft.client.gui.GuiGraphics;
/*    */ import net.minecraft.client.gui.screens.Screen;
/*    */ import net.minecraft.network.chat.Component;
/*    */ 
/*    */ 
/*    */ public abstract class LayeredScreen
/*    */   extends Screen
/*    */ {
/*    */   protected Minecraft minecraft;
/*    */   protected Screen backgroundScreen;
/*    */   
/*    */   protected LayeredScreen(Component component) {
/* 16 */     super(component);
/* 17 */     this.minecraft = Minecraft.getInstance();
/*    */   }
/*    */ 
/*    */   
/*    */   public void display() {
/* 22 */     this.backgroundScreen = this.minecraft.screen;
/* 23 */     this.minecraft.setScreen(this);
/*    */   }
/*    */ 
/*    */   
/*    */   public void resize(Minecraft minecraft, int width, int height) {
/* 28 */     super.resize(minecraft, width, height);
/* 29 */     if (this.backgroundScreen != null)
/*    */     {
/* 31 */       this.backgroundScreen.resize(this.minecraft, this.width, this.height);
/*    */     }
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   @Deprecated
/*    */   public final void render(GuiGraphics graphics, int mouseX, int mouseY, float partialTicks) {
/* 39 */     if (this.backgroundScreen != null)
/*    */     {
/*    */       
/* 42 */       this.backgroundScreen.render(graphics, -1, -1, partialTicks);
/*    */     }
/*    */     
/* 45 */     graphics.pose().translate(0.0D, 0.0D, 2000.0D);
/*    */     
/* 47 */     renderPopupScreenBackground(graphics, mouseX, mouseY, partialTicks);
/* 48 */     renderPopupScreen(graphics, mouseX, mouseY, partialTicks);
/*    */   }
/*    */ 
/*    */   
/*    */   protected void renderPopupScreen(GuiGraphics graphics, int mouseX, int mouseY, float partialTicks) {
/* 53 */     super.render(graphics, mouseX, mouseY, partialTicks);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   protected void renderPopupScreenBackground(GuiGraphics graphics, int mouseX, int mouseY, float partialTicks) {}
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public final void renderBackground(GuiGraphics graphics, int mouseX, int mouseY, float partialTicks) {}
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void onClose() {
/* 70 */     popLayer();
/*    */   }
/*    */ 
/*    */   
/*    */   public void popLayer() {
/* 75 */     if (this.minecraft.screen != null)
/*    */     {
/* 77 */       this.minecraft.screen.removed();
/*    */     }
/* 79 */     this.minecraft.screen = this.backgroundScreen;
/*    */   }
/*    */ 
/*    */   
/*    */   public Screen getBackgroundScreen() {
/* 84 */     return this.backgroundScreen;
/*    */   }
/*    */ }


/* Location:              C:\Users\Administrator\Downloads\journeymap-forge-1.21-6.0.0-beta.18.jar!\journeymap\clien\\ui\component\screens\LayeredScreen.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */