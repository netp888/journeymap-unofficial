/*     */ package journeymap.client.ui.component;
/*     */ 
/*     */ import java.awt.Color;
/*     */ import journeymap.client.Constants;
/*     */ import net.minecraft.Util;
/*     */ import net.minecraft.client.gui.Font;
/*     */ import net.minecraft.client.gui.GuiGraphics;
/*     */ import net.minecraft.client.gui.components.EditBox;
/*     */ import net.minecraft.network.chat.Component;
/*     */ import net.minecraft.util.Mth;
/*     */ import org.jetbrains.annotations.NotNull;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class TextBox
/*     */   extends EditBox
/*     */ {
/*     */   protected final String numericRegex;
/*     */   protected final boolean numeric;
/*     */   protected final boolean allowNegative;
/*     */   protected int minLength;
/*     */   protected Integer clampMin;
/*     */   protected Integer clampMax;
/*  30 */   private long lastClick = 0L;
/*     */ 
/*     */   
/*     */   public TextBox(Object text, Font fontRenderer, int width, int height) {
/*  34 */     this(text, fontRenderer, width, height, false, false);
/*     */   }
/*     */ 
/*     */   
/*     */   public TextBox(Object text, Font fontRenderer, int width, int height, boolean isNumeric, boolean negative) {
/*  39 */     super(fontRenderer, 0, 0, width, height, (Component)Constants.getStringTextComponent((text == null) ? "" : text.toString()));
/*  40 */     setMaxLength(256);
/*  41 */     setValue((text == null) ? "" : text.toString());
/*  42 */     this.numeric = isNumeric;
/*  43 */     this.allowNegative = negative;
/*     */     
/*  45 */     String regex = null;
/*  46 */     if (this.numeric)
/*     */     {
/*  48 */       if (this.allowNegative) {
/*     */         
/*  50 */         regex = "[^-?\\d]";
/*     */       }
/*     */       else {
/*     */         
/*  54 */         regex = "[^\\d]";
/*     */       } 
/*     */     }
/*     */     
/*  58 */     this.numericRegex = regex;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setClamp(Integer min, Integer max) {
/*  63 */     this.clampMin = min;
/*  64 */     this.clampMax = max;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setMinLength(int minLength) {
/*  69 */     this.minLength = minLength;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void insertText(@NotNull String par1Str) {
/*  76 */     if (this.numeric) {
/*     */       
/*  78 */       String fixed = par1Str.replaceAll(this.numericRegex, "");
/*  79 */       if (this.allowNegative)
/*     */       {
/*  81 */         par1Str = ("-".equals(fixed) && getCursorPosition() != 0 && !isAllSelected()) ? "" : fixed;
/*     */       }
/*     */     } 
/*     */     
/*  85 */     super.insertText(par1Str);
/*     */   }
/*     */ 
/*     */   
/*     */   public void setText(Object object) {
/*  90 */     setValue(object.toString());
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isNumeric() {
/*  95 */     return this.numeric;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean hasMinLength() {
/* 100 */     String text = getValue();
/* 101 */     int textLen = (text == null) ? 0 : text.length();
/* 102 */     return (this.minLength <= textLen);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean charTyped(char c, int key) {
/* 108 */     boolean typed = false;
/* 109 */     if (isHoveredOrFocused()) {
/*     */       
/* 111 */       typed = super.charTyped(c, key);
/* 112 */       if (this.numeric && typed)
/*     */       {
/* 114 */         clamp();
/*     */       }
/*     */     } 
/*     */ 
/*     */     
/* 119 */     return typed;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean keyPressed(int key, int value, int modifier) {
/* 125 */     boolean pressed = false;
/* 126 */     if (isHoveredOrFocused())
/*     */     {
/* 128 */       pressed = super.keyPressed(key, value, modifier);
/*     */     }
/* 130 */     return pressed;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean mouseReleased(double mouseX, double mouseY, int mouseButton) {
/* 136 */     return super.mouseReleased(mouseX, mouseY, mouseButton);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean mouseDragged(double mouseX, double mouseY, int button, double mouseDX, double mouseDY) {
/* 143 */     if (isMouseOver(mouseX, mouseY)) {
/*     */       
/* 145 */       if (isFocused() && button == 0) {
/*     */         
/* 147 */         int i = Mth.floor(mouseX) - super.getX();
/* 148 */         if (isBordered())
/*     */         {
/* 150 */           i -= 4;
/*     */         }
/*     */         
/* 153 */         String s = this.font.plainSubstrByWidth(getValue().substring(this.displayPos), getInnerWidth());
/* 154 */         setHighlightPos(this.font.plainSubstrByWidth(s, i).length() + this.displayPos);
/* 155 */         return true;
/*     */       } 
/* 157 */       return super.mouseDragged(mouseX, mouseY, button, mouseDX, mouseDY);
/*     */     } 
/* 159 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean mouseClicked(double mouseX, double mouseY, int mouseButton) {
/* 165 */     setHighlightPos(getCursorPosition());
/* 166 */     if (isMouseOver(mouseX, mouseY) && super.mouseClicked(mouseX, mouseY, mouseButton)) {
/*     */       
/* 168 */       long sysTime = Util.getMillis();
/* 169 */       boolean doubleClick = (sysTime - this.lastClick < 200L);
/* 170 */       this.lastClick = sysTime;
/* 171 */       if (doubleClick)
/*     */       {
/* 173 */         selectAll();
/*     */       }
/* 175 */       setFocused(true);
/* 176 */       return true;
/*     */     } 
/* 178 */     setFocused(false);
/* 179 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void setFocused(boolean focused) {
/* 185 */     super.setFocused(focused);
/*     */   }
/*     */ 
/*     */   
/*     */   public void selectAll() {
/* 190 */     moveCursorToEnd(false);
/* 191 */     setHighlightPos(0);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isAllSelected() {
/* 196 */     return getValue().equals(getHighlighted());
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void setCursorPosition(int position) {
/* 202 */     super.setCursorPosition(position);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isHovered() {
/* 207 */     return this.isHovered;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void renderWidget(GuiGraphics graphics, int mouseX, int mouseY, float partialTicks) {
/* 215 */     super.renderWidget(graphics, mouseX, mouseY, partialTicks);
/* 216 */     if (isVisible())
/*     */     {
/* 218 */       if (!hasMinLength()) {
/*     */         
/* 220 */         int red = Color.red.getRGB();
/* 221 */         int x1 = getX() - 1;
/* 222 */         int y1 = getY() - 1;
/* 223 */         int x2 = x1 + getWidth() + 1;
/* 224 */         int y2 = y1 + getHeight() + 1;
/*     */         
/* 226 */         graphics.fill(x1, y1, x2, y1 + 1, red);
/* 227 */         graphics.fill(x1, y2, x2, y2 + 1, red);
/* 228 */         graphics.fill(x1, y1, x1 + 1, y2, red);
/* 229 */         graphics.fill(x2, y1, x2 + 1, y2, red);
/*     */       } 
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Integer clamp() {
/* 240 */     return clamp(getValue());
/*     */   }
/*     */ 
/*     */   
/*     */   public Integer clamp(String text) {
/*     */     int val;
/* 246 */     if (!this.numeric)
/*     */     {
/* 248 */       return null;
/*     */     }
/*     */     
/* 251 */     if (this.clampMin != null) {
/*     */ 
/*     */       
/* 254 */       if (text == null || text.length() == 0 || text.equals("-"))
/*     */       {
/* 256 */         return null;
/*     */       }
/*     */       
/*     */       try {
/* 260 */         val = Math.max(this.clampMin.intValue(), Integer.parseInt(text));
/*     */       }
/* 262 */       catch (Exception e) {
/*     */         
/* 264 */         return this.clampMin;
/*     */       } 
/* 266 */       if (this.clampMax != null) {
/*     */         
/*     */         try {
/*     */           
/* 270 */           val = Math.min(this.clampMax.intValue(), val);
/*     */         }
/* 272 */         catch (Exception e) {
/*     */           
/* 274 */           return this.clampMax;
/*     */         } 
/*     */       }
/*     */     } else {
/*     */ 
/*     */       
/*     */       try {
/*     */ 
/*     */         
/* 283 */         val = Integer.parseInt(text);
/*     */       }
/* 285 */       catch (Exception e) {
/*     */         
/* 287 */         return null;
/*     */       } 
/*     */     } 
/*     */     
/* 291 */     if (val != Integer.parseInt(text))
/*     */     {
/* 293 */       setText(Integer.valueOf(val));
/*     */     }
/* 295 */     return Integer.valueOf(val);
/*     */   }
/*     */ 
/*     */   
/*     */   public int getX() {
/* 300 */     return super.getX();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void setX(int x) {
/* 306 */     super.setX(x);
/*     */   }
/*     */ 
/*     */   
/*     */   public int getY() {
/* 311 */     return super.getY();
/*     */   }
/*     */ 
/*     */   
/*     */   public void setY(int y) {
/* 316 */     super.setY(y);
/*     */   }
/*     */ 
/*     */   
/*     */   public int getWidth() {
/* 321 */     return this.width;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setWidth(int w) {
/* 326 */     this.width = w;
/*     */   }
/*     */ 
/*     */   
/*     */   public int getHeight() {
/* 331 */     return this.height;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setHeight(int h) {
/* 336 */     this.height = h;
/*     */   }
/*     */ 
/*     */   
/*     */   public int getCenterX() {
/* 341 */     return getX() + getWidth() / 2;
/*     */   }
/*     */ 
/*     */   
/*     */   public int getMiddleY() {
/* 346 */     return getY() + getHeight() / 2;
/*     */   }
/*     */ 
/*     */   
/*     */   public int getBottomY() {
/* 351 */     return getY() + getHeight();
/*     */   }
/*     */ 
/*     */   
/*     */   public int getRightX() {
/* 356 */     return getX() + getWidth();
/*     */   }
/*     */ }


/* Location:              C:\Users\Administrator\Downloads\journeymap-forge-1.21-6.0.0-beta.18.jar!\journeymap\clien\\ui\component\TextBox.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */