/*     */ package journeymap.client.ui.component;
/*     */ 
/*     */ import java.util.Collection;
/*     */ import java.util.Collections;
/*     */ import java.util.List;
/*     */ import journeymap.client.ui.option.SlotMetadata;
/*     */ import net.minecraft.client.gui.ComponentPath;
/*     */ import net.minecraft.client.gui.components.ObjectSelectionList;
/*     */ import net.minecraft.client.gui.components.events.ContainerEventHandler;
/*     */ import net.minecraft.client.gui.components.events.GuiEventListener;
/*     */ import net.minecraft.client.gui.navigation.FocusNavigationEvent;
/*     */ import net.minecraft.network.chat.Component;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class Slot
/*     */   extends ObjectSelectionList.Entry<Slot>
/*     */   implements ContainerEventHandler
/*     */ {
/*     */   private GuiEventListener focused;
/*     */   private boolean dragging;
/*     */   
/*     */   public abstract Collection<SlotMetadata> getMetadata();
/*     */   
/*     */   public abstract List<? extends Slot> getChildSlots(int paramInt1, int paramInt2);
/*     */   
/*     */   public abstract SlotMetadata getLastPressed();
/*     */   
/*     */   public abstract SlotMetadata getCurrentTooltip();
/*     */   
/*     */   public abstract void setEnabled(boolean paramBoolean);
/*     */   
/*     */   public abstract int getColumnWidth();
/*     */   
/*     */   public abstract boolean contains(SlotMetadata paramSlotMetadata);
/*     */   
/*     */   public void displayHover(boolean enabled) {}
/*     */   
/*     */   public Component getNarration() {
/*  41 */     return (Component)Component.literal("");
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public List<? extends GuiEventListener> children() {
/*  47 */     return Collections.emptyList();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isDragging() {
/*  53 */     return this.dragging;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void setDragging(boolean $$0) {
/*  59 */     this.dragging = $$0;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void setFocused(GuiEventListener guiEventListener) {
/*  65 */     if (this.focused != null)
/*     */     {
/*  67 */       this.focused.setFocused(false);
/*     */     }
/*     */     
/*  70 */     this.focused = guiEventListener;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public GuiEventListener getFocused() {
/*  76 */     return this.focused;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public ComponentPath getCurrentFocusPath() {
/*  82 */     if (children().isEmpty())
/*     */     {
/*  84 */       return super.getCurrentFocusPath();
/*     */     }
/*  86 */     if (getFocused() != null)
/*     */     {
/*  88 */       return ComponentPath.path(this, getFocused().getCurrentFocusPath());
/*     */     }
/*  90 */     return super.getCurrentFocusPath();
/*     */   }
/*     */ 
/*     */   
/*     */   public ComponentPath focusPathAtIndex(FocusNavigationEvent focusNavigationEvent, int index) {
/*  95 */     if (children().isEmpty())
/*     */     {
/*  97 */       return null;
/*     */     }
/*     */ 
/*     */     
/* 101 */     ComponentPath path = ((GuiEventListener)children().get(Math.min(index, children().size() - 1))).nextFocusPath(focusNavigationEvent);
/* 102 */     if (path == null)
/*     */     {
/* 104 */       path = ((GuiEventListener)children().get(0)).nextFocusPath(focusNavigationEvent);
/*     */     }
/* 106 */     return ComponentPath.path(this, path);
/*     */   }
/*     */ }


/* Location:              C:\Users\Administrator\Downloads\journeymap-forge-1.21-6.0.0-beta.18.jar!\journeymap\clien\\ui\component\Slot.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */