package journeymap.client.ui.component;

public interface SelectableParent {
  void setSelected(DropDownItem paramDropDownItem);
}


/* Location:              C:\Users\Administrator\Downloads\journeymap-forge-1.21-6.0.0-beta.18.jar!\journeymap\clien\\ui\component\SelectableParent.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */