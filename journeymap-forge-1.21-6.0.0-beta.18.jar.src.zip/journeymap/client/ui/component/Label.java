/*    */ package journeymap.client.ui.component;
/*    */ 
/*    */ import journeymap.client.Constants;
/*    */ import journeymap.client.render.draw.DrawUtil;
/*    */ import journeymap.client.ui.component.buttons.Button;
/*    */ import net.minecraft.client.gui.Font;
/*    */ import net.minecraft.client.gui.GuiGraphics;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Label
/*    */   extends Button
/*    */ {
/* 15 */   private DrawUtil.HAlign hAlign = DrawUtil.HAlign.Left;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public Label(int width, String key, Object... labelArgs) {
/* 26 */     super(Constants.getString(key, labelArgs));
/* 27 */     setDrawBackground(false);
/* 28 */     setDrawFrame(false);
/* 29 */     setEnabled(false);
/* 30 */     setLabelColors(Integer.valueOf(12632256), Integer.valueOf(12632256), Integer.valueOf(12632256));
/* 31 */     setWidth(width);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public int getFitWidth(Font fr) {
/* 37 */     return this.fontRenderer.width(getMessage().getString());
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void fitWidth(Font fr) {}
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void setHAlign(DrawUtil.HAlign hAlign) {
/* 53 */     this.hAlign = hAlign;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public void renderWidget(GuiGraphics graphics, int mouseX, int mouseY, float ticks) {
/*    */     int labelX;
/* 60 */     switch (this.hAlign) {
/*    */ 
/*    */       
/*    */       case Left:
/* 64 */         labelX = getRightX();
/*    */         break;
/*    */ 
/*    */       
/*    */       case Right:
/* 69 */         labelX = getX();
/*    */         break;
/*    */ 
/*    */       
/*    */       default:
/* 74 */         labelX = getCenterX();
/*    */         break;
/*    */     } 
/*    */     
/* 78 */     DrawUtil.drawLabel(graphics, getMessage().getString(), labelX, getMiddleY(), this.hAlign, DrawUtil.VAlign.Middle, null, 0.0F, this.labelColor.intValue(), 1.0F, 1.0D, this.drawLabelShadow);
/*    */   }
/*    */ }


/* Location:              C:\Users\Administrator\Downloads\journeymap-forge-1.21-6.0.0-beta.18.jar!\journeymap\clien\\ui\component\Label.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */