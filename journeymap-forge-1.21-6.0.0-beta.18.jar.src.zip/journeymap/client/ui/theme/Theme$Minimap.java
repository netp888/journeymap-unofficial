/*     */ package journeymap.client.ui.theme;
/*     */ 
/*     */ import com.google.gson.annotations.Since;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Minimap
/*     */ {
/*     */   @Since(1.0D)
/* 507 */   public MinimapCircle circle = new MinimapCircle();
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Since(1.0D)
/* 513 */   public MinimapSquare square = new MinimapSquare();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static abstract class MinimapSpec
/*     */   {
/*     */     @Since(1.0D)
/*     */     public int margin;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @Since(2.0D)
/* 530 */     public Theme.LabelSpec labelTop = new Theme.LabelSpec();
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @Since(2.0D)
/*     */     public boolean labelTopInside = false;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @Since(2.0D)
/* 542 */     public Theme.LabelSpec labelBottom = new Theme.LabelSpec();
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @Since(2.0D)
/*     */     public boolean labelBottomInside = false;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @Since(1.0D)
/* 554 */     public Theme.LabelSpec compassLabel = new Theme.LabelSpec();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @Since(1.0D)
/* 561 */     public Theme.ImageSpec compassPoint = new Theme.ImageSpec();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @Since(1.0D)
/*     */     public int compassPointLabelPad;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @Since(1.0D)
/*     */     public double compassPointOffset;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @Since(1.0D)
/*     */     public boolean compassShowNorth = true;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @Since(1.0D)
/*     */     public boolean compassShowSouth = true;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @Since(1.0D)
/*     */     public boolean compassShowEast = true;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @Since(1.0D)
/*     */     public boolean compassShowWest = true;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @Since(1.0D)
/*     */     public double waypointOffset;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @Since(2.0D)
/* 615 */     public Theme.ColorSpec reticle = new Theme.ColorSpec();
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @Since(2.0D)
/* 621 */     public Theme.ColorSpec reticleHeading = new Theme.ColorSpec();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @Since(1.0D)
/* 628 */     public double reticleThickness = 2.25D;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @Since(1.0D)
/* 635 */     public double reticleHeadingThickness = 2.5D;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @Since(2.0D)
/* 642 */     public int reticleOffsetOuter = 16;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @Since(2.0D)
/* 649 */     public int reticleOffsetInner = 16;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @Since(2.0D)
/* 655 */     public Theme.ColorSpec frame = new Theme.ColorSpec();
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @Since(1.0D)
/* 661 */     public String prefix = "";
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static class MinimapCircle
/*     */     extends MinimapSpec
/*     */   {
/*     */     @Since(1.0D)
/* 682 */     public Theme.ImageSpec rim256 = new Theme.ImageSpec(256, 256);
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @Since(1.0D)
/* 688 */     public Theme.ImageSpec mask256 = new Theme.ImageSpec(256, 256);
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @Since(1.0D)
/* 694 */     public Theme.ImageSpec rim512 = new Theme.ImageSpec(512, 512);
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @Since(1.0D)
/* 700 */     public Theme.ImageSpec mask512 = new Theme.ImageSpec(512, 512);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @Since(2.0D)
/*     */     public boolean rotates = false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static class MinimapSquare
/*     */     extends MinimapSpec
/*     */   {
/*     */     @Since(1.0D)
/* 725 */     public Theme.ImageSpec topLeft = new Theme.ImageSpec();
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @Since(1.0D)
/* 731 */     public Theme.ImageSpec top = new Theme.ImageSpec();
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @Since(1.0D)
/* 737 */     public Theme.ImageSpec topRight = new Theme.ImageSpec();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @Since(1.0D)
/* 744 */     public Theme.ImageSpec right = new Theme.ImageSpec();
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @Since(1.0D)
/* 750 */     public Theme.ImageSpec bottomRight = new Theme.ImageSpec();
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @Since(1.0D)
/* 756 */     public Theme.ImageSpec bottom = new Theme.ImageSpec();
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @Since(1.0D)
/* 762 */     public Theme.ImageSpec bottomLeft = new Theme.ImageSpec();
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @Since(1.0D)
/* 768 */     public Theme.ImageSpec left = new Theme.ImageSpec();
/*     */   }
/*     */ }


/* Location:              C:\Users\Administrator\Downloads\journeymap-forge-1.21-6.0.0-beta.18.jar!\journeymap\clien\\ui\theme\Theme$Minimap.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */