/*    */ package journeymap.client.ui.theme.impl;
/*    */ 
/*    */ import journeymap.client.ui.theme.Theme;
/*    */ import net.minecraft.ChatFormatting;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class Style
/*    */ {
/* 17 */   Theme.LabelSpec label = new Theme.LabelSpec();
/* 18 */   Colors button = new Colors();
/* 19 */   Colors toggle = new Colors();
/* 20 */   Colors text = new Colors();
/* 21 */   String minimapTexPrefix = "";
/* 22 */   String buttonTexPrefix = "";
/* 23 */   String tooltipOnStyle = ChatFormatting.AQUA.toString();
/* 24 */   String tooltipOffStyle = ChatFormatting.GRAY.toString();
/* 25 */   String tooltipDisabledStyle = ChatFormatting.DARK_GRAY.toString();
/* 26 */   int iconSize = 24;
/* 27 */   Theme.ColorSpec frameColorSpec = new Theme.ColorSpec();
/* 28 */   Theme.ColorSpec toolbarColorSpec = new Theme.ColorSpec();
/* 29 */   Theme.ColorSpec fullscreenColorSpec = new Theme.ColorSpec();
/* 30 */   int squareFrameThickness = 8;
/* 31 */   int circleFrameThickness = 8;
/* 32 */   int toolbarMargin = 4;
/* 33 */   int toolbarPadding = 0;
/*    */   
/*    */   boolean useThemeImages = true;
/*    */   
/*    */   Style() {
/* 38 */     this.label.margin = 0;
/*    */   }
/*    */   
/*    */   static class Colors {
/*    */     String on;
/*    */     String off;
/*    */     String hover;
/*    */     String disabled;
/*    */   }
/*    */ }


/* Location:              C:\Users\Administrator\Downloads\journeymap-forge-1.21-6.0.0-beta.18.jar!\journeymap\clien\\ui\theme\impl\Style.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */