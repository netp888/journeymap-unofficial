/*     */ package journeymap.client.ui.theme.impl;
/*     */ 
/*     */ import java.util.Arrays;
/*     */ import journeymap.client.ui.theme.Theme;
/*     */ import journeymap.client.ui.theme.ThemePresets;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class FlatTheme
/*     */   extends Theme
/*     */ {
/*     */   public static Theme createPurist() {
/*  20 */     Style style = new Style();
/*  21 */     style.button.on = "#ffffff";
/*  22 */     style.button.off = "#aaaaaa";
/*  23 */     style.button.hover = "#00ffff";
/*  24 */     style.button.disabled = "#aaaaaa";
/*     */     
/*  26 */     style.toggle.on = "#aaaaaa";
/*  27 */     style.toggle.off = "#ffffff";
/*  28 */     style.toggle.hover = "#00ffff";
/*  29 */     style.toggle.disabled = "#aaaaaa";
/*     */     
/*  31 */     style.label.background.alpha = 0.6F;
/*  32 */     style.label.background.color = "#222222";
/*  33 */     style.label.foreground.alpha = 1.0F;
/*  34 */     style.label.foreground.color = "#dddddd";
/*  35 */     style.label.highlight.alpha = 1.0F;
/*  36 */     style.label.highlight.color = "#ffffff";
/*  37 */     style.label.shadow = true;
/*     */     
/*  39 */     style.fullscreenColorSpec.alpha = 0.8F;
/*  40 */     style.fullscreenColorSpec.color = "#222222";
/*     */     
/*  42 */     style.frameColorSpec.color = "#cccccc";
/*  43 */     style.frameColorSpec.alpha = 1.0F;
/*     */     
/*  45 */     style.toolbarColorSpec.color = "#000000";
/*  46 */     style.toolbarColorSpec.alpha = 0.0F;
/*     */     
/*  48 */     style.useThemeImages = false;
/*  49 */     style.minimapTexPrefix = "pur_";
/*  50 */     style.iconSize = 20;
/*  51 */     style.toolbarPadding = 0;
/*  52 */     Theme theme = new FlatTheme("Purist", "techbrew", style);
/*     */     
/*  54 */     theme.minimap.circle.compassPoint.alpha = 1.0F;
/*  55 */     theme.minimap.square.compassPoint.alpha = 0.5F;
/*  56 */     for (Theme.Minimap.MinimapSpec minimapSpec : Arrays.<Theme.Minimap.MinimapSpec>asList(new Theme.Minimap.MinimapSpec[] { (Theme.Minimap.MinimapSpec)theme.minimap.circle, (Theme.Minimap.MinimapSpec)theme.minimap.square })) {
/*     */       
/*  58 */       minimapSpec.margin = 6;
/*  59 */       minimapSpec.reticle.color = "#222222";
/*  60 */       minimapSpec.reticleHeading.color = "#222222";
/*  61 */       minimapSpec.labelTop.foreground.color = "#cccccc";
/*  62 */       minimapSpec.labelTop.background.color = "#555555";
/*  63 */       minimapSpec.labelBottom.foreground.color = "#cccccc";
/*  64 */       minimapSpec.labelBottom.background.color = "#555555";
/*  65 */       minimapSpec.compassLabel.foreground.color = "#ffffff";
/*  66 */       minimapSpec.compassLabel.background.color = "#555555";
/*     */     } 
/*     */     
/*  69 */     return theme;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Theme createDesertTemple() {
/*  77 */     String light = "#FFFFCD";
/*  78 */     String medium = "#aea87e";
/*  79 */     String dark = "#B7521E";
/*  80 */     String darker = "#803915";
/*  81 */     String darkest = "#361809";
/*     */     
/*  83 */     return createFlatTheme("DesertTemple", light, medium, dark, darker, darkest);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Theme createForestMansion() {
/*  91 */     String light = "#d2e7d2";
/*  92 */     String medium = "#7ab97a";
/*  93 */     String dark = "#1b6f1b";
/*  94 */     String darker = "#114511";
/*  95 */     String darkest = "#061b06";
/*     */     
/*  97 */     return createFlatTheme("ForestMansion", light, medium, dark, darker, darkest);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Theme createNetherFortress() {
/* 105 */     String light = "#FFFF00";
/* 106 */     String medium = "#D2D200";
/* 107 */     String dark = "#6f3634";
/* 108 */     String darker = "#760000";
/* 109 */     String darkest = "#3b0000";
/*     */     
/* 111 */     Theme theme = createFlatTheme("NetherFortress", light, medium, dark, darker, darkest);
/* 112 */     return theme;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Theme createStronghold() {
/* 120 */     String light = "#000000";
/* 121 */     String medium = "#cccccc";
/* 122 */     String dark = "#222222";
/* 123 */     String darker = "#111111";
/* 124 */     String darkest = "#0a1d33";
/*     */     
/* 126 */     Theme theme = createFlatTheme("Stronghold", light, medium, dark, darker, darkest);
/* 127 */     theme.container.toolbar.horizontal.inner.alpha = 0.5F;
/* 128 */     theme.container.toolbar.horizontal.inner.color = darker;
/* 129 */     theme.container.toolbar.vertical.inner.alpha = 0.5F;
/* 130 */     theme.container.toolbar.vertical.inner.color = darker;
/*     */     
/* 132 */     theme.control.button.buttonOff.color = medium;
/* 133 */     theme.control.button.buttonDisabled.color = darker;
/* 134 */     theme.control.button.iconDisabled.color = medium;
/*     */     
/* 136 */     theme.control.toggle.buttonOn.color = dark;
/* 137 */     theme.control.toggle.buttonOff.color = dark;
/* 138 */     theme.control.toggle.iconHoverOn.color = medium;
/* 139 */     theme.control.toggle.iconHoverOff.color = medium;
/* 140 */     theme.control.toggle.iconOn.color = medium;
/*     */     
/* 142 */     theme.control.toggle.iconOff.color = "#555555";
/*     */     
/* 144 */     theme.fullscreen.statusLabel.background.color = darker;
/* 145 */     theme.fullscreen.statusLabel.foreground.color = medium;
/*     */     
/* 147 */     String white = "#ffffff";
/* 148 */     String black = "#000000";
/* 149 */     for (Theme.Minimap.MinimapSpec minimapSpec : Arrays.<Theme.Minimap.MinimapSpec>asList(new Theme.Minimap.MinimapSpec[] { (Theme.Minimap.MinimapSpec)theme.minimap.circle, (Theme.Minimap.MinimapSpec)theme.minimap.square })) {
/*     */       
/* 151 */       minimapSpec.labelTop.foreground.color = white;
/* 152 */       minimapSpec.labelTop.background.color = black;
/* 153 */       minimapSpec.labelBottom.foreground.color = white;
/* 154 */       minimapSpec.labelBottom.background.color = black;
/* 155 */       minimapSpec.compassLabel.foreground.color = white;
/* 156 */       minimapSpec.compassLabel.background.color = black;
/*     */     } 
/*     */     
/* 159 */     return theme;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Theme createOceanMonument() {
/* 167 */     String light = "#dfebec";
/* 168 */     String medium = "#afcecf";
/* 169 */     String dark = "#303dc1";
/* 170 */     String darker = "#212a87";
/* 171 */     String darkest = "#0e1239";
/*     */     
/* 173 */     Theme theme = createFlatTheme("OceanMonument", light, medium, dark, darker, darkest);
/* 174 */     theme.control.toggle.iconDisabled.color = "#555555";
/* 175 */     return theme;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Theme EndCity() {
/* 183 */     String light = "#EAEE9A";
/* 184 */     String dark = "#5A5470";
/* 185 */     String medium = "#CEB46A";
/* 186 */     String darker = "#362744";
/* 187 */     String darkest = "#1F1D2D";
/*     */     
/* 189 */     return createFlatTheme("EndCity", light, medium, dark, darker, darkest);
/*     */   }
/*     */ 
/*     */   
/*     */   private static Theme createFlatTheme(String themeName, String light, String medium, String dark, String darker, String darkest) {
/* 194 */     String white = "#ffffff";
/*     */     
/* 196 */     Style style = new Style();
/* 197 */     style.toggle.on = light;
/* 198 */     style.toggle.off = dark;
/* 199 */     style.toggle.hover = medium;
/* 200 */     style.toggle.disabled = darker;
/*     */     
/* 202 */     style.button.on = light;
/* 203 */     style.button.off = dark;
/* 204 */     style.button.hover = medium;
/* 205 */     style.button.disabled = darker;
/*     */     
/* 207 */     style.label.background.alpha = 0.7F;
/* 208 */     style.label.background.color = darkest;
/* 209 */     style.label.foreground.alpha = 1.0F;
/* 210 */     style.label.foreground.color = light;
/* 211 */     style.label.highlight.alpha = 1.0F;
/* 212 */     style.label.highlight.color = white;
/* 213 */     style.label.shadow = true;
/*     */     
/* 215 */     style.fullscreenColorSpec.alpha = 0.8F;
/* 216 */     style.fullscreenColorSpec.color = darker;
/*     */     
/* 218 */     style.frameColorSpec.color = darker;
/* 219 */     style.frameColorSpec.alpha = 1.0F;
/*     */     
/* 221 */     style.toolbarColorSpec.color = darkest;
/* 222 */     style.toolbarColorSpec.alpha = 0.8F;
/*     */     
/* 224 */     style.minimapTexPrefix = "flat_";
/* 225 */     style.buttonTexPrefix = "flat_";
/*     */     
/* 227 */     Theme theme = new FlatTheme(themeName, "techbrew", style);
/*     */     
/* 229 */     theme.minimap.circle.margin = 6;
/* 230 */     theme.minimap.square.margin = 6;
/* 231 */     theme.minimap.circle.reticle.color = dark;
/* 232 */     theme.minimap.circle.reticleHeading.color = dark;
/* 233 */     theme.minimap.square.reticle.color = dark;
/* 234 */     theme.minimap.square.reticleHeading.color = dark;
/*     */     
/* 236 */     return theme;
/*     */   }
/*     */ 
/*     */   
/*     */   protected FlatTheme(String name, String author, Style style) {
/* 241 */     this.name = name;
/* 242 */     this.author = author;
/* 243 */     this.schema = 2;
/* 244 */     this.directory = ThemePresets.DEFAULT_DIRECTORY;
/* 245 */     this.control.button = button(style);
/* 246 */     this.control.toggle = toggle(style);
/* 247 */     this.fullscreen = fullscreen(style);
/* 248 */     this.container.toolbar.horizontal = toolbar(style, "h", 0, style.iconSize);
/* 249 */     this.container.toolbar.vertical = toolbar(style, "v", style.iconSize, 0);
/* 250 */     this.icon.width = style.iconSize;
/* 251 */     this.icon.height = style.iconSize;
/* 252 */     this.minimap.square = minimapSquare(style);
/* 253 */     this.minimap.circle = minimapCircle(style);
/*     */   }
/*     */ 
/*     */   
/*     */   private static Theme.Control.ButtonSpec commonButton(Style style) {
/* 258 */     Theme.Control.ButtonSpec button = new Theme.Control.ButtonSpec();
/* 259 */     button.useThemeImages = style.useThemeImages;
/* 260 */     button.width = style.iconSize;
/* 261 */     button.height = style.iconSize;
/* 262 */     button.prefix = style.buttonTexPrefix;
/* 263 */     button.tooltipOnStyle = style.tooltipOnStyle;
/* 264 */     button.tooltipOffStyle = style.tooltipOffStyle;
/* 265 */     button.tooltipDisabledStyle = style.tooltipDisabledStyle;
/* 266 */     return button;
/*     */   }
/*     */ 
/*     */   
/*     */   private static Theme.Control.ButtonSpec button(Style style) {
/* 271 */     Theme.Control.ButtonSpec button = commonButton(style);
/* 272 */     button.iconOn.color = style.button.off;
/* 273 */     button.buttonOn.color = style.button.on;
/*     */     
/* 275 */     button.iconOff.color = style.button.on;
/* 276 */     button.buttonOff.color = style.button.off;
/*     */     
/* 278 */     button.iconHoverOn.color = style.button.hover;
/* 279 */     button.buttonHoverOn.color = style.button.on;
/*     */     
/* 281 */     button.iconHoverOff.color = style.button.hover;
/* 282 */     button.buttonHoverOff.color = style.button.off;
/*     */     
/* 284 */     button.iconDisabled.color = style.button.disabled;
/* 285 */     button.buttonDisabled.color = style.button.off;
/*     */     
/* 287 */     return button;
/*     */   }
/*     */ 
/*     */   
/*     */   private static Theme.Control.ButtonSpec toggle(Style style) {
/* 292 */     Theme.Control.ButtonSpec button = commonButton(style);
/*     */     
/* 294 */     button.iconOn.color = style.toggle.off;
/* 295 */     button.buttonOn.color = style.toggle.on;
/*     */     
/* 297 */     button.iconOff.color = style.toggle.on;
/* 298 */     button.buttonOff.color = style.toggle.off;
/*     */     
/* 300 */     button.iconHoverOn.color = style.toggle.hover;
/* 301 */     button.buttonHoverOn.color = style.toggle.on;
/*     */     
/* 303 */     button.iconHoverOff.color = style.toggle.hover;
/* 304 */     button.buttonHoverOff.color = style.toggle.off;
/*     */     
/* 306 */     button.iconDisabled.color = style.toggle.disabled;
/* 307 */     button.buttonDisabled.color = style.toggle.disabled;
/*     */     
/* 309 */     return button;
/*     */   }
/*     */ 
/*     */   
/*     */   private static Theme.Fullscreen fullscreen(Style style) {
/* 314 */     Theme.Fullscreen fullscreen = new Theme.Fullscreen();
/* 315 */     fullscreen.background = style.fullscreenColorSpec.clone();
/* 316 */     fullscreen.statusLabel = style.label.clone();
/* 317 */     return fullscreen;
/*     */   }
/*     */ 
/*     */   
/*     */   private static Theme.Container.Toolbar.ToolbarSpec toolbar(Style style, String prefix, int toolbarCapsWidth, int toolbarCapsHeight) {
/* 322 */     Theme.Container.Toolbar.ToolbarSpec toolbar = new Theme.Container.Toolbar.ToolbarSpec();
/* 323 */     toolbar.useThemeImages = true;
/* 324 */     toolbar.prefix = prefix;
/* 325 */     toolbar.margin = style.toolbarMargin;
/* 326 */     toolbar.padding = style.toolbarPadding;
/*     */     
/* 328 */     toolbar.begin = new Theme.ImageSpec(toolbarCapsWidth, toolbarCapsHeight);
/* 329 */     toolbar.begin.alpha = style.toolbarColorSpec.alpha;
/* 330 */     toolbar.begin.color = style.toolbarColorSpec.color;
/*     */     
/* 332 */     toolbar.inner = new Theme.ImageSpec(style.iconSize, style.iconSize);
/* 333 */     toolbar.inner.alpha = style.toolbarColorSpec.alpha;
/* 334 */     toolbar.inner.color = style.toolbarColorSpec.color;
/*     */     
/* 336 */     toolbar.end = new Theme.ImageSpec(toolbarCapsWidth, toolbarCapsHeight);
/* 337 */     toolbar.end.alpha = style.toolbarColorSpec.alpha;
/* 338 */     toolbar.end.color = style.toolbarColorSpec.color;
/* 339 */     return toolbar;
/*     */   }
/*     */ 
/*     */   
/*     */   private static Theme.Minimap.MinimapSquare minimapSquare(Style style) {
/* 344 */     Theme.Minimap.MinimapSquare minimap = new Theme.Minimap.MinimapSquare();
/* 345 */     applyCommonMinimap(style, (Theme.Minimap.MinimapSpec)minimap);
/* 346 */     minimap.margin = 4;
/* 347 */     minimap.compassPointOffset = (-style.squareFrameThickness - 4);
/* 348 */     minimap.reticleOffsetOuter = 24;
/*     */     
/* 350 */     Theme.ImageSpec cornerSpec = new Theme.ImageSpec(style.squareFrameThickness, style.squareFrameThickness);
/* 351 */     Theme.ImageSpec sidesSpec = new Theme.ImageSpec(style.squareFrameThickness, 1);
/* 352 */     Theme.ImageSpec topBottomSpec = new Theme.ImageSpec(1, style.squareFrameThickness);
/* 353 */     minimap.left = minimap.right = sidesSpec;
/* 354 */     minimap.top = minimap.bottom = topBottomSpec;
/* 355 */     minimap.topLeft = minimap.topRight = minimap.bottomRight = minimap.bottomLeft = cornerSpec;
/*     */     
/* 357 */     return minimap;
/*     */   }
/*     */ 
/*     */   
/*     */   private static Theme.Minimap.MinimapCircle minimapCircle(Style style) {
/* 362 */     Theme.Minimap.MinimapCircle minimap = new Theme.Minimap.MinimapCircle();
/* 363 */     applyCommonMinimap(style, (Theme.Minimap.MinimapSpec)minimap);
/* 364 */     minimap.margin = style.circleFrameThickness;
/* 365 */     minimap.compassPointOffset = (-style.circleFrameThickness - 6);
/* 366 */     minimap.reticleHeading.alpha = 0.4F;
/* 367 */     minimap.compassShowEast = true;
/* 368 */     minimap.compassShowNorth = true;
/* 369 */     minimap.compassShowSouth = true;
/* 370 */     minimap.compassShowWest = true;
/* 371 */     minimap.reticleOffsetOuter = 30;
/* 372 */     minimap.rim256 = new Theme.ImageSpec(256, 256);
/* 373 */     minimap.rim512 = new Theme.ImageSpec(512, 512);
/* 374 */     return minimap;
/*     */   }
/*     */ 
/*     */   
/*     */   private static void applyCommonMinimap(Style style, Theme.Minimap.MinimapSpec minimap) {
/* 379 */     minimap.compassLabel = style.label.clone();
/* 380 */     minimap.compassLabel.background.alpha = 0.0F;
/*     */     
/* 382 */     minimap.compassPoint.height = 16;
/* 383 */     minimap.compassPoint.width = 16;
/* 384 */     minimap.compassPoint.color = style.frameColorSpec.color;
/* 385 */     minimap.compassPoint.alpha = 0.5F;
/* 386 */     minimap.compassPointLabelPad = 0;
/* 387 */     minimap.compassShowEast = true;
/* 388 */     minimap.compassShowNorth = true;
/* 389 */     minimap.compassShowSouth = true;
/* 390 */     minimap.compassShowWest = true;
/* 391 */     minimap.frame = style.frameColorSpec.clone();
/* 392 */     minimap.labelBottom = style.label.clone();
/*     */     
/* 394 */     minimap.labelBottomInside = false;
/* 395 */     minimap.labelTop = style.label.clone();
/*     */     
/* 397 */     minimap.labelTopInside = false;
/* 398 */     minimap.prefix = style.minimapTexPrefix;
/* 399 */     minimap.reticle.alpha = 0.4F;
/* 400 */     minimap.reticle.color = style.button.on;
/* 401 */     minimap.reticleHeading.alpha = 0.4F;
/* 402 */     minimap.reticleHeading.color = style.button.on;
/* 403 */     minimap.reticleHeadingThickness = 2.25D;
/* 404 */     minimap.reticleOffsetInner = 20;
/* 405 */     minimap.reticleOffsetOuter = 20;
/* 406 */     minimap.reticleThickness = 1.25D;
/* 407 */     minimap.waypointOffset = 0.0D;
/*     */   }
/*     */ }


/* Location:              C:\Users\Administrator\Downloads\journeymap-forge-1.21-6.0.0-beta.18.jar!\journeymap\clien\\ui\theme\impl\FlatTheme.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */