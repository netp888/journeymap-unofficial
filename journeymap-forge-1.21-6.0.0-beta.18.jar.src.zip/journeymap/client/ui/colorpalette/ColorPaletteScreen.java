/*     */ package journeymap.client.ui.colorpalette;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Locale;
/*     */ import java.util.Objects;
/*     */ import journeymap.client.Constants;
/*     */ import journeymap.client.JourneymapClient;
/*     */ import journeymap.client.cartography.color.ColorManager;
/*     */ import journeymap.client.cartography.color.ColorPalette;
/*     */ import journeymap.client.model.BlockMD;
/*     */ import journeymap.client.properties.CoreProperties;
/*     */ import journeymap.client.ui.UIManager;
/*     */ import journeymap.client.ui.component.ScrollListPane;
/*     */ import journeymap.client.ui.component.SearchTextBox;
/*     */ import journeymap.client.ui.component.buttons.Button;
/*     */ import journeymap.client.ui.component.screens.JmUI;
/*     */ import net.minecraft.client.gui.ComponentPath;
/*     */ import net.minecraft.client.gui.GuiGraphics;
/*     */ import net.minecraft.client.gui.components.Button;
/*     */ import net.minecraft.client.gui.components.Renderable;
/*     */ import net.minecraft.client.gui.components.events.GuiEventListener;
/*     */ import net.minecraft.client.gui.layouts.LayoutElement;
/*     */ import net.minecraft.client.gui.layouts.LinearLayout;
/*     */ import net.minecraft.client.gui.screens.Screen;
/*     */ import net.minecraft.network.chat.Component;
/*     */ import net.minecraft.network.chat.FormattedText;
/*     */ import net.minecraft.resources.ResourceLocation;
/*     */ 
/*     */ public class ColorPaletteScreen extends JmUI {
/*  29 */   private final Component labelClose = (Component)Component.translatable("jm.common.close");
/*  30 */   private final Component labelManagePalettes = (Component)Component.translatable("jm.colorpalette.manage_palettes");
/*  31 */   private final Component labelModsAndPlayers = (Component)Component.translatable("jm.colorpalette.mobs_and_players");
/*     */   
/*     */   static final String ASCEND = "▲";
/*     */   static final String DESCEND = "▼";
/*     */   private static ColorPaletteItem.Sort currentSort;
/*  36 */   private static String searchString = "";
/*     */   
/*     */   protected ScrollListPane itemScrollPane;
/*  39 */   protected int rowHeight = 36; private SortButton buttonSortName;
/*     */   private SortButton buttonSortId;
/*     */   private DomainDropDownButton buttonDomains;
/*     */   private PaletteDropDownButton buttonPalettes;
/*     */   private SearchTextBox searchText;
/*  44 */   private ArrayList<ColorPaletteItem> items = new ArrayList<>();
/*     */   
/*     */   private boolean remapNeeded = false;
/*     */   
/*     */   public ColorPaletteScreen(Screen returnDisplay) {
/*  49 */     super(Constants.getString("jm.colorpalette.manage_colors_title"), true, returnDisplay);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void init() {
/*  55 */     super.init();
/*     */     
/*  57 */     LinearLayout leftHeaderButtons = LinearLayout.horizontal();
/*  58 */     leftHeaderButtons.spacing(4).defaultCellSetting();
/*  59 */     this.buttonDomains = (DomainDropDownButton)leftHeaderButtons.addChild((LayoutElement)new DomainDropDownButton(ColorManager.INSTANCE.getDefaultPalette(), b -> updateItems()));
/*  60 */     boolean hasGlobal = !ColorManager.INSTANCE.getGlobalPalette().isEmpty();
/*  61 */     boolean hasWorld = !ColorManager.INSTANCE.getWorldPalette().isEmpty();
/*  62 */     this.buttonPalettes = (PaletteDropDownButton)leftHeaderButtons.addChild((LayoutElement)new PaletteDropDownButton(hasGlobal, hasWorld, b -> updateItems()));
/*  63 */     this.buttonPalettes.setVisible((hasGlobal || hasWorld));
/*  64 */     this.topLeftHeader.addChild((LayoutElement)leftHeaderButtons);
/*     */     
/*  66 */     LinearLayout bottomHeaderButtons = LinearLayout.horizontal();
/*  67 */     bottomHeaderButtons.spacing(4).defaultCellSetting();
/*  68 */     ColorPaletteItem.Sort nameSort = new ColorPaletteItem.NameComparator(true);
/*  69 */     this.buttonSortName = (SortButton)bottomHeaderButtons.addChild((LayoutElement)new SortButton(Constants.getString("jm.colorpalette.name"), nameSort, this::sortButtonPressed));
/*  70 */     this.buttonSortName.setTextOnly(getFontRenderer());
/*  71 */     this.buttonSortName.drawUnderline(true);
/*  72 */     ColorPaletteItem.Sort idSort = new ColorPaletteItem.IdComparator(true);
/*  73 */     this.buttonSortId = (SortButton)bottomHeaderButtons.addChild((LayoutElement)new SortButton(Constants.getString("jm.colorpalette.id"), idSort, this::sortButtonPressed));
/*  74 */     this.buttonSortId.setTextOnly(getFontRenderer());
/*  75 */     this.buttonSortId.drawUnderline(true);
/*  76 */     this.bottomHeader.addChild((LayoutElement)bottomHeaderButtons);
/*     */     
/*  78 */     this; this.searchText = (SearchTextBox)this.topRightHeader.addChild((LayoutElement)new SearchTextBox(searchString, this.font, 100, 20, false, false));
/*  79 */     this.searchText.setResponder(t -> updateItems());
/*  80 */     this.searchText.setMinLength(0);
/*     */     
/*  82 */     this.footerLayout.addChild((LayoutElement)Button.builder(this.labelModsAndPlayers, b -> UIManager.INSTANCE.openMobsAndPlayersColorEditor((Screen)this)).width(this.font.width((FormattedText)this.labelModsAndPlayers) + 10).build());
/*  83 */     this.footerLayout.addChild((LayoutElement)Button.builder(this.labelManagePalettes, b -> UIManager.INSTANCE.openColorPaletteManager(this)).width(this.font.width((FormattedText)this.labelManagePalettes) + 10).build());
/*  84 */     this.footerLayout.addChild((LayoutElement)Button.builder(this.labelClose, b -> refreshAndClose()).width(this.font.width((FormattedText)this.labelClose) + 10).build());
/*     */     
/*  86 */     Objects.requireNonNull(this); Objects.requireNonNull(this); Objects.requireNonNull(this); this.itemScrollPane = (ScrollListPane)this.contentLayout.addChild((LayoutElement)new ScrollListPane(this.minecraft, 0, 36, this.width, this.height - 36 - 30, this.rowHeight));
/*     */     
/*  88 */     SortButton sortButton = getInitialSort();
/*  89 */     currentSort = sortButton.sort;
/*  90 */     updateSort(sortButton);
/*     */     
/*  92 */     repositionElements();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected void repositionElements() {
/*  98 */     updateItems();
/*  99 */     Objects.requireNonNull(this); Objects.requireNonNull(this); Objects.requireNonNull(this); this.itemScrollPane.updateSize(this.width, this.height - 36 - 30, 0, 36);
/* 100 */     this.itemScrollPane.setListWidth(panelWidth());
/* 101 */     this.itemScrollPane.setScrollAmount(this.itemScrollPane.getScrollAmount());
/* 102 */     super.repositionElements();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void render(GuiGraphics graphics, int x, int y, float partialTicks) {
/* 108 */     this.buttonSortName.setEnabled(!this.items.isEmpty());
/* 109 */     this.buttonSortId.setEnabled(!this.items.isEmpty());
/*     */     
/* 111 */     super.render(graphics, x, y, partialTicks);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void renderBackground(GuiGraphics graphics, int x, int y, float partialTicks) {}
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean mouseClicked(double mouseX, double mouseY, int mouseButton) {
/* 123 */     if (this.searchText.mouseOver(mouseX, mouseY)) {
/*     */       
/* 125 */       this.searchText.mouseClicked(mouseX, mouseY, mouseButton);
/* 126 */       setFocused((GuiEventListener)this.searchText);
/* 127 */       return true;
/*     */     } 
/*     */     
/* 130 */     return super.mouseClicked(mouseX, mouseY, mouseButton);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean charTyped(char typedChar, int keyCode) {
/* 136 */     if (this.searchText.isHoveredOrFocused())
/*     */     {
/* 138 */       return this.searchText.charTyped(typedChar, keyCode);
/*     */     }
/* 140 */     return super.charTyped(typedChar, keyCode);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void changeFocus(ComponentPath path) {
/* 146 */     super.changeFocus(path);
/*     */   }
/*     */ 
/*     */   
/*     */   public void copyBlock(String blockID, boolean globalToWorld) {
/* 151 */     ColorPalette worldPalette = ColorManager.INSTANCE.getWorldPalette();
/* 152 */     ColorPalette globalPalette = ColorManager.INSTANCE.getGlobalPalette();
/*     */     
/* 154 */     if (globalToWorld) {
/*     */       
/* 156 */       worldPalette.copyFromPalette(globalPalette, blockID);
/*     */     }
/*     */     else {
/*     */       
/* 160 */       globalPalette.copyFromPalette(worldPalette, blockID);
/*     */     } 
/* 162 */     ColorPaletteItem selected = (ColorPaletteItem)this.itemScrollPane.getSelected();
/* 163 */     updateItems();
/* 164 */     if (selected != null)
/*     */     {
/* 166 */       selectItem(selected.blockID, selected.palette);
/*     */     }
/*     */     
/* 169 */     setRemapNeeded();
/*     */   }
/*     */ 
/*     */   
/*     */   public void removeFromPalette(String blockID, ColorPalette.Type type) {
/* 174 */     ColorPalette palette = (type == ColorPalette.Type.Global) ? ColorManager.INSTANCE.getGlobalPalette() : ColorManager.INSTANCE.getWorldPalette();
/* 175 */     palette.remove(blockID);
/* 176 */     updateItems();
/* 177 */     selectItem(blockID, ColorManager.INSTANCE.getDefaultPalette());
/* 178 */     setRemapNeeded();
/*     */   }
/*     */ 
/*     */   
/*     */   public void setRemapNeeded() {
/* 183 */     this.remapNeeded = true;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected void selectItem(String blockID, ColorPalette palette) {
/* 189 */     if (this.items.isEmpty()) {
/*     */       return;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 196 */     int index = IntStream.range(0, this.items.size()).filter(i -> (blockID.equals(((ColorPaletteItem)this.items.get(i)).blockID) && palette == ((ColorPaletteItem)this.items.get(i)).palette)).findFirst().orElse(0);
/*     */     
/* 198 */     ColorPaletteItem toSelect = (ColorPaletteItem)this.itemScrollPane.getSlot(index);
/* 199 */     this.itemScrollPane.setFocused((GuiEventListener)toSelect);
/* 200 */     toSelect.focusEditButton();
/*     */   }
/*     */ 
/*     */   
/*     */   protected void updateItems() {
/* 205 */     if (this.searchText == null) {
/*     */       return;
/*     */     }
/*     */ 
/*     */     
/* 210 */     boolean hasGlobal = !ColorManager.INSTANCE.getGlobalPalette().isEmpty();
/* 211 */     boolean hasWorld = !ColorManager.INSTANCE.getWorldPalette().isEmpty();
/* 212 */     this.buttonPalettes.setValidPalettes(hasGlobal, hasWorld);
/* 213 */     this.buttonPalettes.setVisible((hasGlobal || hasWorld));
/*     */     
/* 215 */     this.items.clear();
/* 216 */     String domain = DomainDropDownButton.currentDomain;
/* 217 */     searchString = this.searchText.getText();
/*     */     
/* 219 */     boolean all = PaletteDropDownButton.currentPalette.equals("all");
/* 220 */     ColorPalette defaultPalette = ColorManager.INSTANCE.getDefaultPalette();
/*     */     
/* 222 */     if (all)
/*     */     {
/* 224 */       for (String blockID : defaultPalette.getAllBlocks()) {
/*     */         
/* 226 */         if (filterDomain(domain, blockID) && filterSearch(searchString, blockID)) {
/*     */           
/* 228 */           ColorPaletteItem item = new ColorPaletteItem(defaultPalette, blockID, false, getFontRenderer(), this);
/* 229 */           this.items.add(item);
/*     */         } 
/*     */       } 
/*     */     }
/*     */     
/* 234 */     boolean global = PaletteDropDownButton.currentPalette.equals("global");
/* 235 */     boolean world = PaletteDropDownButton.currentPalette.equals("world");
/*     */     
/* 237 */     if (all || global) {
/*     */       
/* 239 */       ColorPalette globalPalette = ColorManager.INSTANCE.getGlobalPalette();
/* 240 */       for (String blockID : globalPalette.getAllBlocks()) {
/*     */         
/* 242 */         if (filterDomain(domain, blockID) && filterSearch(searchString, blockID) && defaultPalette.hasBlockID(blockID)) {
/*     */           
/* 244 */           ColorPaletteItem item = new ColorPaletteItem(globalPalette, blockID, all, getFontRenderer(), this);
/* 245 */           this.items.add(item);
/*     */         } 
/*     */       } 
/*     */     } 
/*     */     
/* 250 */     if (all || world) {
/*     */       
/* 252 */       ColorPalette worldPalette = ColorManager.INSTANCE.getWorldPalette();
/* 253 */       for (String blockID : worldPalette.getAllBlocks()) {
/*     */         
/* 255 */         if (filterDomain(domain, blockID) && filterSearch(searchString, blockID) && defaultPalette.hasBlockID(blockID)) {
/*     */           
/* 257 */           ColorPaletteItem item = new ColorPaletteItem(worldPalette, blockID, all, getFontRenderer(), this);
/* 258 */           this.items.add(item);
/*     */         } 
/*     */       } 
/*     */     } 
/*     */     
/* 263 */     this.items.sort(currentSort);
/* 264 */     this.itemScrollPane.setSlots(this.items);
/* 265 */     this.itemScrollPane.setScrollAmount(this.itemScrollPane.getScrollAmount());
/*     */   }
/*     */ 
/*     */   
/*     */   private int panelWidth() {
/* 270 */     return (int)Math.min(this.width, 960.0D * calculateScaleFactor());
/*     */   }
/*     */ 
/*     */   
/*     */   private boolean filterDomain(String domain, String blockID) {
/* 275 */     return (domain == null || domain.isEmpty() || ResourceLocation.parse(blockID).getNamespace().equals(domain));
/*     */   }
/*     */ 
/*     */   
/*     */   private boolean filterSearch(String search, String blockID) {
/* 280 */     if (search == null || search.isEmpty())
/*     */     {
/* 282 */       return true;
/*     */     }
/*     */     
/* 285 */     search = search.toLowerCase(Locale.ROOT);
/* 286 */     String blockName = BlockMD.getBlockName((Block)BuiltInRegistries.BLOCK.get(ResourceLocation.parse(blockID))).toLowerCase(Locale.ROOT);
/* 287 */     return (blockID.toLowerCase(Locale.ROOT).contains(search) || blockName.contains(search));
/*     */   }
/*     */ 
/*     */   
/*     */   private void sortButtonPressed(Button button) {
/* 292 */     SortButton sortButton = (SortButton)button;
/* 293 */     sortButton.toggle();
/* 294 */     if (!sortButton.sort.equals(currentSort) && sortButton.sort.ascending != currentSort.ascending)
/*     */     {
/* 296 */       sortButton.toggle();
/*     */     }
/* 298 */     updateSort(sortButton);
/* 299 */     this.items.sort(currentSort);
/* 300 */     this.itemScrollPane.setSlots(this.items);
/*     */   }
/*     */ 
/*     */   
/*     */   private void updateSort(SortButton sortButton) {
/* 305 */     for (Renderable button : getRenderables()) {
/*     */       
/* 307 */       if (button instanceof SortButton) {
/*     */ 
/*     */         
/* 310 */         if (button == sortButton) {
/*     */           
/* 312 */           if (!sortButton.sort.equals(currentSort))
/*     */           {
/* 314 */             sortButton.setActive(true);
/*     */           }
/* 316 */           updateSortProperty(sortButton);
/* 317 */           currentSort = sortButton.sort;
/*     */           
/*     */           continue;
/*     */         } 
/* 321 */         ((SortButton)button).setActive(false);
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected void refreshAndClose() {
/* 329 */     closeAndReturn();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected void closeAndReturn() {
/* 335 */     if (this.remapNeeded) {
/*     */       
/* 337 */       ColorManager.INSTANCE.applyColors();
/* 338 */       ColorManager.INSTANCE.savePalettes();
/*     */     } 
/*     */     
/* 341 */     if (returnDisplayStack == null || returnDisplayStack.peek() == null) {
/*     */       
/* 343 */       UIManager.INSTANCE.closeAll();
/*     */     }
/*     */     else {
/*     */       
/* 347 */       UIManager.INSTANCE.open(returnDisplayStack.pop());
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   private SortButton getInitialSort() {
/* 353 */     CoreProperties prop = JourneymapClient.getInstance().getCoreProperties();
/* 354 */     boolean ascending = prop.sortAscending.get().booleanValue();
/* 355 */     switch ((ColorPaletteItem.SortType)prop.initialSortOrder.get()) { default: throw new MatchException(null, null);
/*     */       case Id: 
/*     */       case Name:
/* 358 */         break; }  SortButton button = this.buttonSortName;
/*     */     
/* 360 */     button.sort.ascending = ascending;
/* 361 */     button.setToggled(Boolean.valueOf(ascending));
/* 362 */     return button;
/*     */   }
/*     */ 
/*     */   
/*     */   private void updateSortProperty(SortButton sortButton) {
/* 367 */     CoreProperties prop = JourneymapClient.getInstance().getCoreProperties();
/* 368 */     if (sortButton == this.buttonSortName) {
/*     */       
/* 370 */       prop.initialSortOrder.set(ColorPaletteItem.SortType.Name);
/*     */     }
/*     */     else {
/*     */       
/* 374 */       prop.initialSortOrder.set(ColorPaletteItem.SortType.Id);
/*     */     } 
/* 376 */     prop.sortAscending.set(Boolean.valueOf(sortButton.sort.ascending));
/*     */   }
/*     */ }


/* Location:              C:\Users\Administrator\Downloads\journeymap-forge-1.21-6.0.0-beta.18.jar!\journeymap\clien\\ui\colorpalette\ColorPaletteScreen.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */