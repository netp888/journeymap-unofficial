/*    */ package journeymap.client.ui.colorpalette;
/*    */ 
/*    */ import com.google.common.collect.Lists;
/*    */ import com.google.common.collect.Maps;
/*    */ import java.util.List;
/*    */ import java.util.Map;
/*    */ import journeymap.api.services.Services;
/*    */ import journeymap.client.Constants;
/*    */ import journeymap.client.cartography.color.ColorPalette;
/*    */ import journeymap.client.ui.component.DropDownItem;
/*    */ import journeymap.client.ui.component.SelectableParent;
/*    */ import journeymap.client.ui.component.buttons.DropDownButton;
/*    */ import net.minecraft.client.gui.components.Button;
/*    */ import net.minecraft.resources.ResourceLocation;
/*    */ import net.minecraft.util.SortedArraySet;
/*    */ 
/*    */ public class DomainDropDownButton extends DropDownButton {
/*    */   static String currentDomain;
/* 19 */   private final Map<String, DropDownItem> itemMap = Maps.newHashMap();
/*    */   
/*    */   private final DropDownItem all;
/*    */   
/*    */   public DomainDropDownButton(ColorPalette colorPalette, Button.OnPress onPress) {
/* 24 */     super("", onPress);
/* 25 */     this.all = new DropDownItem((SelectableParent)this, null, Constants.getString("jm.colorpalette.domain", new Object[] { Constants.getString("jm.colorpalette.domain_all") }), new String[] { "" });
/* 26 */     setItems(createListItems(colorPalette));
/* 27 */     setSelected(currentDomain);
/*    */     
/* 29 */     if (this.items.size() <= 2)
/*    */     {
/* 31 */       setVisible(false);
/*    */     }
/*    */   }
/*    */ 
/*    */   
/*    */   private List<DropDownItem> createListItems(ColorPalette colorPalette) {
/* 37 */     SortedArraySet<String> domains = SortedArraySet.create();
/* 38 */     for (String blockID : colorPalette.getAllBlocks()) {
/*    */       
/* 40 */       String namespace = ResourceLocation.parse(blockID).getNamespace();
/* 41 */       if (!namespace.equals("minecraft"))
/*    */       {
/* 43 */         domains.add(namespace);
/*    */       }
/*    */     } 
/*    */     
/* 47 */     List<DropDownItem> list = Lists.newArrayList();
/* 48 */     list.add(this.all);
/* 49 */     list.add(new DropDownItem((SelectableParent)this, "minecraft", "Minecraft", new String[] { "" }));
/* 50 */     for (String domain : domains)
/*    */     {
/* 52 */       list.add(dropDown(domain));
/*    */     }
/* 54 */     return list;
/*    */   }
/*    */ 
/*    */   
/*    */   private DropDownItem dropDown(String domain) {
/* 59 */     String name = Services.COMMON_SERVICE.getModName(domain);
/* 60 */     if (name.isEmpty())
/*    */     {
/* 62 */       name = domain;
/*    */     }
/* 64 */     String tooltip = domain.equals(name) ? "" : domain;
/* 65 */     DropDownItem dropDownItem = new DropDownItem((SelectableParent)this, domain, name, new String[] { tooltip });
/* 66 */     this.itemMap.put(domain, dropDownItem);
/* 67 */     return dropDownItem;
/*    */   }
/*    */ 
/*    */   
/*    */   private void setSelected(String modId) {
/* 72 */     DropDownItem selected = (modId == null) ? this.all : this.itemMap.get(modId);
/* 73 */     currentDomain = (selected != null) ? modId : null;
/* 74 */     setSelected(selected);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public void setSelected(DropDownItem selectedButton) {
/* 80 */     this.selected = selectedButton;
/* 81 */     if (this.selected == null && currentDomain == null) {
/*    */       
/* 83 */       super.setSelected(this.all);
/*    */       
/*    */       return;
/*    */     } 
/* 87 */     currentDomain = (this.selected != null) ? (String)this.selected.getId() : null;
/* 88 */     super.setSelected(this.selected);
/*    */   }
/*    */ }


/* Location:              C:\Users\Administrator\Downloads\journeymap-forge-1.21-6.0.0-beta.18.jar!\journeymap\clien\\ui\colorpalette\DomainDropDownButton.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */