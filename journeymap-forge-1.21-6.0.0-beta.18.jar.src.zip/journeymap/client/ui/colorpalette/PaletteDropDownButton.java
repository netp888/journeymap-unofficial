/*    */ package journeymap.client.ui.colorpalette;
/*    */ 
/*    */ import com.google.common.collect.Lists;
/*    */ import java.util.List;
/*    */ import journeymap.client.Constants;
/*    */ import journeymap.client.ui.component.DropDownItem;
/*    */ import journeymap.client.ui.component.SelectableParent;
/*    */ import journeymap.client.ui.component.buttons.DropDownButton;
/*    */ import net.minecraft.client.gui.components.Button;
/*    */ import net.minecraft.network.chat.Component;
/*    */ 
/*    */ public class PaletteDropDownButton extends DropDownButton {
/* 13 */   static String currentPalette = "all";
/*    */   
/*    */   private final DropDownItem all;
/*    */   
/*    */   public PaletteDropDownButton(boolean global, boolean world, Button.OnPress onPress) {
/* 18 */     super("", onPress);
/* 19 */     this.all = new DropDownItem((SelectableParent)this, "all", Constants.getString("jm.colorpalette.palette", new Object[] { Constants.getString("jm.colorpalette.palette_all") }), new String[] { "" });
/* 20 */     setItems(createListItems(global, world));
/* 21 */     setSelected(currentPalette);
/*    */   }
/*    */ 
/*    */   
/*    */   private List<DropDownItem> createListItems(boolean global, boolean world) {
/* 26 */     List<DropDownItem> list = Lists.newArrayList();
/* 27 */     list.add(this.all);
/* 28 */     if (global)
/*    */     {
/* 30 */       list.add(new DropDownItem((SelectableParent)this, "global", Constants.getString("jm.colorpalette.global"), new String[] { "" }));
/*    */     }
/* 32 */     if (world)
/*    */     {
/* 34 */       list.add(new DropDownItem((SelectableParent)this, "world", Constants.getString("jm.colorpalette.world"), new String[] { "" }));
/*    */     }
/* 36 */     return list;
/*    */   }
/*    */ 
/*    */   
/*    */   private void setSelected(String palette) {
/* 41 */     this.selected = null;
/*    */     
/* 43 */     for (DropDownItem item : this.items) {
/*    */       
/* 45 */       if (palette.equals(item.getId())) {
/*    */         
/* 47 */         this.selected = item;
/*    */         break;
/*    */       } 
/*    */     } 
/* 51 */     if (this.selected == null)
/*    */     {
/* 53 */       this.selected = this.all;
/*    */     }
/*    */     
/* 56 */     setMessage((Component)Component.literal(this.selected.getLabel()));
/* 57 */     currentPalette = (String)this.selected.getId();
/*    */   }
/*    */ 
/*    */   
/*    */   public void setValidPalettes(boolean global, boolean world) {
/* 62 */     this.items.clear();
/* 63 */     setItems(createListItems(global, world));
/* 64 */     setSelected(currentPalette);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public void setSelected(DropDownItem selectedButton) {
/* 70 */     currentPalette = (String)selectedButton.getId();
/* 71 */     super.setSelected(selectedButton);
/*    */   }
/*    */ }


/* Location:              C:\Users\Administrator\Downloads\journeymap-forge-1.21-6.0.0-beta.18.jar!\journeymap\clien\\ui\colorpalette\PaletteDropDownButton.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */