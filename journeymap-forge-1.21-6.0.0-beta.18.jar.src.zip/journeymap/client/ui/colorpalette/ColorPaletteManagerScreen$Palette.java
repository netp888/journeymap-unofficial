/*     */ package journeymap.client.ui.colorpalette;
/*     */ 
/*     */ import java.util.function.Supplier;
/*     */ import journeymap.client.Constants;
/*     */ import journeymap.client.cartography.color.ColorPalette;
/*     */ import journeymap.client.ui.component.popupscreenbutton.PopupButton;
/*     */ import journeymap.client.ui.component.popupscreenbutton.PopupButtonScreen;
/*     */ import journeymap.client.ui.component.popupscreenbutton.simple.ConfirmationPopup;
/*     */ import net.minecraft.ChatFormatting;
/*     */ import net.minecraft.client.gui.Font;
/*     */ import net.minecraft.client.gui.components.StringWidget;
/*     */ import net.minecraft.client.gui.layouts.LayoutElement;
/*     */ import net.minecraft.client.gui.layouts.LinearLayout;
/*     */ import net.minecraft.client.gui.layouts.SpacerElement;
/*     */ import net.minecraft.network.chat.Component;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class Palette
/*     */   extends LinearLayout
/*     */ {
/* 126 */   private final Component labelGlobal = (Component)Component.translatable("jm.colorpalette.global").withStyle(ChatFormatting.BOLD);
/* 127 */   private final Component labelWorld = (Component)Component.translatable("jm.colorpalette.world").withStyle(ChatFormatting.BOLD);
/* 128 */   private final Component labelBlocks = (Component)Component.translatable("jm.colorpalette.blocks");
/* 129 */   private final Component labelStates = (Component)Component.translatable("jm.colorpalette.states");
/* 130 */   private final String deleteLabel = Constants.getString("jm.colorpalette.delete_all");
/* 131 */   private final String labelCopyToRight = "  " + Constants.getString("jm.colorpalette.copy") + " >";
/* 132 */   private final String labelCopyToLeft = "< " + Constants.getString("jm.colorpalette.copy") + "  ";
/*     */   
/*     */   private final ColorPalette colorPalette;
/*     */   
/*     */   private final ColorPaletteManagerScreen screen;
/*     */   
/*     */   public Palette(ColorPalette colorPalette, Font font, ColorPaletteManagerScreen screen) {
/* 139 */     super(0, 0, LinearLayout.Orientation.VERTICAL);
/* 140 */     this.colorPalette = colorPalette;
/* 141 */     this.screen = screen;
/*     */     
/* 143 */     spacing(4).defaultCellSetting().alignHorizontallyCenter();
/* 144 */     addChild((LayoutElement)new SpacerElement(100, 0));
/* 145 */     addChild((LayoutElement)new StringWidget((colorPalette.getType() == ColorPalette.Type.Global) ? this.labelGlobal : this.labelWorld, font));
/* 146 */     addChild((LayoutElement)new SpacerElement(0, 0));
/* 147 */     addChild((LayoutElement)new StringWidget((Component)this.labelBlocks.copy().append(String.valueOf(colorPalette.blockCount())), font));
/* 148 */     addChild((LayoutElement)new StringWidget((Component)this.labelStates.copy().append(String.valueOf(colorPalette.stateCount())), font));
/*     */     
/* 150 */     if (colorPalette.isEmpty()) {
/*     */       
/* 152 */       addChild((LayoutElement)new SpacerElement(0, 44));
/*     */     }
/*     */     else {
/*     */       
/* 156 */       String labelCopy = (colorPalette.getType() == ColorPalette.Type.Global) ? this.labelCopyToRight : this.labelCopyToLeft;
/* 157 */       addChild((LayoutElement)new PopupButton(font
/* 158 */             .width(labelCopy) + 10, 0, labelCopy, CopyPalettePopup::new, this::copyPalette));
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 164 */       addChild((LayoutElement)new PopupButton(font
/* 165 */             .width(this.deleteLabel) + 10, 0, this.deleteLabel, () -> new ConfirmationPopup("jm.colorpalette.delete_all_dialog", "jm.colorpalette.delete_all", "jm.colorpalette.cancel"), this::deletePalette));
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 175 */     addChild((LayoutElement)new SpacerElement(0, 0));
/*     */   }
/*     */ 
/*     */   
/*     */   public void copyPalette(CopyPalettePopup.Mode mode) {
/* 180 */     if (mode != null)
/*     */     {
/* 182 */       this.screen.copyPalette(mode, (this.colorPalette.getType() == ColorPalette.Type.Global));
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public void deletePalette(boolean delete) {
/* 188 */     if (delete)
/*     */     {
/* 190 */       this.screen.deleteAll(this.colorPalette.getType());
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\Administrator\Downloads\journeymap-forge-1.21-6.0.0-beta.18.jar!\journeymap\clien\\ui\colorpalette\ColorPaletteManagerScreen$Palette.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */