/*     */ package journeymap.client.ui.colorpalette;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.List;
/*     */ import java.util.Objects;
/*     */ import javax.annotation.Nullable;
/*     */ import journeymap.client.Constants;
/*     */ import journeymap.client.JourneymapClient;
/*     */ import journeymap.client.cartography.color.RGB;
/*     */ import journeymap.client.render.draw.DrawUtil;
/*     */ import journeymap.client.texture.Texture;
/*     */ import journeymap.client.texture.TextureCache;
/*     */ import journeymap.client.ui.component.Slot;
/*     */ import journeymap.client.ui.component.buttons.Button;
/*     */ import journeymap.client.ui.component.popupscreenbutton.colorpicker.ColorPickerButton;
/*     */ import journeymap.client.ui.component.popupscreenbutton.colorpicker.ColorPickerScreen;
/*     */ import journeymap.client.ui.option.SlotMetadata;
/*     */ import journeymap.common.Journeymap;
/*     */ import journeymap.common.properties.config.StringField;
/*     */ import net.minecraft.Util;
/*     */ import net.minecraft.client.gui.ComponentPath;
/*     */ import net.minecraft.client.gui.Font;
/*     */ import net.minecraft.client.gui.GuiGraphics;
/*     */ import net.minecraft.client.gui.components.Button;
/*     */ import net.minecraft.client.gui.components.events.ContainerEventHandler;
/*     */ import net.minecraft.client.gui.components.events.GuiEventListener;
/*     */ import net.minecraft.resources.ResourceLocation;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class DotLabelColorItem
/*     */   extends Slot
/*     */ {
/*     */   private final Font fontRenderer;
/*     */   private final String name;
/*     */   private final StringField property;
/* 216 */   private Texture textureBG = null;
/* 217 */   private Texture texture = null;
/* 218 */   private String label = null;
/*     */   private int color;
/*     */   private final int originalColor;
/*     */   private final MobsAndPlayersColorEditor editor;
/*     */   private final Button buttonDefault;
/*     */   private final Button buttonUndo;
/*     */   private final ColorPickerButton buttonColorPicker;
/* 225 */   private final List<GuiEventListener> children = new ArrayList<>();
/* 226 */   private long lastClick = 0L;
/*     */ 
/*     */   
/*     */   DotLabelColorItem(Font fontRenderer, String nameKey, StringField property, String label, MobsAndPlayersColorEditor editor) {
/* 230 */     this(fontRenderer, nameKey, property, null, null, label, editor);
/*     */   }
/*     */ 
/*     */   
/*     */   DotLabelColorItem(Font fontRenderer, String nameKey, StringField property, @Nullable ResourceLocation textureBG, ResourceLocation texture, MobsAndPlayersColorEditor editor) {
/* 235 */     this(fontRenderer, nameKey, property, textureBG, texture, null, editor);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   DotLabelColorItem(Font fontRenderer, String nameKey, StringField property, @Nullable ResourceLocation textureBG, @Nullable ResourceLocation texture, @Nullable String labelKey, MobsAndPlayersColorEditor editor) {
/* 241 */     this.fontRenderer = fontRenderer;
/* 242 */     this.name = Constants.getString(nameKey);
/* 243 */     this.property = property;
/* 244 */     if (textureBG != null)
/*     */     {
/* 246 */       this.textureBG = TextureCache.getTexture(textureBG);
/*     */     }
/* 248 */     if (texture != null)
/*     */     {
/* 250 */       this.texture = TextureCache.getTexture(texture);
/*     */     }
/* 252 */     if (labelKey != null)
/*     */     {
/* 254 */       this.label = Constants.getString(labelKey);
/*     */     }
/* 256 */     this.originalColor = JourneymapClient.getInstance().getCoreProperties().getColor(property);
/* 257 */     this.color = this.originalColor;
/* 258 */     this.editor = editor;
/* 259 */     this.buttonDefault = new Button(Constants.getString("jm.colorpalette.default"), b -> resetColorToDefault());
/* 260 */     this.buttonDefault.fitWidth(fontRenderer);
/* 261 */     this.buttonUndo = new Button(Constants.getString("jm.colorpalette.undo"), b -> undoColor());
/* 262 */     this.buttonUndo.fitWidth(fontRenderer);
/* 263 */     this.buttonColorPicker = new ColorPickerButton(24, 24, () -> this.color, () -> false, this::colorPicked);
/*     */     
/* 265 */     this.children.add(this.buttonColorPicker);
/* 266 */     this.children.add(this.buttonUndo);
/* 267 */     this.children.add(this.buttonDefault);
/*     */   }
/*     */ 
/*     */   
/*     */   private void colorPicked(ColorPickerScreen.ColorPickerResponse response) {
/* 272 */     if (response.canceled()) {
/*     */       return;
/*     */     }
/*     */ 
/*     */     
/* 277 */     this.editor.editColorsOfSelected(response.color());
/*     */   }
/*     */ 
/*     */   
/*     */   public void setColor(int color) {
/* 282 */     this.color = color;
/*     */   }
/*     */ 
/*     */   
/*     */   private void resetColorToDefault() {
/* 287 */     this.color = RGB.hexToInt(this.property.getDefaultValue());
/* 288 */     this.editor.validate();
/*     */   }
/*     */ 
/*     */   
/*     */   private void undoColor() {
/* 293 */     this.color = this.originalColor;
/* 294 */     this.editor.validate();
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isEdited() {
/* 299 */     return (this.color != this.originalColor);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Collection<SlotMetadata> getMetadata() {
/* 305 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean mouseClicked(double mouseX, double mouseY, int mouseEvent) {
/*     */     try {
/* 313 */       if (this.buttonColorPicker.mouseClicked(mouseX, mouseY, mouseEvent)) {
/*     */         
/* 315 */         this.editor.buttonColorPickerPressed(this);
/* 316 */         return false;
/*     */       } 
/* 318 */       if (this.buttonDefault.mouseClicked(mouseX, mouseY, mouseEvent))
/*     */       {
/* 320 */         return true;
/*     */       }
/* 322 */       if (this.buttonUndo.mouseClicked(mouseX, mouseY, mouseEvent))
/*     */       {
/* 324 */         return true;
/*     */       }
/*     */       
/* 327 */       if (mouseEvent == 0) {
/*     */         
/* 329 */         long sysTime = Util.getMillis();
/* 330 */         boolean doubleClick = (sysTime - this.lastClick < 200L);
/* 331 */         this.lastClick = sysTime;
/* 332 */         if (doubleClick) {
/*     */           
/* 334 */           this.buttonColorPicker.onPress();
/* 335 */           this.editor.selectOnly(this);
/* 336 */           return false;
/*     */         } 
/*     */       } 
/*     */       
/* 340 */       MobsAndPlayersColorEditor.access$000(this.editor, ComponentPath.path((ContainerEventHandler)this, ComponentPath.leaf((GuiEventListener)this.buttonColorPicker)));
/*     */       
/* 342 */       return true;
/*     */     }
/* 344 */     catch (Exception e) {
/*     */       
/* 346 */       Journeymap.getLogger().error("WARNING: Problem with mouseClicked.");
/* 347 */       throw new RuntimeException("mouseClicked", e);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public List<? extends Slot> getChildSlots(int listWidth, int columnWidth) {
/* 354 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public SlotMetadata getLastPressed() {
/* 360 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public SlotMetadata getCurrentTooltip() {
/* 366 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setEnabled(boolean enabled) {}
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getColumnWidth() {
/* 378 */     return 0;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean contains(SlotMetadata slotMetadata) {
/* 384 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void render(GuiGraphics graphics, int slotIndex, int y, int x, int rowWidth, int itemHeight, int mouseX, int mouseY, boolean isMouseOver, float partialTicks) {
/* 390 */     DrawUtil.drawRectangle(graphics, x, y, (rowWidth - 4), itemHeight, 3158064, 1.0F);
/*     */     
/* 392 */     int xName = 80;
/* 393 */     if (this.label != null) {
/*     */       
/* 395 */       int xLabel = x + xName / 2;
/* 396 */       int yLabel = y + itemHeight / 2;
/* 397 */       DrawUtil.drawLabel(graphics, this.label, xLabel, yLabel, DrawUtil.HAlign.Center, DrawUtil.VAlign.Middle, Integer.valueOf(0), 1.0F, this.color, 1.0F, 1.0D, false);
/*     */     }
/*     */     else {
/*     */       
/* 401 */       float scale = 0.2F;
/* 402 */       double xTex = (x + (xName - this.texture.getWidth() * scale) / 2.0F);
/* 403 */       double yTex = (y + (itemHeight - this.texture.getHeight() * scale) / 2.0F);
/* 404 */       if (this.textureBG != null)
/*     */       {
/* 406 */         DrawUtil.drawColoredImage(graphics.pose(), this.textureBG, 16777215, 1.0F, xTex, yTex, scale, 225.0D);
/*     */       }
/* 408 */       DrawUtil.drawColoredImage(graphics.pose(), this.texture, this.color, 1.0F, xTex, yTex, scale, 225.0D);
/*     */     } 
/*     */     
/* 411 */     Objects.requireNonNull(this.fontRenderer); graphics.drawString(this.fontRenderer, this.name, x + xName, y + (itemHeight - 9) / 2, -1, true);
/*     */     
/* 413 */     this.buttonDefault.leftOf(x + rowWidth - 32);
/* 414 */     this.buttonDefault.below(y + 3);
/* 415 */     this.buttonDefault.render(graphics, mouseX, mouseY, partialTicks);
/*     */     
/* 417 */     this.buttonUndo.setVisible(isEdited());
/* 418 */     this.buttonUndo.leftOf(x + rowWidth - 34 - this.buttonDefault.getWidth());
/* 419 */     this.buttonUndo.below(y + 3);
/* 420 */     this.buttonUndo.render(graphics, mouseX, mouseY, partialTicks);
/*     */ 
/*     */     
/* 423 */     if (isMouseOver || isFocused()) {
/*     */       
/* 425 */       this.buttonColorPicker.leftOf(x + rowWidth - 5);
/* 426 */       this.buttonColorPicker.below(y + 1);
/* 427 */       this.buttonColorPicker.render(graphics, mouseX, mouseY, partialTicks);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public List<? extends GuiEventListener> children() {
/* 434 */     return this.children;
/*     */   }
/*     */ }


/* Location:              C:\Users\Administrator\Downloads\journeymap-forge-1.21-6.0.0-beta.18.jar!\journeymap\clien\\ui\colorpalette\MobsAndPlayersColorEditor$DotLabelColorItem.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */