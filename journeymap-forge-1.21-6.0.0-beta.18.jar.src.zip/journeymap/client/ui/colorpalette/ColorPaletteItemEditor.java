/*     */ package journeymap.client.ui.colorpalette;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.EnumSet;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Objects;
/*     */ import journeymap.client.Constants;
/*     */ import journeymap.client.cartography.color.BlockStateColor;
/*     */ import journeymap.client.cartography.color.ColorManager;
/*     */ import journeymap.client.cartography.color.ColorPalette;
/*     */ import journeymap.client.cartography.color.RGB;
/*     */ import journeymap.client.model.BlockFlag;
/*     */ import journeymap.client.render.draw.DrawUtil;
/*     */ import journeymap.client.ui.UIManager;
/*     */ import journeymap.client.ui.component.MultiSelectableScrollListPane;
/*     */ import journeymap.client.ui.component.Slot;
/*     */ import journeymap.client.ui.component.buttons.Button;
/*     */ import journeymap.client.ui.component.popupscreenbutton.blockflags.BlockFlagsButton;
/*     */ import journeymap.client.ui.component.popupscreenbutton.blockflags.BlockFlagsScreen;
/*     */ import journeymap.client.ui.component.popupscreenbutton.colorpicker.ColorPickerButton;
/*     */ import journeymap.client.ui.component.popupscreenbutton.colorpicker.ColorPickerScreen;
/*     */ import journeymap.client.ui.component.screens.JmUI;
/*     */ import journeymap.client.ui.option.SlotMetadata;
/*     */ import journeymap.common.Journeymap;
/*     */ import journeymap.common.log.LogFormatter;
/*     */ import net.minecraft.Util;
/*     */ import net.minecraft.client.gui.ComponentPath;
/*     */ import net.minecraft.client.gui.Font;
/*     */ import net.minecraft.client.gui.GuiGraphics;
/*     */ import net.minecraft.client.gui.components.Button;
/*     */ import net.minecraft.client.gui.components.events.ContainerEventHandler;
/*     */ import net.minecraft.client.gui.components.events.GuiEventListener;
/*     */ import net.minecraft.client.gui.layouts.LayoutElement;
/*     */ import net.minecraft.client.gui.layouts.LinearLayout;
/*     */ import net.minecraft.client.gui.screens.Screen;
/*     */ import net.minecraft.network.chat.Component;
/*     */ import net.minecraft.network.chat.FormattedText;
/*     */ 
/*     */ public class ColorPaletteItemEditor extends JmUI {
/*  42 */   private final String labelSelectAll = Constants.getString("jm.colorpalette.select_all");
/*  43 */   private final String labelSelectSameColor = Constants.getString("jm.colorpalette.select_same_color");
/*  44 */   private final String labelSaveToGlobal = Constants.getString("jm.colorpalette.save_to_global");
/*  45 */   private final String labelSaveToWorld = Constants.getString("jm.colorpalette.save_to_world");
/*  46 */   private final Component labelClose = (Component)Component.translatable("jm.common.close");
/*     */   
/*     */   private Button buttonSaveToGlobal;
/*     */   
/*     */   private Button buttonSaveToWorld;
/*     */   
/*     */   private Button buttonSelectAll;
/*     */   
/*     */   private Button buttonSelectSameColor;
/*     */   private final String blockId;
/*     */   private final Map<String, BlockStateColor> originalColors;
/*     */   private MultiSelectableScrollListPane<ColorStateItem> statesScrollPane;
/*     */   private final boolean saveToGlobal;
/*     */   private final boolean saveToWorld;
/*     */   
/*     */   public ColorPaletteItemEditor(String blockID, Map<String, BlockStateColor> blockStatesToColor, boolean saveToGlobal, boolean saveToWorld, Screen returnDisplay) {
/*  62 */     super(Constants.getString("jm.colorpalette.edit_title") + " (" + Constants.getString("jm.colorpalette.edit_title") + ")", true, returnDisplay);
/*  63 */     this.blockId = blockID;
/*  64 */     this.originalColors = blockStatesToColor;
/*  65 */     this.saveToGlobal = saveToGlobal;
/*  66 */     this.saveToWorld = saveToWorld;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void init() {
/*  72 */     super.init();
/*     */     
/*  74 */     boolean isVanilla = this.blockId.startsWith("minecraft:");
/*  75 */     ArrayList<ColorStateItem> statesItemList = new ArrayList<>();
/*  76 */     for (Map.Entry<String, BlockStateColor> state : this.originalColors.entrySet())
/*     */     {
/*  78 */       statesItemList.add(new ColorStateItem(this.font, this.blockId, state.getKey(), state.getValue(), isVanilla, this));
/*     */     }
/*     */     
/*  81 */     Objects.requireNonNull(this); Objects.requireNonNull(this); Objects.requireNonNull(this); this.statesScrollPane = (MultiSelectableScrollListPane<ColorStateItem>)this.contentLayout.addChild((LayoutElement)new MultiSelectableScrollListPane(this.minecraft, 0, 36, this.width, this.height - 36 - 30, 30));
/*     */     
/*  83 */     this.statesScrollPane.setSlots(statesItemList);
/*     */     
/*  85 */     LinearLayout headerButtons = LinearLayout.horizontal();
/*  86 */     headerButtons.spacing(4).defaultCellSetting();
/*  87 */     this.buttonSelectAll = (Button)headerButtons.addChild((LayoutElement)new Button(this.labelSelectAll, b -> this.statesScrollPane.selectAll()));
/*  88 */     this.buttonSelectAll.setTextOnly(getFontRenderer());
/*  89 */     this.buttonSelectAll.drawUnderline(true);
/*  90 */     this.buttonSelectAll.setEnabled((this.statesScrollPane.getRootSlots().size() > 1));
/*  91 */     this.buttonSelectSameColor = (Button)headerButtons.addChild((LayoutElement)new Button(this.labelSelectSameColor, b -> {
/*     */             ColorStateItem selected = (ColorStateItem)this.statesScrollPane.getSelected();
/*     */ 
/*     */             
/*     */             if (selected != null) {
/*     */               for (ColorStateItem item : this.statesScrollPane.getRootSlots()) {
/*     */                 if (item.color == selected.color) {
/*     */                   this.statesScrollPane.setSelectedAndKeepCurrent(item);
/*     */                 }
/*     */               } 
/*     */             }
/*     */           }));
/*     */     
/* 104 */     this.buttonSelectSameColor.setTextOnly(getFontRenderer());
/* 105 */     this.buttonSelectSameColor.drawUnderline(true);
/* 106 */     this.buttonSelectSameColor.setEnabled((this.statesScrollPane.getRootSlots().size() > 1));
/* 107 */     this.bottomHeader.addChild((LayoutElement)headerButtons);
/*     */     
/* 109 */     if (this.saveToGlobal) {
/*     */       
/* 111 */       this.buttonSaveToGlobal = (Button)this.footerLayout.addChild((LayoutElement)new Button(this.labelSaveToGlobal, b -> save(ColorPalette.Type.Global)));
/* 112 */       this.buttonSaveToGlobal.setWidth(this.font.width(this.labelSaveToGlobal) + 10);
/*     */     } 
/* 114 */     if (this.saveToWorld) {
/*     */       
/* 116 */       this.buttonSaveToWorld = (Button)this.footerLayout.addChild((LayoutElement)new Button(this.labelSaveToWorld, b -> save(ColorPalette.Type.World)));
/* 117 */       this.buttonSaveToWorld.setWidth(this.font.width(this.labelSaveToWorld) + 10);
/*     */     } 
/* 119 */     this.footerLayout.addChild((LayoutElement)Button.builder(this.labelClose, b -> refreshAndClose()).width(this.font.width((FormattedText)this.labelClose) + 10).build());
/*     */     
/* 121 */     validate();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected void repositionElements() {
/* 127 */     Objects.requireNonNull(this); Objects.requireNonNull(this); Objects.requireNonNull(this); this.statesScrollPane.updateSize(this.width, this.height - 36 - 30, 0, 36);
/* 128 */     this.statesScrollPane.setListWidth(panelWidth());
/* 129 */     this.statesScrollPane.setScrollAmount(this.statesScrollPane.getScrollAmount());
/* 130 */     super.repositionElements();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void render(GuiGraphics graphics, int x, int y, float partialTicks) {
/*     */     try {
/* 138 */       this.buttonSelectSameColor.setEnabled((this.statesScrollPane.getRootSlots().size() > 1 && this.statesScrollPane.getSelectedCount() == 1));
/* 139 */       super.render(graphics, x, y, partialTicks);
/*     */     }
/* 141 */     catch (Throwable t) {
/*     */       
/* 143 */       Journeymap.getLogger().error("Error during ColorPaletteItemEditor render: {}", LogFormatter.toPartialString(t));
/* 144 */       UIManager.INSTANCE.closeAll();
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   private int panelWidth() {
/* 150 */     return (int)Math.min(this.width, 960.0D * calculateScaleFactor());
/*     */   }
/*     */ 
/*     */   
/*     */   protected boolean validate() {
/* 155 */     boolean valid = false;
/*     */     
/* 157 */     for (ColorStateItem state : this.statesScrollPane.getRootSlots()) {
/*     */       
/* 159 */       if (state.isEdited()) {
/*     */         
/* 161 */         valid = true;
/*     */         
/*     */         break;
/*     */       } 
/*     */     } 
/* 166 */     if (this.buttonSaveToGlobal != null)
/*     */     {
/* 168 */       this.buttonSaveToGlobal.setEnabled(valid);
/*     */     }
/* 170 */     if (this.buttonSaveToWorld != null)
/*     */     {
/* 172 */       this.buttonSaveToWorld.setEnabled(valid);
/*     */     }
/*     */     
/* 175 */     return valid;
/*     */   }
/*     */ 
/*     */   
/*     */   protected void save(ColorPalette.Type type) {
/* 180 */     if (!validate()) {
/*     */       return;
/*     */     }
/*     */ 
/*     */     
/* 185 */     ColorPalette palette = (type == ColorPalette.Type.Global) ? ColorManager.INSTANCE.getGlobalPalette() : ColorManager.INSTANCE.getWorldPalette();
/*     */     
/* 187 */     for (ColorStateItem state : this.statesScrollPane.getRootSlots()) {
/*     */       
/* 189 */       int color = state.color & 0xFFFFFF;
/* 190 */       float alpha = (state.color >> 24 & 0xFF) / 255.0F;
/* 191 */       palette.setBlockStateColor(this.blockId, state.state, color, alpha, state.flags.clone());
/*     */     } 
/*     */     
/* 194 */     refreshAndClose();
/*     */   }
/*     */ 
/*     */   
/*     */   private void popupButtonPressed(ColorStateItem item) {
/* 199 */     if (!this.statesScrollPane.isSelectedItem(item))
/*     */     {
/* 201 */       this.statesScrollPane.setSelected(item);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   private void selectOnly(ColorStateItem item) {
/* 207 */     this.statesScrollPane.setSelected(null);
/* 208 */     this.statesScrollPane.setSelected(item);
/*     */   }
/*     */ 
/*     */   
/*     */   private void editFlagsOfSelected(EnumSet<BlockFlag> flags) {
/* 213 */     for (Slot slot : this.statesScrollPane.getAllSelected()) {
/*     */       
/* 215 */       ColorStateItem state = (ColorStateItem)slot;
/* 216 */       state.setFlags(flags);
/*     */     } 
/*     */     
/* 219 */     validate();
/*     */   }
/*     */ 
/*     */   
/*     */   private void editColorsOfSelected(int color) {
/* 224 */     for (Slot slot : this.statesScrollPane.getAllSelected()) {
/*     */       
/* 226 */       ColorStateItem state = (ColorStateItem)slot;
/* 227 */       state.setColor(color);
/*     */     } 
/*     */     
/* 230 */     validate();
/*     */   }
/*     */ 
/*     */   
/*     */   protected void refreshAndClose() {
/* 235 */     if (returnDisplayStack != null && returnDisplayStack.peek() != null) { ColorPaletteScreen colorPaletteScreen = (ColorPaletteScreen)returnDisplayStack.peek(); if (colorPaletteScreen instanceof ColorPaletteScreen) { ColorPaletteScreen colorPaletteScreen1 = colorPaletteScreen;
/*     */         
/* 237 */         for (ColorStateItem item : this.statesScrollPane.getRootSlots()) {
/*     */           
/* 239 */           if (item.isEdited()) {
/*     */             
/* 241 */             colorPaletteScreen1.setRemapNeeded();
/*     */             break;
/*     */           } 
/*     */         }  }
/*     */        }
/*     */     
/* 247 */     closeAndReturn();
/*     */   }
/*     */   
/*     */   static class ColorStateItem
/*     */     extends Slot
/*     */   {
/*     */     private final Font fontRenderer;
/*     */     private final String blockId;
/*     */     private final String state;
/*     */     private EnumSet<BlockFlag> flags;
/*     */     private String flagsString;
/*     */     private int color;
/*     */     private final EnumSet<BlockFlag> originalFlags;
/*     */     private final int originalColor;
/*     */     private final ColorPaletteItemEditor editor;
/*     */     private final Button buttonDefault;
/*     */     private final Button buttonUndo;
/*     */     private BlockFlagsButton buttonBlockFlags;
/*     */     private ColorPickerButton buttonColorPicker;
/* 266 */     private final List<GuiEventListener> children = new ArrayList<>();
/* 267 */     private long lastClick = 0L;
/*     */ 
/*     */ 
/*     */     
/*     */     ColorStateItem(Font fontRenderer, String blockId, String state, BlockStateColor blockState, boolean isVanilla, ColorPaletteItemEditor editor) {
/* 272 */       this.fontRenderer = fontRenderer;
/* 273 */       this.blockId = blockId;
/* 274 */       this.state = state;
/* 275 */       this.originalFlags = (blockState.flags == null) ? EnumSet.<BlockFlag>noneOf(BlockFlag.class) : blockState.flags;
/* 276 */       this.originalColor = RGB.hexToInt(blockState.color) & 0xFFFFFF | (int)(blockState.alpha.floatValue() * 255.0F) << 24;
/* 277 */       this.flags = this.originalFlags.clone();
/* 278 */       this.flagsString = this.flags.toString();
/* 279 */       this.color = this.originalColor;
/* 280 */       this.editor = editor;
/* 281 */       this.buttonDefault = new Button(Constants.getString("jm.colorpalette.default"), b -> resetItemToDefault());
/* 282 */       this.buttonDefault.fitWidth(fontRenderer);
/* 283 */       this.buttonUndo = new Button(Constants.getString("jm.colorpalette.undo"), b -> undoItem());
/* 284 */       this.buttonUndo.fitWidth(fontRenderer);
/* 285 */       if (!isVanilla)
/*     */       {
/* 287 */         this.buttonBlockFlags = new BlockFlagsButton(24, 24, () -> this.flags, this::flagsChanged);
/*     */       }
/* 289 */       this.buttonColorPicker = new ColorPickerButton(24, 24, () -> this.color, () -> this.flags.contains(BlockFlag.Transparency), this::colorPicked);
/*     */       
/* 291 */       this.children.add(this.buttonColorPicker);
/* 292 */       this.children.add(this.buttonUndo);
/* 293 */       this.children.add(this.buttonDefault);
/* 294 */       if (!isVanilla)
/*     */       {
/* 296 */         this.children.add(this.buttonBlockFlags);
/*     */       }
/*     */     }
/*     */ 
/*     */     
/*     */     private void flagsChanged(BlockFlagsScreen.BlockFlagsResponse response) {
/* 302 */       if (response.canceled()) {
/*     */         return;
/*     */       }
/*     */ 
/*     */       
/* 307 */       this.editor.editFlagsOfSelected(response.flags());
/*     */     }
/*     */ 
/*     */     
/*     */     private void colorPicked(ColorPickerScreen.ColorPickerResponse response) {
/* 312 */       if (response.canceled()) {
/*     */         return;
/*     */       }
/*     */ 
/*     */       
/* 317 */       this.editor.editColorsOfSelected(response.color());
/*     */     }
/*     */ 
/*     */     
/*     */     public void setFlags(EnumSet<BlockFlag> flags) {
/* 322 */       this.flags = flags.clone();
/* 323 */       this.flagsString = flags.toString();
/*     */     }
/*     */ 
/*     */     
/*     */     public void setColor(int color) {
/* 328 */       this.color = color;
/*     */     }
/*     */ 
/*     */     
/*     */     public void resetItemToDefault() {
/* 333 */       ColorPalette defaultPalette = ColorManager.INSTANCE.getDefaultPalette();
/* 334 */       BlockStateColor defaultBSC = defaultPalette.getBlockStateColor(this.blockId, this.state);
/* 335 */       EnumSet<BlockFlag> flags = (defaultBSC.flags == null) ? EnumSet.<BlockFlag>noneOf(BlockFlag.class) : defaultBSC.flags;
/* 336 */       int color = RGB.hexToInt(defaultBSC.color) & 0xFFFFFF | (int)(defaultBSC.alpha.floatValue() * 255.0F) << 24;
/* 337 */       setColor(color);
/* 338 */       setFlags(flags);
/* 339 */       this.editor.validate();
/*     */     }
/*     */ 
/*     */     
/*     */     public void undoItem() {
/* 344 */       setColor(this.originalColor);
/* 345 */       setFlags(this.originalFlags);
/* 346 */       this.editor.validate();
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean isEdited() {
/* 351 */       return (this.color != this.originalColor || !this.flags.equals(this.originalFlags));
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public Collection<SlotMetadata> getMetadata() {
/* 357 */       return null;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public boolean mouseClicked(double mouseX, double mouseY, int mouseEvent) {
/*     */       try {
/* 365 */         if (this.buttonDefault.mouseClicked(mouseX, mouseY, mouseEvent))
/*     */         {
/* 367 */           return true;
/*     */         }
/* 369 */         if (this.buttonUndo.mouseClicked(mouseX, mouseY, mouseEvent))
/*     */         {
/* 371 */           return true;
/*     */         }
/* 373 */         if (this.buttonBlockFlags != null && this.buttonBlockFlags.mouseClicked(mouseX, mouseY, mouseEvent)) {
/*     */           
/* 375 */           this.editor.popupButtonPressed(this);
/* 376 */           return false;
/*     */         } 
/* 378 */         if (this.buttonColorPicker.mouseClicked(mouseX, mouseY, mouseEvent)) {
/*     */           
/* 380 */           this.editor.popupButtonPressed(this);
/* 381 */           this.editor.changeFocus(ComponentPath.path((ContainerEventHandler)this, ComponentPath.leaf((GuiEventListener)this.buttonColorPicker)));
/* 382 */           return false;
/*     */         } 
/*     */         
/* 385 */         if (mouseEvent == 0) {
/*     */           
/* 387 */           long sysTime = Util.getMillis();
/* 388 */           boolean doubleClick = (sysTime - this.lastClick < 200L);
/* 389 */           this.lastClick = sysTime;
/* 390 */           if (doubleClick) {
/*     */             
/* 392 */             this.buttonColorPicker.onPress();
/* 393 */             this.editor.selectOnly(this);
/* 394 */             return false;
/*     */           } 
/*     */         } 
/*     */         
/* 398 */         this.editor.changeFocus(ComponentPath.path((ContainerEventHandler)this, ComponentPath.leaf((GuiEventListener)this.buttonColorPicker)));
/*     */         
/* 400 */         return true;
/*     */       }
/* 402 */       catch (Exception e) {
/*     */         
/* 404 */         Journeymap.getLogger().error("WARNING: Problem with mouseClicked.");
/* 405 */         throw new RuntimeException("mouseClicked", e);
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public List<? extends Slot> getChildSlots(int listWidth, int columnWidth) {
/* 412 */       return null;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public SlotMetadata getLastPressed() {
/* 418 */       return null;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public SlotMetadata getCurrentTooltip() {
/* 424 */       return null;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public void setEnabled(boolean enabled) {}
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public int getColumnWidth() {
/* 436 */       return 0;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public boolean contains(SlotMetadata slotMetadata) {
/* 442 */       return false;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public void render(GuiGraphics graphics, int slotIndex, int y, int x, int rowWidth, int itemHeight, int mouseX, int mouseY, boolean isMouseOver, float partialTicks) {
/* 448 */       DrawUtil.drawRectangle(graphics, x, y, (rowWidth - 4), itemHeight, this.color, 1.0F);
/*     */       
/* 450 */       Objects.requireNonNull(this.fontRenderer); graphics.drawString(this.fontRenderer, this.state, x + 5, y + (itemHeight - 9) / 2 - 3, -1, true);
/* 451 */       if (!this.flags.isEmpty()) {
/*     */         
/* 453 */         Objects.requireNonNull(this.fontRenderer); graphics.drawString(this.fontRenderer, this.flagsString, x + 5, y + (itemHeight + 9) / 2 - 2, 12632256, true);
/*     */       } 
/*     */       
/* 456 */       this.buttonDefault.leftOf(x + rowWidth - 57);
/* 457 */       this.buttonDefault.below(y + 3);
/* 458 */       this.buttonDefault.render(graphics, mouseX, mouseY, partialTicks);
/*     */       
/* 460 */       this.buttonUndo.setVisible(isEdited());
/* 461 */       this.buttonUndo.leftOf(x + rowWidth - 59 - this.buttonDefault.getWidth());
/* 462 */       this.buttonUndo.below(y + 3);
/* 463 */       this.buttonUndo.render(graphics, mouseX, mouseY, partialTicks);
/*     */       
/* 465 */       if (isMouseOver || isFocused()) {
/*     */         
/* 467 */         if (this.buttonBlockFlags != null) {
/*     */           
/* 469 */           this.buttonBlockFlags.leftOf(x + rowWidth - 30);
/* 470 */           this.buttonBlockFlags.below(y + 1);
/* 471 */           this.buttonBlockFlags.render(graphics, mouseX, mouseY, partialTicks);
/*     */         } 
/*     */ 
/*     */         
/* 475 */         this.buttonColorPicker.leftOf(x + rowWidth - 5);
/* 476 */         this.buttonColorPicker.below(y + 1);
/* 477 */         this.buttonColorPicker.render(graphics, mouseX, mouseY, partialTicks);
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public List<? extends GuiEventListener> children() {
/* 484 */       return this.children;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\Administrator\Downloads\journeymap-forge-1.21-6.0.0-beta.18.jar!\journeymap\clien\\ui\colorpalette\ColorPaletteItemEditor.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */