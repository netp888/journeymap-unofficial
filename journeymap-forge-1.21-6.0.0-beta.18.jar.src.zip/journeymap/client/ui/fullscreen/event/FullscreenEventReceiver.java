/*    */ package journeymap.client.ui.fullscreen.event;
/*    */ 
/*    */ import journeymap.api.client.impl.ClientAPI;
/*    */ import journeymap.api.v2.client.IClientAPI;
/*    */ import journeymap.api.v2.client.IClientPlugin;
/*    */ import journeymap.api.v2.client.event.WaypointEvent;
/*    */ import journeymap.api.v2.common.waypoint.Waypoint;
/*    */ import net.minecraft.client.Minecraft;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class FullscreenEventReceiver
/*    */   implements IClientPlugin
/*    */ {
/*    */   ClientAPI api;
/* 18 */   String test = "This is a test class I use for internal testing of api features. it is not enabled in production";
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void initialize(IClientAPI api) {
/* 24 */     this.api = (ClientAPI)api;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public String getModId() {
/* 30 */     return "journeymap";
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void onWaypointEvent(WaypointEvent event) {
/* 68 */     if (event.getContext() == WaypointEvent.Context.UPDATE)
/*    */     {
/*    */       
/* 71 */       if (event.getWaypoint().getId().equals("test123")) {
/*    */         
/* 73 */         this.api.getAllWaypoints();
/* 74 */         this.api.getAllWaypoints((Minecraft.getInstance()).level.dimension());
/* 75 */         Waypoint wp = this.api.getWaypoint(getModId(), "test123");
/* 76 */         this.api.getWaypoints(getModId());
/*    */         
/* 78 */         this.api.removeWaypoint(getModId(), wp);
/*    */       } 
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Users\Administrator\Downloads\journeymap-forge-1.21-6.0.0-beta.18.jar!\journeymap\clien\\ui\fullscreen\event\FullscreenEventReceiver.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */