/*    */ package journeymap.client.ui.fullscreen.layer;
/*    */ 
/*    */ import java.awt.geom.Point2D;
/*    */ import java.util.List;
/*    */ import journeymap.client.render.draw.DrawStep;
/*    */ import journeymap.client.render.map.Renderer;
/*    */ import journeymap.client.ui.fullscreen.Fullscreen;
/*    */ import net.minecraft.client.Minecraft;
/*    */ import net.minecraft.core.BlockPos;
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class Layer
/*    */ {
/*    */   protected final Fullscreen fullscreen;
/*    */   
/*    */   public Layer(Fullscreen fullscreen) {
/* 18 */     this.fullscreen = fullscreen;
/*    */   }
/*    */   
/*    */   public abstract List<DrawStep> onMouseMove(Minecraft paramMinecraft, Renderer paramRenderer, Point2D.Double paramDouble, BlockPos paramBlockPos, float paramFloat, boolean paramBoolean);
/*    */   
/*    */   public abstract List<DrawStep> onMouseClick(Minecraft paramMinecraft, Renderer paramRenderer, Point2D.Double paramDouble, BlockPos paramBlockPos, int paramInt, boolean paramBoolean, float paramFloat);
/*    */   
/*    */   public abstract boolean propagateClick();
/*    */ }


/* Location:              C:\Users\Administrator\Downloads\journeymap-forge-1.21-6.0.0-beta.18.jar!\journeymap\clien\\ui\fullscreen\layer\Layer.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */