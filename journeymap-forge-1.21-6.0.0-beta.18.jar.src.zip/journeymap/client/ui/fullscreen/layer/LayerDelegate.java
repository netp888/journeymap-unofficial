/*     */ package journeymap.client.ui.fullscreen.layer;
/*     */ 
/*     */ import java.awt.geom.Point2D;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import journeymap.client.JourneymapClient;
/*     */ import journeymap.client.cartography.ChunkRenderController;
/*     */ import journeymap.client.cartography.render.BaseRenderer;
/*     */ import journeymap.client.data.DataCache;
/*     */ import journeymap.client.io.FileHandler;
/*     */ import journeymap.client.model.ChunkMD;
/*     */ import journeymap.client.model.RegionCoord;
/*     */ import journeymap.client.render.draw.DrawStep;
/*     */ import journeymap.client.render.map.Renderer;
/*     */ import journeymap.client.ui.fullscreen.Fullscreen;
/*     */ import journeymap.common.Journeymap;
/*     */ import journeymap.common.log.LogFormatter;
/*     */ import journeymap.common.nbt.RegionData;
/*     */ import journeymap.common.nbt.RegionDataStorageHandler;
/*     */ import net.minecraft.Util;
/*     */ import net.minecraft.client.Minecraft;
/*     */ import net.minecraft.core.BlockPos;
/*     */ import net.minecraft.world.level.ChunkPos;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class LayerDelegate
/*     */ {
/*  39 */   long lastClick = 0L;
/*  40 */   BlockPos lastBlockPos = null;
/*  41 */   private final List<DrawStep> drawSteps = new ArrayList<>();
/*  42 */   private final List<Layer> layers = new ArrayList<>();
/*  43 */   long lastHover = 0L;
/*  44 */   private final long hoverDelay = 10L;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public LayerDelegate(Fullscreen fullscreen) {
/*  51 */     this.layers.add(new WaypointLayer(fullscreen));
/*  52 */     this.layers.add(new ModOverlayLayer(fullscreen));
/*  53 */     this.layers.add(new BlockInfoLayer(fullscreen));
/*  54 */     this.layers.add(new KeybindingInfoLayer(fullscreen));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void onMouseMove(Minecraft mc, Renderer renderer, Point2D.Double mousePosition, float fontScale, boolean isScrolling) {
/*  67 */     long now = Util.getMillis();
/*     */     
/*  69 */     if (this.lastBlockPos == null || (!isScrolling && now - this.lastHover > 10L)) {
/*     */       
/*  71 */       this.lastBlockPos = getBlockPos(mc, renderer, mousePosition);
/*  72 */       this.lastHover = now;
/*     */     } 
/*     */     
/*  75 */     this.drawSteps.clear();
/*  76 */     for (Layer layer : this.layers) {
/*     */ 
/*     */       
/*     */       try {
/*  80 */         this.drawSteps.addAll(layer.onMouseMove(mc, renderer, mousePosition, this.lastBlockPos, fontScale, isScrolling));
/*     */       }
/*  82 */       catch (Exception e) {
/*     */         
/*  84 */         Journeymap.getLogger().error(LogFormatter.toString(e));
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void onMouseClicked(Minecraft mc, Renderer renderer, Point2D.Double mousePosition, int button, float fontScale) {
/* 100 */     this.lastBlockPos = renderer.getFullscreen().getBlockAtMouse();
/*     */ 
/*     */     
/* 103 */     long sysTime = Util.getMillis();
/* 104 */     boolean doubleClick = (sysTime - this.lastClick < 200L);
/* 105 */     this.lastClick = sysTime;
/*     */     
/* 107 */     this.drawSteps.clear();
/* 108 */     for (Layer layer : this.layers) {
/*     */ 
/*     */       
/*     */       try {
/* 112 */         this.drawSteps.addAll(layer.onMouseClick(mc, renderer, mousePosition, this.lastBlockPos, button, doubleClick, fontScale));
/* 113 */         if (!layer.propagateClick())
/*     */         {
/*     */           break;
/*     */         }
/*     */       }
/* 118 */       catch (Exception e) {
/*     */         
/* 120 */         Journeymap.getLogger().error(LogFormatter.toString(e));
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public BlockPos getBlockPos(Minecraft mc, Renderer renderer, Point2D.Double mousePosition) {
/* 127 */     BlockPos seaLevel = renderer.getBlockAtPixel(mousePosition);
/* 128 */     ChunkMD chunkMD = DataCache.INSTANCE.getChunkMD(seaLevel);
/*     */     
/* 130 */     int y = seaLevel.getY();
/* 131 */     RegionData regionData = RegionDataStorageHandler.getInstance().getRegionDataAsyncNoCache(seaLevel, renderer.getMapType());
/* 132 */     if (regionData != null && (JourneymapClient.getInstance().getCoreProperties()).dataCachingEnabled.get().booleanValue()) {
/*     */       
/* 134 */       y = regionData.getTopY(seaLevel).intValue();
/* 135 */       return new BlockPos(seaLevel.getX(), y, seaLevel.getZ());
/*     */     } 
/*     */     
/* 138 */     if (chunkMD != null) {
/*     */       
/* 140 */       ChunkRenderController crc = JourneymapClient.getInstance().getChunkRenderController();
/* 141 */       if (crc != null) {
/*     */         
/* 143 */         ChunkPos chunkCoord = chunkMD.getCoord();
/* 144 */         RegionCoord rCoord = RegionCoord.fromChunkPos(FileHandler.getJMWorldDir(mc), renderer.getMapType(), chunkCoord.x, chunkCoord.z);
/* 145 */         BaseRenderer chunkRenderer = crc.getRenderer(rCoord, renderer.getMapType(), chunkMD);
/* 146 */         int blockY = chunkRenderer.getBlockHeight(chunkMD, seaLevel);
/* 147 */         return new BlockPos(seaLevel.getX(), blockY, seaLevel.getZ());
/*     */       } 
/*     */     } 
/* 150 */     return new BlockPos(seaLevel.getX(), y + 1, seaLevel.getZ());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List<DrawStep> getDrawSteps() {
/* 160 */     return this.drawSteps;
/*     */   }
/*     */ }


/* Location:              C:\Users\Administrator\Downloads\journeymap-forge-1.21-6.0.0-beta.18.jar!\journeymap\clien\\ui\fullscreen\layer\LayerDelegate.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */