/*     */ package journeymap.client.ui.fullscreen.layer;
/*     */ 
/*     */ import java.awt.geom.Point2D;
/*     */ import java.awt.geom.Rectangle2D;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.List;
/*     */ import java.util.Objects;
/*     */ import journeymap.api.client.impl.ClientAPI;
/*     */ import journeymap.api.client.impl.ModPopupMenuImpl;
/*     */ import journeymap.api.v2.client.display.IOverlayListener;
/*     */ import journeymap.api.v2.client.display.Overlay;
/*     */ import journeymap.api.v2.client.fullscreen.ModPopupMenu;
/*     */ import journeymap.api.v2.client.util.UIState;
/*     */ import journeymap.client.render.draw.DrawStep;
/*     */ import journeymap.client.render.draw.OverlayDrawStep;
/*     */ import journeymap.client.render.map.Renderer;
/*     */ import journeymap.client.ui.fullscreen.Fullscreen;
/*     */ import journeymap.common.Journeymap;
/*     */ import net.minecraft.client.Minecraft;
/*     */ import net.minecraft.core.BlockPos;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ModOverlayLayer
/*     */   extends Layer
/*     */ {
/*  34 */   protected List<OverlayDrawStep> allDrawSteps = new ArrayList<>();
/*  35 */   protected List<OverlayDrawStep> visibleSteps = new ArrayList<>();
/*  36 */   protected List<OverlayDrawStep> touchedSteps = new ArrayList<>();
/*     */   
/*     */   protected BlockPos lastCoord;
/*     */   protected Point2D.Double lastMousePosition;
/*     */   protected UIState lastUiState;
/*     */   protected boolean propagateClick;
/*     */   
/*     */   public ModOverlayLayer(Fullscreen fullscreen) {
/*  44 */     super(fullscreen);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void ensureCurrent(Minecraft mc, Renderer renderer, Point2D.Double mousePosition, BlockPos blockCoord) {
/*  53 */     UIState currentUiState = renderer.getUIState();
/*  54 */     boolean uiStateChange = !Objects.equals(this.lastUiState, currentUiState);
/*     */     
/*  56 */     if (uiStateChange || !Objects.equals(blockCoord, this.lastCoord) || this.lastMousePosition == null) {
/*     */       
/*  58 */       this.lastCoord = blockCoord;
/*  59 */       this.lastUiState = currentUiState;
/*  60 */       this.lastMousePosition = mousePosition;
/*     */       
/*  62 */       this.allDrawSteps.clear();
/*  63 */       ClientAPI.INSTANCE.getDrawSteps(this.allDrawSteps, currentUiState);
/*     */       
/*  65 */       updateOverlayState(renderer, mousePosition, blockCoord, uiStateChange);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public List<DrawStep> onMouseMove(Minecraft mc, Renderer renderer, Point2D.Double mousePosition, BlockPos blockCoord, float fontScale, boolean isScrolling) {
/*  72 */     ensureCurrent(mc, renderer, mousePosition, blockCoord);
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  77 */     if (!this.touchedSteps.isEmpty())
/*     */     {
/*  79 */       for (OverlayDrawStep overlayDrawStep : this.touchedSteps) {
/*     */ 
/*     */         
/*     */         try {
/*  83 */           Overlay overlay = overlayDrawStep.getOverlay();
/*  84 */           IOverlayListener listener = overlay.getOverlayListener();
/*  85 */           fireOnMouseMove(listener, mousePosition, blockCoord);
/*  86 */           overlayDrawStep.setTitlePosition(mousePosition);
/*     */         }
/*  88 */         catch (Throwable t) {
/*     */           
/*  90 */           Journeymap.getLogger().error(t.getMessage(), t);
/*     */         } 
/*     */       } 
/*     */     }
/*  94 */     return Collections.emptyList();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List<DrawStep> onMouseClick(Minecraft mc, Renderer renderer, Point2D.Double mousePosition, BlockPos blockCoord, int button, boolean doubleClick, float fontScale) {
/* 101 */     ensureCurrent(mc, renderer, mousePosition, blockCoord);
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 106 */     this.propagateClick = true;
/* 107 */     if (!this.touchedSteps.isEmpty())
/*     */     {
/* 109 */       for (OverlayDrawStep overlayDrawStep : this.touchedSteps) {
/*     */ 
/*     */         
/*     */         try {
/* 113 */           Overlay overlay = overlayDrawStep.getOverlay();
/* 114 */           IOverlayListener listener = overlay.getOverlayListener();
/* 115 */           if (listener != null) {
/*     */             
/* 117 */             boolean continueClick = fireOnMouseClick(listener, mousePosition, blockCoord, button, doubleClick);
/* 118 */             if (button == 1)
/*     */             {
/* 120 */               fireOnMenuPopup(listener, mousePosition, blockCoord);
/*     */             }
/* 122 */             overlayDrawStep.setTitlePosition(mousePosition);
/* 123 */             if (!continueClick) {
/*     */               
/* 125 */               this.propagateClick = false;
/*     */               
/*     */               break;
/*     */             } 
/*     */           } 
/* 130 */         } catch (Throwable t) {
/*     */           
/* 132 */           Journeymap.getLogger().error(t.getMessage(), t);
/*     */         } 
/*     */       } 
/*     */     }
/* 136 */     return Collections.emptyList();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean propagateClick() {
/* 142 */     return this.propagateClick;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void updateOverlayState(Renderer renderer, Point2D.Double mousePosition, BlockPos blockCoord, boolean uiStateChange) {
/* 152 */     for (OverlayDrawStep overlayDrawStep : this.allDrawSteps) {
/*     */       
/* 154 */       Overlay overlay = overlayDrawStep.getOverlay();
/* 155 */       IOverlayListener listener = overlay.getOverlayListener();
/* 156 */       overlayDrawStep.setTitlePosition(null);
/* 157 */       boolean currentlyActive = this.visibleSteps.contains(overlayDrawStep);
/* 158 */       boolean currentlyTouched = this.touchedSteps.contains(overlayDrawStep);
/*     */       
/* 160 */       if (overlayDrawStep.isOnScreen(0.0D, 0.0D, renderer, 0.0D)) {
/*     */         
/* 162 */         if (!currentlyActive) {
/*     */           
/* 164 */           this.visibleSteps.add(overlayDrawStep);
/* 165 */           fireActivate(listener);
/*     */         }
/* 167 */         else if (uiStateChange) {
/*     */           
/* 169 */           fireActivate(listener);
/*     */         } 
/*     */         
/* 172 */         Rectangle2D.Double bounds = overlayDrawStep.getBounds();
/* 173 */         if (bounds != null && bounds.contains(mousePosition)) {
/*     */           
/* 175 */           if (!currentlyTouched)
/*     */           {
/* 177 */             this.touchedSteps.add(overlayDrawStep);
/*     */           }
/*     */           
/*     */           continue;
/*     */         } 
/*     */         
/* 183 */         if (currentlyTouched) {
/*     */           
/* 185 */           this.touchedSteps.remove(overlayDrawStep);
/* 186 */           fireOnMouseOut(listener, mousePosition, blockCoord);
/*     */         } 
/*     */ 
/*     */         
/*     */         continue;
/*     */       } 
/*     */       
/* 193 */       if (currentlyTouched) {
/*     */         
/* 195 */         this.touchedSteps.remove(overlayDrawStep);
/* 196 */         fireOnMouseOut(listener, mousePosition, blockCoord);
/*     */       } 
/*     */       
/* 199 */       if (currentlyActive) {
/*     */         
/* 201 */         this.visibleSteps.remove(overlayDrawStep);
/* 202 */         fireDeActivate(listener);
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void fireActivate(IOverlayListener listener) {
/* 211 */     if (listener != null) {
/*     */       
/*     */       try {
/*     */         
/* 215 */         listener.onActivate(this.lastUiState);
/*     */       }
/* 217 */       catch (Throwable t) {
/*     */         
/* 219 */         t.printStackTrace();
/*     */       } 
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   private void fireDeActivate(IOverlayListener listener) {
/* 226 */     if (listener != null) {
/*     */       
/*     */       try {
/*     */         
/* 230 */         listener.onDeactivate(this.lastUiState);
/*     */       }
/* 232 */       catch (Throwable t) {
/*     */         
/* 234 */         t.printStackTrace();
/*     */       } 
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   private void fireOnMouseMove(IOverlayListener listener, Point2D.Double mousePosition, BlockPos blockCoord) {
/* 241 */     if (listener != null) {
/*     */       
/*     */       try {
/*     */         
/* 245 */         listener.onMouseMove(this.lastUiState, mousePosition, blockCoord);
/*     */       }
/* 247 */       catch (Throwable t) {
/*     */         
/* 249 */         t.printStackTrace();
/*     */       } 
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void fireOnMenuPopup(IOverlayListener listener, Point2D.Double mousePosition, BlockPos blockCoord) {
/* 258 */     if (listener != null) {
/*     */       
/*     */       try {
/*     */         
/* 262 */         ModPopupMenuImpl modPopupMenuImpl = new ModPopupMenuImpl(this.fullscreen.popupMenu);
/* 263 */         listener.onOverlayMenuPopup(this.lastUiState, mousePosition, blockCoord, (ModPopupMenu)modPopupMenuImpl);
/* 264 */         this.fullscreen.popupMenu.displayOptions(blockCoord, (ModPopupMenu)modPopupMenuImpl);
/*     */       }
/* 266 */       catch (Throwable t) {
/*     */         
/* 268 */         t.printStackTrace();
/*     */       } 
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   private boolean fireOnMouseClick(IOverlayListener listener, Point2D.Double mousePosition, BlockPos blockCoord, int button, boolean doubleClick) {
/* 275 */     if (listener != null) {
/*     */       
/*     */       try {
/*     */         
/* 279 */         return listener.onMouseClick(this.lastUiState, mousePosition, blockCoord, button, doubleClick);
/*     */       }
/* 281 */       catch (Throwable t) {
/*     */         
/* 283 */         t.printStackTrace();
/*     */       } 
/*     */     }
/* 286 */     return true;
/*     */   }
/*     */ 
/*     */   
/*     */   private void fireOnMouseOut(IOverlayListener listener, Point2D.Double mousePosition, BlockPos blockCoord) {
/* 291 */     if (listener != null)
/*     */       
/*     */       try {
/*     */         
/* 295 */         listener.onMouseOut(this.lastUiState, mousePosition, blockCoord);
/*     */       }
/* 297 */       catch (Throwable t) {
/*     */         
/* 299 */         t.printStackTrace();
/*     */       }  
/*     */   }
/*     */ }


/* Location:              C:\Users\Administrator\Downloads\journeymap-forge-1.21-6.0.0-beta.18.jar!\journeymap\clien\\ui\fullscreen\layer\ModOverlayLayer.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */