/*     */ package journeymap.client.ui.dialog;
/*     */ 
/*     */ import com.mojang.blaze3d.vertex.VertexConsumer;
/*     */ import java.awt.Color;
/*     */ import java.awt.geom.Rectangle2D;
/*     */ import java.util.Collection;
/*     */ import java.util.EnumSet;
/*     */ import journeymap.client.Constants;
/*     */ import journeymap.client.JourneymapClient;
/*     */ import journeymap.client.io.ThemeLoader;
/*     */ import journeymap.client.model.GridSpec;
/*     */ import journeymap.client.model.GridSpecs;
/*     */ import journeymap.client.model.MapType;
/*     */ import journeymap.client.render.draw.DrawUtil;
/*     */ import journeymap.client.texture.SimpleTextureImpl;
/*     */ import journeymap.client.texture.Texture;
/*     */ import journeymap.client.texture.TextureCache;
/*     */ import journeymap.client.ui.UIManager;
/*     */ import journeymap.client.ui.component.ButtonList;
/*     */ import journeymap.client.ui.component.buttons.Button;
/*     */ import journeymap.client.ui.component.buttons.CheckBox;
/*     */ import journeymap.client.ui.component.buttons.FloatSliderButton;
/*     */ import journeymap.client.ui.component.buttons.PropertyDropdownButton;
/*     */ import journeymap.client.ui.component.screens.JmUILegacy;
/*     */ import journeymap.client.ui.theme.Theme;
/*     */ import journeymap.client.ui.theme.ThemeToggle;
/*     */ import journeymap.common.Journeymap;
/*     */ import journeymap.common.log.LogFormatter;
/*     */ import journeymap.common.properties.catagory.Category;
/*     */ import journeymap.common.properties.config.ConfigField;
/*     */ import journeymap.common.properties.config.EnumField;
/*     */ import journeymap.common.properties.config.FloatField;
/*     */ import net.minecraft.client.gui.GuiGraphics;
/*     */ import net.minecraft.client.gui.components.Button;
/*     */ import net.minecraft.client.gui.components.events.GuiEventListener;
/*     */ import net.minecraft.client.gui.screens.Screen;
/*     */ import net.minecraft.client.renderer.MultiBufferSource;
/*     */ import net.minecraft.client.renderer.RenderType;
/*     */ import net.minecraft.resources.ResourceLocation;
/*     */ import net.minecraft.world.level.Level;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class GridEditor
/*     */   extends JmUILegacy
/*     */ {
/*     */   private final Texture colorPickTexture;
/*  50 */   private final int tileSize = 128;
/*  51 */   private final int sampleTextureSize = 128;
/*     */   
/*     */   private GridSpecs gridSpecs;
/*     */   
/*     */   private PropertyDropdownButton<GridSpec.Style> buttonStyle;
/*     */   private FloatSliderButton buttonOpacity;
/*     */   private CheckBox checkDay;
/*     */   private CheckBox checkNight;
/*     */   private CheckBox checkUnderground;
/*     */   private ThemeToggle buttonDay;
/*     */   private ThemeToggle buttonNight;
/*     */   private ThemeToggle buttonUnderground;
/*     */   private Integer activeColor;
/*     */   private MapType activeMapType;
/*     */   private Button buttonReset;
/*     */   private Button buttonCancel;
/*     */   private Button buttonClose;
/*     */   private Rectangle2D.Double colorPickRect;
/*     */   private ButtonList topButtons;
/*     */   private ButtonList leftButtons;
/*     */   private ButtonList leftChecks;
/*     */   private ButtonList bottomButtons;
/*     */   private ResourceLocation colorPicResource;
/*     */   
/*     */   public GridEditor(Screen returnDisplay) {
/*  76 */     super(Constants.getString("jm.common.grid_editor"), returnDisplay);
/*  77 */     this.colorPicResource = (Constants.birthdayMessage() == null) ? TextureCache.ColorPicker : TextureCache.ColorPicker2;
/*     */     
/*  79 */     this.colorPickTexture = TextureCache.getTexture(this.colorPicResource);
/*  80 */     this.colorPickRect = new Rectangle2D.Double(0.0D, 0.0D, this.colorPickTexture.getWidth(), this.colorPickTexture.getHeight());
/*     */     
/*  82 */     this.gridSpecs = (JourneymapClient.getInstance().getCoreProperties()).gridSpecs.clone();
/*     */     
/*  84 */     this.activeMapType = MapType.day(Level.OVERWORLD);
/*  85 */     this.activeColor = this.gridSpecs.getSpec(this.activeMapType).getColor();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void init() {
/*     */     try {
/*  97 */       setRenderBottomBar(true);
/*  98 */       if (getRenderables().isEmpty())
/*     */       {
/* 100 */         GridSpec spec = this.gridSpecs.getSpec(this.activeMapType);
/*     */ 
/*     */         
/* 103 */         this
/*     */           
/* 105 */           .buttonStyle = new PropertyDropdownButton(EnumSet.allOf(GridSpec.Style.class), Constants.getString("jm.common.grid_style"), (ConfigField)new EnumField(Category.Hidden, "", (Enum)spec.style), b -> updateGridSpecs());
/*     */ 
/*     */         
/* 108 */         addRenderableWidget((GuiEventListener)this.buttonStyle);
/* 109 */         this.buttonStyle.setDefaultStyle(false);
/* 110 */         this.buttonStyle.setDrawBackground(false);
/*     */         
/* 112 */         this
/*     */           
/* 114 */           .buttonOpacity = new FloatSliderButton(new FloatField(Category.Hidden, "", 0.0F, 1.0F, spec.alpha), Constants.getString("jm.common.grid_opacity") + " : ", "");
/*     */         
/* 116 */         addRenderableWidget((GuiEventListener)this.buttonOpacity);
/* 117 */         this.buttonOpacity.setDefaultStyle(false);
/* 118 */         this.buttonOpacity.setDrawBackground(false);
/*     */         
/* 120 */         this.topButtons = new ButtonList(new Button[] { (Button)this.buttonStyle, (Button)this.buttonOpacity });
/* 121 */         this.topButtons.equalizeWidths(getFontRenderer());
/*     */ 
/*     */         
/* 124 */         this.checkDay = new CheckBox("", (this.activeMapType == MapType.day(Level.OVERWORLD)), b -> updatePreview(MapType.day(Level.OVERWORLD)));
/* 125 */         addRenderableWidget((GuiEventListener)this.checkDay);
/* 126 */         this.checkNight = new CheckBox("", (this.activeMapType == MapType.night(Level.OVERWORLD)), b -> updatePreview(MapType.night(Level.OVERWORLD)));
/* 127 */         addRenderableWidget((GuiEventListener)this.checkNight);
/* 128 */         this.checkUnderground = new CheckBox("", this.activeMapType.isUnderground(), b -> updatePreview(MapType.underground(Integer.valueOf(0), Level.OVERWORLD)));
/* 129 */         addRenderableWidget((GuiEventListener)this.checkUnderground);
/* 130 */         this.leftChecks = new ButtonList(new Button[] { (Button)this.checkDay, (Button)this.checkNight, (Button)this.checkUnderground });
/*     */ 
/*     */         
/* 133 */         Theme theme = ThemeLoader.getCurrentTheme();
/* 134 */         this.buttonDay = new ThemeToggle(theme, "jm.fullscreen.map_day", "day", b -> updatePreview(MapType.day(Level.OVERWORLD)));
/*     */         
/* 136 */         addRenderableWidget((GuiEventListener)this.buttonDay);
/* 137 */         this.buttonNight = new ThemeToggle(theme, "jm.fullscreen.map_night", "night", b -> updatePreview(MapType.night(Level.OVERWORLD)));
/*     */         
/* 139 */         addRenderableWidget((GuiEventListener)this.buttonNight);
/* 140 */         this.buttonUnderground = new ThemeToggle(theme, "jm.fullscreen.map_caves", "caves", b -> updatePreview(MapType.underground(Integer.valueOf(0), Level.OVERWORLD)));
/*     */         
/* 142 */         addRenderableWidget((GuiEventListener)this.buttonUnderground);
/* 143 */         this.leftButtons = new ButtonList(new Button[] { (Button)this.buttonDay, (Button)this.buttonNight, (Button)this.buttonUnderground });
/*     */ 
/*     */         
/* 146 */         this.buttonReset = new Button(Constants.getString("jm.waypoint.reset"), b -> resetGridSpecs());
/* 147 */         addRenderableWidget((GuiEventListener)this.buttonReset);
/* 148 */         this.buttonReset.setDefaultStyle(false);
/* 149 */         this.buttonCancel = new Button(Constants.getString("jm.waypoint.cancel"), b -> {
/*     */               resetGridSpecs();
/*     */               closeAndReturn();
/*     */             });
/* 153 */         this.buttonCancel.setDefaultStyle(false);
/* 154 */         addRenderableWidget((GuiEventListener)this.buttonCancel);
/* 155 */         this.buttonClose = new Button(Constants.getString("jm.waypoint.save"), b -> saveAndClose());
/* 156 */         this.buttonClose.setDefaultStyle(false);
/* 157 */         addRenderableWidget((GuiEventListener)this.buttonClose);
/* 158 */         this.bottomButtons = new ButtonList(new Button[] { this.buttonReset, this.buttonCancel, this.buttonClose });
/* 159 */         this.bottomButtons.equalizeWidths(getFontRenderer());
/*     */         
/* 161 */         getRenderables().addAll((Collection)this.topButtons);
/* 162 */         getRenderables().addAll((Collection)this.leftChecks);
/* 163 */         getRenderables().addAll((Collection)this.leftButtons);
/* 164 */         getRenderables().addAll((Collection)this.bottomButtons);
/*     */         
/* 166 */         updatePreview(this.activeMapType);
/*     */       }
/*     */     
/* 169 */     } catch (Throwable t) {
/*     */       
/* 171 */       Journeymap.getLogger().error(LogFormatter.toString(t));
/* 172 */       UIManager.INSTANCE.closeAll();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void layoutButtons(GuiGraphics graphics) {
/*     */     try {
/* 185 */       init();
/*     */ 
/*     */       
/* 188 */       int hgap = 6;
/* 189 */       int vgap = 6;
/* 190 */       int startY = Math.max(40, (this.height - 230) / 2);
/* 191 */       int centerX = this.width / 2;
/*     */ 
/*     */       
/* 194 */       int cpSize = this.topButtons.getHeight(6);
/* 195 */       int topRowWidth = 6 + cpSize + ((Button)this.topButtons.get(0)).getWidth();
/* 196 */       int topRowLeft = centerX - topRowWidth / 2;
/* 197 */       this.topButtons.layoutVertical(topRowLeft + 6 + cpSize, startY, true, 6);
/* 198 */       drawColorPicker(graphics, topRowLeft, this.topButtons.getTopY(), cpSize);
/*     */ 
/*     */ 
/*     */       
/* 202 */       int tileX = centerX - 64;
/* 203 */       int tileY = this.topButtons.getBottomY() + 12;
/*     */ 
/*     */       
/* 206 */       MultiBufferSource.BufferSource buffers = graphics.bufferSource();
/* 207 */       drawMapTile(graphics, buffers, tileX, tileY);
/*     */ 
/*     */       
/* 210 */       this.leftButtons.layoutVertical(tileX - ((Button)this.leftButtons.get(0)).getWidth() - 6, tileY + 6, true, 6);
/*     */ 
/*     */       
/* 213 */       this.leftChecks.setHeights(((Button)this.leftButtons.get(0)).getHeight());
/* 214 */       this.leftChecks.setWidths(15);
/* 215 */       this.leftChecks.layoutVertical(this.leftButtons.getLeftX() - this.checkDay.getWidth(), this.leftButtons.getTopY(), true, 6);
/*     */ 
/*     */       
/* 218 */       int bottomY = Math.min(tileY + 128 + 12, this.height - 10 - this.buttonClose.getHeight());
/* 219 */       this.bottomButtons.equalizeWidths(getFontRenderer(), 6, ((Button)this.topButtons.get(0)).getRightX() - topRowLeft);
/* 220 */       this.bottomButtons.layoutCenteredHorizontal(centerX, bottomY, true, 6);
/*     */     }
/* 222 */     catch (Throwable t) {
/*     */       
/* 224 */       this.logger.error("Error in GridEditor.layoutButtons: " + LogFormatter.toString(t));
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void render(GuiGraphics graphics, int x, int y, float par3) {
/*     */     try {
/* 233 */       renderBackground(graphics, x, y, par3);
/* 234 */       renderBottomBar(graphics);
/* 235 */       layoutButtons(graphics);
/*     */       
/* 237 */       for (int k = 0; k < getRenderables().size(); k++) {
/*     */         
/* 239 */         Button guibutton = getRenderables().get(k);
/* 240 */         guibutton.render(graphics, x, y, 0.0F);
/*     */       } 
/*     */       
/* 243 */       drawTitle(graphics);
/* 244 */       drawLogo(graphics);
/*     */     }
/* 246 */     catch (Throwable t) {
/*     */       
/* 248 */       this.logger.error("Error in GridEditor.render: " + LogFormatter.toString(t));
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   protected void drawColorPicker(GuiGraphics graphics, int x, int y, float size) {
/* 254 */     int sizeI = (int)size;
/* 255 */     graphics.fill(x - 1, y - 1, x + sizeI + 1, y + sizeI + 1, -6250336);
/* 256 */     float scale = size / this.colorPickTexture.getWidth();
/* 257 */     if (this.colorPickRect.width != size)
/*     */     {
/* 259 */       ((SimpleTextureImpl)this.colorPickTexture).resize(scale);
/*     */     }
/* 261 */     this.colorPickRect.setRect(x, y, size, size);
/*     */     
/* 263 */     DrawUtil.drawImage(graphics.pose(), this.colorPickTexture, x, y, false, scale, 0.0D);
/*     */     
/* 265 */     GridSpec activeSpec = this.gridSpecs.getSpec(this.activeMapType);
/* 266 */     int colorX = activeSpec.getColorX();
/* 267 */     int colorY = activeSpec.getColorY();
/* 268 */     if (colorX > 0 && colorY > 0) {
/*     */       
/* 270 */       colorX += x;
/* 271 */       colorY += y;
/* 272 */       DrawUtil.drawRectangle(graphics, (colorX - 2), (colorY - 2), 5.0D, 5.0D, Color.darkGray.getRGB(), 0.8F);
/* 273 */       DrawUtil.drawRectangle(graphics, (colorX - 1), colorY, 3.0D, 1.0D, this.activeColor.intValue(), 1.0F);
/* 274 */       DrawUtil.drawRectangle(graphics, colorX, (colorY - 1), 1.0D, 3.0D, this.activeColor.intValue(), 1.0F);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   protected void drawMapTile(GuiGraphics graphics, MultiBufferSource.BufferSource buffers, int x, int y) {
/* 280 */     float scale = 1.0F;
/*     */     
/* 282 */     graphics.fill(x - 1, y - 1, x + 128 + 1, y + 128 + 1, -6250336);
/*     */     
/* 284 */     Texture tileTex = getTileSample(this.activeMapType);
/* 285 */     DrawUtil.drawImage(graphics.pose(), tileTex, x, y, false, 1.0F, 0.0D);
/* 286 */     if (scale == 2.0F) {
/*     */       
/* 288 */       DrawUtil.drawImage(graphics.pose(), tileTex, (x + 128), y, true, 1.0F, 0.0D);
/* 289 */       DrawUtil.drawImage(graphics.pose(), tileTex, x, (y + 128), true, 1.0F, 180.0D);
/* 290 */       DrawUtil.drawImage(graphics.pose(), tileTex, (x + 128), (y + 128), false, 1.0F, 180.0D);
/*     */     } 
/*     */     
/* 293 */     GridSpec gridSpec = this.gridSpecs.getSpec(this.activeMapType);
/* 294 */     RenderType renderType = gridSpec.getRenderType(512);
/* 295 */     VertexConsumer regionTileBuffer = buffers.getBuffer(renderType);
/* 296 */     DrawUtil.drawQuad(graphics.pose(), regionTileBuffer, gridSpec.getColor().intValue(), gridSpec.alpha, x, y, 128.0D, 128.0D, 0.0D, 0.0D, 0.25D, 0.25D, 0.0D, false);
/* 297 */     buffers.endBatch(renderType);
/*     */   }
/*     */ 
/*     */   
/*     */   protected void drawLabel(GuiGraphics graphics, String label, int x, int y) {
/* 302 */     graphics.drawString(getFontRenderer(), label, x, y, Color.cyan.getRGB());
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean charTyped(char typedChar, int keyCode) {
/*     */     try {
/* 309 */       switch (keyCode) {
/*     */         
/*     */         case 256:
/* 312 */           closeAndReturn();
/* 313 */           return true;
/*     */         case 257:
/* 315 */           saveAndClose();
/* 316 */           return true;
/*     */       } 
/*     */ 
/*     */ 
/*     */     
/* 321 */     } catch (Throwable t) {
/*     */       
/* 323 */       this.logger.error("Error in GridEditor.keyTyped: " + LogFormatter.toString(t));
/*     */     } 
/* 325 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean mouseDragged(double mouseX, double mouseY, int button, double mouseDX, double mouseDY) {
/*     */     try {
/* 333 */       if (this.buttonOpacity.dragging)
/*     */       {
/* 335 */         updateGridSpecs();
/*     */       }
/*     */       else
/*     */       {
/* 339 */         checkColorPicker(mouseX, mouseY);
/*     */       }
/*     */     
/* 342 */     } catch (Throwable t) {
/*     */       
/* 344 */       this.logger.error("Error in GridEditor.mouseClickMove: " + LogFormatter.toString(t));
/*     */     } 
/* 346 */     return super.mouseDragged(mouseX, mouseY, button, mouseDX, mouseDY);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean mouseClicked(double mouseX, double mouseY, int mouseButton) {
/*     */     try {
/* 354 */       super.mouseClicked(mouseX, mouseY, mouseButton);
/* 355 */       if (mouseButton == 0)
/*     */       {
/* 357 */         checkColorPicker(mouseX, mouseY);
/*     */       }
/*     */     }
/* 360 */     catch (Throwable t) {
/*     */       
/* 362 */       this.logger.error("Error in GridEditor.mouseClicked: " + LogFormatter.toString(t));
/*     */     } 
/* 364 */     return true;
/*     */   }
/*     */ 
/*     */   
/*     */   protected void checkColorPicker(double mouseX, double mouseY) {
/* 369 */     if (this.colorPickRect.contains(mouseX, mouseY)) {
/*     */       
/* 371 */       int x = (int)(mouseX - (int)this.colorPickRect.x);
/* 372 */       int y = (int)(mouseY - (int)this.colorPickRect.y);
/* 373 */       this.activeColor = this.colorPickTexture.getRGB(x, y);
/* 374 */       GridSpec activeSpec = this.gridSpecs.getSpec(this.activeMapType);
/* 375 */       activeSpec.setColorCoords(x, y);
/* 376 */       updateGridSpecs();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected void updatePreview(MapType mapType) {
/* 383 */     this.activeMapType = mapType;
/* 384 */     GridSpec activeSpec = this.gridSpecs.getSpec(this.activeMapType);
/* 385 */     this.activeColor = activeSpec.getColor();
/* 386 */     this.buttonOpacity.setValue(activeSpec.alpha);
/* 387 */     this.buttonStyle.setValue(activeSpec.style);
/*     */     
/* 389 */     this.checkDay.setToggled(Boolean.valueOf(mapType.isDay()));
/* 390 */     this.checkNight.setToggled(Boolean.valueOf(mapType.isNight()));
/* 391 */     this.checkUnderground.setToggled(Boolean.valueOf(mapType.isUnderground()));
/* 392 */     this.buttonDay.setToggled(Boolean.valueOf(mapType.isDay()));
/* 393 */     this.buttonNight.setToggled(Boolean.valueOf(mapType.isNight()));
/* 394 */     this.buttonUnderground.setToggled(Boolean.valueOf(mapType.isUnderground()));
/*     */   }
/*     */ 
/*     */   
/*     */   protected void updateGridSpecs() {
/* 399 */     GridSpec activeSpec = this.gridSpecs.getSpec(this.activeMapType);
/* 400 */     int colorX = activeSpec.getColorX();
/* 401 */     int colorY = activeSpec.getColorY();
/*     */     
/* 403 */     GridSpec newSpec = (new GridSpec((GridSpec.Style)this.buttonStyle.getField().get(), new Color(this.activeColor.intValue()), this.buttonOpacity.getValue())).setColorCoords(colorX, colorY);
/*     */     
/* 405 */     if (this.checkDay.getToggled().booleanValue())
/*     */     {
/* 407 */       this.gridSpecs.setSpec(MapType.day(Level.OVERWORLD), newSpec);
/*     */     }
/*     */     
/* 410 */     if (this.checkNight.getToggled().booleanValue())
/*     */     {
/* 412 */       this.gridSpecs.setSpec(MapType.night(Level.OVERWORLD), newSpec);
/*     */     }
/*     */     
/* 415 */     if (this.checkUnderground.getToggled().booleanValue())
/*     */     {
/* 417 */       this.gridSpecs.setSpec(MapType.underground(Integer.valueOf(0), Level.OVERWORLD), newSpec);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   protected void saveAndClose() {
/* 423 */     updateGridSpecs();
/* 424 */     (JourneymapClient.getInstance().getCoreProperties()).gridSpecs.updateFrom(this.gridSpecs);
/* 425 */     JourneymapClient.getInstance().getCoreProperties().save();
/* 426 */     closeAndReturn();
/*     */   }
/*     */ 
/*     */   
/*     */   protected void resetGridSpecs() {
/* 431 */     if (this.checkDay.getToggled().booleanValue())
/*     */     {
/* 433 */       this.gridSpecs.setSpec(MapType.day(Level.OVERWORLD), GridSpecs.DEFAULT_DAY.clone());
/*     */     }
/* 435 */     if (this.checkNight.getToggled().booleanValue())
/*     */     {
/* 437 */       this.gridSpecs.setSpec(MapType.night(Level.OVERWORLD), GridSpecs.DEFAULT_NIGHT.clone());
/*     */     }
/* 439 */     if (this.checkUnderground.getToggled().booleanValue())
/*     */     {
/* 441 */       this.gridSpecs.setSpec(MapType.underground(Integer.valueOf(0), Level.OVERWORLD), GridSpecs.DEFAULT_UNDERGROUND.clone());
/*     */     }
/* 443 */     children().clear();
/* 444 */     getRenderables().clear();
/* 445 */     init();
/*     */   }
/*     */ 
/*     */   
/*     */   public Texture getTileSample(MapType mapType) {
/* 450 */     if (mapType.isNight())
/*     */     {
/* 452 */       return TextureCache.getTexture(TextureCache.TileSampleNight);
/*     */     }
/* 454 */     if (mapType.isUnderground())
/*     */     {
/* 456 */       return TextureCache.getTexture(TextureCache.TileSampleUnderground);
/*     */     }
/*     */ 
/*     */     
/* 460 */     return TextureCache.getTexture(TextureCache.TileSampleDay);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void renderBottomBar(GuiGraphics graphics) {
/* 467 */     DrawUtil.drawRectangle(graphics, 0.0D, (this.height - 30), this.width, this.height, 0, 0.6F);
/*     */   }
/*     */ }


/* Location:              C:\Users\Administrator\Downloads\journeymap-forge-1.21-6.0.0-beta.18.jar!\journeymap\clien\\ui\dialog\GridEditor.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */