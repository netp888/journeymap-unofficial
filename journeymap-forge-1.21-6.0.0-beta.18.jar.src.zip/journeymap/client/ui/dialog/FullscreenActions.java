/*     */ package journeymap.client.ui.dialog;
/*     */ 
/*     */ import java.net.URLEncoder;
/*     */ import journeymap.client.JourneymapClient;
/*     */ import journeymap.client.ui.UIManager;
/*     */ import journeymap.client.ui.fullscreen.Fullscreen;
/*     */ import journeymap.common.JM;
/*     */ import journeymap.common.Journeymap;
/*     */ import journeymap.common.version.VersionCheck;
/*     */ import net.minecraft.Util;
/*     */ import net.minecraft.client.Minecraft;
/*     */ import net.minecraft.client.gui.screens.Screen;
/*     */ import net.minecraft.client.gui.screens.options.controls.ControlsScreen;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class FullscreenActions
/*     */ {
/*     */   public static void open() {
/*  32 */     UIManager.INSTANCE.openFullscreenMap();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void showCaveLayers() {
/*  40 */     UIManager.INSTANCE.openFullscreenMap().showCaveLayers();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void launchLocalhost() {
/*  48 */     String url = "http://localhost:" + String.valueOf((JourneymapClient.getInstance().getWebMapProperties()).port.get());
/*  49 */     Util.getPlatform().openUri(url);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void launchWebsite(String path) {
/*  59 */     String url = Journeymap.WEBSITE_URL + Journeymap.WEBSITE_URL;
/*  60 */     Util.getPlatform().openUri(url);
/*     */   }
/*     */ 
/*     */   
/*     */   public static void toggleSearchBar() {
/*  65 */     UIManager.INSTANCE.openFullscreenMap().toggleSearchBar(true);
/*     */   }
/*     */ 
/*     */   
/*     */   public static void openKeybindings() {
/*  70 */     UIManager.INSTANCE.closeAll();
/*  71 */     Fullscreen fullscreen = UIManager.INSTANCE.openFullscreenMap();
/*  72 */     Minecraft mc = Minecraft.getInstance();
/*  73 */     mc.setScreen((Screen)new ControlsScreen((Screen)fullscreen, mc.options));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void tweet(String message) {
/*  83 */     String url = null;
/*     */     
/*     */     try {
/*  86 */       url = "http://twitter.com/home/?status=@JourneyMapMod+" + URLEncoder.encode(message, "UTF-8");
/*  87 */       Util.getPlatform().openUri(url);
/*     */     }
/*  89 */     catch (Throwable e) {
/*     */       
/*  91 */       e.printStackTrace();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void discord() {
/* 101 */     String url = JM.DISCORD_URL;
/* 102 */     Util.getPlatform().openUri(url);
/*     */   }
/*     */ 
/*     */   
/*     */   public static void changeLog() {
/* 107 */     String url = "https://gist.github.com/mysticdrew/d0a59ca9509bcb2a3566437621d9ee4e";
/* 108 */     Util.getPlatform().openUri(url);
/*     */   }
/*     */ 
/*     */   
/*     */   public static void webmapDownloadCF() {
/* 113 */     String url = "https://www.curseforge.com/minecraft/mc-mods/journeymap-web-map";
/* 114 */     Util.getPlatform().openUri(url);
/*     */   }
/*     */ 
/*     */   
/*     */   public static void webmapDownloadMR() {
/* 119 */     String url = "https://modrinth.com/mod/journeymap-web-map";
/* 120 */     Util.getPlatform().openUri(url);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void launchDownloadWebsite() {
/* 128 */     String url = VersionCheck.getDownloadUrl();
/* 129 */     Util.getPlatform().openUri(url);
/*     */   }
/*     */ 
/*     */   
/*     */   public static void launchWebMapDownloadWebsite(String url) {
/* 134 */     Util.getPlatform().openUri(url);
/*     */   }
/*     */ }


/* Location:              C:\Users\Administrator\Downloads\journeymap-forge-1.21-6.0.0-beta.18.jar!\journeymap\clien\\ui\dialog\FullscreenActions.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */