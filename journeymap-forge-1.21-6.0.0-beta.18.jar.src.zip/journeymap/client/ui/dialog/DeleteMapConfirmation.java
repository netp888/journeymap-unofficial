/*     */ package journeymap.client.ui.dialog;
/*     */ 
/*     */ import journeymap.client.Constants;
/*     */ import journeymap.client.task.main.DeleteMapTask;
/*     */ import journeymap.client.ui.component.buttons.Button;
/*     */ import journeymap.client.ui.component.screens.JmUILegacy;
/*     */ import net.minecraft.client.gui.GuiGraphics;
/*     */ import net.minecraft.client.gui.components.Button;
/*     */ import net.minecraft.client.gui.components.events.GuiEventListener;
/*     */ import net.minecraft.client.gui.screens.Screen;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DeleteMapConfirmation
/*     */   extends JmUILegacy
/*     */ {
/*     */   Button buttonAll;
/*     */   Button buttonCurrent;
/*     */   Button buttonClose;
/*     */   
/*     */   public DeleteMapConfirmation() {
/*  40 */     this((Screen)null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public DeleteMapConfirmation(Screen returnDisplay) {
/*  48 */     super(Constants.getString("jm.common.deletemap_dialog"), returnDisplay);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void init() {
/*  57 */     getRenderables().clear();
/*  58 */     setRenderBottomBar(true);
/*  59 */     addRenderableWidget((GuiEventListener)(this.buttonAll = new Button(Constants.getString("jm.common.deletemap_dialog_all"), b -> {
/*     */             DeleteMapTask.queue(true);
/*     */             closeAndReturn();
/*     */           })));
/*  63 */     addRenderableWidget((GuiEventListener)(this.buttonCurrent = new Button(Constants.getString("jm.common.deletemap_dialog_this"), b -> {
/*     */             DeleteMapTask.queue(false);
/*     */             
/*     */             closeAndReturn();
/*     */           })));
/*  68 */     addRenderableWidget((GuiEventListener)(this.buttonClose = new Button(Constants.getString("jm.waypoint.cancel"), b -> closeAndReturn())));
/*     */     
/*  70 */     this.buttonAll.setDefaultStyle(false);
/*  71 */     this.buttonCurrent.setDefaultStyle(false);
/*  72 */     this.buttonClose.setDefaultStyle(false);
/*  73 */     getRenderables().add(this.buttonAll);
/*  74 */     getRenderables().add(this.buttonCurrent);
/*     */     
/*  76 */     getRenderables().add(this.buttonClose);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void layoutButtons(GuiGraphics graphics) {
/*  83 */     if (getRenderables().isEmpty())
/*     */     {
/*  85 */       init();
/*     */     }
/*     */     
/*  88 */     int x = this.width / 2;
/*  89 */     int y = this.height / 4;
/*  90 */     int vgap = 3;
/*     */     
/*  92 */     graphics.drawCenteredString(getFontRenderer(), Constants.getString("jm.common.deletemap_dialog_text"), x, y, 16777215);
/*     */     
/*  94 */     this.buttonAll.centerHorizontalOn(x).setY(y + 18);
/*  95 */     this.buttonCurrent.centerHorizontalOn(x).below(this.buttonAll, 3);
/*  96 */     this.buttonClose.centerHorizontalOn(x).below(this.buttonCurrent, 12);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean charTyped(char typedChar, int keyCode) {
/* 103 */     switch (keyCode) {
/*     */ 
/*     */       
/*     */       case 256:
/* 107 */         closeAndReturn();
/*     */         break;
/*     */     } 
/* 110 */     return true;
/*     */   }
/*     */ }


/* Location:              C:\Users\Administrator\Downloads\journeymap-forge-1.21-6.0.0-beta.18.jar!\journeymap\clien\\ui\dialog\DeleteMapConfirmation.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */