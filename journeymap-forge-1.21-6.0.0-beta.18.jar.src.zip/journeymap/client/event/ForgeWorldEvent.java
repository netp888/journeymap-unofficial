/*    */ package journeymap.client.event;
/*    */ 
/*    */ import journeymap.client.event.handlers.WorldEventHandler;
/*    */ import net.minecraftforge.event.level.LevelEvent;
/*    */ import net.minecraftforge.eventbus.api.SubscribeEvent;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ForgeWorldEvent
/*    */   implements ForgeEventHandlerManager.EventHandler
/*    */ {
/* 13 */   private final WorldEventHandler worldEventHandler = new WorldEventHandler();
/*    */ 
/*    */ 
/*    */   
/*    */   @SubscribeEvent
/*    */   public void onUnload(LevelEvent.Unload event) {
/* 19 */     this.worldEventHandler.onUnload(event.getLevel());
/*    */   }
/*    */ }


/* Location:              C:\Users\Administrator\Downloads\journeymap-forge-1.21-6.0.0-beta.18.jar!\journeymap\client\event\ForgeWorldEvent.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */