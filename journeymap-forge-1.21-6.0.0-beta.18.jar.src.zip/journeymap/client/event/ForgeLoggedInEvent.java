/*    */ package journeymap.client.event;
/*    */ 
/*    */ import journeymap.client.event.handlers.PlayerConnectHandler;
/*    */ import net.minecraftforge.client.event.ClientPlayerNetworkEvent;
/*    */ import net.minecraftforge.eventbus.api.SubscribeEvent;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ForgeLoggedInEvent
/*    */   implements ForgeEventHandlerManager.EventHandler
/*    */ {
/* 13 */   private final PlayerConnectHandler playerConnectHandler = new PlayerConnectHandler();
/*    */ 
/*    */ 
/*    */   
/*    */   @SubscribeEvent
/*    */   public void onConnect(ClientPlayerNetworkEvent.LoggingIn event) {
/* 19 */     this.playerConnectHandler.onConnect();
/*    */   }
/*    */ }


/* Location:              C:\Users\Administrator\Downloads\journeymap-forge-1.21-6.0.0-beta.18.jar!\journeymap\client\event\ForgeLoggedInEvent.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */