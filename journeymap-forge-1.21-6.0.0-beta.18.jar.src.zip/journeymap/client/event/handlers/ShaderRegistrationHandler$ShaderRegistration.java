/*    */ package journeymap.client.event.handlers;
/*    */ 
/*    */ import com.mojang.blaze3d.vertex.VertexFormat;
/*    */ import java.util.function.Consumer;
/*    */ import net.minecraft.client.renderer.ShaderInstance;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class ShaderRegistration
/*    */   extends Record
/*    */ {
/*    */   private final VertexFormat format;
/*    */   private final Consumer<ShaderInstance> onLoad;
/*    */   
/*    */   public final String toString() {
/*    */     // Byte code:
/*    */     //   0: aload_0
/*    */     //   1: <illegal opcode> toString : (Ljourneymap/client/event/handlers/ShaderRegistrationHandler$ShaderRegistration;)Ljava/lang/String;
/*    */     //   6: areturn
/*    */     // Line number table:
/*    */     //   Java source line number -> byte code offset
/*    */     //   #45	-> 0
/*    */     // Local variable table:
/*    */     //   start	length	slot	name	descriptor
/*    */     //   0	7	0	this	Ljourneymap/client/event/handlers/ShaderRegistrationHandler$ShaderRegistration;
/*    */   }
/*    */   
/*    */   public final int hashCode() {
/*    */     // Byte code:
/*    */     //   0: aload_0
/*    */     //   1: <illegal opcode> hashCode : (Ljourneymap/client/event/handlers/ShaderRegistrationHandler$ShaderRegistration;)I
/*    */     //   6: ireturn
/*    */     // Line number table:
/*    */     //   Java source line number -> byte code offset
/*    */     //   #45	-> 0
/*    */     // Local variable table:
/*    */     //   start	length	slot	name	descriptor
/*    */     //   0	7	0	this	Ljourneymap/client/event/handlers/ShaderRegistrationHandler$ShaderRegistration;
/*    */   }
/*    */   
/*    */   public final boolean equals(Object o) {
/*    */     // Byte code:
/*    */     //   0: aload_0
/*    */     //   1: aload_1
/*    */     //   2: <illegal opcode> equals : (Ljourneymap/client/event/handlers/ShaderRegistrationHandler$ShaderRegistration;Ljava/lang/Object;)Z
/*    */     //   7: ireturn
/*    */     // Line number table:
/*    */     //   Java source line number -> byte code offset
/*    */     //   #45	-> 0
/*    */     // Local variable table:
/*    */     //   start	length	slot	name	descriptor
/*    */     //   0	8	0	this	Ljourneymap/client/event/handlers/ShaderRegistrationHandler$ShaderRegistration;
/*    */     //   0	8	1	o	Ljava/lang/Object;
/*    */   }
/*    */   
/*    */   public ShaderRegistration(VertexFormat format, Consumer<ShaderInstance> onLoad) {
/* 45 */     this.format = format; this.onLoad = onLoad; } public VertexFormat format() { return this.format; } public Consumer<ShaderInstance> onLoad() { return this.onLoad; }
/*    */ 
/*    */ }


/* Location:              C:\Users\Administrator\Downloads\journeymap-forge-1.21-6.0.0-beta.18.jar!\journeymap\client\event\handlers\ShaderRegistrationHandler$ShaderRegistration.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */