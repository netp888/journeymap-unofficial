/*    */ package journeymap.client.event.handlers;
/*    */ 
/*    */ import com.mojang.blaze3d.vertex.DefaultVertexFormat;
/*    */ import com.mojang.blaze3d.vertex.VertexFormat;
/*    */ import java.util.HashMap;
/*    */ import java.util.Map;
/*    */ import java.util.function.Consumer;
/*    */ import journeymap.client.render.JMRenderTypes;
/*    */ import journeymap.client.render.RegionTileShaders;
/*    */ import net.minecraft.client.renderer.ShaderInstance;
/*    */ import net.minecraft.resources.ResourceLocation;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ShaderRegistrationHandler
/*    */ {
/*    */   public static Map<ResourceLocation, ShaderRegistration> getShaders() {
/* 20 */     Map<ResourceLocation, ShaderRegistration> shaderMap = new HashMap<>();
/*    */     
/* 22 */     RegionTileShaders.REGION_SHADERS.forEach(name -> {
/*    */           if (!"default".equals(name)) {
/*    */             ResourceLocation location = getCoreLocation(name);
/*    */ 
/*    */             
/*    */             ShaderRegistration registration = new ShaderRegistration(DefaultVertexFormat.POSITION_TEX_COLOR, ());
/*    */ 
/*    */             
/*    */             shaderMap.put(location, registration);
/*    */           } 
/*    */         });
/*    */     
/* 34 */     ResourceLocation location = getCoreLocation("jm_position_tex_color");
/* 35 */     ShaderRegistration registration = new ShaderRegistration(DefaultVertexFormat.POSITION_TEX_COLOR, JMRenderTypes::registerPosTexColorShader);
/* 36 */     shaderMap.put(location, registration);
/* 37 */     return shaderMap;
/*    */   }
/*    */ 
/*    */   
/*    */   static ResourceLocation getCoreLocation(String name) {
/* 42 */     return ResourceLocation.fromNamespaceAndPath("journeymap", name);
/*    */   }
/*    */   public static final class ShaderRegistration extends Record { private final VertexFormat format; private final Consumer<ShaderInstance> onLoad;
/* 45 */     public ShaderRegistration(VertexFormat format, Consumer<ShaderInstance> onLoad) { this.format = format; this.onLoad = onLoad; } public final String toString() { // Byte code:
/*    */       //   0: aload_0
/*    */       //   1: <illegal opcode> toString : (Ljourneymap/client/event/handlers/ShaderRegistrationHandler$ShaderRegistration;)Ljava/lang/String;
/*    */       //   6: areturn
/*    */       // Line number table:
/*    */       //   Java source line number -> byte code offset
/*    */       //   #45	-> 0
/*    */       // Local variable table:
/*    */       //   start	length	slot	name	descriptor
/* 45 */       //   0	7	0	this	Ljourneymap/client/event/handlers/ShaderRegistrationHandler$ShaderRegistration; } public VertexFormat format() { return this.format; } public final int hashCode() { // Byte code:
/*    */       //   0: aload_0
/*    */       //   1: <illegal opcode> hashCode : (Ljourneymap/client/event/handlers/ShaderRegistrationHandler$ShaderRegistration;)I
/*    */       //   6: ireturn
/*    */       // Line number table:
/*    */       //   Java source line number -> byte code offset
/*    */       //   #45	-> 0
/*    */       // Local variable table:
/*    */       //   start	length	slot	name	descriptor
/*    */       //   0	7	0	this	Ljourneymap/client/event/handlers/ShaderRegistrationHandler$ShaderRegistration; } public final boolean equals(Object o) { // Byte code:
/*    */       //   0: aload_0
/*    */       //   1: aload_1
/*    */       //   2: <illegal opcode> equals : (Ljourneymap/client/event/handlers/ShaderRegistrationHandler$ShaderRegistration;Ljava/lang/Object;)Z
/*    */       //   7: ireturn
/*    */       // Line number table:
/*    */       //   Java source line number -> byte code offset
/*    */       //   #45	-> 0
/*    */       // Local variable table:
/*    */       //   start	length	slot	name	descriptor
/*    */       //   0	8	0	this	Ljourneymap/client/event/handlers/ShaderRegistrationHandler$ShaderRegistration;
/* 45 */       //   0	8	1	o	Ljava/lang/Object; } public Consumer<ShaderInstance> onLoad() { return this.onLoad; }
/*    */      }
/*    */ 
/*    */ }


/* Location:              C:\Users\Administrator\Downloads\journeymap-forge-1.21-6.0.0-beta.18.jar!\journeymap\client\event\handlers\ShaderRegistrationHandler.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */