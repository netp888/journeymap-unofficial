/*     */ package journeymap.client.event.handlers;
/*     */ 
/*     */ import journeymap.client.JourneymapClient;
/*     */ import journeymap.client.data.DataCache;
/*     */ import journeymap.client.model.ChunkMD;
/*     */ import journeymap.common.Journeymap;
/*     */ import net.minecraft.client.Minecraft;
/*     */ import net.minecraft.core.BlockPos;
/*     */ import net.minecraft.world.level.ChunkPos;
/*     */ import net.minecraft.world.level.LevelAccessor;
/*     */ import net.minecraft.world.level.chunk.ChunkAccess;
/*     */ import net.minecraft.world.level.chunk.LevelChunk;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ChunkMonitorHandler
/*     */ {
/*     */   private LevelAccessor world;
/*     */   private static ChunkMonitorHandler instance;
/*     */   
/*     */   public static ChunkMonitorHandler getInstance() {
/*  35 */     if (instance == null)
/*     */     {
/*  37 */       instance = new ChunkMonitorHandler();
/*     */     }
/*  39 */     return instance;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void reset() {
/*  47 */     this.world = null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void resetRenderTimes(long pos) {
/*  57 */     if (JourneymapClient.getInstance().enabled()) {
/*     */       
/*  59 */       ChunkMD chunkMD = DataCache.INSTANCE.getChunkMD(pos);
/*  60 */       if (chunkMD != null && 
/*  61 */         (Minecraft.getInstance()).player != null && chunkMD.getChunk().getLevel() == (Minecraft.getInstance()).player.getCommandSenderWorld())
/*     */       {
/*  63 */         chunkMD.resetRenderTimes();
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void onChunkLoad(LevelAccessor world, ChunkAccess chunkAccess) {
/*  76 */     if (JourneymapClient.getInstance().enabled()) {
/*     */       
/*  78 */       if (world == null || !world.isClientSide() || !isLevelCurrent()) {
/*     */         return;
/*     */       }
/*     */ 
/*     */       
/*  83 */       if (this.world == null)
/*     */       {
/*  85 */         this.world = world;
/*     */       }
/*     */       
/*  88 */       LevelChunk chunk = (LevelChunk)chunkAccess;
/*  89 */       if (chunk != null && 
/*  90 */         (Minecraft.getInstance()).player != null && chunk.getLevel() == (Minecraft.getInstance()).player.getCommandSenderWorld())
/*     */       {
/*  92 */         DataCache.INSTANCE.addChunkMD(new ChunkMD(chunk));
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void onWorldUnload(LevelAccessor world) {
/* 104 */     if (JourneymapClient.getInstance().enabled()) {
/*     */       
/*     */       try {
/*     */         
/* 108 */         if (world.equals(this.world))
/*     */         {
/* 110 */           reset();
/*     */         }
/*     */       }
/* 113 */       catch (Exception e) {
/*     */         
/* 115 */         Journeymap.getLogger().error("Error handling WorldEvent.Unload", e);
/*     */       } 
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public void onBlockUpdate(LevelAccessor world, BlockPos pos) {
/* 122 */     if (JourneymapClient.getInstance().enabled())
/*     */     {
/* 124 */       if (world != null && isLevelCurrent()) {
/*     */         
/* 126 */         int chunkX = pos.getX() >> 4;
/* 127 */         int chunkZ = pos.getZ() >> 4;
/* 128 */         markBlockRangeForRenderUpdate(chunkX * 16, chunkZ * 16, chunkX * 16 + 15, chunkZ * 16 + 15);
/*     */       } 
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public void onChunkUpdate(LevelAccessor world, ChunkPos pos) {
/* 135 */     if (JourneymapClient.getInstance().enabled())
/*     */     {
/*     */       
/* 138 */       if (world != null && isLevelCurrent())
/*     */       {
/* 140 */         resetRenderTimes(pos.toLong());
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private void markBlockRangeForRenderUpdate(int x1, int z1, int x2, int z2) {
/* 148 */     int cx1 = x1 >> 4;
/* 149 */     int cz1 = z1 >> 4;
/* 150 */     int cx2 = x2 >> 4;
/* 151 */     int cz2 = z2 >> 4;
/*     */     
/* 153 */     if (cx1 == cx2 && cz1 == cz2) {
/*     */       
/* 155 */       resetRenderTimes(ChunkPos.asLong(cx1, cz1));
/*     */     }
/*     */     else {
/*     */       
/* 159 */       for (int chunkXPos = cx1; chunkXPos < cx2; chunkXPos++) {
/*     */         
/* 161 */         for (int chunkZPos = cz1; chunkZPos < cz2; chunkZPos++)
/*     */         {
/* 163 */           resetRenderTimes(ChunkPos.asLong(chunkXPos, chunkZPos));
/*     */         }
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean isLevelCurrent() {
/* 172 */     Minecraft mc = Minecraft.getInstance();
/* 173 */     return (mc.level != null && mc.player != null && mc.level == mc.player.getCommandSenderWorld());
/*     */   }
/*     */ }


/* Location:              C:\Users\Administrator\Downloads\journeymap-forge-1.21-6.0.0-beta.18.jar!\journeymap\client\event\handlers\ChunkMonitorHandler.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */