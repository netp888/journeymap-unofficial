/*     */ package journeymap.client.event.handlers;
/*     */ 
/*     */ import com.google.common.base.Strings;
/*     */ import com.mojang.brigadier.exceptions.CommandSyntaxException;
/*     */ import journeymap.client.JourneymapClient;
/*     */ import journeymap.client.command.ClientCommandInvoker;
/*     */ import journeymap.client.command.CmdChatPosition;
/*     */ import journeymap.client.command.CmdEditWaypoint;
/*     */ import journeymap.client.command.CmdReloadWaypoint;
/*     */ import journeymap.client.command.JMCommand;
/*     */ import journeymap.client.waypoint.WaypointParser;
/*     */ import journeymap.common.Journeymap;
/*     */ import journeymap.common.log.LogFormatter;
/*     */ import net.minecraft.client.Minecraft;
/*     */ import net.minecraft.client.player.LocalPlayer;
/*     */ import net.minecraft.commands.CommandSource;
/*     */ import net.minecraft.network.chat.Component;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ChatEventHandler
/*     */ {
/*     */   private final ClientCommandInvoker clientCommandInvoker;
/*     */   private static ChatEventHandler INSTANCE;
/*     */   
/*     */   private ChatEventHandler() {
/*  35 */     this.clientCommandInvoker = new ClientCommandInvoker();
/*  36 */     this.clientCommandInvoker.registerSub((JMCommand)new CmdChatPosition());
/*  37 */     this.clientCommandInvoker.registerSub((JMCommand)new CmdEditWaypoint());
/*  38 */     this.clientCommandInvoker.registerSub((JMCommand)new CmdReloadWaypoint());
/*     */   }
/*     */ 
/*     */   
/*     */   public static ChatEventHandler getInstance() {
/*  43 */     if (INSTANCE == null)
/*     */     {
/*  45 */       INSTANCE = new ChatEventHandler();
/*     */     }
/*  47 */     return INSTANCE;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Component onClientChatEventReceived(Component message) {
/*  57 */     if (JourneymapClient.getInstance().enabled())
/*     */     {
/*  59 */       if (message != null) {
/*     */         
/*     */         try {
/*     */           
/*  63 */           String text = message.getString();
/*  64 */           if (!Strings.isNullOrEmpty(text))
/*     */           {
/*  66 */             return WaypointParser.parseChatForWaypoints(message, text);
/*     */           }
/*     */         }
/*  69 */         catch (Exception e) {
/*     */           
/*  71 */           Journeymap.getLogger().warn("Unexpected exception on ClientChatReceivedEvent: " + LogFormatter.toString(e));
/*     */         } 
/*     */       }
/*     */     }
/*  75 */     return message;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean onChatEvent(String message) {
/*  80 */     if (JourneymapClient.getInstance().enabled())
/*     */     {
/*  82 */       if (message.regionMatches(0, "/jm", 0, 3)) {
/*     */         
/*  84 */         if (message.length() > 3) {
/*     */           
/*     */           try
/*     */           {
/*  88 */             LocalPlayer localPlayer = (Minecraft.getInstance()).player;
/*  89 */             message = message.substring(4);
/*  90 */             this.clientCommandInvoker.execute((CommandSource)localPlayer, message.split(" "));
/*     */           }
/*  92 */           catch (CommandSyntaxException e)
/*     */           {
/*  94 */             Journeymap.getLogger().error(e);
/*     */           }
/*     */         
/*     */         } else {
/*     */           
/*  99 */           String commands = this.clientCommandInvoker.getPossibleCommands();
/* 100 */           String text = "Available sub commands are: " + commands;
/* 101 */           (Minecraft.getInstance()).player.sendSystemMessage((Component)Component.literal(text));
/*     */         } 
/* 103 */         return true;
/*     */       } 
/*     */     }
/* 106 */     return false;
/*     */   }
/*     */ }


/* Location:              C:\Users\Administrator\Downloads\journeymap-forge-1.21-6.0.0-beta.18.jar!\journeymap\client\event\handlers\ChatEventHandler.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */