/*     */ package journeymap.client.event.handlers;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.io.IOException;
/*     */ import java.nio.file.Path;
/*     */ import java.util.Collection;
/*     */ import java.util.Optional;
/*     */ import java.util.concurrent.CompletableFuture;
/*     */ import journeymap.api.common.waypoint.WaypointFactoryImpl;
/*     */ import journeymap.api.v2.client.event.PopupMenuEvent;
/*     */ import journeymap.api.v2.client.fullscreen.IFullscreen;
/*     */ import journeymap.api.v2.client.fullscreen.ModPopupMenu;
/*     */ import journeymap.api.v2.common.event.ClientEventRegistry;
/*     */ import journeymap.client.Constants;
/*     */ import journeymap.client.JourneymapClient;
/*     */ import journeymap.client.command.CmdTeleportWaypoint;
/*     */ import journeymap.client.data.DataCache;
/*     */ import journeymap.client.io.FileHandler;
/*     */ import journeymap.client.model.ChunkMD;
/*     */ import journeymap.client.model.MapType;
/*     */ import journeymap.client.model.NBTChunkMD;
/*     */ import journeymap.client.model.RegionCoord;
/*     */ import journeymap.client.task.main.DeleteMapTask;
/*     */ import journeymap.client.ui.UIManager;
/*     */ import journeymap.client.ui.fullscreen.Fullscreen;
/*     */ import journeymap.client.ui.waypointmanager.legacy.LegacyWaypointManager;
/*     */ import journeymap.client.waypoint.ClientWaypointImpl;
/*     */ import journeymap.common.Journeymap;
/*     */ import journeymap.common.nbt.RegionData;
/*     */ import journeymap.common.nbt.RegionDataStorageHandler;
/*     */ import journeymap.common.waypoint.WaypointGroupStore;
/*     */ import journeymap.common.waypoint.WaypointStore;
/*     */ import net.minecraft.client.Minecraft;
/*     */ import net.minecraft.client.gui.screens.Screen;
/*     */ import net.minecraft.core.BlockPos;
/*     */ import net.minecraft.nbt.CompoundTag;
/*     */ import net.minecraft.nbt.NbtIo;
/*     */ import net.minecraft.util.datafix.DataFixers;
/*     */ import net.minecraft.world.level.ChunkPos;
/*     */ import net.minecraft.world.level.Level;
/*     */ import net.minecraft.world.level.chunk.LevelChunk;
/*     */ import net.minecraft.world.level.chunk.storage.ChunkStorage;
/*     */ import net.minecraft.world.level.chunk.storage.RegionStorageInfo;
/*     */ import org.apache.commons.lang3.time.StopWatch;
/*     */ 
/*     */ 
/*     */ public class PopupMenuEventHandler
/*     */ {
/*     */   public static PopupMenuEventHandler INSTANCE;
/*     */   
/*     */   private PopupMenuEventHandler() {
/*  52 */     ClientEventRegistry.FULLSCREEN_POPUP_MENU_EVENT.subscribe("journeymap", this::onFullscreenPopupMenu);
/*  53 */     ClientEventRegistry.WAYPOINT_POPUP_MENU_EVENT.subscribe("journeymap", this::onWaypointPopupMenu);
/*     */   }
/*     */ 
/*     */   
/*     */   public static PopupMenuEventHandler init() {
/*  58 */     if (INSTANCE == null)
/*     */     {
/*  60 */       INSTANCE = new PopupMenuEventHandler();
/*     */     }
/*  62 */     return INSTANCE;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void onFullscreenPopupMenu(PopupMenuEvent.FullscreenPopupMenuEvent event) {
/*  72 */     if (JourneymapClient.getInstance().enabled() && !event.isCancelled()) {
/*     */       
/*     */       try {
/*     */         
/*  76 */         if (CmdTeleportWaypoint.isPermitted(Minecraft.getInstance()))
/*     */         {
/*  78 */           event.getPopupMenu().addMenuItem(Constants.getString("jm.waypoint.teleport"), doTeleport(event.getFullscreen()));
/*     */         }
/*     */         
/*  81 */         if (JourneymapClient.getInstance().getStateHandler().isWaypointsAllowed())
/*     */         {
/*  83 */           event.getPopupMenu().createSubItemList(Constants.getString("jm.waypoint.waypoints"))
/*  84 */             .addMenuItem(Constants.getString("key.journeymap.create_waypoint"), createWaypoint(event.getFullscreen(), false))
/*  85 */             .addMenuItem(Constants.getString("jm.waypoint.create_temp_waypoint"), createWaypoint(event.getFullscreen(), true))
/*  86 */             .addMenuItem(Constants.getString("jm.waypoint.show_all"), b -> LegacyWaypointManager.renderWaypoints(true))
/*  87 */             .addMenuItem(Constants.getString("jm.waypoint.hide_all"), b -> LegacyWaypointManager.renderWaypoints(false));
/*     */         }
/*  89 */         event.getPopupMenu().addMenuItem(Constants.getString("key.journeymap.fullscreen.menu.chat_position"), chatAtPos(event.getFullscreen()));
/*  90 */         event.getPopupMenu().createSubItemList(Constants.getString("jm.fullscreen.menu.advanced"))
/*  91 */           .addMenuItem(Constants.getString("jm.fullscreen.menu.delete_region"), blockPos -> deleteRegion(blockPos, (Fullscreen)event.getFullscreen()));
/*     */       }
/*  93 */       catch (Exception e) {
/*     */         
/*  95 */         Journeymap.getLogger().error("Error handling PopupMenuEvent.FullscreenPopupMenuEvent", e);
/*     */       } 
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public void onWaypointPopupMenu(PopupMenuEvent.WaypointPopupMenuEvent event) {
/* 102 */     if (JourneymapClient.getInstance().enabled() && !event.isCancelled()) {
/*     */       
/*     */       try {
/*     */         
/* 106 */         if (JourneymapClient.getInstance().getStateHandler().isWaypointsAllowed()) {
/*     */           
/* 108 */           Collection<ClientWaypointImpl> waypoints = WaypointStore.getInstance().getAll();
/* 109 */           ClientWaypointImpl waypoint = waypoints.stream().filter(wp -> event.getWaypoint().getId().equals(wp.getId())).findAny().orElse(null);
/*     */           
/* 111 */           if (waypoint != null)
/*     */           {
/* 113 */             if (CmdTeleportWaypoint.isPermitted(Minecraft.getInstance()))
/*     */             {
/* 115 */               if (CmdTeleportWaypoint.isPermitted(Minecraft.getInstance()))
/*     */               {
/* 117 */                 event.getPopupMenu().addMenuItem(Constants.getString("jm.waypoint.teleport"), blockPos -> (new CmdTeleportWaypoint(waypoint)).run());
/*     */               }
/*     */             }
/* 120 */             event.getPopupMenu().addMenuItem(Constants.getString("jm.waypoint.edit"), blockPos -> UIManager.INSTANCE.openWaypointEditor(waypoint, false, (Screen)event.getFullscreen()));
/*     */             
/* 122 */             event.getPopupMenu().addMenuItem(Constants.getString("jm.waypoint.disable"), blockPos -> {
/*     */                   waypoint.setEnabled(false);
/*     */                   WaypointStore.getInstance().save(waypoint, false);
/*     */                 });
/* 126 */             event.getPopupMenu().addMenuItem(Constants.getString("jm.waypoint.remove"), blockPos -> WaypointStore.getInstance().remove(waypoint, true));
/*     */           }
/*     */         
/*     */         } 
/* 130 */       } catch (Exception e) {
/*     */         
/* 132 */         Journeymap.getLogger().error("Error handling PopupMenuEvent.FullscreenPopupMenuEvent", e);
/*     */       } 
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   private ModPopupMenu.Action chatAtPos(IFullscreen fullscreen) {
/* 139 */     return blockPos -> {
/*     */         ClientWaypointImpl waypoint = WaypointFactoryImpl.at(blockPos, false, (fullscreen.getMinecraft()).player.getCommandSenderWorld().dimension().location().toString());
/*     */         ((Fullscreen)fullscreen).chatOpenedFromEvent = true;
/*     */         ((Fullscreen)fullscreen).openChat(waypoint.toChatString());
/*     */       };
/*     */   }
/*     */ 
/*     */   
/*     */   private ModPopupMenu.Action createWaypoint(IFullscreen fullscreen, boolean temp) {
/* 148 */     return blockPos -> {
/*     */         int y = blockPos.getY();
/*     */         RegionData regionData = RegionDataStorageHandler.getInstance().getRegionDataAsyncNoCache(blockPos, ((Fullscreen)fullscreen).getMapType());
/*     */         if (regionData != null) {
/*     */           regionData.getTopY(blockPos);
/*     */         }
/*     */         BlockPos pos = new BlockPos(blockPos.getX(), y + 1, blockPos.getZ());
/*     */         ClientWaypointImpl waypoint = WaypointFactoryImpl.at(pos, false, (fullscreen.getMinecraft()).player.getCommandSenderWorld().dimension().location().toString());
/*     */         if (temp) {
/*     */           waypoint.setOrigin("temp");
/*     */           waypoint.setName(Constants.getString("jm.waypoint.temp") + Constants.getString("jm.waypoint.temp"));
/*     */           waypoint.setGroupId(WaypointGroupStore.TEMP.getGuid());
/*     */           WaypointStore.getInstance().save(waypoint, true);
/*     */         } else {
/*     */           UIManager.INSTANCE.openWaypointEditor(waypoint, true, (Screen)fullscreen);
/*     */         } 
/*     */       };
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private ModPopupMenu.Action doTeleport(IFullscreen fullscreen) {
/* 177 */     return blockPos -> {
/*     */         int y = blockPos.getY();
/*     */         RegionData regionData = RegionDataStorageHandler.getInstance().getRegionDataAsyncNoCache(blockPos, ((Fullscreen)fullscreen).getMapType());
/*     */         if (regionData != null) {
/*     */           y = regionData.getTopY(blockPos).intValue();
/*     */         }
/*     */         BlockPos pos = new BlockPos(blockPos.getX(), y + 1, blockPos.getZ());
/*     */         CmdTeleportWaypoint.teleport(pos, (Minecraft.getInstance()).level.dimension(), null);
/*     */       };
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void deleteRegion(BlockPos blockPos, Fullscreen fullscreen) {
/*     */     try {
/* 196 */       MapType mapType = fullscreen.getMapType();
/* 197 */       ChunkPos pos = new ChunkPos(blockPos);
/* 198 */       File jmWorldDir = FileHandler.getJMWorldDir(Minecraft.getInstance());
/* 199 */       RegionCoord rCoord = RegionCoord.fromChunkPos(jmWorldDir, mapType, pos.x, pos.z);
/* 200 */       DeleteMapTask.queue(rCoord, mapType);
/*     */     }
/* 202 */     catch (Exception e) {
/*     */       
/* 204 */       e.printStackTrace();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private ModPopupMenu.Action doRender(Fullscreen fullscreen) {
/* 212 */     return blockPos -> renderChunk(blockPos, fullscreen);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void saveChunk(BlockPos pos) {
/*     */     try {
/* 221 */       Minecraft mc = Minecraft.getInstance();
/* 222 */       Path path = (new File(FileHandler.getWorldSaveDir(mc), "region")).toPath();
/* 223 */       RegionStorageInfo storage = new RegionStorageInfo(path.toString(), mc.level.dimension(), "chunk");
/* 224 */       ChunkStorage loader = new ChunkStorage(storage, path, DataFixers.getDataFixer(), true);
/* 225 */       CompletableFuture<Optional<CompoundTag>> chunkFuture = loader.read(new ChunkPos(pos));
/* 226 */       File jmWorldDir = FileHandler.getJMWorldDir(mc);
/* 227 */       chunkFuture.whenCompleteAsync((chunkOptional, throwable) -> {
/*     */ 
/*     */             
/*     */             if (chunkOptional.isPresent()) {
/*     */               
/*     */               try {
/*     */                 NbtIo.writeCompressed(chunkOptional.get(), (new File(String.valueOf(jmWorldDir) + "/" + String.valueOf(jmWorldDir) + ".chunk.dat")).toPath());
/* 234 */               } catch (IOException e) {
/*     */                 
/*     */                 throw new RuntimeException(e);
/*     */               }
/*     */             
/*     */             }
/*     */           
/*     */           });
/* 242 */     } catch (Exception exception) {}
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void renderChunk(BlockPos blockPos, Fullscreen fullscreen) {
/* 250 */     MapType mapType = fullscreen.getMapType();
/* 251 */     CompoundTag chunk = RegionDataStorageHandler.getInstance().getRegionDataAsyncNoCache(blockPos, mapType).getChunkNbt(new ChunkPos(blockPos));
/* 252 */     ChunkPos chunkPos = new ChunkPos(chunk.getLong("pos"));
/* 253 */     File jmWorldDir = FileHandler.getJMWorldDir(Minecraft.getInstance());
/* 254 */     RegionCoord rCoord = RegionCoord.fromChunkPos(jmWorldDir, mapType, chunkPos.x, chunkPos.z);
/* 255 */     RegionDataStorageHandler.Key key = new RegionDataStorageHandler.Key(rCoord, mapType);
/* 256 */     RegionData regionData = RegionDataStorageHandler.getInstance().getRegionData(key);
/*     */ 
/*     */     
/*     */     try {
/* 260 */       NbtIo.writeCompressed(chunk, (new File(String.valueOf(jmWorldDir) + "/" + String.valueOf(jmWorldDir) + ".chunk.dat")).toPath());
/*     */     }
/* 262 */     catch (IOException e) {
/*     */       
/* 264 */       e.printStackTrace();
/*     */     } 
/*     */     
/* 267 */     NBTChunkMD nBTChunkMD = new NBTChunkMD(new LevelChunk((Level)(Minecraft.getInstance()).level, chunkPos), chunkPos, chunk, mapType);
/*     */     
/* 269 */     ChunkMD md = DataCache.INSTANCE.getChunkMD(chunkPos.toLong());
/* 270 */     JourneymapClient.getInstance().getChunkRenderController().renderChunk(rCoord, fullscreen.getMapType(), (ChunkMD)nBTChunkMD, regionData);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void renderRegion(BlockPos blockPos, Fullscreen fullscreen) {
/*     */     try {
/* 279 */       JourneymapClient.getInstance().queueOneOff(() -> {
/*     */             MapType mapType = fullscreen.getMapType();
/*     */             
/*     */             ChunkPos pos = new ChunkPos(blockPos);
/*     */             
/*     */             File jmWorldDir = FileHandler.getJMWorldDir(Minecraft.getInstance());
/*     */             
/*     */             RegionCoord rCoord = RegionCoord.fromChunkPos(jmWorldDir, mapType, pos.x, pos.z);
/*     */             
/*     */             RegionDataStorageHandler.Key key = new RegionDataStorageHandler.Key(rCoord, mapType);
/*     */             
/*     */             RegionData regionData = RegionDataStorageHandler.getInstance().getRegionData(key);
/*     */             
/*     */             StopWatch stopwatch = new StopWatch();
/*     */             
/*     */             stopwatch.start();
/*     */             
/*     */             for (ChunkPos chunkPos : rCoord.getChunkCoordsInRegion()) {
/*     */               CompoundTag chunk = regionData.getChunkNbt(chunkPos);
/*     */               if (chunk.getAllKeys().size() <= 1) {
/*     */                 continue;
/*     */               }
/*     */               NBTChunkMD nBTChunkMD = new NBTChunkMD(new LevelChunk((Level)(Minecraft.getInstance()).level, chunkPos), chunkPos, chunk, mapType);
/*     */               ChunkMD md = DataCache.INSTANCE.getChunkMD(chunkPos.toLong());
/*     */               JourneymapClient.getInstance().getChunkRenderController().renderChunk(rCoord, fullscreen.getMapType(), (ChunkMD)nBTChunkMD, regionData);
/*     */             } 
/*     */             stopwatch.stop();
/*     */           });
/* 307 */     } catch (Exception e) {
/*     */       
/* 309 */       e.printStackTrace();
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\Administrator\Downloads\journeymap-forge-1.21-6.0.0-beta.18.jar!\journeymap\client\event\handlers\PopupMenuEventHandler.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */