package journeymap.client.event.handlers.keymapping;

import com.mojang.blaze3d.platform.InputConstants;
import net.minecraft.network.chat.Component;

public interface UpdateAwareKeyBinding {
  KeyModifier getModifier();
  
  boolean isActiveAndMatches(InputConstants.Key paramKey);
  
  InputConstants.Key getKeyValue();
  
  boolean modifierActive();
  
  boolean isKeyPressed();
  
  Component getTranslatedName();
  
  String getText();
}


/* Location:              C:\Users\Administrator\Downloads\journeymap-forge-1.21-6.0.0-beta.18.jar!\journeymap\client\event\handlers\keymapping\UpdateAwareKeyBinding.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */