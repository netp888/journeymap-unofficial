/*    */ package journeymap.client.event.handlers.keymapping;
/*    */ 
/*    */ import com.mojang.blaze3d.platform.InputConstants;
/*    */ import journeymap.client.Constants;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class KeyBindingAction
/*    */ {
/*    */   UpdateAwareKeyBinding keyBinding;
/*    */   Runnable action;
/*    */   
/*    */   public KeyBindingAction(UpdateAwareKeyBinding keyBinding, Runnable action) {
/* 16 */     this.keyBinding = keyBinding;
/* 17 */     this.action = action;
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean isActive(int key, boolean useContext, InputConstants.Type type) {
/* 22 */     if (useContext)
/*    */     {
/* 24 */       return this.keyBinding.isActiveAndMatches(type.getOrCreate(key));
/*    */     }
/*    */ 
/*    */     
/* 28 */     return (this.keyBinding.getKeyValue().getValue() == key && this.keyBinding.modifierActive());
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public Runnable getAction() {
/* 34 */     return this.action;
/*    */   }
/*    */ 
/*    */   
/*    */   public UpdateAwareKeyBinding getKeyBinding() {
/* 39 */     return this.keyBinding;
/*    */   }
/*    */ 
/*    */   
/*    */   public int order() {
/* 44 */     return this.keyBinding.getModifier().ordinal();
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public String toString() {
/* 50 */     return "KeyBindingAction{" + this.keyBinding.getTranslatedName().getString().toUpperCase() + " = " + Constants.getString(this.keyBinding.getText()) + "}";
/*    */   }
/*    */ }


/* Location:              C:\Users\Administrator\Downloads\journeymap-forge-1.21-6.0.0-beta.18.jar!\journeymap\client\event\handlers\keymapping\KeyBindingAction.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */