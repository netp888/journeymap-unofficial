/*    */ package journeymap.client.event.handlers;
/*    */ 
/*    */ import journeymap.client.JourneymapClient;
/*    */ import journeymap.client.task.main.EnsureCurrentColorsTask;
/*    */ import journeymap.client.task.main.IMainThreadTask;
/*    */ import journeymap.client.texture.TextureCache;
/*    */ import journeymap.client.ui.UIManager;
/*    */ import journeymap.client.ui.fullscreen.Fullscreen;
/*    */ import journeymap.client.ui.minimap.MiniMap;
/*    */ import journeymap.common.Journeymap;
/*    */ import journeymap.common.log.LogFormatter;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ResourceReloadHandler
/*    */ {
/* 20 */   IMainThreadTask task = (IMainThreadTask)new EnsureCurrentColorsTask();
/*    */ 
/*    */   
/*    */   public void onResourceReload() {
/* 24 */     if (JourneymapClient.getInstance().enabled())
/*    */       
/*    */       try {
/*    */         
/* 28 */         TextureCache.reset();
/* 29 */         UIManager.INSTANCE.getMiniMap().reset();
/* 30 */         Fullscreen.state().requireRefresh();
/* 31 */         MiniMap.state().requireRefresh();
/* 32 */         JourneymapClient.getInstance().queueMainThreadTask(this.task);
/*    */       }
/* 34 */       catch (Exception e) {
/*    */         
/* 36 */         Journeymap.getLogger().warn("Error handling ResourceReloadHandler: " + LogFormatter.toString(e));
/*    */       }  
/*    */   }
/*    */ }


/* Location:              C:\Users\Administrator\Downloads\journeymap-forge-1.21-6.0.0-beta.18.jar!\journeymap\client\event\handlers\ResourceReloadHandler.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */