/*    */ package journeymap.client.event.handlers;
/*    */ 
/*    */ import journeymap.client.JourneymapClient;
/*    */ import journeymap.common.Journeymap;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class PlayerConnectHandler
/*    */ {
/*    */   public void onConnect() {
/*    */     try {
/* 16 */       JourneymapClient.getInstance().getDispatcher().sendHandshakePacket(Journeymap.JM_VERSION.toJson());
/*    */     }
/* 18 */     catch (Exception e) {
/*    */       
/* 20 */       Journeymap.getLogger().error("Error handling ClientPlayerNetworkEvent.LoggedInEvent", e);
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Users\Administrator\Downloads\journeymap-forge-1.21-6.0.0-beta.18.jar!\journeymap\client\event\handlers\PlayerConnectHandler.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */