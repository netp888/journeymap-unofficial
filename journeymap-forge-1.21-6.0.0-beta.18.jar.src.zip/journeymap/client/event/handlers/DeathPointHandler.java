/*    */ package journeymap.client.event.handlers;
/*    */ 
/*    */ import java.util.concurrent.CompletableFuture;
/*    */ import journeymap.api.common.waypoint.WaypointFactoryImpl;
/*    */ import journeymap.api.services.EventBus;
/*    */ import journeymap.api.v2.client.event.DeathWaypointEvent;
/*    */ import journeymap.api.v2.common.event.impl.JourneyMapEvent;
/*    */ import journeymap.client.JourneymapClient;
/*    */ import journeymap.client.properties.WaypointProperties;
/*    */ import journeymap.common.Journeymap;
/*    */ import journeymap.common.log.LogFormatter;
/*    */ import net.minecraft.Util;
/*    */ import net.minecraft.client.Minecraft;
/*    */ import net.minecraft.client.player.LocalPlayer;
/*    */ import net.minecraft.core.BlockPos;
/*    */ import net.minecraft.resources.ResourceKey;
/*    */ import net.minecraft.util.Mth;
/*    */ import net.minecraft.world.level.Level;
/*    */ 
/*    */ public class DeathPointHandler
/*    */ {
/* 22 */   Minecraft mc = Minecraft.getInstance();
/*    */ 
/*    */   
/*    */   public void handlePlayerDeath() {
/* 26 */     if (JourneymapClient.getInstance().enabled())
/*    */     {
/* 28 */       if (this.mc.player != null)
/*    */       {
/* 30 */         createDeathpoint();
/*    */       }
/*    */     }
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   private void createDeathpoint() {
/*    */     try {
/* 39 */       LocalPlayer localPlayer = this.mc.player;
/* 40 */       if (localPlayer == null) {
/*    */         
/* 42 */         Journeymap.getLogger().error("Lost reference to player before Deathpoint could be created");
/*    */         
/*    */         return;
/*    */       } 
/* 46 */       WaypointProperties waypointProperties = JourneymapClient.getInstance().getWaypointProperties();
/* 47 */       boolean enabled = (waypointProperties.managerEnabled.get().booleanValue() && waypointProperties.createDeathpoints.get().booleanValue() && JourneymapClient.getInstance().getStateHandler().isAllowDeathPoints());
/* 48 */       boolean cancelled = false;
/*    */       
/* 50 */       int buildMinY = localPlayer.getCommandSenderWorld().dimensionType().minY() + 2;
/* 51 */       double playerY = Math.max(Mth.floor(localPlayer.getY()), buildMinY);
/* 52 */       BlockPos pos = BlockPos.containing(localPlayer.getX(), playerY, localPlayer.getZ());
/* 53 */       if (enabled) {
/*    */         
/* 55 */         ResourceKey<Level> dim = (Minecraft.getInstance()).player.getCommandSenderWorld().dimension();
/*    */         
/* 57 */         DeathWaypointEvent event = new DeathWaypointEvent(pos, dim);
/* 58 */         EventBus.post((JourneyMapEvent)event);
/* 59 */         if (!event.isCancelled()) {
/*    */           
/* 61 */           CompletableFuture.runAsync(() -> {
/*    */                 try {
/*    */                   Thread.sleep(3000L);
/*    */ 
/*    */                   
/*    */                   WaypointFactoryImpl.createDeathPoint(pos, dim.location().toString());
/* 67 */                 } catch (InterruptedException e) {
/*    */                   
/*    */                   throw new RuntimeException(e);
/*    */                 } 
/* 71 */               }Util.backgroundExecutor());
/*    */         }
/*    */         else {
/*    */           
/* 75 */           cancelled = true;
/*    */         } 
/*    */       } 
/*    */       
/* 79 */       Journeymap.getLogger().info(String.format("%s died at %s. Deathpoints enabled: %s. Deathpoint created: %s", new Object[] { localPlayer
/* 80 */               .getName().getString(), pos, 
/*    */               
/* 82 */               Boolean.valueOf(enabled), 
/* 83 */               cancelled ? "cancelled" : Boolean.valueOf(true) }));
/*    */ 
/*    */     
/*    */     }
/* 87 */     catch (Throwable t) {
/*    */       
/* 89 */       Journeymap.getLogger().error("Unexpected Error in createDeathpoint(): " + LogFormatter.toString(t));
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Users\Administrator\Downloads\journeymap-forge-1.21-6.0.0-beta.18.jar!\journeymap\client\event\handlers\DeathPointHandler.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */