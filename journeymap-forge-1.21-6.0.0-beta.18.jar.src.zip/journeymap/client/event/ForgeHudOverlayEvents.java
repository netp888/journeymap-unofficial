/*    */ package journeymap.client.event;
/*    */ 
/*    */ import journeymap.client.event.handlers.HudOverlayHandler;
/*    */ import net.minecraftforge.client.event.CustomizeGuiOverlayEvent;
/*    */ import net.minecraftforge.eventbus.api.EventPriority;
/*    */ import net.minecraftforge.eventbus.api.SubscribeEvent;
/*    */ 
/*    */ public class ForgeHudOverlayEvents
/*    */   implements ForgeEventHandlerManager.EventHandler
/*    */ {
/*    */   @SubscribeEvent(priority = EventPriority.NORMAL)
/*    */   public void onRenderOverlayDebug(CustomizeGuiOverlayEvent.DebugText event) {
/* 13 */     if (CustomizeGuiOverlayEvent.DebugText.Side.Left == event.getSide())
/*    */     {
/* 15 */       HudOverlayHandler.getInstance().onRenderOverlayDebug(event.getText());
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Users\Administrator\Downloads\journeymap-forge-1.21-6.0.0-beta.18.jar!\journeymap\client\event\ForgeHudOverlayEvents.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */