/*    */ package journeymap.client.event;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import journeymap.client.event.handlers.ShaderRegistrationHandler;
/*    */ import net.minecraft.client.renderer.ShaderInstance;
/*    */ import net.minecraft.resources.ResourceLocation;
/*    */ import net.minecraftforge.api.distmarker.Dist;
/*    */ import net.minecraftforge.client.event.RegisterShadersEvent;
/*    */ import net.minecraftforge.eventbus.api.SubscribeEvent;
/*    */ import net.minecraftforge.fml.common.Mod;
/*    */ import net.minecraftforge.fml.common.Mod.EventBusSubscriber;
/*    */ 
/*    */ 
/*    */ @EventBusSubscriber(value = {Dist.CLIENT}, modid = "journeymap", bus = Mod.EventBusSubscriber.Bus.MOD)
/*    */ public class ForgeShaderRegistration
/*    */ {
/*    */   @SubscribeEvent
/*    */   public static void registerShaders(RegisterShadersEvent event) {
/* 19 */     ShaderRegistrationHandler.getShaders().forEach((id, shader) -> {
/*    */ 
/*    */           
/*    */           try {
/*    */             event.registerShader(new ShaderInstance(event.getResourceProvider(), id, shader.format()), shader.onLoad());
/* 24 */           } catch (IOException e) {
/*    */             throw new RuntimeException(e);
/*    */           } 
/*    */         });
/*    */   }
/*    */ }


/* Location:              C:\Users\Administrator\Downloads\journeymap-forge-1.21-6.0.0-beta.18.jar!\journeymap\client\event\ForgeShaderRegistration.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */