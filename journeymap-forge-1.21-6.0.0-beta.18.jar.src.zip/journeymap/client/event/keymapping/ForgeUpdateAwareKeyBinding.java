/*    */ package journeymap.client.event.keymapping;
/*    */ 
/*    */ import com.mojang.blaze3d.platform.InputConstants;
/*    */ import journeymap.client.event.handlers.KeyEventHandler;
/*    */ import journeymap.client.event.handlers.keymapping.KeyConflictContext;
/*    */ import journeymap.client.event.handlers.keymapping.KeyModifier;
/*    */ import journeymap.client.event.handlers.keymapping.UpdateAwareKeyBinding;
/*    */ import net.minecraft.client.KeyMapping;
/*    */ import net.minecraft.network.chat.Component;
/*    */ import net.minecraftforge.client.settings.IKeyConflictContext;
/*    */ import net.minecraftforge.client.settings.KeyModifier;
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ForgeUpdateAwareKeyBinding
/*    */   extends KeyMapping
/*    */   implements UpdateAwareKeyBinding
/*    */ {
/*    */   KeyModifier keyModifier;
/*    */   IKeyConflictContext conflictContext;
/*    */   InputConstants.Key key;
/*    */   final KeyEventHandler handler;
/*    */   
/*    */   public ForgeUpdateAwareKeyBinding(String description, KeyConflictContext keyConflictContext, KeyModifier keyModifier, InputConstants.Type inputType, int keyCode, String category, KeyEventHandler handler) {
/* 25 */     super(description, ForgeKeyHooks.getForgeConflictContext(keyConflictContext), ForgeKeyHooks.getForgeModifier(keyModifier), inputType, keyCode, category);
/* 26 */     this.keyModifier = keyModifier;
/* 27 */     this.conflictContext = ForgeKeyHooks.getForgeConflictContext(keyConflictContext);
/* 28 */     this.handler = handler;
/* 29 */     this.key = InputConstants.Type.KEYSYM.getOrCreate(keyCode);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public void setKey(InputConstants.Key key) {
/* 35 */     super.setKey(key);
/*    */     
/* 37 */     if (this.handler != null) {
/*    */       
/* 39 */       this.handler.sortActionsNeeded = true;
/* 40 */       this.handler.sortActions();
/*    */     } 
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public InputConstants.Key getKeyValue() {
/* 48 */     return getKey();
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public boolean modifierActive() {
/* 54 */     return getKeyModifier().isActive(getKeyConflictContext());
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public boolean isKeyPressed() {
/* 60 */     return isDown();
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public Component getTranslatedName() {
/* 66 */     return getTranslatedKeyMessage();
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public String getText() {
/* 72 */     return getName();
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public KeyModifier getModifier() {
/* 78 */     return this.keyModifier;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public boolean isActiveAndMatches(InputConstants.Key keyCode) {
/* 84 */     return (keyCode != InputConstants.UNKNOWN && keyCode.equals(getKey()) && getKeyConflictContext().isActive() && getKeyModifier().isActive(getKeyConflictContext()));
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public void setKeyModifierAndCode(KeyModifier keyModifier, InputConstants.Key keyCode) {
/* 90 */     super.setKeyModifierAndCode(keyModifier, keyCode);
/*    */     
/* 92 */     if (this.handler != null) {
/*    */       
/* 94 */       this.handler.sortActionsNeeded = true;
/* 95 */       this.handler.sortActions();
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Users\Administrator\Downloads\journeymap-forge-1.21-6.0.0-beta.18.jar!\journeymap\client\event\keymapping\ForgeUpdateAwareKeyBinding.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */