/*    */ package journeymap.client.event.dispatchers;
/*    */ 
/*    */ import java.awt.geom.Point2D;
/*    */ import journeymap.api.services.EventBus;
/*    */ import journeymap.api.v2.client.event.FullscreenMapEvent;
/*    */ import journeymap.api.v2.client.fullscreen.IBlockInfo;
/*    */ import journeymap.api.v2.common.event.impl.JourneyMapEvent;
/*    */ import net.minecraft.core.BlockPos;
/*    */ import net.minecraft.resources.ResourceKey;
/*    */ import net.minecraft.world.level.Level;
/*    */ 
/*    */ 
/*    */ public class FullscreenEventDispatcher
/*    */ {
/*    */   public static boolean clickEventPre(BlockPos location, ResourceKey<Level> level, Point2D.Double mousePosition, int button) {
/* 16 */     FullscreenMapEvent.ClickEvent clickEvent = new FullscreenMapEvent.ClickEvent(FullscreenMapEvent.Stage.PRE, location, level, mousePosition, button);
/* 17 */     EventBus.post((JourneyMapEvent)clickEvent);
/* 18 */     return clickEvent.isCancelled();
/*    */   }
/*    */ 
/*    */   
/*    */   public static void clickEventPost(BlockPos location, ResourceKey<Level> level, Point2D.Double mousePosition, int button) {
/* 23 */     FullscreenMapEvent.ClickEvent clickEvent = new FullscreenMapEvent.ClickEvent(FullscreenMapEvent.Stage.POST, location, level, mousePosition, button);
/* 24 */     EventBus.post((JourneyMapEvent)clickEvent);
/*    */   }
/*    */ 
/*    */   
/*    */   public static boolean dragEventPre(BlockPos location, ResourceKey<Level> level, Point2D.Double mousePosition, int button) {
/* 29 */     FullscreenMapEvent.MouseDraggedEvent mouseDraggedEvent = new FullscreenMapEvent.MouseDraggedEvent(FullscreenMapEvent.Stage.PRE, location, level, mousePosition, button);
/* 30 */     EventBus.post((JourneyMapEvent)mouseDraggedEvent);
/* 31 */     return mouseDraggedEvent.isCancelled();
/*    */   }
/*    */ 
/*    */   
/*    */   public static void dragEventPost(BlockPos location, ResourceKey<Level> level, Point2D.Double mousePosition, int button) {
/* 36 */     FullscreenMapEvent.MouseDraggedEvent mouseDraggedEvent = new FullscreenMapEvent.MouseDraggedEvent(FullscreenMapEvent.Stage.POST, location, level, mousePosition, button);
/* 37 */     EventBus.post((JourneyMapEvent)mouseDraggedEvent);
/*    */   }
/*    */ 
/*    */   
/*    */   public static void moveEvent(ResourceKey<Level> level, IBlockInfo info, Point2D.Double mousePosition) {
/* 42 */     FullscreenMapEvent.MouseMoveEvent mouseMoveEvent = new FullscreenMapEvent.MouseMoveEvent(level, info, mousePosition);
/* 43 */     EventBus.post((JourneyMapEvent)mouseMoveEvent);
/*    */   }
/*    */ }


/* Location:              C:\Users\Administrator\Downloads\journeymap-forge-1.21-6.0.0-beta.18.jar!\journeymap\client\event\dispatchers\FullscreenEventDispatcher.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */