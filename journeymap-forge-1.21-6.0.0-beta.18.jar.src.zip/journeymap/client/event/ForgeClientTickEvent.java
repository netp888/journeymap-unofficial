/*    */ package journeymap.client.event;
/*    */ 
/*    */ import journeymap.client.event.handlers.StateTickHandler;
/*    */ import net.minecraftforge.event.TickEvent;
/*    */ import net.minecraftforge.eventbus.api.SubscribeEvent;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ForgeClientTickEvent
/*    */   implements ForgeEventHandlerManager.EventHandler
/*    */ {
/* 13 */   private final StateTickHandler stateTickHandler = new StateTickHandler();
/*    */ 
/*    */ 
/*    */   
/*    */   @SubscribeEvent
/*    */   public void onClientTick(TickEvent.ClientTickEvent event) {
/* 19 */     if (event.phase == TickEvent.Phase.END) {
/*    */       return;
/*    */     }
/*    */     
/* 23 */     this.stateTickHandler.onClientTick();
/*    */   }
/*    */ }


/* Location:              C:\Users\Administrator\Downloads\journeymap-forge-1.21-6.0.0-beta.18.jar!\journeymap\client\event\ForgeClientTickEvent.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */