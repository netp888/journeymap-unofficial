/*     */ package journeymap.client.event;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashMap;
/*     */ import journeymap.client.JourneymapClientForge;
/*     */ import journeymap.client.cartography.color.ColorManager;
/*     */ import journeymap.common.Journeymap;
/*     */ import net.minecraftforge.common.MinecraftForge;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ForgeEventHandlerManager
/*     */ {
/*  24 */   private static HashMap<Class<? extends EventHandler>, EventHandler> handlers = new HashMap<>();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void registerHandlers() {
/*  38 */     register(JourneymapClientForge.getInstance().getKeyEvents());
/*  39 */     register(new ForgeChatEvents());
/*  40 */     register(new ForgeHudOverlayEvents());
/*  41 */     register(new ForgeWorldEvent());
/*  42 */     register(new ForgeChunkEvents());
/*  43 */     register(new ForgeClientTickEvent());
/*  44 */     register(new ForgeRenderLevelStageEvent());
/*  45 */     register(new ForgeLoggedInEvent());
/*  46 */     register(new ForgeScreenEvents());
/*     */ 
/*     */     
/*  49 */     ColorManager.INSTANCE.getDeclaringClass();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void unregisterAll() {
/*  58 */     ArrayList<Class<? extends EventHandler>> list = new ArrayList<>(handlers.keySet());
/*  59 */     for (Class<? extends EventHandler> handlerClass : list)
/*     */     {
/*  61 */       unregister(handlerClass);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public static void register(EventHandler handler) {
/*  67 */     Class<? extends EventHandler> handlerClass = handler.getClass();
/*  68 */     if (handlers.containsKey(handlerClass)) {
/*     */       
/*  70 */       Journeymap.getLogger().warn("Handler already registered: " + handlerClass.getName());
/*     */       
/*     */       return;
/*     */     } 
/*     */     
/*     */     try {
/*  76 */       MinecraftForge.EVENT_BUS.register(handler);
/*  77 */       Journeymap.getLogger().debug("Handler registered: " + handlerClass.getName());
/*  78 */       handlers.put(handler.getClass(), handler);
/*     */     }
/*  80 */     catch (Throwable t) {
/*     */       
/*  82 */       Journeymap.getLogger().error(handlerClass.getName() + " registration FAILED: " + handlerClass.getName());
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void unregister(Class<? extends EventHandler> handlerClass) {
/*  93 */     EventHandler handler = handlers.remove(handlerClass);
/*  94 */     if (handler != null) {
/*     */       
/*     */       try {
/*     */         
/*  98 */         MinecraftForge.EVENT_BUS.unregister(handler);
/*  99 */         Journeymap.getLogger().debug("Handler unregistered: " + handlerClass.getName());
/*     */       }
/* 101 */       catch (Throwable t) {
/*     */         
/* 103 */         Journeymap.getLogger().error(String.valueOf(handler) + " unregistration FAILED: " + String.valueOf(handler));
/*     */       } 
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public static HashMap<Class<? extends EventHandler>, EventHandler> getHandlers() {
/* 110 */     return handlers;
/*     */   }
/*     */   
/*     */   public static interface EventHandler {}
/*     */ }


/* Location:              C:\Users\Administrator\Downloads\journeymap-forge-1.21-6.0.0-beta.18.jar!\journeymap\client\event\ForgeEventHandlerManager.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */