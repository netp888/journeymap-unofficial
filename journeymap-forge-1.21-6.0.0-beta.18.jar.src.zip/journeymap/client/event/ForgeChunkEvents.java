/*    */ package journeymap.client.event;
/*    */ 
/*    */ import journeymap.client.event.handlers.ChunkMonitorHandler;
/*    */ import net.minecraft.world.level.LevelAccessor;
/*    */ import net.minecraftforge.event.level.BlockEvent;
/*    */ import net.minecraftforge.event.level.ChunkEvent;
/*    */ import net.minecraftforge.event.level.ChunkWatchEvent;
/*    */ import net.minecraftforge.eventbus.api.SubscribeEvent;
/*    */ 
/*    */ public class ForgeChunkEvents
/*    */   implements ForgeEventHandlerManager.EventHandler
/*    */ {
/*    */   @SubscribeEvent
/*    */   public void onBlockUpdate(BlockEvent event) {
/* 15 */     ChunkMonitorHandler.getInstance().onBlockUpdate(event.getLevel(), event.getPos());
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   @SubscribeEvent
/*    */   public void onChunkUpdate(ChunkWatchEvent event) {
/* 22 */     ChunkMonitorHandler.getInstance().onChunkUpdate((LevelAccessor)event.getLevel(), event.getPos());
/*    */   }
/*    */ 
/*    */   
/*    */   @SubscribeEvent
/*    */   public void onChunkLoad(ChunkEvent.Load event) {
/* 28 */     ChunkMonitorHandler.getInstance().onChunkLoad(event.getLevel(), event.getChunk());
/*    */   }
/*    */ }


/* Location:              C:\Users\Administrator\Downloads\journeymap-forge-1.21-6.0.0-beta.18.jar!\journeymap\client\event\ForgeChunkEvents.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */