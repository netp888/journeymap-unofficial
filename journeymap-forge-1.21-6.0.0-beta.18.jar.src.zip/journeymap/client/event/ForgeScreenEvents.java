/*    */ package journeymap.client.event;
/*    */ 
/*    */ import journeymap.client.event.handlers.ScreenEventHandler;
/*    */ import net.minecraftforge.client.event.ScreenEvent;
/*    */ import net.minecraftforge.eventbus.api.SubscribeEvent;
/*    */ 
/*    */ public class ForgeScreenEvents
/*    */   implements ForgeEventHandlerManager.EventHandler
/*    */ {
/*    */   @SubscribeEvent
/*    */   public void onScreenMousePressedEvent(ScreenEvent.MouseButtonPressed.Pre event) {
/* 12 */     boolean handled = ScreenEventHandler.getInstance().onScreenMousePressedEvent(event.getScreen(), event.getMouseX(), event.getMouseY(), event.getButton());
/* 13 */     event.setCanceled(handled);
/*    */   }
/*    */ 
/*    */   
/*    */   @SubscribeEvent
/*    */   public void onScreenMouseDraggedEvent(ScreenEvent.MouseDragged.Pre event) {
/* 19 */     boolean handled = ScreenEventHandler.getInstance().onScreenMouseDraggedEvent(event.getScreen(), event.getMouseX(), event.getMouseY(), event.getDragX(), event.getDragY(), event.getMouseButton());
/* 20 */     event.setCanceled(handled);
/*    */   }
/*    */ 
/*    */   
/*    */   @SubscribeEvent
/*    */   public void onScreenMouseReleasedEvent(ScreenEvent.MouseButtonReleased.Pre event) {
/* 26 */     boolean handled = ScreenEventHandler.getInstance().onScreenMouseReleasedEvent(event.getScreen(), event.getMouseX(), event.getMouseY(), event.getButton());
/* 27 */     event.setCanceled(handled);
/*    */   }
/*    */ 
/*    */   
/*    */   @SubscribeEvent
/*    */   public void onScreenMouseReleasedEvent(ScreenEvent.Closing event) {
/* 33 */     ScreenEventHandler.getInstance().onScreenClosedEvent(event.getScreen());
/*    */   }
/*    */ }


/* Location:              C:\Users\Administrator\Downloads\journeymap-forge-1.21-6.0.0-beta.18.jar!\journeymap\client\event\ForgeScreenEvents.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */