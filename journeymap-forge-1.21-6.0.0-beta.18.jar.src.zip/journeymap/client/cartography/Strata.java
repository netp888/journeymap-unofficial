/*     */ package journeymap.client.cartography;
/*     */ 
/*     */ import java.util.Stack;
/*     */ import journeymap.client.JourneymapClient;
/*     */ import journeymap.client.cartography.color.RGB;
/*     */ import journeymap.client.log.JMLogger;
/*     */ import journeymap.client.model.BlockMD;
/*     */ import journeymap.client.model.ChunkMD;
/*     */ import journeymap.common.Journeymap;
/*     */ import net.minecraft.core.BlockPos;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Strata
/*     */ {
/*     */   final String name;
/*     */   final int initialPoolSize;
/*     */   final int poolGrowthIncrement;
/*     */   private final boolean underground;
/*  36 */   private boolean mapCaveLighting = (JourneymapClient.getInstance().getCoreProperties()).mapCaveLighting.get().booleanValue();
/*  37 */   private Integer topY = null;
/*  38 */   private Integer bottomY = null;
/*  39 */   private Integer topFluidY = null;
/*  40 */   private Integer bottomFluidY = null;
/*  41 */   private Integer maxLightLevel = null;
/*  42 */   private Integer fluidColor = null;
/*  43 */   private Integer renderDayColor = null;
/*  44 */   private Integer renderNightColor = null;
/*  45 */   private Integer renderCaveColor = null;
/*  46 */   private int lightAttenuation = 0;
/*     */   private boolean blocksFound = false;
/*  48 */   private Stack<Stratum> unusedStack = new Stack<>();
/*  49 */   private Stack<Stratum> sStack = new Stack<>();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Strata(String name, int initialPoolSize, int poolGrowthIncrement, boolean underground) {
/*  61 */     this.name = name;
/*  62 */     this.underground = underground;
/*  63 */     this.initialPoolSize = initialPoolSize;
/*  64 */     this.poolGrowthIncrement = poolGrowthIncrement;
/*  65 */     growFreePool(initialPoolSize);
/*     */   }
/*     */ 
/*     */   
/*     */   private Stratum allocate() {
/*  70 */     if (this.unusedStack.isEmpty()) {
/*     */       
/*  72 */       int amount = this.sStack.isEmpty() ? this.initialPoolSize : this.poolGrowthIncrement;
/*  73 */       growFreePool(amount);
/*  74 */       Journeymap.getLogger().debug(String.format("Grew Strata pool for '%s' by '%s'. Free: %s, Used: %s", new Object[] { this.name, Integer.valueOf(amount), Integer.valueOf(this.unusedStack.size()), Integer.valueOf(this.sStack.size()) }));
/*     */     } 
/*     */     
/*  77 */     this.sStack.push(this.unusedStack.pop());
/*  78 */     return this.sStack.peek();
/*     */   }
/*     */ 
/*     */   
/*     */   private void growFreePool(int amount) {
/*  83 */     for (int i = 0; i < amount; i++)
/*     */     {
/*  85 */       this.unusedStack.push(new Stratum());
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void reset() {
/*  94 */     setTopY(null);
/*  95 */     setBottomY(null);
/*  96 */     setTopFluidY(null);
/*  97 */     setBottomFluidY(null);
/*  98 */     setMaxLightLevel(null);
/*  99 */     setFluidColor(null);
/* 100 */     setRenderDayColor(null);
/* 101 */     setRenderNightColor(null);
/* 102 */     setRenderCaveColor(null);
/* 103 */     setLightAttenuation(0);
/* 104 */     setBlocksFound(false);
/*     */     
/* 106 */     this.mapCaveLighting = (JourneymapClient.getInstance().getCoreProperties()).mapCaveLighting.get().booleanValue();
/*     */     
/* 108 */     while (!this.sStack.isEmpty())
/*     */     {
/* 110 */       release(this.sStack.peek());
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void release(Stratum stratum) {
/* 121 */     if (stratum == null) {
/*     */       
/* 123 */       Journeymap.getLogger().warn("Null stratum in pool.");
/*     */       
/*     */       return;
/*     */     } 
/*     */     
/* 128 */     stratum.clear();
/* 129 */     this.unusedStack.add(0, this.sStack.pop());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Stratum push(ChunkMD chunkMd, BlockMD blockMD, int x, int y, int z) {
/* 145 */     return push(chunkMd, blockMD, x, y, z, null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Stratum push(ChunkMD chunkMd, BlockMD blockMD, int localX, int y, int localZ, Integer lightLevel) {
/*     */     try {
/* 164 */       Stratum stratum = allocate();
/* 165 */       stratum.set(chunkMd, blockMD, localX, y, localZ, lightLevel);
/*     */ 
/*     */       
/* 168 */       setTopY(Integer.valueOf((getTopY() == null) ? y : Math.max(getTopY().intValue(), y)));
/* 169 */       setBottomY(Integer.valueOf((getBottomY() == null) ? y : Math.min(getBottomY().intValue(), y)));
/* 170 */       setMaxLightLevel(Integer.valueOf((getMaxLightLevel() == null) ? stratum.getLightLevel() : Math.max(getMaxLightLevel().intValue(), stratum.getLightLevel())));
/* 171 */       setLightAttenuation(getLightAttenuation() + stratum.getLightOpacity());
/* 172 */       setBlocksFound(true);
/*     */ 
/*     */       
/* 175 */       if (blockMD.isWater() || blockMD.isFluid()) {
/*     */         
/* 177 */         setTopFluidY(Integer.valueOf((getTopFluidY() == null) ? y : Math.max(getTopFluidY().intValue(), y)));
/* 178 */         setBottomFluidY(Integer.valueOf((getBottomFluidY() == null) ? y : Math.min(getBottomFluidY().intValue(), y)));
/* 179 */         if (getFluidColor() == null) {
/*     */           
/* 181 */           BlockPos blockPos = chunkMd.getBlockPos(localX, y, localZ);
/* 182 */           setFluidColor(Integer.valueOf(blockMD.getBlockColor(chunkMd, blockPos)));
/*     */         } 
/*     */       } 
/*     */       
/* 186 */       return stratum;
/*     */     }
/* 188 */     catch (journeymap.client.model.ChunkMD.ChunkMissingException e) {
/*     */       
/* 190 */       throw e;
/*     */     }
/* 192 */     catch (Throwable t) {
/*     */       
/* 194 */       JMLogger.throwLogOnce("Couldn't push Stratum into stack: " + t.getMessage(), t);
/* 195 */       return null;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Stratum nextUp(IChunkRenderer renderer, boolean ignoreMiddleFluid) {
/* 208 */     Stratum stratum = null;
/*     */     
/*     */     try {
/* 211 */       stratum = this.sStack.peek();
/* 212 */       if (stratum.isUninitialized())
/*     */       {
/* 214 */         throw new IllegalStateException("Stratum wasn't initialized for Strata.nextUp()");
/*     */       }
/*     */       
/* 217 */       setLightAttenuation(Math.max(0, getLightAttenuation() - stratum.getLightOpacity()));
/*     */ 
/*     */       
/* 220 */       if (ignoreMiddleFluid && stratum.isFluid() && isFluidAbove(stratum) && !this.sStack.isEmpty()) {
/*     */         
/* 222 */         release(stratum);
/* 223 */         return nextUp(renderer, true);
/*     */       } 
/*     */       
/* 226 */       renderer.setStratumColors(stratum, getLightAttenuation(), getFluidColor(), isFluidAbove(stratum), isUnderground(), isMapCaveLighting());
/* 227 */       return stratum;
/*     */     }
/* 229 */     catch (RuntimeException t) {
/*     */       
/* 231 */       throw t;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   int depth() {
/* 242 */     return this.sStack.isEmpty() ? 0 : (getTopY().intValue() - getBottomY().intValue() + 1);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isEmpty() {
/* 252 */     return this.sStack.isEmpty();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   boolean hasFluid() {
/* 262 */     return (getTopFluidY() != null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   boolean isFluidAbove(Stratum stratum) {
/* 273 */     return (getTopFluidY() != null && getTopFluidY().intValue() > stratum.getY());
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 279 */     return "Strata{name='" + this.name + "', initialPoolSize=" + this.initialPoolSize + ", poolGrowthIncrement=" + this.poolGrowthIncrement + ", stack=" + this.sStack
/*     */ 
/*     */ 
/*     */       
/* 283 */       .size() + ", unusedStack=" + this.unusedStack
/* 284 */       .size() + ", stack=" + this.sStack
/* 285 */       .size() + ", topY=" + 
/* 286 */       getTopY() + ", bottomY=" + 
/* 287 */       getBottomY() + ", topFluidY=" + 
/* 288 */       getTopFluidY() + ", bottomFluidY=" + 
/* 289 */       getBottomFluidY() + ", maxLightLevel=" + 
/* 290 */       getMaxLightLevel() + ", fluidColor=" + 
/* 291 */       RGB.toString(getFluidColor()) + ", renderDayColor=" + 
/* 292 */       RGB.toString(getRenderDayColor()) + ", renderNightColor=" + 
/* 293 */       RGB.toString(getRenderNightColor()) + ", lightAttenuation=" + 
/* 294 */       getLightAttenuation() + "}";
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isMapCaveLighting() {
/* 305 */     return this.mapCaveLighting;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isUnderground() {
/* 315 */     return this.underground;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Integer getTopY() {
/* 325 */     return this.topY;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setTopY(Integer topY) {
/* 335 */     this.topY = topY;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Integer getBottomY() {
/* 345 */     return this.bottomY;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setBottomY(Integer bottomY) {
/* 355 */     this.bottomY = bottomY;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Integer getTopFluidY() {
/* 365 */     return this.topFluidY;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setTopFluidY(Integer topFluidY) {
/* 375 */     this.topFluidY = topFluidY;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Integer getBottomFluidY() {
/* 385 */     return this.bottomFluidY;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setBottomFluidY(Integer bottomFluidY) {
/* 395 */     this.bottomFluidY = bottomFluidY;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Integer getMaxLightLevel() {
/* 405 */     return this.maxLightLevel;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setMaxLightLevel(Integer maxLightLevel) {
/* 415 */     this.maxLightLevel = maxLightLevel;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Integer getFluidColor() {
/* 425 */     return this.fluidColor;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setFluidColor(Integer fluidColor) {
/* 435 */     this.fluidColor = fluidColor;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Integer getRenderDayColor() {
/* 445 */     return this.renderDayColor;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setRenderDayColor(Integer renderDayColor) {
/* 455 */     this.renderDayColor = renderDayColor;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Integer getRenderNightColor() {
/* 465 */     return this.renderNightColor;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setRenderNightColor(Integer renderNightColor) {
/* 475 */     this.renderNightColor = renderNightColor;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Integer getRenderCaveColor() {
/* 485 */     return this.renderCaveColor;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setRenderCaveColor(Integer renderCaveColor) {
/* 495 */     this.renderCaveColor = renderCaveColor;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getLightAttenuation() {
/* 505 */     return this.lightAttenuation;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setLightAttenuation(int lightAttenuation) {
/* 515 */     this.lightAttenuation = lightAttenuation;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isBlocksFound() {
/* 525 */     return this.blocksFound;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setBlocksFound(boolean blocksFound) {
/* 535 */     this.blocksFound = blocksFound;
/*     */   }
/*     */ }


/* Location:              C:\Users\Administrator\Downloads\journeymap-forge-1.21-6.0.0-beta.18.jar!\journeymap\client\cartography\Strata.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */