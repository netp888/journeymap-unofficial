/*     */ package journeymap.client.cartography.render;
/*     */ 
/*     */ import com.mojang.blaze3d.platform.NativeImage;
/*     */ import journeymap.client.cartography.IChunkRenderer;
/*     */ import journeymap.client.cartography.Strata;
/*     */ import journeymap.client.cartography.Stratum;
/*     */ import journeymap.client.cartography.color.RGB;
/*     */ import journeymap.client.log.JMLogger;
/*     */ import journeymap.client.log.StatTimer;
/*     */ import journeymap.client.model.BlockCoordIntPair;
/*     */ import journeymap.client.model.BlockMD;
/*     */ import journeymap.client.model.ChunkMD;
/*     */ import journeymap.client.model.MapType;
/*     */ import journeymap.client.texture.ComparableNativeImage;
/*     */ import journeymap.common.Journeymap;
/*     */ import journeymap.common.log.LogFormatter;
/*     */ import journeymap.common.nbt.RegionData;
/*     */ import net.minecraft.core.BlockPos;
/*     */ import net.minecraft.nbt.CompoundTag;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SurfaceRenderer
/*     */   extends BaseRenderer
/*     */   implements IChunkRenderer
/*     */ {
/*  34 */   protected StatTimer renderSurfaceTimer = StatTimer.get("SurfaceRenderer.renderSurface");
/*     */ 
/*     */ 
/*     */   
/*  38 */   protected StatTimer renderSurfacePrepassTimer = StatTimer.get("SurfaceRenderer.renderSurface.CavePrepass");
/*     */ 
/*     */ 
/*     */   
/*  42 */   protected Strata strata = new Strata("Surface", 40, 8, false);
/*     */ 
/*     */ 
/*     */   
/*  46 */   protected float maxDepth = 8.0F;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SurfaceRenderer() {
/*  53 */     updateOptions((ChunkMD)null, (MapType)null);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected boolean updateOptions(ChunkMD chunkMd, MapType mapType) {
/*  59 */     if (super.updateOptions(chunkMd, mapType)) {
/*     */       
/*  61 */       this.ambientColor = RGB.floats(this.tweakSurfaceAmbientColor);
/*  62 */       return true;
/*     */     } 
/*  64 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public int getBlockHeight(ChunkMD chunkMd, BlockPos blockPos) {
/*  70 */     Integer y = getBlockHeight(chunkMd, blockPos.getX() & 0xF, (Integer)null, blockPos.getZ() & 0xF, (Integer)null, (Integer)null);
/*  71 */     return (y == null) ? blockPos.getY() : y.intValue();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean render(ComparableNativeImage dayChunkImage, RegionData regionData, ChunkMD chunkMd, Integer ignored) {
/*  80 */     return render(dayChunkImage, (NativeImage)null, regionData, chunkMd, (Integer)null, false);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean render(ComparableNativeImage dayChunkImage, NativeImage nightChunkImage, RegionData regionData, ChunkMD chunkMd) {
/*  93 */     return render(dayChunkImage, nightChunkImage, regionData, chunkMd, (Integer)null, false);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public synchronized boolean render(ComparableNativeImage dayChunkImage, NativeImage nightChunkImage, RegionData regionData, ChunkMD chunkMd, Integer vSlice, boolean cavePrePass) {
/* 108 */     StatTimer timer = cavePrePass ? this.renderSurfacePrepassTimer : this.renderSurfaceTimer;
/*     */ 
/*     */     
/*     */     try {
/* 112 */       timer.start();
/*     */       
/* 114 */       updateOptions(chunkMd, MapType.from(MapType.Name.surface, null, chunkMd.getDimension()));
/*     */ 
/*     */       
/* 117 */       if (!hasSlopes(chunkMd, vSlice))
/*     */       {
/* 119 */         populateSlopes(chunkMd, vSlice, getSlopes(chunkMd, vSlice));
/*     */       }
/*     */ 
/*     */       
/* 123 */       return renderSurface((NativeImage)dayChunkImage, nightChunkImage, regionData, chunkMd, vSlice, cavePrePass);
/*     */     }
/* 125 */     catch (Throwable t) {
/*     */       
/* 127 */       JMLogger.throwLogOnce("Chunk Error", t);
/* 128 */       return false;
/*     */     }
/*     */     finally {
/*     */       
/* 132 */       this.strata.reset();
/* 133 */       timer.stop();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected boolean renderSurface(NativeImage dayChunkImage, NativeImage nightChunkImage, RegionData regionData, ChunkMD chunkMd, Integer vSlice, boolean cavePrePass) {
/* 151 */     boolean chunkOk = false;
/*     */ 
/*     */     
/*     */     try {
/* 155 */       int sliceMaxY = 0;
/*     */       
/* 157 */       if (cavePrePass) {
/*     */         
/* 159 */         int[] sliceBounds = getVSliceBounds(chunkMd, vSlice);
/* 160 */         sliceMaxY = sliceBounds[1];
/*     */       } 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 166 */       CompoundTag chunkNbt = regionData.getChunkNbt(chunkMd.getCoord());
/* 167 */       for (int x = 0; x < 16; x++) {
/*     */ 
/*     */         
/* 170 */         for (int z = 0; z < 16; z++) {
/*     */ 
/*     */ 
/*     */           
/* 174 */           CompoundTag blockNbt = regionData.getBlockDataFromBlockPos(chunkMd.getCoord(), chunkNbt, x, z);
/* 175 */           this.strata.reset();
/* 176 */           int blockHeight = getBlockHeight(chunkMd, x, (Integer)null, z, (Integer)null, (Integer)null).intValue();
/*     */           
/* 178 */           int upperY = Math.max(chunkMd.getMinY().intValue(), chunkMd.getPrecipitationHeight(x, z));
/*     */ 
/*     */           
/* 181 */           int lowerY = Math.max(chunkMd.getMinY().intValue(), blockHeight);
/*     */           
/* 183 */           BlockMD blockMd = chunkMd.getBlockMD(x, blockHeight, z);
/*     */           
/* 185 */           if ((upperY == chunkMd.getMinY().intValue() || lowerY < chunkMd.getMinY().intValue()) && blockMd.getBlockState().isAir()) {
/*     */             
/* 187 */             int dayVoid = paintVoidBlock(dayChunkImage, x, z);
/* 188 */             regionData.setBlockColor(blockNbt, dayVoid, MapType.Name.day);
/* 189 */             if (!cavePrePass && nightChunkImage != null) {
/*     */               
/* 191 */               int nightVoid = paintVoidBlock(nightChunkImage, x, z);
/* 192 */               regionData.setBlockColor(blockNbt, nightVoid, MapType.Name.night);
/*     */             } 
/* 194 */             chunkOk = true;
/*     */ 
/*     */ 
/*     */           
/*     */           }
/* 199 */           else if (cavePrePass && upperY > sliceMaxY && (upperY - sliceMaxY) > this.maxDepth) {
/*     */             
/* 201 */             chunkOk = true;
/* 202 */             paintBlackBlock(dayChunkImage, x, z);
/*     */           }
/*     */           else {
/*     */             
/* 206 */             boolean showSlope = !chunkMd.getBlockMD(x, lowerY, z).hasNoShadow();
/*     */             
/* 208 */             if (this.mapBathymetry) {
/*     */               
/* 210 */               Integer[][] waterHeights = getFluidHeights(chunkMd, null);
/* 211 */               Integer waterHeight = waterHeights[z][x];
/* 212 */               if (waterHeight != null)
/*     */               {
/* 214 */                 upperY = waterHeight.intValue();
/*     */               }
/*     */             } 
/*     */ 
/*     */             
/* 219 */             buildStrata(this.strata, upperY, chunkMd, regionData, blockNbt, x, lowerY, z);
/*     */             
/* 221 */             BlockPos pos = chunkMd.getBlockPos(x, upperY, z);
/* 222 */             regionData.setBiome(blockNbt, chunkMd.getBiome(pos));
/* 223 */             regionData.setY(blockNbt, ((this.strata.getTopY() == null) ? regionData.getTopY(pos) : this.strata.getTopY()).intValue());
/*     */             
/* 225 */             chunkOk = (paintStrata(this.strata, dayChunkImage, nightChunkImage, regionData, blockNbt, chunkMd, x, z, showSlope, cavePrePass) || chunkOk);
/*     */           } 
/*     */         } 
/*     */       } 
/* 229 */       regionData.writeChunk(chunkMd.getCoord(), chunkNbt);
/*     */     }
/* 231 */     catch (Throwable t) {
/*     */       
/* 233 */       Journeymap.getLogger().warn("Error rendering surface: ", t);
/*     */     }
/*     */     finally {
/*     */       
/* 237 */       this.strata.reset();
/*     */     } 
/* 239 */     return chunkOk;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getSurfaceBlockHeight(ChunkMD chunkMd, int x, int z, BlockCoordIntPair offset, int defaultVal) {
/* 254 */     ChunkMD targetChunkMd = getOffsetChunk(chunkMd, x, z, offset);
/* 255 */     int newX = ((chunkMd.getCoord()).x << 4) + x + offset.x & 0xF;
/* 256 */     int newZ = ((chunkMd.getCoord()).z << 4) + z + offset.z & 0xF;
/*     */     
/* 258 */     if (targetChunkMd != null) {
/*     */       
/* 260 */       Integer height = getBlockHeight(targetChunkMd, newX, (Integer)null, newZ, (Integer)null, (Integer)null);
/* 261 */       if (height == null)
/*     */       {
/* 263 */         return defaultVal;
/*     */       }
/*     */ 
/*     */       
/* 267 */       return height.intValue();
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 272 */     return defaultVal;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Integer getBlockHeight(ChunkMD chunkMd, int localX, Integer vSlice, int localZ, Integer sliceMinY, Integer sliceMaxY) {
/* 282 */     Integer[][] heights = getHeights(chunkMd, null);
/* 283 */     if (heights == null)
/*     */     {
/*     */       
/* 286 */       return null;
/*     */     }
/*     */ 
/*     */     
/* 290 */     Integer y = heights[localX][localZ];
/*     */     
/* 292 */     if (y != null)
/*     */     {
/*     */       
/* 295 */       return y;
/*     */     }
/*     */ 
/*     */     
/* 299 */     y = Integer.valueOf(Math.max(chunkMd.getMinY().intValue(), chunkMd.getPrecipitationHeight(localX, localZ)));
/*     */     
/* 301 */     if (y.equals(chunkMd.getMinY()))
/*     */     {
/* 303 */       return chunkMd.getMinY();
/*     */     }
/*     */ 
/*     */     
/* 307 */     boolean setFluidHeight = true;
/*     */ 
/*     */     
/*     */     try {
/* 311 */       while (y.intValue() > chunkMd.getMinY().intValue())
/*     */       {
/* 313 */         BlockMD blockMD = BlockMD.getBlockMDFromChunkLocal(chunkMd, localX, y.intValue(), localZ);
/*     */         
/* 315 */         if (blockMD.isIgnore()) {
/*     */           
/* 317 */           Integer integer = y; y = Integer.valueOf(y.intValue() - 1);
/*     */           
/*     */           continue;
/*     */         } 
/* 321 */         if (blockMD.isWater() || blockMD.isFluid()) {
/*     */           
/* 323 */           if (!this.mapBathymetry) {
/*     */             break;
/*     */           }
/*     */           
/* 327 */           if (setFluidHeight) {
/*     */             
/* 329 */             getFluidHeights(chunkMd, null)[localZ][localX] = y;
/* 330 */             setFluidHeight = false;
/*     */           } 
/* 332 */           Integer integer = y; y = Integer.valueOf(y.intValue() - 1);
/*     */           
/*     */           continue;
/*     */         } 
/* 336 */         if (blockMD.hasTransparency() && this.mapTransparency) {
/*     */           
/* 338 */           Integer integer = y; y = Integer.valueOf(y.intValue() - 1);
/*     */           
/*     */           continue;
/*     */         } 
/* 342 */         if (blockMD.isLava()) {
/*     */           break;
/*     */         }
/*     */ 
/*     */         
/* 347 */         if (blockMD.hasNoShadow())
/*     */         {
/* 349 */           Integer integer = y; y = Integer.valueOf(y.intValue() - 1);
/*     */         }
/*     */       
/*     */       }
/*     */     
/*     */     }
/* 355 */     catch (Exception e) {
/*     */       
/* 357 */       Journeymap.getLogger().warn(String.format("Couldn't get safe surface block height for %s coords %s,%s: %s", new Object[] { chunkMd, Integer.valueOf(localX), Integer.valueOf(localZ), LogFormatter.toString(e) }));
/*     */     } 
/*     */     
/* 360 */     y = Integer.valueOf(Math.max(chunkMd.getMinY().intValue(), y.intValue()));
/*     */     
/* 362 */     heights[localX][localZ] = y;
/*     */     
/* 364 */     return y;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void buildStrata(Strata strata, int upperY, ChunkMD chunkMd, RegionData regionData, CompoundTag blockNbt, int x, int lowerY, int z) {
/* 383 */     while (upperY > lowerY) {
/*     */       
/* 385 */       BlockMD topBlockMd = BlockMD.getBlockMDFromChunkLocal(chunkMd, x, upperY, z);
/* 386 */       if (!topBlockMd.isIgnore()) {
/*     */         
/* 388 */         if (topBlockMd.hasTransparency()) {
/*     */           
/* 390 */           strata.push(chunkMd, topBlockMd, x, upperY, z);
/* 391 */           if (!this.mapTransparency) {
/*     */             break;
/*     */           }
/*     */         } 
/*     */ 
/*     */         
/* 397 */         if (topBlockMd.hasNoShadow()) {
/*     */           
/* 399 */           lowerY = upperY;
/*     */           break;
/*     */         } 
/*     */       } 
/* 403 */       upperY--;
/*     */     } 
/*     */     
/* 406 */     if (this.mapTransparency || strata.isEmpty())
/*     */     {
/* 408 */       while (lowerY >= chunkMd.getMinY().intValue()) {
/*     */         
/* 410 */         if ((upperY - lowerY) >= this.maxDepth) {
/*     */           break;
/*     */         }
/*     */         
/* 414 */         BlockMD bottomBlockMd = BlockMD.getBlockMDFromChunkLocal(chunkMd, x, lowerY, z);
/*     */         
/* 416 */         if (!bottomBlockMd.isIgnore()) {
/*     */           
/* 418 */           strata.push(chunkMd, bottomBlockMd, x, lowerY, z);
/*     */           
/* 420 */           if (!bottomBlockMd.hasTransparency() || !this.mapTransparency) {
/*     */             break;
/*     */           }
/*     */         } 
/*     */         
/* 425 */         lowerY--;
/*     */       } 
/*     */     }
/* 428 */     regionData.setBlockState(blockNbt, chunkMd, chunkMd.getBlockPos(x, upperY, z));
/* 429 */     regionData.setBlockState(blockNbt, chunkMd, chunkMd.getBlockPos(x, lowerY, z));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected boolean paintStrata(Strata strata, NativeImage dayChunkImage, NativeImage nightChunkImage, RegionData regionData, CompoundTag blockNbt, ChunkMD chunkMd, int x, int z, boolean showSlope, boolean cavePrePass) {
/* 448 */     Integer y = strata.getTopY();
/* 449 */     if (strata.isEmpty() || y == null) {
/*     */       
/* 451 */       y = Integer.valueOf(0);
/* 452 */       if (dayChunkImage != null)
/*     */       {
/* 454 */         paintBadBlock(dayChunkImage, x, y.intValue(), z);
/*     */       }
/* 456 */       if (nightChunkImage != null)
/*     */       {
/* 458 */         paintBadBlock(nightChunkImage, x, y.intValue(), z);
/*     */       }
/* 460 */       return false;
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/*     */     try {
/* 466 */       while (!strata.isEmpty()) {
/*     */         
/* 468 */         Stratum stratum = strata.nextUp(this, true);
/* 469 */         if (strata.getRenderDayColor() == null || strata.getRenderNightColor() == null) {
/*     */           
/* 471 */           strata.setRenderDayColor(Integer.valueOf(stratum.getDayColor()));
/* 472 */           if (!cavePrePass)
/*     */           {
/* 474 */             strata.setRenderNightColor(Integer.valueOf(stratum.getNightColor()));
/*     */           }
/*     */         }
/*     */         else {
/*     */           
/* 479 */           strata.setRenderDayColor(Integer.valueOf(RGB.blendWith(strata.getRenderDayColor().intValue(), stratum.getDayColor(), stratum.getBlockMD().getAlpha())));
/* 480 */           if (!cavePrePass)
/*     */           {
/* 482 */             strata.setRenderNightColor(Integer.valueOf(RGB.blendWith(strata.getRenderNightColor().intValue(), stratum.getNightColor(), stratum.getBlockMD().getAlpha())));
/*     */           }
/*     */         } 
/*     */         
/* 486 */         strata.release(stratum);
/*     */       } 
/*     */ 
/*     */ 
/*     */       
/* 491 */       if (strata.getRenderDayColor() == null) {
/*     */         
/* 493 */         paintBadBlock(dayChunkImage, x, y.intValue(), z);
/* 494 */         paintBadBlock(nightChunkImage, x, y.intValue(), z);
/* 495 */         return false;
/*     */       } 
/*     */       
/* 498 */       if (nightChunkImage != null)
/*     */       {
/*     */         
/* 501 */         if (strata.getRenderNightColor() == null) {
/*     */           
/* 503 */           paintBadBlock(nightChunkImage, x, y.intValue(), z);
/* 504 */           return false;
/*     */         } 
/*     */       }
/*     */ 
/*     */       
/* 509 */       if (showSlope) {
/*     */         
/* 511 */         float slope = getSlope(chunkMd, x, null, z);
/* 512 */         if (slope != 1.0F) {
/*     */           
/* 514 */           strata.setRenderDayColor(Integer.valueOf(RGB.bevelSlope(strata.getRenderDayColor().intValue(), slope)));
/* 515 */           if (!cavePrePass)
/*     */           {
/* 517 */             strata.setRenderNightColor(Integer.valueOf(RGB.bevelSlope(strata.getRenderNightColor().intValue(), slope)));
/*     */           }
/*     */         } 
/*     */       } 
/*     */       
/* 522 */       int dayColor = paintBlock(dayChunkImage, x, z, strata.getRenderDayColor().intValue());
/* 523 */       regionData.setBlockColor(blockNbt, dayColor, MapType.Name.day);
/* 524 */       if (nightChunkImage != null)
/*     */       {
/* 526 */         int nightColor = paintBlock(nightChunkImage, x, z, strata.getRenderNightColor().intValue());
/* 527 */         regionData.setBlockColor(blockNbt, nightColor, MapType.Name.night);
/*     */       }
/*     */     
/* 530 */     } catch (RuntimeException e) {
/*     */       
/* 532 */       throw e;
/*     */     } 
/*     */     
/* 535 */     return true;
/*     */   }
/*     */ }


/* Location:              C:\Users\Administrator\Downloads\journeymap-forge-1.21-6.0.0-beta.18.jar!\journeymap\client\cartography\render\SurfaceRenderer.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */