/*     */ package journeymap.client.cartography.render;
/*     */ 
/*     */ import com.mojang.blaze3d.platform.NativeImage;
/*     */ import journeymap.client.JourneymapClient;
/*     */ import journeymap.client.cartography.IChunkRenderer;
/*     */ import journeymap.client.cartography.color.RGB;
/*     */ import journeymap.client.log.JMLogger;
/*     */ import journeymap.client.log.StatTimer;
/*     */ import journeymap.client.model.BlockCoordIntPair;
/*     */ import journeymap.client.model.BlockFlag;
/*     */ import journeymap.client.model.BlockMD;
/*     */ import journeymap.client.model.ChunkMD;
/*     */ import journeymap.client.model.MapType;
/*     */ import journeymap.client.properties.TopoProperties;
/*     */ import journeymap.client.texture.ComparableNativeImage;
/*     */ import journeymap.client.world.JmBlockAccess;
/*     */ import journeymap.common.Journeymap;
/*     */ import journeymap.common.log.LogFormatter;
/*     */ import journeymap.common.nbt.RegionData;
/*     */ import net.minecraft.core.BlockPos;
/*     */ import net.minecraft.nbt.CompoundTag;
/*     */ import org.apache.logging.log4j.Level;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class TopoRenderer
/*     */   extends BaseRenderer
/*     */   implements IChunkRenderer
/*     */ {
/*     */   private static final String PROP_SHORE = "isShore";
/*     */   private Integer[] waterPalette;
/*     */   private Integer[] landPalette;
/*     */   private int waterPaletteRange;
/*     */   private int landPaletteRange;
/*     */   private long lastTopoFileUpdate;
/*  41 */   protected StatTimer renderTopoTimer = StatTimer.get("TopoRenderer.renderSurface");
/*     */   
/*     */   private Integer landContourColor;
/*     */   
/*     */   private Integer waterContourColor;
/*     */   
/*     */   private double waterContourInterval;
/*     */   
/*     */   private double landContourInterval;
/*     */   
/*     */   TopoProperties topoProperties;
/*     */ 
/*     */   
/*     */   public TopoRenderer() {
/*  55 */     this.primarySlopeOffsets.clear();
/*  56 */     this.secondarySlopeOffsets.clear();
/*     */     
/*  58 */     this.primarySlopeOffsets.add(new BlockCoordIntPair(0, -1));
/*  59 */     this.primarySlopeOffsets.add(new BlockCoordIntPair(-1, 0));
/*  60 */     this.primarySlopeOffsets.add(new BlockCoordIntPair(0, 1));
/*  61 */     this.primarySlopeOffsets.add(new BlockCoordIntPair(1, 0));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected boolean updateOptions(ChunkMD chunkMd, MapType mapType) {
/*  71 */     boolean needUpdate = false;
/*  72 */     if (super.updateOptions(chunkMd, mapType)) {
/*     */       
/*  74 */       double worldHeight = JmBlockAccess.INSTANCE.getMaxBuildHeight();
/*  75 */       if (chunkMd != null)
/*     */       {
/*  77 */         worldHeight = chunkMd.getWorld().getMaxBuildHeight();
/*     */       }
/*     */       
/*  80 */       this.topoProperties = JourneymapClient.getInstance().getTopoProperties();
/*  81 */       if (System.currentTimeMillis() - this.lastTopoFileUpdate > 5000L && this.lastTopoFileUpdate < this.topoProperties.lastModified()) {
/*     */         
/*  83 */         needUpdate = true;
/*  84 */         this.topoProperties.load();
/*  85 */         this.lastTopoFileUpdate = this.topoProperties.lastModified();
/*     */         
/*  87 */         this.landContourColor = this.topoProperties.getLandContourColor();
/*  88 */         this.waterContourColor = this.topoProperties.getWaterContourColor();
/*     */         
/*  90 */         this.waterPalette = this.topoProperties.getWaterColors();
/*  91 */         this.waterPaletteRange = this.waterPalette.length - 1;
/*  92 */         this.waterContourInterval = worldHeight / Math.max(1, this.waterPalette.length);
/*     */         
/*  94 */         this.landPalette = this.topoProperties.getLandColors();
/*     */         
/*  96 */         this.landPaletteRange = this.landPalette.length - 1;
/*  97 */         this.landContourInterval = worldHeight / Math.max(1, this.landPalette.length);
/*     */       } 
/*     */       
/* 100 */       if (chunkMd != null) {
/*     */         
/* 102 */         Long lastUpdate = (Long)chunkMd.getProperty("lastTopoPropFileUpdate", Long.valueOf(this.lastTopoFileUpdate));
/* 103 */         if (needUpdate || lastUpdate.longValue() < this.lastTopoFileUpdate) {
/*     */           
/* 105 */           needUpdate = true;
/* 106 */           chunkMd.resetBlockData(getCurrentMapType());
/*     */         } 
/* 108 */         chunkMd.setProperty("lastTopoPropFileUpdate", Long.valueOf(this.lastTopoFileUpdate));
/*     */       } 
/*     */     } 
/*     */     
/* 112 */     return needUpdate;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean render(ComparableNativeImage chunkImage, RegionData regionData, ChunkMD chunkMd, Integer vSlice) {
/* 121 */     StatTimer timer = this.renderTopoTimer;
/*     */     
/* 123 */     if (this.landPalette == null || this.landPalette.length < 1 || this.waterPalette == null || this.waterPalette.length < 1)
/*     */     {
/* 125 */       return false;
/*     */     }
/*     */ 
/*     */     
/*     */     try {
/* 130 */       timer.start();
/*     */       
/* 132 */       updateOptions(chunkMd, MapType.from(MapType.Name.topo, null, chunkMd.getDimension()));
/*     */ 
/*     */       
/* 135 */       if (!hasSlopes(chunkMd, null))
/*     */       {
/* 137 */         populateSlopes(chunkMd);
/*     */       }
/*     */ 
/*     */       
/* 141 */       return renderSurface((NativeImage)chunkImage, regionData, chunkMd, vSlice, false);
/*     */     }
/* 143 */     catch (Throwable t) {
/*     */       
/* 145 */       JMLogger.throwLogOnce("Chunk Error", t);
/* 146 */       return false;
/*     */     
/*     */     }
/*     */     finally {
/*     */       
/* 151 */       timer.stop();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected boolean renderSurface(NativeImage chunkImage, RegionData regionData, ChunkMD chunkMd, Integer vSlice, boolean cavePrePass) {
/* 160 */     boolean chunkOk = false;
/*     */ 
/*     */     
/*     */     try {
/* 164 */       CompoundTag chunkNbt = regionData.getChunkNbt(chunkMd.getCoord());
/* 165 */       for (int x = 0; x < 16; x++) {
/*     */ 
/*     */         
/* 168 */         for (int z = 0; z < 16; z++) {
/*     */           
/* 170 */           CompoundTag blockNbt = regionData.getBlockDataFromBlockPos(chunkMd.getCoord(), chunkNbt, x, z);
/*     */           
/* 172 */           BlockMD topBlockMd = null;
/* 173 */           int y = Math.max(chunkMd.getMinY().intValue(), getBlockHeight(chunkMd, x, (Integer)null, z, (Integer)null, (Integer)null).intValue());
/*     */           
/* 175 */           if (this.mapBathymetry) {
/*     */             
/* 177 */             Integer[][] waterHeights = getFluidHeights(chunkMd, null);
/* 178 */             if (waterHeights[z] != null && waterHeights[z][x] != null)
/*     */             {
/* 180 */               y = getFluidHeights(chunkMd, null)[z][x].intValue();
/*     */             }
/*     */           } 
/*     */           
/* 184 */           topBlockMd = chunkMd.getBlockMD(x, y, z);
/* 185 */           if (topBlockMd == null) {
/*     */             
/* 187 */             paintBadBlock(chunkImage, x, y, z);
/*     */           }
/*     */           else {
/*     */             
/* 191 */             chunkOk = (paintContour(chunkImage, regionData, blockNbt, chunkMd, topBlockMd, x, y, z) || chunkOk);
/* 192 */             regionData.setBiome(blockNbt, chunkMd.getBiome(chunkMd.getBlockPos(x, y, z)));
/* 193 */             regionData.setY(blockNbt, y);
/*     */           } 
/*     */         } 
/* 196 */       }  regionData.writeChunk(chunkMd.getCoord(), chunkNbt);
/*     */     }
/* 198 */     catch (Throwable t) {
/*     */       
/* 200 */       Journeymap.getLogger().log(Level.WARN, "Error in renderSurface: " + LogFormatter.toString(t));
/*     */     } 
/*     */     
/* 203 */     return chunkOk;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Integer getBlockHeight(ChunkMD chunkMd, int localX, Integer vSlice, int localZ, Integer sliceMinY, Integer sliceMaxY) {
/* 209 */     Integer[][] heights = getHeights(chunkMd, null);
/* 210 */     if (heights == null)
/*     */     {
/*     */       
/* 213 */       return null;
/*     */     }
/*     */     
/* 216 */     Integer y = heights[localX][localZ];
/* 217 */     if (y != null)
/*     */     {
/*     */       
/* 220 */       return y;
/*     */     }
/*     */ 
/*     */     
/* 224 */     y = Integer.valueOf(Math.max(chunkMd.getMinY().intValue(), chunkMd.getPrecipitationHeight(localX, localZ)));
/*     */ 
/*     */     
/*     */     try {
/* 228 */       BlockMD blockMD = BlockMD.getBlockMDFromChunkLocal(chunkMd, localX, y.intValue(), localZ);
/* 229 */       while (y.intValue() > chunkMd.getMinY().intValue())
/*     */       {
/* 231 */         if (blockMD.isWater() || blockMD.isIce()) {
/*     */           
/* 233 */           if (this.mapBathymetry)
/*     */           {
/* 235 */             getFluidHeights(chunkMd, null)[localZ][localX] = y;
/*     */           }
/*     */           else
/*     */           {
/*     */             break;
/*     */           }
/*     */         
/* 242 */         } else if (!blockMD.hasAnyFlag(BlockMD.FlagsPlantAndCrop)) {
/*     */ 
/*     */ 
/*     */           
/* 246 */           if (!blockMD.isIgnore() && !blockMD.hasFlag(BlockFlag.NoTopo)) {
/*     */             break;
/*     */           }
/*     */         } 
/* 250 */         Integer integer = y; y = Integer.valueOf(y.intValue() - 1);
/* 251 */         blockMD = BlockMD.getBlockMDFromChunkLocal(chunkMd, localX, y.intValue(), localZ);
/*     */       }
/*     */     
/* 254 */     } catch (Exception e) {
/*     */       
/* 256 */       Journeymap.getLogger().debug("Couldn't get safe surface block height at " + localX + "," + localZ + ": " + String.valueOf(e));
/*     */     } 
/*     */     
/* 259 */     y = Integer.valueOf(Math.max(chunkMd.getMinY().intValue(), y.intValue()));
/*     */     
/* 261 */     heights[localX][localZ] = y;
/*     */     
/* 263 */     return y;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected Float[][] populateSlopes(ChunkMD chunkMd) {
/* 271 */     Float[][] slopes = getSlopes(chunkMd, null);
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 276 */     float nearZero = 1.0E-4F;
/* 277 */     for (int z = 0; z < 16; z++) {
/*     */       
/* 279 */       for (int x = 0; x < 16; x++) {
/*     */         Float slope; double contourInterval;
/* 281 */         float h = getBlockHeight(chunkMd, x, (Integer)null, z, (Integer)null, (Integer)null).intValue();
/*     */         
/* 283 */         BlockMD blockMD = BlockMD.getBlockMDFromChunkLocal(chunkMd, x, (int)h, z);
/*     */         
/* 285 */         boolean isWater = false;
/*     */         
/* 287 */         if (blockMD.isWater() || blockMD.isIce() || (this.mapBathymetry && getFluidHeights(chunkMd, null)[z][x] != null)) {
/*     */           
/* 289 */           isWater = true;
/* 290 */           contourInterval = this.waterContourInterval;
/*     */         }
/*     */         else {
/*     */           
/* 294 */           contourInterval = this.landContourInterval;
/*     */         } 
/*     */         
/* 297 */         float[] heights = new float[this.primarySlopeOffsets.size()];
/* 298 */         Float lastOffsetHeight = null;
/* 299 */         boolean flatOffsets = true;
/* 300 */         boolean isShore = false;
/* 301 */         for (int i = 0; i < heights.length; i++) {
/*     */           
/* 303 */           BlockCoordIntPair offset = this.primarySlopeOffsets.get(i);
/*     */ 
/*     */           
/* 306 */           float offsetHeight = getOffsetBlockHeight(chunkMd, x, null, z, null, null, offset, (int)h);
/*     */ 
/*     */           
/* 309 */           if (isWater && !isShore) {
/*     */ 
/*     */             
/* 312 */             ChunkMD targetChunkMd = getOffsetChunk(chunkMd, x, z, offset);
/* 313 */             int newX = ((chunkMd.getCoord()).x << 4) + x + offset.x & 0xF;
/* 314 */             int newZ = ((chunkMd.getCoord()).z << 4) + z + offset.z & 0xF;
/*     */             
/* 316 */             if (targetChunkMd != null)
/*     */             {
/* 318 */               if (this.mapBathymetry && this.mapBathymetry && getFluidHeights(chunkMd, null)[z][x] == null) {
/*     */                 
/* 320 */                 isShore = true;
/*     */               }
/*     */               else {
/*     */                 
/* 324 */                 int ceiling = targetChunkMd.ceiling(newX, newZ);
/* 325 */                 BlockMD offsetBlock = targetChunkMd.getBlockMD(newX, ceiling, newZ);
/* 326 */                 if (!offsetBlock.isWater() && !offsetBlock.isIce())
/*     */                 {
/* 328 */                   isShore = true;
/*     */                 }
/*     */               } 
/*     */             }
/*     */           } 
/*     */ 
/*     */           
/* 335 */           offsetHeight = (float)Math.max(nearZero, offsetHeight - offsetHeight % contourInterval);
/* 336 */           heights[i] = offsetHeight;
/*     */           
/* 338 */           if (lastOffsetHeight == null) {
/*     */             
/* 340 */             lastOffsetHeight = Float.valueOf(offsetHeight);
/*     */           }
/* 342 */           else if (flatOffsets) {
/*     */             
/* 344 */             flatOffsets = (lastOffsetHeight.floatValue() == offsetHeight);
/*     */           } 
/*     */         } 
/*     */         
/* 348 */         if (isWater)
/*     */         {
/* 350 */           getShore(chunkMd)[z][x] = Boolean.valueOf(isShore);
/*     */         }
/*     */ 
/*     */ 
/*     */         
/* 355 */         h = (float)Math.max(nearZero, h - h % contourInterval);
/*     */         
/* 357 */         if (flatOffsets) {
/*     */           
/* 359 */           slope = Float.valueOf(1.0F);
/*     */         }
/*     */         else {
/*     */           
/* 363 */           slope = Float.valueOf(0.0F);
/* 364 */           for (float offsetHeight : heights)
/*     */           {
/* 366 */             slope = Float.valueOf(slope.floatValue() + h / offsetHeight);
/*     */           }
/* 368 */           slope = Float.valueOf(slope.floatValue() / heights.length);
/*     */         } 
/*     */         
/* 371 */         if (slope.isNaN() || slope.isInfinite())
/*     */         {
/*     */           
/* 374 */           slope = Float.valueOf(1.0F);
/*     */         }
/*     */         
/* 377 */         slopes[x][z] = slope;
/*     */       } 
/*     */     } 
/* 380 */     return slopes;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public int getBlockHeight(ChunkMD chunkMd, BlockPos blockPos) {
/* 386 */     return chunkMd.getPrecipitationHeight(blockPos);
/*     */   }
/*     */ 
/*     */   
/*     */   protected boolean paintContour(NativeImage chunkImage, RegionData regionData, CompoundTag blockNbt, ChunkMD chunkMd, BlockMD topBlockMd, int x, int y, int z) {
/* 391 */     if (!chunkMd.hasChunk())
/*     */     {
/* 393 */       return false;
/*     */     }
/*     */     
/*     */     try {
/*     */       Integer color;
/*     */       
/* 399 */       float slope = getSlope(chunkMd, x, null, z);
/* 400 */       boolean isWater = (topBlockMd.isWater() || topBlockMd.isIce());
/*     */ 
/*     */       
/* 403 */       if (slope > 1.0F && this.waterContourColor != null && this.landContourColor != null) {
/*     */ 
/*     */         
/* 406 */         color = isWater ? this.waterContourColor : this.landContourColor;
/*     */ 
/*     */ 
/*     */       
/*     */       }
/* 411 */       else if (topBlockMd.isLava()) {
/*     */ 
/*     */         
/* 414 */         color = Integer.valueOf(topBlockMd.getTextureColor());
/*     */       }
/* 416 */       else if (isWater) {
/*     */         
/* 418 */         if (getShore(chunkMd)[z][x] == Boolean.TRUE && this.waterContourColor != null)
/*     */         {
/*     */           
/* 421 */           color = this.waterContourColor;
/*     */         
/*     */         }
/*     */         else
/*     */         {
/* 426 */           int index = (int)Math.floor((y - y % this.waterContourInterval) / this.waterContourInterval);
/*     */ 
/*     */           
/* 429 */           index = Math.max(0, Math.min(index, this.waterPaletteRange));
/* 430 */           color = this.waterPalette[index];
/*     */ 
/*     */           
/* 433 */           if (slope < 1.0F)
/*     */           {
/* 435 */             color = Integer.valueOf(RGB.adjustBrightness(color.intValue(), 0.9F));
/*     */           }
/*     */         }
/*     */       
/*     */       }
/*     */       else {
/*     */         
/* 442 */         int index = (int)Math.floor((y - y % this.landContourInterval) / this.landContourInterval);
/*     */ 
/*     */         
/* 445 */         index = Math.max(0, Math.min(index, this.landPaletteRange));
/* 446 */         color = this.landPalette[index];
/*     */ 
/*     */         
/* 449 */         if (slope < 1.0F && this.waterContourColor != null && this.landContourColor != null)
/*     */         {
/* 451 */           color = Integer.valueOf(RGB.adjustBrightness(color.intValue(), 0.85F));
/*     */         }
/*     */       } 
/*     */ 
/*     */       
/* 456 */       int blockColor = paintBlock(chunkImage, x, z, color.intValue());
/* 457 */       regionData.setBlockState(blockNbt, chunkMd, chunkMd.getBlockPos(x, y, z));
/* 458 */       regionData.setBlockColor(blockNbt, blockColor, MapType.Name.topo);
/*     */     }
/* 460 */     catch (Exception e) {
/*     */       
/* 462 */       e.printStackTrace();
/*     */     } 
/*     */     
/* 465 */     return true;
/*     */   }
/*     */ 
/*     */   
/*     */   protected final Boolean[][] getShore(ChunkMD chunkMd) {
/* 470 */     return (Boolean[][])chunkMd.getBlockDataBooleans(getCurrentMapType()).get("isShore");
/*     */   }
/*     */ 
/*     */   
/*     */   protected final boolean hasShore(ChunkMD chunkMd) {
/* 475 */     return chunkMd.getBlockDataBooleans(getCurrentMapType()).has("isShore");
/*     */   }
/*     */ 
/*     */   
/*     */   protected final void resetShore(ChunkMD chunkMd) {
/* 480 */     chunkMd.getBlockDataBooleans(getCurrentMapType()).clear("isShore");
/*     */   }
/*     */ }


/* Location:              C:\Users\Administrator\Downloads\journeymap-forge-1.21-6.0.0-beta.18.jar!\journeymap\client\cartography\render\TopoRenderer.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */