/*    */ package journeymap.client.cartography.render;
/*    */ 
/*    */ import journeymap.client.cartography.IChunkRenderer;
/*    */ import journeymap.client.cartography.color.RGB;
/*    */ import journeymap.client.model.ChunkMD;
/*    */ import journeymap.client.model.MapType;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class EndSurfaceRenderer
/*    */   extends SurfaceRenderer
/*    */   implements IChunkRenderer
/*    */ {
/*    */   protected boolean updateOptions(ChunkMD chunkMd, MapType mapType) {
/* 30 */     if (super.updateOptions(chunkMd, mapType)) {
/*    */       
/* 32 */       this.ambientColor = RGB.floats(this.tweakEndAmbientColor);
/* 33 */       this.tweakMoonlightLevel = 5.0F;
/* 34 */       return true;
/*    */     } 
/* 36 */     return false;
/*    */   }
/*    */ }


/* Location:              C:\Users\Administrator\Downloads\journeymap-forge-1.21-6.0.0-beta.18.jar!\journeymap\client\cartography\render\EndSurfaceRenderer.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */