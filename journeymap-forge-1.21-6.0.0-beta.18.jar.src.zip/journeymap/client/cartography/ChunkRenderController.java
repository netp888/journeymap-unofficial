/*     */ package journeymap.client.cartography;
/*     */ 
/*     */ import com.mojang.blaze3d.platform.NativeImage;
/*     */ import journeymap.client.JourneymapClient;
/*     */ import journeymap.client.cartography.render.BaseRenderer;
/*     */ import journeymap.client.cartography.render.BiomeRenderer;
/*     */ import journeymap.client.cartography.render.CaveRenderer;
/*     */ import journeymap.client.cartography.render.EndCaveRenderer;
/*     */ import journeymap.client.cartography.render.EndSurfaceRenderer;
/*     */ import journeymap.client.cartography.render.NetherCaveRenderer;
/*     */ import journeymap.client.cartography.render.NetherSurfaceRenderer;
/*     */ import journeymap.client.cartography.render.SurfaceRenderer;
/*     */ import journeymap.client.cartography.render.TopoRenderer;
/*     */ import journeymap.client.model.ChunkMD;
/*     */ import journeymap.client.model.MapType;
/*     */ import journeymap.client.model.RegionCoord;
/*     */ import journeymap.client.model.RegionImageCache;
/*     */ import journeymap.client.model.RegionImageSet;
/*     */ import journeymap.client.texture.ComparableNativeImage;
/*     */ import journeymap.common.Journeymap;
/*     */ import journeymap.common.log.LogFormatter;
/*     */ import journeymap.common.nbt.RegionData;
/*     */ import net.minecraft.client.Minecraft;
/*     */ import net.minecraft.world.level.Level;
/*     */ import org.apache.logging.log4j.Level;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ChunkRenderController
/*     */ {
/*  49 */   private final SurfaceRenderer overWorldSurfaceRenderer = new SurfaceRenderer();
/*  50 */   private final BaseRenderer overWorldCaveRenderer = (BaseRenderer)new CaveRenderer(this.overWorldSurfaceRenderer);
/*  51 */   private final SurfaceRenderer netherSurfaceRenderer = (SurfaceRenderer)new NetherSurfaceRenderer();
/*  52 */   private final BaseRenderer netherCaveRenderer = (BaseRenderer)new NetherCaveRenderer();
/*  53 */   private final SurfaceRenderer endSurfaceRenderer = (SurfaceRenderer)new EndSurfaceRenderer();
/*  54 */   private final BaseRenderer endCaveRenderer = (BaseRenderer)new EndCaveRenderer(this.endSurfaceRenderer);
/*  55 */   private final BaseRenderer topoRenderer = (BaseRenderer)new TopoRenderer();
/*  56 */   private final BaseRenderer biomeRenderer = (BaseRenderer)new BiomeRenderer();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public BaseRenderer getRenderer(RegionCoord rCoord, MapType mapType, ChunkMD chunkMd) {
/*     */     try {
/*  66 */       RegionImageSet regionImageSet = RegionImageCache.INSTANCE.getRegionImageSet(rCoord);
/*  67 */       if (mapType.isUnderground())
/*     */       
/*  69 */       { ComparableNativeImage comparableNativeImage = regionImageSet.getChunkImage(chunkMd, mapType);
/*     */         
/*  71 */         try { if (comparableNativeImage != null)
/*     */           
/*  73 */           { if (Level.NETHER.equals(rCoord.dimension))
/*     */             
/*  75 */             { BaseRenderer baseRenderer1 = this.netherCaveRenderer;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */               
/*  83 */               if (comparableNativeImage != null) comparableNativeImage.close();  return baseRenderer1; }  if (Level.END.equals(rCoord.dimension)) { BaseRenderer baseRenderer1 = this.endCaveRenderer; if (comparableNativeImage != null) comparableNativeImage.close();  return baseRenderer1; }  BaseRenderer baseRenderer = this.overWorldCaveRenderer; if (comparableNativeImage != null) comparableNativeImage.close();  return baseRenderer; }  if (comparableNativeImage != null) comparableNativeImage.close();  } catch (Throwable throwable) { if (comparableNativeImage != null)
/*     */             try { comparableNativeImage.close(); } catch (Throwable throwable1) { throwable.addSuppressed(throwable1); }   throw throwable; }
/*     */          }
/*  86 */       else { if (Level.NETHER.equals(rCoord.dimension))
/*     */         {
/*  88 */           return (BaseRenderer)this.netherSurfaceRenderer;
/*     */         }
/*     */ 
/*     */         
/*  92 */         return (BaseRenderer)this.overWorldSurfaceRenderer; }
/*     */ 
/*     */     
/*  95 */     } catch (Throwable t) {
/*     */       
/*  97 */       Journeymap.getLogger().error("Unexpected error in ChunkRenderController: " + LogFormatter.toPartialString(t));
/*     */     } 
/*     */     
/* 100 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean renderChunk(RegionCoord rCoord, MapType mapType, ChunkMD chunkMd, RegionData regionData) {
/* 105 */     Minecraft mc = Minecraft.getInstance();
/*     */     
/* 107 */     if (!JourneymapClient.getInstance().isMapping().booleanValue() || chunkMd
/* 108 */       .getChunk().getLevel().dimension() != mc.player.getCommandSenderWorld().dimension() || mc.player
/* 109 */       .getCommandSenderWorld() != mc.level)
/*     */     {
/* 111 */       return false;
/*     */     }
/*     */     
/* 114 */     boolean renderOkay = false;
/*     */ 
/*     */     
/*     */     try {
/* 118 */       RegionImageSet regionImageSet = RegionImageCache.INSTANCE.getRegionImageSet(rCoord);
/* 119 */       if (mapType.isUnderground())
/*     */       
/* 121 */       { ComparableNativeImage chunkSliceImage = regionImageSet.getChunkImage(chunkMd, mapType);
/*     */         
/* 123 */         try { if (chunkSliceImage != null) {
/*     */             
/* 125 */             if (Level.NETHER.equals(rCoord.dimension)) {
/*     */               
/* 127 */               renderOkay = this.netherCaveRenderer.render(chunkSliceImage, regionData, chunkMd, mapType.vSlice);
/*     */             }
/* 129 */             else if (Level.END.equals(rCoord.dimension)) {
/*     */               
/* 131 */               renderOkay = this.endCaveRenderer.render(chunkSliceImage, regionData, chunkMd, mapType.vSlice);
/*     */             }
/*     */             else {
/*     */               
/* 135 */               renderOkay = this.overWorldCaveRenderer.render(chunkSliceImage, regionData, chunkMd, mapType.vSlice);
/*     */             } 
/*     */             
/* 138 */             if (renderOkay)
/*     */             {
/* 140 */               regionImageSet.setChunkImage(chunkMd, mapType, chunkSliceImage);
/*     */             }
/*     */           } 
/* 143 */           if (chunkSliceImage != null) chunkSliceImage.close();  } catch (Throwable throwable) { if (chunkSliceImage != null)
/*     */             try { chunkSliceImage.close(); } catch (Throwable throwable1) { throwable.addSuppressed(throwable1); }
/*     */               throw throwable; }
/*     */          }
/* 147 */       else if (mapType.isTopo())
/*     */       
/* 149 */       { ComparableNativeImage imageTopo = regionImageSet.getChunkImage(chunkMd, MapType.topo(rCoord.dimension));
/*     */         
/* 151 */         try { renderOkay = this.topoRenderer.render(imageTopo, regionData, chunkMd, null);
/* 152 */           if (renderOkay)
/*     */           {
/* 154 */             regionImageSet.setChunkImage(chunkMd, MapType.topo(rCoord.dimension), imageTopo);
/*     */           }
/* 156 */           if (imageTopo != null) imageTopo.close();  } catch (Throwable throwable) { if (imageTopo != null)
/*     */             try { imageTopo.close(); } catch (Throwable throwable1) { throwable.addSuppressed(throwable1); }   throw throwable; }  }
/* 158 */       else if (mapType.isBiome())
/*     */       
/* 160 */       { ComparableNativeImage imageBiome = regionImageSet.getChunkImage(chunkMd, MapType.biome(rCoord.dimension));
/*     */         
/* 162 */         try { renderOkay = this.biomeRenderer.render(imageBiome, regionData, chunkMd, null);
/* 163 */           if (renderOkay)
/*     */           {
/* 165 */             regionImageSet.setChunkImage(chunkMd, MapType.biome(rCoord.dimension), imageBiome);
/*     */           }
/* 167 */           if (imageBiome != null) imageBiome.close();  } catch (Throwable throwable) { if (imageBiome != null)
/*     */             try { imageBiome.close(); }
/*     */             catch (Throwable throwable1) { throwable.addSuppressed(throwable1); }
/*     */               throw throwable; }
/*     */          }
/* 172 */       else { ComparableNativeImage imageDay = regionImageSet.getChunkImage(chunkMd, MapType.day(rCoord.dimension)); 
/* 173 */         try { ComparableNativeImage imageNight = regionImageSet.getChunkImage(chunkMd, MapType.night(rCoord.dimension));
/*     */ 
/*     */           
/* 176 */           try { renderOkay = this.overWorldSurfaceRenderer.render(imageDay, (NativeImage)imageNight, regionData, chunkMd);
/*     */             
/* 178 */             if (renderOkay) {
/*     */               
/* 180 */               regionImageSet.setChunkImage(chunkMd, MapType.day(rCoord.dimension), imageDay);
/* 181 */               regionImageSet.setChunkImage(chunkMd, MapType.night(rCoord.dimension), imageNight);
/*     */             } 
/* 183 */             if (imageNight != null) imageNight.close();  } catch (Throwable throwable) { if (imageNight != null) try { imageNight.close(); } catch (Throwable throwable1) { throwable.addSuppressed(throwable1); }   throw throwable; }  if (imageDay != null) imageDay.close();  } catch (Throwable throwable) { if (imageDay != null)
/*     */             try { imageDay.close(); } catch (Throwable throwable1) { throwable.addSuppressed(throwable1); }   throw throwable; }
/*     */          }
/*     */     
/* 187 */     } catch (ArrayIndexOutOfBoundsException e) {
/*     */       
/* 189 */       Journeymap.getLogger().log(Level.WARN, LogFormatter.toString(e));
/* 190 */       return false;
/*     */     }
/* 192 */     catch (Throwable t) {
/*     */       
/* 194 */       Journeymap.getLogger().error("Unexpected error in ChunkRenderController: " + LogFormatter.toString(t));
/*     */     } 
/*     */     
/* 197 */     if (!renderOkay)
/*     */     {
/* 199 */       if (Journeymap.getLogger().isDebugEnabled())
/*     */       {
/* 201 */         Journeymap.getLogger().debug(String.format("Chunk %s render failed for %s", new Object[] { chunkMd.getCoord(), mapType }));
/*     */       }
/*     */     }
/*     */     
/* 205 */     return renderOkay;
/*     */   }
/*     */ }


/* Location:              C:\Users\Administrator\Downloads\journeymap-forge-1.21-6.0.0-beta.18.jar!\journeymap\client\cartography\ChunkRenderController.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */