/*     */ package journeymap.api.client.impl;
/*     */ 
/*     */ import net.minecraft.core.BlockPos;
/*     */ import net.minecraft.world.level.ChunkPos;
/*     */ import net.minecraft.world.level.biome.Biome;
/*     */ import net.minecraft.world.level.block.Block;
/*     */ import net.minecraft.world.level.block.state.BlockState;
/*     */ import net.minecraft.world.level.chunk.LevelChunk;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Builder
/*     */ {
/*     */   private BlockPos blockPos;
/*     */   private Block block;
/*     */   private BlockState blockState;
/*     */   private Biome biome;
/*     */   private LevelChunk chunk;
/*     */   private ChunkPos chunkPos;
/*     */   private Integer regionX;
/*     */   private Integer regionZ;
/*     */   
/*     */   public BlockInfo build() {
/* 102 */     return new BlockInfo(this);
/*     */   }
/*     */ 
/*     */   
/*     */   public Builder withBlockPos(BlockPos blockPos) {
/* 107 */     this.blockPos = blockPos;
/* 108 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public Builder withBlock(Block block) {
/* 113 */     this.block = block;
/* 114 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public Builder withBlockState(BlockState blockState) {
/* 119 */     this.blockState = blockState;
/* 120 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public Builder withBiome(Biome biome) {
/* 125 */     this.biome = biome;
/* 126 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public Builder withChunk(LevelChunk chunk) {
/* 131 */     this.chunk = chunk;
/* 132 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public Builder withChunkPos(ChunkPos chunkPos) {
/* 137 */     this.chunkPos = chunkPos;
/* 138 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public Builder withRegionX(Integer regionX) {
/* 143 */     this.regionX = regionX;
/* 144 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public Builder withRegionZ(Integer regionZ) {
/* 149 */     this.regionZ = regionZ;
/* 150 */     return this;
/*     */   }
/*     */ }


/* Location:              C:\Users\Administrator\Downloads\journeymap-forge-1.21-6.0.0-beta.18.jar!\journeymap\api\client\impl\BlockInfo$Builder.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */