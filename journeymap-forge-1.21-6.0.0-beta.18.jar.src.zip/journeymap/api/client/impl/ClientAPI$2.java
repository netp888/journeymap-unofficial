/*    */ package journeymap.api.client.impl;
/*    */ 
/*    */ import journeymap.api.v2.client.display.Context;
/*    */ 


/* Location:              C:\Users\Administrator\Downloads\journeymap-forge-1.21-6.0.0-beta.18.jar!\journeymap\api\client\impl\ClientAPI$2.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */