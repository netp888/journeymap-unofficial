/*    */ package journeymap.api.services;
/*    */ 
/*    */ import com.mojang.blaze3d.platform.InputConstants;
/*    */ import java.util.List;
/*    */ import javax.annotation.Nullable;
/*    */ import journeymap.client.event.handlers.KeyEventHandler;
/*    */ import journeymap.client.event.handlers.keymapping.KeyConflictContext;
/*    */ import journeymap.client.event.handlers.keymapping.KeyModifier;
/*    */ import journeymap.client.event.handlers.keymapping.UpdateAwareKeyBinding;
/*    */ import journeymap.client.model.BlockMD;
/*    */ import net.minecraft.client.renderer.RenderType;
/*    */ import net.minecraft.client.renderer.block.model.BakedQuad;
/*    */ import net.minecraft.client.renderer.texture.TextureAtlasSprite;
/*    */ import net.minecraft.client.resources.model.BakedModel;
/*    */ import net.minecraft.core.BlockPos;
/*    */ import net.minecraft.core.Direction;
/*    */ import net.minecraft.world.level.block.state.BlockState;
/*    */ 
/*    */ 
/*    */ public interface ClientPlatformService
/*    */ {
/*    */   public static final int DEFAULT_WATER_COLOR = 4159204;
/*    */   
/*    */   TextureAtlasSprite getTextureAtlasSprite(BlockMD paramBlockMD);
/*    */   
/*    */   List<BakedQuad> getQuads(BakedModel paramBakedModel, @Nullable BlockState paramBlockState, @Nullable Direction paramDirection, @Nullable BlockPos paramBlockPos, RenderType paramRenderType);
/*    */   
/*    */   int getFluidTint(BlockMD paramBlockMD);
/*    */   
/*    */   UpdateAwareKeyBinding getKeyBinding(String paramString1, KeyConflictContext paramKeyConflictContext, KeyModifier paramKeyModifier, InputConstants.Type paramType, int paramInt, String paramString2, KeyEventHandler paramKeyEventHandler);
/*    */   
/*    */   default float getFarPlane() {
/* 33 */     return 21000.0F;
/*    */   }
/*    */ }


/* Location:              C:\Users\Administrator\Downloads\journeymap-forge-1.21-6.0.0-beta.18.jar!\journeymap\api\services\ClientPlatformService.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */