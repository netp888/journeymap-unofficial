/*    */ package journeymap.api.services;
/*    */ 
/*    */ import java.util.List;
/*    */ import journeymap.api.v2.common.event.impl.EventFactory;
/*    */ import journeymap.api.v2.common.event.impl.EventImpl;
/*    */ import journeymap.api.v2.common.event.impl.JourneyMapEvent;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class EventBus
/*    */ {
/*    */   public static <T extends JourneyMapEvent> void post(T event) {
/* 14 */     EventImpl<JourneyMapEvent> impl = (EventImpl<JourneyMapEvent>)EventFactory.getInstance().getEvents().get(event.getClass());
/* 15 */     if (impl != null && impl.getListeners() != null)
/*    */     {
/* 17 */       impl.getListeners().forEach(listener -> listener.listener().accept(event));
/*    */     }
/*    */   }
/*    */ 
/*    */   
/*    */   public static <T extends JourneyMapEvent> boolean hasListeners(T event) {
/* 23 */     List<EventImpl.Listener<JourneyMapEvent>> listeners = getEventListeners(event);
/* 24 */     return (listeners != null && !listeners.isEmpty());
/*    */   }
/*    */ 
/*    */   
/*    */   public static <T extends JourneyMapEvent> List<EventImpl.Listener<JourneyMapEvent>> getEventListeners(T event) {
/* 29 */     return ((EventImpl)EventFactory.getInstance().getEvents().get(event.getClass())).getListeners();
/*    */   }
/*    */ 
/*    */   
/*    */   public static <T extends JourneyMapEvent> boolean pluginHasListeners(String modId, T event) {
/* 34 */     List<EventImpl.Listener<JourneyMapEvent>> listeners = getEventListeners(event);
/* 35 */     return (listeners != null && listeners.size() > 0 && listeners
/* 36 */       .stream()
/* 37 */       .anyMatch(listener -> listener.modId().equals(modId)));
/*    */   }
/*    */ }


/* Location:              C:\Users\Administrator\Downloads\journeymap-forge-1.21-6.0.0-beta.18.jar!\journeymap\api\services\EventBus.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */