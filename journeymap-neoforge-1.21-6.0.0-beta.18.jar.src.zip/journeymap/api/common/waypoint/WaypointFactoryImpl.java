/*     */ package journeymap.api.common.waypoint;
/*     */ 
/*     */ import java.text.SimpleDateFormat;
/*     */ import java.util.Date;
/*     */ import java.util.Optional;
/*     */ import java.util.Set;
/*     */ import java.util.TreeSet;
/*     */ import java.util.UUID;
/*     */ import journeymap.api.v2.common.waypoint.Waypoint;
/*     */ import journeymap.api.v2.common.waypoint.WaypointFactory;
/*     */ import journeymap.api.v2.common.waypoint.WaypointGroup;
/*     */ import journeymap.client.Constants;
/*     */ import journeymap.client.JourneymapClient;
/*     */ import journeymap.client.cartography.color.RGB;
/*     */ import journeymap.client.properties.WaypointProperties;
/*     */ import journeymap.client.waypoint.ClientWaypointImpl;
/*     */ import journeymap.common.waypoint.WaypointGroupImpl;
/*     */ import journeymap.common.waypoint.WaypointGroupStore;
/*     */ import journeymap.common.waypoint.WaypointIcon;
/*     */ import journeymap.common.waypoint.WaypointPos;
/*     */ import journeymap.common.waypoint.WaypointSettings;
/*     */ import journeymap.common.waypoint.WaypointStore;
/*     */ import net.minecraft.client.Minecraft;
/*     */ import net.minecraft.client.player.LocalPlayer;
/*     */ import net.minecraft.core.BlockPos;
/*     */ import net.minecraft.resources.ResourceLocation;
/*     */ import net.minecraft.util.Mth;
/*     */ import org.jetbrains.annotations.Nullable;
/*     */ 
/*     */ 
/*     */ 
/*     */ public class WaypointFactoryImpl
/*     */   implements WaypointFactory.WaypointStore
/*     */ {
/*     */   public static WaypointFactoryImpl instance;
/*     */   public static WaypointFactory factory;
/*     */   
/*     */   public static void init() {
/*  39 */     instance = new WaypointFactoryImpl();
/*  40 */     factory = new WaypointFactory(instance);
/*     */   }
/*     */ 
/*     */   
/*     */   public static Waypoint createWaypoint(String modId, BlockPos blockPos, String name, String dimension, boolean showDeviation) {
/*  45 */     return createWaypoint(modId, blockPos, name, dimension, false, showDeviation, RGB.randomColor(), true);
/*     */   }
/*     */ 
/*     */   
/*     */   public static Waypoint createWaypoint(String modId, BlockPos blockPos, String name, String dimension, int color) {
/*  50 */     return createWaypoint(modId, blockPos, name, dimension, false, false, color, true);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Waypoint createClientWaypoint(String modId, BlockPos pos, @Nullable String name, String primaryDimension, boolean persistent) {
/*  56 */     return createWaypoint(modId, pos, name, primaryDimension, false, persistent);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public WaypointGroup createWaypointGroup(String modId, String name) {
/*  63 */     return (WaypointGroup)new WaypointGroupImpl(modId, name);
/*     */   }
/*     */ 
/*     */   
/*     */   public WaypointGroup createWaypointGroup(String name) {
/*  68 */     return createWaypointGroup("journeymap", name);
/*     */   }
/*     */ 
/*     */   
/*     */   public static Waypoint createWaypoint(String modId, BlockPos pos, @Nullable String name, String primaryDimension, boolean isDeath, boolean persistent) {
/*  73 */     return createWaypoint(modId, pos, name, primaryDimension, isDeath, false, RGB.randomColor(), persistent);
/*     */   }
/*     */ 
/*     */   
/*     */   public static Waypoint createWaypoint(String modId, BlockPos blockPos, @Nullable String name, String primaryDimension, boolean isDeath, boolean showDeviation, int color, boolean persistent) {
/*  78 */     String guid = UUID.randomUUID().toString();
/*  79 */     if (name == null)
/*     */     {
/*  81 */       name = createName(blockPos.getX(), blockPos.getZ());
/*     */     }
/*  83 */     ResourceLocation icon = isDeath ? WaypointIcon.DEFAULT_ICON_DEATH : WaypointIcon.DEFAULT_ICON_NORMAL;
/*  84 */     String group = isDeath ? WaypointGroupStore.DEATH.getGuid() : WaypointGroupStore.DEFAULT.getGuid();
/*  85 */     return (Waypoint)new ClientWaypointImpl(name, "1", modId, guid, modId, group, new WaypointPos(blockPos, primaryDimension), 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/*  93 */         Integer.valueOf(color), new WaypointIcon(icon), new WaypointSettings(true, showDeviation, persistent), new TreeSet(
/*     */ 
/*     */           
/*  96 */           Set.of(primaryDimension)), 
/*  97 */         Optional.empty());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void createDeathPoint(BlockPos blockPos, String dimension) {
/* 111 */     Date now = new Date();
/* 112 */     WaypointProperties properties = JourneymapClient.getInstance().getWaypointProperties();
/* 113 */     SimpleDateFormat simpleDateFormat = new SimpleDateFormat(properties.timeFormat.get() + " " + properties.timeFormat.get());
/* 114 */     String timeDate = simpleDateFormat.format(now);
/* 115 */     String name = String.format("%s %s", new Object[] { Constants.getString("jm.waypoint.deathpoint"), timeDate });
/* 116 */     Waypoint waypoint = createWaypoint("journeymap", blockPos, name, dimension, true, true);
/* 117 */     WaypointStore.getInstance().save((ClientWaypointImpl)waypoint, false);
/*     */   }
/*     */ 
/*     */   
/*     */   public static ClientWaypointImpl at(BlockPos blockPos, boolean isDeath, String dimension) {
/* 122 */     return (ClientWaypointImpl)createWaypoint("journeymap", blockPos, createName(blockPos.getX(), blockPos.getZ()), dimension, isDeath, true);
/*     */   }
/*     */ 
/*     */   
/*     */   private static String createName(int x, int z) {
/* 127 */     return String.format("%s, %s", new Object[] { Integer.valueOf(x), Integer.valueOf(z) });
/*     */   }
/*     */ 
/*     */   
/*     */   public static ClientWaypointImpl of(LocalPlayer player) {
/* 132 */     BlockPos blockPos = new BlockPos(Mth.floor(player.getX()), Mth.floor(player.getY()), Mth.floor(player.getZ()));
/* 133 */     return at(blockPos, false, (Minecraft.getInstance()).player.getCommandSenderWorld().dimension().location().toString());
/*     */   }
/*     */ }


/* Location:              C:\Users\Administrator\Downloads\journeymap-neoforge-1.21-6.0.0-beta.18.jar!\journeymap\api\common\waypoint\WaypointFactoryImpl.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */