/*     */ package journeymap.api.client.impl;
/*     */ 
/*     */ import com.google.common.base.MoreObjects;
/*     */ import com.google.common.base.Objects;
/*     */ import com.google.common.collect.HashBasedTable;
/*     */ import com.google.common.collect.Table;
/*     */ import com.mojang.blaze3d.platform.NativeImage;
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Locale;
/*     */ import java.util.stream.Collectors;
/*     */ import javax.annotation.Nullable;
/*     */ import javax.annotation.ParametersAreNonnullByDefault;
/*     */ import journeymap.api.v2.client.IClientPlugin;
/*     */ import journeymap.api.v2.client.display.DisplayType;
/*     */ import journeymap.api.v2.client.display.Displayable;
/*     */ import journeymap.api.v2.client.display.ImageOverlay;
/*     */ import journeymap.api.v2.client.display.MarkerOverlay;
/*     */ import journeymap.api.v2.client.display.Overlay;
/*     */ import journeymap.api.v2.client.display.PolygonOverlay;
/*     */ import journeymap.api.v2.client.model.ShapeProperties;
/*     */ import journeymap.api.v2.client.util.UIState;
/*     */ import journeymap.api.v2.common.waypoint.Waypoint;
/*     */ import journeymap.client.data.DataCache;
/*     */ import journeymap.client.render.draw.DrawImageStep;
/*     */ import journeymap.client.render.draw.DrawMarkerStep;
/*     */ import journeymap.client.render.draw.DrawPolygonStep;
/*     */ import journeymap.client.render.draw.OverlayDrawStep;
/*     */ import journeymap.client.texture.DynamicTextureImpl;
/*     */ import journeymap.client.texture.ImageUtil;
/*     */ import journeymap.client.texture.SimpleTextureImpl;
/*     */ import journeymap.client.texture.TextureCache;
/*     */ import journeymap.client.waypoint.ClientWaypointImpl;
/*     */ import journeymap.common.CommonConstants;
/*     */ import journeymap.common.Journeymap;
/*     */ import journeymap.common.helper.DimensionHelper;
/*     */ import journeymap.common.log.LogFormatter;
/*     */ import journeymap.common.waypoint.WaypointIcon;
/*     */ import journeymap.common.waypoint.WaypointImpl;
/*     */ import journeymap.common.waypoint.WaypointStore;
/*     */ import net.minecraft.client.Minecraft;
/*     */ import net.minecraft.client.renderer.texture.AbstractTexture;
/*     */ import net.minecraft.client.renderer.texture.TextureManager;
/*     */ import net.minecraft.resources.ResourceKey;
/*     */ import net.minecraft.resources.ResourceLocation;
/*     */ import net.minecraft.world.level.Level;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @ParametersAreNonnullByDefault
/*     */ class PluginWrapper
/*     */ {
/*     */   private final IClientPlugin plugin;
/*     */   private final String modId;
/*  62 */   private final HashMap<String, HashBasedTable<String, Overlay, OverlayDrawStep>> dimensionOverlays = new HashMap<>();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public PluginWrapper(IClientPlugin plugin) {
/*  73 */     this.modId = plugin.getModId();
/*  74 */     this.plugin = plugin;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private HashBasedTable<String, Overlay, OverlayDrawStep> getOverlays(ResourceKey<Level> dimension) {
/*  85 */     String dimName = DimensionHelper.getDimKeyName(dimension);
/*  86 */     HashBasedTable<String, Overlay, OverlayDrawStep> table = this.dimensionOverlays.get(dimName);
/*  87 */     if (table == null) {
/*     */       
/*  89 */       table = HashBasedTable.create();
/*  90 */       this.dimensionOverlays.put(dimName, table);
/*     */     } 
/*  92 */     return table;
/*     */   } public void show(Displayable displayable) throws Exception {
/*     */     PolygonOverlay polygon;
/*     */     DrawPolygonStep polygonStep;
/*     */     ShapeProperties prop;
/*     */     MarkerOverlay marker;
/*     */     DrawMarkerStep markerStep;
/*     */     ImageOverlay imageOverlay;
/*     */     DrawImageStep imageStep;
/* 101 */     String displayId = displayable.getId();
/* 102 */     switch (displayable.getDisplayType()) {
/*     */       
/*     */       case Polygon:
/* 105 */         polygon = (PolygonOverlay)displayable;
/* 106 */         polygonStep = DataCache.INSTANCE.getDrawPolygonStep(polygon);
/* 107 */         prop = polygon.getShapeProperties();
/* 108 */         if (prop.getImage() != null || prop.getImageLocation() != null)
/*     */         {
/* 110 */           polygonStep.setTextureResource(getPolygonImageResource(polygon));
/*     */         }
/* 112 */         polygonStep.setEnabled(true);
/* 113 */         getOverlays(polygon.getDimension()).put(displayId, polygon, polygonStep);
/*     */         break;
/*     */       case Marker:
/* 116 */         marker = (MarkerOverlay)displayable;
/* 117 */         markerStep = DataCache.INSTANCE.getDrawMakerStep(marker);
/* 118 */         markerStep.setEnabled(true);
/* 119 */         getOverlays(marker.getDimension()).put(displayId, marker, markerStep);
/*     */         break;
/*     */       case Image:
/* 122 */         imageOverlay = (ImageOverlay)displayable;
/* 123 */         imageStep = DataCache.INSTANCE.getDrawImageStep(imageOverlay);
/* 124 */         imageStep.setEnabled(true);
/* 125 */         getOverlays(imageOverlay.getDimension()).put(displayId, imageOverlay, imageStep);
/*     */         break;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public Waypoint getWaypoint(String guid) {
/* 135 */     ClientWaypointImpl waypoint = WaypointStore.getInstance().get(guid);
/* 136 */     if (waypoint != null && this.modId.equals(waypoint.getModId()))
/*     */     {
/* 138 */       return (Waypoint)waypoint;
/*     */     }
/* 140 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   public List<Waypoint> getWaypoints() {
/* 145 */     return (List<Waypoint>)WaypointStore.getInstance().getAll().stream()
/* 146 */       .filter(waypoint -> this.modId.equals(waypoint.getModId())).collect(Collectors.toList());
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private ResourceLocation convertToFakeIcon(Waypoint waypoint) {
/* 152 */     WaypointIcon image = ((WaypointImpl)waypoint).getIcon();
/* 153 */     ResourceLocation resourceLocation = image.getResourceLocation();
/* 154 */     if (resourceLocation != null) {
/*     */       
/* 156 */       TextureManager manager = Minecraft.getInstance().getTextureManager();
/* 157 */       ResourceLocation fakeLocation = ResourceLocation.fromNamespaceAndPath("fake", resourceLocation.getPath());
/* 158 */       if (manager.getTexture(fakeLocation, null) == null) {
/*     */         
/* 160 */         SimpleTextureImpl simpleTexture = new SimpleTextureImpl(resourceLocation);
/*     */ 
/*     */         
/* 163 */         try { NativeImage img = ImageUtil.getScaledImage(4.0F, simpleTexture.getNativeImage(), false);
/* 164 */           DynamicTextureImpl scaledTexture = new DynamicTextureImpl(img, fakeLocation);
/* 165 */           manager.register(fakeLocation, (AbstractTexture)scaledTexture);
/* 166 */           scaledTexture.setDisplayHeight(image.getTextureHeight().intValue());
/* 167 */           scaledTexture.setDisplayWidth(image.getTextureWidth().intValue());
/* 168 */           TextureCache.modTextureMap.put(resourceLocation, fakeLocation);
/* 169 */           simpleTexture.close(); } catch (Throwable throwable) { try { simpleTexture.close(); } catch (Throwable throwable1) { throwable.addSuppressed(throwable1); }
/*     */            throw throwable; }
/*     */       
/*     */       } 
/* 173 */     }  return resourceLocation;
/*     */   }
/*     */ 
/*     */   
/*     */   private ResourceLocation getPolygonImageResource(PolygonOverlay polygon) {
/* 178 */     ShapeProperties prop = polygon.getShapeProperties();
/* 179 */     NativeImage image = prop.getImage();
/* 180 */     ResourceLocation resourceLocation = prop.getImageLocation();
/* 181 */     if (image != null) {
/*     */       
/* 183 */       resourceLocation = ResourceLocation.fromNamespaceAndPath("fake", CommonConstants.getSafeString(polygon.getGuid(), "-").toLowerCase(Locale.ROOT));
/* 184 */       NativeImage clonedImage = new NativeImage(image.getWidth(), image.getHeight(), false);
/* 185 */       clonedImage.copyFrom(image);
/* 186 */       DynamicTextureImpl texture = new DynamicTextureImpl(clonedImage, resourceLocation);
/* 187 */       Minecraft.getInstance().getTextureManager().register(resourceLocation, (AbstractTexture)texture);
/*     */     }
/* 189 */     else if (resourceLocation != null) {
/*     */       
/* 191 */       TextureManager manager = Minecraft.getInstance().getTextureManager();
/* 192 */       ResourceLocation oldLocation = resourceLocation;
/* 193 */       resourceLocation = ResourceLocation.fromNamespaceAndPath("fake", oldLocation.getPath());
/* 194 */       if (manager.getTexture(resourceLocation, null) == null) {
/*     */         
/* 196 */         SimpleTextureImpl simpleTexture = new SimpleTextureImpl(oldLocation);
/*     */         
/* 198 */         try { NativeImage simpleImage = simpleTexture.getNativeImage();
/* 199 */           NativeImage clonedImage = new NativeImage(simpleImage.getWidth(), simpleImage.getHeight(), false);
/* 200 */           clonedImage.copyFrom(simpleImage);
/* 201 */           DynamicTextureImpl dynamicTexture = new DynamicTextureImpl(clonedImage, resourceLocation);
/* 202 */           manager.register(resourceLocation, (AbstractTexture)dynamicTexture);
/* 203 */           simpleTexture.close(); } catch (Throwable throwable) { try { simpleTexture.close(); } catch (Throwable throwable1) { throwable.addSuppressed(throwable1); }
/*     */            throw throwable; }
/*     */       
/*     */       } 
/* 207 */     }  return resourceLocation;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void remove(Displayable displayable) {
/* 215 */     String displayId = displayable.getId();
/*     */     
/*     */     try {
/* 218 */       Overlay overlay = (Overlay)displayable;
/* 219 */       OverlayDrawStep drawStep = (OverlayDrawStep)getOverlays(overlay.getDimension()).remove(displayId, displayable);
/* 220 */       if (drawStep != null)
/*     */       {
/* 222 */         drawStep.setEnabled(false);
/*     */       }
/*     */     }
/* 225 */     catch (Throwable t) {
/*     */       
/* 227 */       Journeymap.getLogger().error("Error removing DrawMarkerStep: {}", LogFormatter.toString(t), t);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void remove(Waypoint wp) {
/* 238 */     ClientWaypointImpl waypoint = WaypointStore.getInstance().get(wp.getGuid());
/* 239 */     if (waypoint != null && wp.getModId().equals(waypoint.getModId()))
/*     */     {
/* 241 */       WaypointStore.getInstance().remove(waypoint, true);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void add(Waypoint waypoint) {
/* 253 */     if (((WaypointImpl)waypoint).getIcon() != null && !"journeymap".equals(((WaypointImpl)waypoint).getIcon().getResourceLocation().getNamespace())) {
/*     */ 
/*     */       
/* 256 */       WaypointIcon icon = new WaypointIcon(convertToFakeIcon(waypoint));
/* 257 */       icon.setColor(((WaypointImpl)waypoint).getIcon().getColor());
/* 258 */       ((WaypointImpl)waypoint).setIcon(icon);
/*     */     } 
/* 260 */     WaypointStore.getInstance().save((ClientWaypointImpl)waypoint, true);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void removeAll(DisplayType displayType) {
/* 269 */     for (HashBasedTable<String, Overlay, OverlayDrawStep> overlays : this.dimensionOverlays.values()) {
/*     */       
/* 271 */       List<Displayable> list = new ArrayList<>(overlays.columnKeySet());
/* 272 */       for (Displayable displayable : list) {
/*     */         
/* 274 */         if (displayable.getDisplayType() == displayType) {
/*     */           
/* 276 */           remove(displayable);
/* 277 */           if (displayable instanceof PolygonOverlay) { PolygonOverlay polygonOverlay = (PolygonOverlay)displayable;
/*     */             
/* 279 */             DataCache.INSTANCE.invalidatePolygon(polygonOverlay); }
/*     */         
/*     */         } 
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void removeAllWaypoints() {
/* 292 */     List<ClientWaypointImpl> waypoints = WaypointStore.getInstance().getAll(this.modId);
/* 293 */     for (Waypoint waypoint : waypoints)
/*     */     {
/* 295 */       remove(waypoint);
/*     */     }
/*     */     
/* 298 */     if (!this.dimensionOverlays.isEmpty())
/*     */     {
/* 300 */       this.dimensionOverlays.clear();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean exists(Displayable displayable) {
/* 312 */     String displayId = displayable.getId();
/* 313 */     if (displayable instanceof Overlay) {
/*     */       
/* 315 */       ResourceKey<Level> dimension = ((Overlay)displayable).getDimension();
/* 316 */       return getOverlays(dimension).containsRow(displayId);
/*     */     } 
/* 318 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void getDrawSteps(List<OverlayDrawStep> list, UIState uiState) {
/* 326 */     HashBasedTable<String, Overlay, OverlayDrawStep> table = getOverlays(uiState.dimension);
/* 327 */     for (Table.Cell<String, Overlay, OverlayDrawStep> cell : (Iterable<Table.Cell<String, Overlay, OverlayDrawStep>>)table.cellSet()) {
/*     */       
/* 329 */       if (((Overlay)cell.getColumnKey()).isActiveIn(uiState))
/*     */       {
/* 331 */         list.add((OverlayDrawStep)cell.getValue());
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean equals(Object o) {
/*     */     PluginWrapper that;
/* 339 */     if (this == o)
/*     */     {
/* 341 */       return true;
/*     */     }
/* 343 */     if (o instanceof PluginWrapper) { that = (PluginWrapper)o; }
/*     */     else
/* 345 */     { return false; }
/*     */     
/* 347 */     return Objects.equal(this.modId, that.modId);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 353 */     return Objects.hashCode(new Object[] { this.modId });
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 359 */     return MoreObjects.toStringHelper(this.plugin)
/* 360 */       .add("modId", this.modId)
/* 361 */       .toString();
/*     */   }
/*     */ }


/* Location:              C:\Users\Administrator\Downloads\journeymap-neoforge-1.21-6.0.0-beta.18.jar!\journeymap\api\client\impl\PluginWrapper.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */