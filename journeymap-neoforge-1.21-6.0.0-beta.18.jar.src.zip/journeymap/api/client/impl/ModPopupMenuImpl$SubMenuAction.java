package journeymap.api.client.impl;

import journeymap.api.v2.client.fullscreen.ModPopupMenu;
import journeymap.client.ui.component.buttons.Button;
import net.minecraft.core.BlockPos;

public interface SubMenuAction extends ModPopupMenu.Action {
  default void doAction(BlockPos blockPos) {}
  
  void doAction(BlockPos paramBlockPos, Button paramButton);
  
  void onHoverState(BlockPos paramBlockPos, Button paramButton, boolean paramBoolean);
}


/* Location:              C:\Users\Administrator\Downloads\journeymap-neoforge-1.21-6.0.0-beta.18.jar!\journeymap\api\client\impl\ModPopupMenuImpl$SubMenuAction.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */