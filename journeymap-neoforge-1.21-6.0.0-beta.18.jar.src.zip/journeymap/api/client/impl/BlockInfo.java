/*     */ package journeymap.api.client.impl;
/*     */ 
/*     */ import journeymap.api.v2.client.fullscreen.IBlockInfo;
/*     */ import net.minecraft.core.BlockPos;
/*     */ import net.minecraft.world.level.ChunkPos;
/*     */ import net.minecraft.world.level.biome.Biome;
/*     */ import net.minecraft.world.level.block.Block;
/*     */ import net.minecraft.world.level.block.state.BlockState;
/*     */ import net.minecraft.world.level.chunk.LevelChunk;
/*     */ 
/*     */ 
/*     */ 
/*     */ public class BlockInfo
/*     */   implements IBlockInfo
/*     */ {
/*     */   private BlockPos blockPos;
/*     */   private Block block;
/*     */   private BlockState blockState;
/*     */   private Biome biome;
/*     */   private LevelChunk chunk;
/*     */   private ChunkPos chunkPos;
/*     */   private Integer regionX;
/*     */   private Integer regionZ;
/*     */   
/*     */   private BlockInfo(Builder builder) {
/*  26 */     this.blockPos = builder.blockPos;
/*  27 */     this.block = builder.block;
/*  28 */     this.blockState = builder.blockState;
/*  29 */     this.biome = builder.biome;
/*  30 */     this.chunk = builder.chunk;
/*  31 */     this.chunkPos = builder.chunkPos;
/*  32 */     this.regionX = builder.regionX;
/*  33 */     this.regionZ = builder.regionZ;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public BlockPos getBlockPos() {
/*  39 */     return this.blockPos;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Block getBlock() {
/*  45 */     return this.block;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public BlockState getBlockState() {
/*  51 */     return this.blockState;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Biome getBiome() {
/*  57 */     return this.biome;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public LevelChunk getChunk() {
/*  63 */     return this.chunk;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public ChunkPos getChunkPos() {
/*  69 */     return this.chunkPos;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Integer getRegionX() {
/*  75 */     return this.regionX;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Integer getRegionZ() {
/*  81 */     return this.regionZ;
/*     */   }
/*     */ 
/*     */   
/*     */   public static Builder builder() {
/*  86 */     return new Builder();
/*     */   }
/*     */ 
/*     */   
/*     */   public static class Builder
/*     */   {
/*     */     private BlockPos blockPos;
/*     */     private Block block;
/*     */     private BlockState blockState;
/*     */     private Biome biome;
/*     */     private LevelChunk chunk;
/*     */     private ChunkPos chunkPos;
/*     */     private Integer regionX;
/*     */     private Integer regionZ;
/*     */     
/*     */     public BlockInfo build() {
/* 102 */       return new BlockInfo(this);
/*     */     }
/*     */ 
/*     */     
/*     */     public Builder withBlockPos(BlockPos blockPos) {
/* 107 */       this.blockPos = blockPos;
/* 108 */       return this;
/*     */     }
/*     */ 
/*     */     
/*     */     public Builder withBlock(Block block) {
/* 113 */       this.block = block;
/* 114 */       return this;
/*     */     }
/*     */ 
/*     */     
/*     */     public Builder withBlockState(BlockState blockState) {
/* 119 */       this.blockState = blockState;
/* 120 */       return this;
/*     */     }
/*     */ 
/*     */     
/*     */     public Builder withBiome(Biome biome) {
/* 125 */       this.biome = biome;
/* 126 */       return this;
/*     */     }
/*     */ 
/*     */     
/*     */     public Builder withChunk(LevelChunk chunk) {
/* 131 */       this.chunk = chunk;
/* 132 */       return this;
/*     */     }
/*     */ 
/*     */     
/*     */     public Builder withChunkPos(ChunkPos chunkPos) {
/* 137 */       this.chunkPos = chunkPos;
/* 138 */       return this;
/*     */     }
/*     */ 
/*     */     
/*     */     public Builder withRegionX(Integer regionX) {
/* 143 */       this.regionX = regionX;
/* 144 */       return this;
/*     */     }
/*     */ 
/*     */     
/*     */     public Builder withRegionZ(Integer regionZ) {
/* 149 */       this.regionZ = regionZ;
/* 150 */       return this;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\Administrator\Downloads\journeymap-neoforge-1.21-6.0.0-beta.18.jar!\journeymap\api\client\impl\BlockInfo.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */