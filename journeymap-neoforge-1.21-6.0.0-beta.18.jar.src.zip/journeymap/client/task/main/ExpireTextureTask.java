/*     */ package journeymap.client.task.main;
/*     */ 
/*     */ import com.mojang.blaze3d.platform.TextureUtil;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import journeymap.client.JourneymapClient;
/*     */ import journeymap.client.texture.Texture;
/*     */ import journeymap.common.Journeymap;
/*     */ import net.minecraft.client.Minecraft;
/*     */ import org.apache.logging.log4j.Logger;
/*     */ import org.lwjgl.glfw.GLFW;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ExpireTextureTask
/*     */   implements IMainThreadTask
/*     */ {
/*     */   private static final int MAX_FAILS = 5;
/*  27 */   private static String NAME = "Tick." + MappingMonitorTask.class.getSimpleName();
/*  28 */   private static Logger LOGGER = Journeymap.getLogger();
/*     */   
/*     */   private final List<Texture> textures;
/*     */   private final int textureId;
/*     */   private volatile int fails;
/*     */   
/*     */   private ExpireTextureTask(int textureId) {
/*  35 */     this.textures = null;
/*  36 */     this.textureId = textureId;
/*     */   }
/*     */ 
/*     */   
/*     */   private ExpireTextureTask(Texture texture) {
/*  41 */     this.textures = new ArrayList<>();
/*  42 */     this.textures.add(texture);
/*  43 */     this.textureId = -1;
/*     */   }
/*     */ 
/*     */   
/*     */   private ExpireTextureTask(Collection<Texture> textureCollection) {
/*  48 */     this.textures = new ArrayList<>(textureCollection);
/*  49 */     this.textureId = -1;
/*     */   }
/*     */ 
/*     */   
/*     */   public static void queue(int textureId) {
/*  54 */     if (textureId != -1)
/*     */     {
/*  56 */       JourneymapClient.getInstance().queueMainThreadTask(new ExpireTextureTask(textureId));
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public static void queue(Texture texture) {
/*  62 */     JourneymapClient.getInstance().queueMainThreadTask(new ExpireTextureTask(texture));
/*     */   }
/*     */ 
/*     */   
/*     */   public static void queue(Collection<Texture> textureCollection) {
/*  67 */     JourneymapClient.getInstance().queueMainThreadTask(new ExpireTextureTask(textureCollection));
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public IMainThreadTask perform(Minecraft mc, JourneymapClient jm) {
/*  73 */     boolean success = deleteTextures();
/*  74 */     if (!success && this.textures != null && !this.textures.isEmpty()) {
/*     */       
/*  76 */       this.fails++;
/*  77 */       LOGGER.warn("ExpireTextureTask.perform() couldn't delete textures: " + String.valueOf(this.textures) + ", fails: " + this.fails);
/*  78 */       if (this.fails <= 5)
/*     */       {
/*  80 */         return this;
/*     */       }
/*     */     } 
/*  83 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean deleteTextures() {
/*  91 */     if (this.textureId != -1)
/*     */     {
/*  93 */       return deleteTexture(this.textureId);
/*     */     }
/*     */ 
/*     */     
/*  97 */     Iterator<Texture> iter = this.textures.listIterator();
/*  98 */     while (iter.hasNext()) {
/*     */       
/* 100 */       Texture texture = iter.next();
/* 101 */       if (texture == null) {
/*     */         
/* 103 */         iter.remove();
/*     */         continue;
/*     */       } 
/* 106 */       if (deleteTexture(texture))
/*     */       {
/* 108 */         iter.remove();
/*     */       }
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 115 */     return this.textures.isEmpty();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean deleteTexture(Texture texture) {
/* 121 */     boolean success = false;
/* 122 */     if (texture.getTextureId() != -1) {
/*     */       
/*     */       try
/*     */       {
/* 126 */         texture.release();
/*     */         
/* 128 */         texture.remove();
/* 129 */         success = true;
/*     */       }
/* 131 */       catch (Exception t)
/*     */       {
/* 133 */         LOGGER.warn("Couldn't delete texture " + String.valueOf(texture) + ": " + String.valueOf(t));
/*     */       }
/*     */     
/*     */     } else {
/*     */       
/* 138 */       texture.remove();
/* 139 */       success = true;
/*     */     } 
/*     */     
/* 142 */     return success;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean deleteTexture(int textureId) {
/*     */     try {
/* 150 */       if (GLFW.glfwGetCurrentContext() == Minecraft.getInstance().getWindow().getWindow())
/*     */       {
/* 152 */         TextureUtil.releaseTextureId(textureId);
/* 153 */         return true;
/*     */       }
/*     */     
/* 156 */     } catch (Exception t) {
/*     */       
/* 158 */       LOGGER.warn("Couldn't delete textureId " + textureId + ": " + String.valueOf(t));
/*     */     } 
/* 160 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String getName() {
/* 166 */     return NAME;
/*     */   }
/*     */ }


/* Location:              C:\Users\Administrator\Downloads\journeymap-neoforge-1.21-6.0.0-beta.18.jar!\journeymap\client\task\main\ExpireTextureTask.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */