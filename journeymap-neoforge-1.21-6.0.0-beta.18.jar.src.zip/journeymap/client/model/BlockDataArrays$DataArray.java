/*     */ package journeymap.client.model;
/*     */ 
/*     */ import java.util.HashMap;
/*     */ import java.util.function.Supplier;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DataArray<T>
/*     */ {
/* 143 */   private final HashMap<String, T[][]> map = new HashMap<>(4);
/*     */ 
/*     */ 
/*     */   
/*     */   private final Supplier<T[][]> initFn;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected DataArray(Supplier<T[][]> initFn) {
/* 153 */     this.initFn = initFn;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean has(String name) {
/* 164 */     return this.map.containsKey(name);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public T[][] get(String name) {
/* 175 */     return this.map.computeIfAbsent(name, s -> (Object[][])this.initFn.get());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public T get(String name, int x, int z) {
/* 188 */     return get(name)[z][x];
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean set(String name, int x, int z, T value) {
/* 202 */     T[][] arr = get(name);
/* 203 */     T old = arr[z][x];
/* 204 */     arr[z][x] = value;
/* 205 */     return (value != old);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public T[][] copy(String name) {
/* 216 */     T[][] src = get(name);
/* 217 */     T[][] dest = this.initFn.get();
/* 218 */     for (int i = 0; i < src.length; i++)
/*     */     {
/* 220 */       System.arraycopy(src[i], 0, dest[i], 0, (src[0]).length);
/*     */     }
/* 222 */     return dest;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void copyTo(String srcName, String dstName) {
/* 233 */     this.map.put(dstName, copy(srcName));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void clear(String name) {
/* 243 */     this.map.remove(name);
/*     */   }
/*     */ }


/* Location:              C:\Users\Administrator\Downloads\journeymap-neoforge-1.21-6.0.0-beta.18.jar!\journeymap\client\model\BlockDataArrays$DataArray.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */