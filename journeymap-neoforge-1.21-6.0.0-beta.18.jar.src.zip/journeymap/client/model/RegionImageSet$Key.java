/*     */ package journeymap.client.model;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.util.StringJoiner;
/*     */ import net.minecraft.resources.ResourceKey;
/*     */ import net.minecraft.world.level.Level;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Key
/*     */ {
/*     */   private final File worldDir;
/*     */   private final int regionX;
/*     */   private final int regionZ;
/*     */   private final ResourceKey<Level> dimension;
/*     */   
/*     */   private Key(File worldDir, int regionX, int regionZ, ResourceKey<Level> dimension) {
/* 194 */     this.worldDir = worldDir;
/* 195 */     this.regionX = regionX;
/* 196 */     this.regionZ = regionZ;
/* 197 */     this.dimension = dimension;
/*     */   }
/*     */ 
/*     */   
/*     */   public static Key from(RegionCoord rCoord) {
/* 202 */     return new Key(rCoord.worldDir, rCoord.regionX, rCoord.regionZ, rCoord.dimension);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean equals(Object o) {
/* 208 */     if (this == o)
/*     */     {
/* 210 */       return true;
/*     */     }
/* 212 */     if (o == null || getClass() != o.getClass())
/*     */     {
/* 214 */       return false;
/*     */     }
/*     */     
/* 217 */     Key key = (Key)o;
/*     */     
/* 219 */     if (this.dimension != key.dimension)
/*     */     {
/* 221 */       return false;
/*     */     }
/* 223 */     if (this.regionX != key.regionX)
/*     */     {
/* 225 */       return false;
/*     */     }
/* 227 */     if (this.regionZ != key.regionZ)
/*     */     {
/* 229 */       return false;
/*     */     }
/* 231 */     if (!this.worldDir.equals(key.worldDir))
/*     */     {
/* 233 */       return false;
/*     */     }
/*     */     
/* 236 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 242 */     int result = this.worldDir.hashCode();
/* 243 */     result = 31 * result + this.regionX;
/* 244 */     result = 31 * result + this.regionZ;
/* 245 */     result = 31 * result + this.dimension.hashCode();
/* 246 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 252 */     return (new StringJoiner(", ", Key.class.getSimpleName() + "[", "]"))
/* 253 */       .add("worldDir=" + String.valueOf(this.worldDir))
/* 254 */       .add("regionX=" + this.regionX)
/* 255 */       .add("regionZ=" + this.regionZ)
/* 256 */       .add("dimension=" + String.valueOf(this.dimension))
/* 257 */       .toString();
/*     */   }
/*     */ }


/* Location:              C:\Users\Administrator\Downloads\journeymap-neoforge-1.21-6.0.0-beta.18.jar!\journeymap\client\model\RegionImageSet$Key.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */