/*    */ package journeymap.client.event;
/*    */ 
/*    */ import journeymap.client.event.handlers.ChatEventHandler;
/*    */ import net.minecraft.network.chat.Component;
/*    */ import net.neoforged.bus.api.SubscribeEvent;
/*    */ import net.neoforged.neoforge.client.event.ClientChatReceivedEvent;
/*    */ 
/*    */ 
/*    */ public class NeoForgeChatEvents
/*    */   implements NeoForgeEventHandlerManager.EventHandler
/*    */ {
/*    */   @SubscribeEvent
/*    */   public void invoke(ClientChatReceivedEvent event) {
/* 14 */     Component component = ChatEventHandler.getInstance().onClientChatEventReceived(event.getMessage());
/* 15 */     if (component != null)
/*    */     {
/* 17 */       event.setMessage(component);
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Users\Administrator\Downloads\journeymap-neoforge-1.21-6.0.0-beta.18.jar!\journeymap\client\event\NeoForgeChatEvents.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */