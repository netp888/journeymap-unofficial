/*    */ package journeymap.client.event;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import journeymap.client.event.handlers.ShaderRegistrationHandler;
/*    */ import net.minecraft.client.renderer.ShaderInstance;
/*    */ import net.minecraft.resources.ResourceLocation;
/*    */ import net.neoforged.api.distmarker.Dist;
/*    */ import net.neoforged.bus.api.SubscribeEvent;
/*    */ import net.neoforged.fml.common.EventBusSubscriber;
/*    */ import net.neoforged.neoforge.client.event.RegisterShadersEvent;
/*    */ 
/*    */ 
/*    */ 
/*    */ @EventBusSubscriber(value = {Dist.CLIENT}, modid = "journeymap", bus = EventBusSubscriber.Bus.MOD)
/*    */ public class NeoForgeShaderRegistration
/*    */ {
/*    */   @SubscribeEvent
/*    */   public static void registerShaders(RegisterShadersEvent event) {
/* 19 */     ShaderRegistrationHandler.getShaders().forEach((id, shader) -> {
/*    */ 
/*    */           
/*    */           try {
/*    */             event.registerShader(new ShaderInstance(event.getResourceProvider(), id, shader.format()), shader.onLoad());
/* 24 */           } catch (IOException e) {
/*    */             throw new RuntimeException(e);
/*    */           } 
/*    */         });
/*    */   }
/*    */ }


/* Location:              C:\Users\Administrator\Downloads\journeymap-neoforge-1.21-6.0.0-beta.18.jar!\journeymap\client\event\NeoForgeShaderRegistration.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */