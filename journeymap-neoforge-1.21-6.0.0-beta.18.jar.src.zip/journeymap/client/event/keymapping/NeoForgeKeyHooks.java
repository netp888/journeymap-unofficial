/*    */ package journeymap.client.event.keymapping;
/*    */ 
/*    */ import journeymap.client.event.handlers.keymapping.KeyConflictContext;
/*    */ import journeymap.client.event.handlers.keymapping.KeyModifier;
/*    */ import net.neoforged.neoforge.client.settings.IKeyConflictContext;
/*    */ import net.neoforged.neoforge.client.settings.KeyConflictContext;
/*    */ import net.neoforged.neoforge.client.settings.KeyModifier;
/*    */ 
/*    */ public class NeoForgeKeyHooks {
/*    */   public static KeyModifier getForgeModifier(KeyModifier key) {
/* 11 */     switch (key) { case UNIVERSAL: case GUI: case IN_GAME:  }  return 
/*    */ 
/*    */ 
/*    */ 
/*    */       
/* 16 */       KeyModifier.NONE;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public static IKeyConflictContext getForgeConflictContext(KeyConflictContext context) {
/* 22 */     switch (context) { default: throw new MatchException(null, null);case UNIVERSAL: case GUI: case IN_GAME: break; }  return 
/*    */ 
/*    */ 
/*    */       
/* 26 */       (IKeyConflictContext)KeyConflictContext.IN_GAME;
/*    */   }
/*    */ }


/* Location:              C:\Users\Administrator\Downloads\journeymap-neoforge-1.21-6.0.0-beta.18.jar!\journeymap\client\event\keymapping\NeoForgeKeyHooks.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */