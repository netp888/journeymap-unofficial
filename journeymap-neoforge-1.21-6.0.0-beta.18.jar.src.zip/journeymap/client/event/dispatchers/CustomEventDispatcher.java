/*     */ package journeymap.client.event.dispatchers;
/*     */ 
/*     */ import com.google.common.collect.Lists;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import java.util.Objects;
/*     */ import journeymap.api.client.impl.ClientAPI;
/*     */ import journeymap.api.client.impl.ThemeButtonDisplayFactory;
/*     */ import journeymap.api.client.impl.ThemeToolbarDisplayFactory;
/*     */ import journeymap.api.services.EventBus;
/*     */ import journeymap.api.v2.client.entity.WrappedEntity;
/*     */ import journeymap.api.v2.client.event.EntityRadarUpdateEvent;
/*     */ import journeymap.api.v2.client.event.FullscreenDisplayEvent;
/*     */ import journeymap.api.v2.client.event.PopupMenuEvent;
/*     */ import journeymap.api.v2.client.fullscreen.CustomToolBarBuilder;
/*     */ import journeymap.api.v2.client.fullscreen.IFullscreen;
/*     */ import journeymap.api.v2.client.fullscreen.ModPopupMenu;
/*     */ import journeymap.api.v2.client.fullscreen.ThemeButtonDisplay;
/*     */ import journeymap.api.v2.common.event.impl.JourneyMapEvent;
/*     */ import journeymap.api.v2.common.waypoint.Waypoint;
/*     */ import journeymap.client.model.EntityDTO;
/*     */ import journeymap.client.ui.component.buttons.Button;
/*     */ import journeymap.client.ui.component.screens.JmUILegacy;
/*     */ import journeymap.client.ui.fullscreen.Fullscreen;
/*     */ import journeymap.client.ui.theme.Theme;
/*     */ import journeymap.client.ui.theme.ThemeButton;
/*     */ import journeymap.client.ui.theme.ThemeToolbar;
/*     */ import journeymap.client.waypoint.ClientWaypointImpl;
/*     */ 
/*     */ public class CustomEventDispatcher
/*     */ {
/*     */   public static CustomEventDispatcher getInstance() {
/*  33 */     if (INSTANCE == null)
/*     */     {
/*  35 */       INSTANCE = new CustomEventDispatcher();
/*     */     }
/*  37 */     return INSTANCE;
/*     */   }
/*     */   private static CustomEventDispatcher INSTANCE;
/*     */   
/*     */   public ThemeToolbar getMapTypeToolbar(Fullscreen fullscreen, Theme theme, Button... buttons) {
/*  42 */     ThemeButtonDisplayFactory factory = new ThemeButtonDisplayFactory(theme);
/*  43 */     FullscreenDisplayEvent.MapTypeButtonDisplayEvent event = new FullscreenDisplayEvent.MapTypeButtonDisplayEvent((IFullscreen)fullscreen, (ThemeButtonDisplay)factory);
/*  44 */     EventBus.post((JourneyMapEvent)event);
/*  45 */     if (!factory.getThemeButtonList().isEmpty()) {
/*     */       
/*  47 */       ArrayList<Button> themeButtonList = Lists.newArrayList((Object[])buttons);
/*  48 */       Objects.requireNonNull(fullscreen); factory.getThemeButtonList().forEach(fullscreen::addButtonWidget);
/*  49 */       themeButtonList.addAll(0, factory.getThemeButtonList());
/*     */       
/*  51 */       return new ThemeToolbar(theme, themeButtonList.<Button>toArray(new Button[0]));
/*     */     } 
/*  53 */     return new ThemeToolbar(theme, buttons);
/*     */   }
/*     */ 
/*     */   
/*     */   public ThemeToolbar getAddonToolbar(Fullscreen fullscreen, Theme theme) {
/*  58 */     ThemeButtonDisplayFactory factory = new ThemeButtonDisplayFactory(theme);
/*  59 */     FullscreenDisplayEvent.AddonButtonDisplayEvent event = new FullscreenDisplayEvent.AddonButtonDisplayEvent((IFullscreen)fullscreen, (ThemeButtonDisplay)factory);
/*  60 */     EventBus.post((JourneyMapEvent)event);
/*  61 */     if (!factory.getThemeButtonList().isEmpty()) {
/*     */       
/*  63 */       Objects.requireNonNull(fullscreen); factory.getThemeButtonList().forEach(fullscreen::addButtonWidget);
/*  64 */       return new ThemeToolbar(theme, (ThemeButton[])factory.getThemeButtonList().toArray((Object[])new ThemeButton[0]));
/*     */     } 
/*  66 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   public List<ThemeToolbar> getCustomToolBars(Fullscreen fullscreen, Theme theme) {
/*  71 */     ThemeToolbarDisplayFactory factory = new ThemeToolbarDisplayFactory(theme, fullscreen);
/*  72 */     FullscreenDisplayEvent.CustomToolbarEvent event = new FullscreenDisplayEvent.CustomToolbarEvent((IFullscreen)fullscreen, (CustomToolBarBuilder)factory);
/*  73 */     EventBus.post((JourneyMapEvent)event);
/*     */     
/*  75 */     if (!factory.getToolbarList().isEmpty()) {
/*     */       
/*  77 */       factory.getToolbarList().forEach(bar -> bar.addAllButtons((JmUILegacy)fullscreen));
/*  78 */       return factory.getToolbarList();
/*     */     } 
/*  80 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean popupWaypointMenuEvent(Fullscreen fullscreen, ModPopupMenu menu, ClientWaypointImpl wp) {
/*  85 */     PopupMenuEvent.WaypointPopupMenuEvent event = new PopupMenuEvent.WaypointPopupMenuEvent(menu, (IFullscreen)fullscreen, (Waypoint)wp);
/*  86 */     EventBus.post((JourneyMapEvent)event);
/*  87 */     return !event.isCancelled();
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean popupMenuEvent(Fullscreen fullscreen, ModPopupMenu menu) {
/*  92 */     PopupMenuEvent.FullscreenPopupMenuEvent event = new PopupMenuEvent.FullscreenPopupMenuEvent(menu, (IFullscreen)fullscreen);
/*  93 */     EventBus.post((JourneyMapEvent)event);
/*  94 */     return !event.isCancelled();
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean entityRadarPlayerUpdateEvent(EntityDTO dto) {
/*  99 */     return entityRadarUpdateEvent(EntityRadarUpdateEvent.EntityType.PLAYER, dto);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean entityRadarMobUpdateEvent(EntityDTO dto) {
/* 104 */     return entityRadarUpdateEvent(EntityRadarUpdateEvent.EntityType.MOB, dto);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean entityRadarUpdateEvent(EntityRadarUpdateEvent.EntityType type, EntityDTO dto) {
/* 110 */     EntityRadarUpdateEvent event = new EntityRadarUpdateEvent(ClientAPI.INSTANCE.getLastUIState(), type, (WrappedEntity)dto);
/* 111 */     EventBus.post((JourneyMapEvent)event);
/* 112 */     return (!dto.isDisabled() && !event.isCancelled());
/*     */   }
/*     */ }


/* Location:              C:\Users\Administrator\Downloads\journeymap-neoforge-1.21-6.0.0-beta.18.jar!\journeymap\client\event\dispatchers\CustomEventDispatcher.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */