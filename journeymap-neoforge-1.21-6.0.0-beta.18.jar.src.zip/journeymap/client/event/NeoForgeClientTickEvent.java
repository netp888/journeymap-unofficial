/*    */ package journeymap.client.event;
/*    */ 
/*    */ import journeymap.client.event.handlers.StateTickHandler;
/*    */ import net.neoforged.bus.api.SubscribeEvent;
/*    */ import net.neoforged.neoforge.client.event.ClientTickEvent;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class NeoForgeClientTickEvent
/*    */   implements NeoForgeEventHandlerManager.EventHandler
/*    */ {
/* 13 */   private final StateTickHandler stateTickHandler = new StateTickHandler();
/*    */ 
/*    */ 
/*    */   
/*    */   @SubscribeEvent
/*    */   public void onClientTick(ClientTickEvent.Post event) {
/* 19 */     this.stateTickHandler.onClientTick();
/*    */   }
/*    */ }


/* Location:              C:\Users\Administrator\Downloads\journeymap-neoforge-1.21-6.0.0-beta.18.jar!\journeymap\client\event\NeoForgeClientTickEvent.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */