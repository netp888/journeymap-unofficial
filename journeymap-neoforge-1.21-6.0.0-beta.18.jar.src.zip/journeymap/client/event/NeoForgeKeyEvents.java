/*     */ package journeymap.client.event;
/*     */ 
/*     */ import com.google.common.collect.Lists;
/*     */ import java.util.List;
/*     */ import java.util.Objects;
/*     */ import javax.annotation.ParametersAreNonnullByDefault;
/*     */ import journeymap.client.event.handlers.KeyEventHandler;
/*     */ import journeymap.client.event.handlers.keymapping.KeyEvent;
/*     */ import journeymap.common.Journeymap;
/*     */ import net.minecraft.client.KeyMapping;
/*     */ import net.minecraft.client.Minecraft;
/*     */ import net.neoforged.bus.api.SubscribeEvent;
/*     */ import net.neoforged.neoforge.client.event.InputEvent;
/*     */ import net.neoforged.neoforge.client.event.RegisterKeyMappingsEvent;
/*     */ import net.neoforged.neoforge.client.event.ScreenEvent;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @ParametersAreNonnullByDefault
/*     */ public class NeoForgeKeyEvents
/*     */   implements KeyEvent, NeoForgeEventHandlerManager.EventHandler
/*     */ {
/*  31 */   private static final List<KeyMapping> keyList = Lists.newArrayList();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  39 */   private final KeyEventHandler keyEventHandler = new KeyEventHandler(this);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @SubscribeEvent
/*     */   public void onGameKeyboardEvent(InputEvent.Key event) {
/*  50 */     int key = event.getKey();
/*  51 */     this.keyEventHandler.onGameKeyboardEvent(key);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @SubscribeEvent
/*     */   public void onGuiKeyboardEvent(ScreenEvent.KeyPressed.Post event) {
/*  63 */     int key = event.getKeyCode();
/*  64 */     boolean success = this.keyEventHandler.onGuiKeyboardEvent(event.getScreen(), key);
/*  65 */     event.setCanceled(success);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @SubscribeEvent
/*     */   public void onGuiMouseEvent(ScreenEvent.MouseButtonPressed.Post event) {
/*  76 */     int key = event.getButton();
/*  77 */     this.keyEventHandler.onMouseEvent(key, event.getScreen());
/*     */   }
/*     */ 
/*     */   
/*     */   @SubscribeEvent
/*     */   public void onMouseEvent(InputEvent.MouseButton.Post event) {
/*  83 */     if ((Minecraft.getInstance()).screen == null && event.getAction() == 0) {
/*     */       
/*  85 */       int key = event.getButton();
/*  86 */       this.keyEventHandler.onMouseEvent(key, null);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public KeyEventHandler getHandler() {
/*  92 */     return this.keyEventHandler;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public KeyMapping register(KeyMapping keyMapping) {
/*  98 */     keyList.add(keyMapping);
/*  99 */     return keyMapping;
/*     */   }
/*     */ 
/*     */   
/*     */   public void onKeyRegisterEvent(RegisterKeyMappingsEvent event) {
/* 104 */     Journeymap.getLogger().info("Registering Keybinds");
/* 105 */     Objects.requireNonNull(event); keyList.forEach(event::register);
/*     */   }
/*     */ }


/* Location:              C:\Users\Administrator\Downloads\journeymap-neoforge-1.21-6.0.0-beta.18.jar!\journeymap\client\event\NeoForgeKeyEvents.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */