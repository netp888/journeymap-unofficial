/*    */ package journeymap.client.event;
/*    */ 
/*    */ import journeymap.client.event.handlers.WaypointBeaconHandler;
/*    */ import net.minecraft.client.Minecraft;
/*    */ import net.neoforged.bus.api.SubscribeEvent;
/*    */ import net.neoforged.neoforge.client.event.RenderLevelStageEvent;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class NeoForgeRenderLevelStageEvent
/*    */   implements NeoForgeEventHandlerManager.EventHandler
/*    */ {
/* 15 */   private final WaypointBeaconHandler waypointBeaconHandler = new WaypointBeaconHandler();
/*    */ 
/*    */ 
/*    */   
/*    */   @SubscribeEvent
/*    */   public void onRenderWorldLastEvent(RenderLevelStageEvent event) {
/* 21 */     if (RenderLevelStageEvent.Stage.AFTER_TRANSLUCENT_BLOCKS.equals(event.getStage()) && Minecraft.useShaderTransparency()) {
/*    */       
/* 23 */       this.waypointBeaconHandler.onRenderWaypoints(event.getPoseStack());
/*    */     }
/* 25 */     else if (RenderLevelStageEvent.Stage.AFTER_PARTICLES.equals(event.getStage())) {
/*    */       
/* 27 */       this.waypointBeaconHandler.onRenderWaypoints(event.getPoseStack());
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Users\Administrator\Downloads\journeymap-neoforge-1.21-6.0.0-beta.18.jar!\journeymap\client\event\NeoForgeRenderLevelStageEvent.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */