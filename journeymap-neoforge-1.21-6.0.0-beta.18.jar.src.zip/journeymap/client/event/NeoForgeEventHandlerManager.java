/*     */ package journeymap.client.event;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashMap;
/*     */ import journeymap.client.JourneymapClientNeoForge;
/*     */ import journeymap.client.cartography.color.ColorManager;
/*     */ import journeymap.common.Journeymap;
/*     */ import net.neoforged.neoforge.common.NeoForge;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class NeoForgeEventHandlerManager
/*     */ {
/*  24 */   private static HashMap<Class<? extends EventHandler>, EventHandler> handlers = new HashMap<>();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void registerHandlers() {
/*  38 */     register(JourneymapClientNeoForge.getInstance().getKeyEvents());
/*  39 */     register(new NeoForgeChatEvents());
/*  40 */     register(new NeoForgeHudOverlayEvents());
/*  41 */     register(new NeoForgeWorldEvent());
/*  42 */     register(new NeoForgeChunkEvents());
/*  43 */     register(new NeoForgeClientTickEvent());
/*  44 */     register(new NeoForgeRenderLevelStageEvent());
/*  45 */     register(new NeoForgeLoggedInEvent());
/*  46 */     register(new NeoForgeScreenEvents());
/*     */ 
/*     */     
/*  49 */     ColorManager.INSTANCE.getDeclaringClass();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void unregisterAll() {
/*  58 */     ArrayList<Class<? extends EventHandler>> list = new ArrayList<>(handlers.keySet());
/*  59 */     for (Class<? extends EventHandler> handlerClass : list)
/*     */     {
/*  61 */       unregister(handlerClass);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public static void register(EventHandler handler) {
/*  67 */     Class<? extends EventHandler> handlerClass = handler.getClass();
/*  68 */     if (handlers.containsKey(handlerClass)) {
/*     */       
/*  70 */       Journeymap.getLogger().warn("Handler already registered: " + handlerClass.getName());
/*     */       
/*     */       return;
/*     */     } 
/*     */     
/*     */     try {
/*  76 */       NeoForge.EVENT_BUS.register(handler);
/*  77 */       Journeymap.getLogger().debug("Handler registered: " + handlerClass.getName());
/*  78 */       handlers.put(handler.getClass(), handler);
/*     */     }
/*  80 */     catch (Throwable t) {
/*     */       
/*  82 */       Journeymap.getLogger().error(handlerClass.getName() + " registration FAILED: " + handlerClass.getName());
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void unregister(Class<? extends EventHandler> handlerClass) {
/*  93 */     EventHandler handler = handlers.remove(handlerClass);
/*  94 */     if (handler != null) {
/*     */       
/*     */       try {
/*     */         
/*  98 */         NeoForge.EVENT_BUS.unregister(handler);
/*  99 */         Journeymap.getLogger().debug("Handler unregistered: " + handlerClass.getName());
/*     */       }
/* 101 */       catch (Throwable t) {
/*     */         
/* 103 */         Journeymap.getLogger().error(String.valueOf(handler) + " unregistration FAILED: " + String.valueOf(handler));
/*     */       } 
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public static HashMap<Class<? extends EventHandler>, EventHandler> getHandlers() {
/* 110 */     return handlers;
/*     */   }
/*     */   
/*     */   public static interface EventHandler {}
/*     */ }


/* Location:              C:\Users\Administrator\Downloads\journeymap-neoforge-1.21-6.0.0-beta.18.jar!\journeymap\client\event\NeoForgeEventHandlerManager.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */