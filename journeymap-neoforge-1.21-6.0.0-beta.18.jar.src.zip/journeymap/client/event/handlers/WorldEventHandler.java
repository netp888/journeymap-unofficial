/*    */ package journeymap.client.event.handlers;
/*    */ 
/*    */ import journeymap.client.JourneymapClient;
/*    */ import journeymap.client.cartography.color.ColorManager;
/*    */ import journeymap.client.feature.FeatureManager;
/*    */ import journeymap.common.Journeymap;
/*    */ import net.minecraft.client.Minecraft;
/*    */ import net.minecraft.client.player.LocalPlayer;
/*    */ import net.minecraft.world.level.LevelAccessor;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class WorldEventHandler
/*    */ {
/*    */   public void onUnload(LevelAccessor world) {
/* 25 */     if (JourneymapClient.getInstance().enabled())
/*    */       
/*    */       try {
/*    */         
/* 29 */         ChunkMonitorHandler.getInstance().onWorldUnload(world);
/* 30 */         LocalPlayer localPlayer = (Minecraft.getInstance()).player;
/* 31 */         if (localPlayer != null)
/*    */         {
/* 33 */           if (localPlayer.getCommandSenderWorld().dimensionType().equals(world.dimensionType()))
/*    */           {
/* 35 */             ColorManager.INSTANCE.closePalettes();
/*    */             
/* 37 */             JourneymapClient.getInstance().stopMapping();
/* 38 */             FeatureManager.getInstance().reset();
/*    */           }
/*    */         
/*    */         }
/* 42 */       } catch (Exception e) {
/*    */         
/* 44 */         Journeymap.getLogger().error("Error handling WorldEvent.Unload", e);
/*    */       }  
/*    */   }
/*    */ }


/* Location:              C:\Users\Administrator\Downloads\journeymap-neoforge-1.21-6.0.0-beta.18.jar!\journeymap\client\event\handlers\WorldEventHandler.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */