/*    */ package journeymap.client.event.handlers;
/*    */ 
/*    */ import com.mojang.blaze3d.vertex.PoseStack;
/*    */ import journeymap.client.JourneymapClient;
/*    */ import journeymap.client.render.ingame.WaypointBeaconRenderer;
/*    */ import journeymap.client.render.ingame.WaypointRenderer;
/*    */ import net.minecraft.client.Minecraft;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class WaypointBeaconHandler
/*    */ {
/* 20 */   final Minecraft mc = Minecraft.getInstance();
/* 21 */   final WaypointRenderer beaconRenderer = (WaypointRenderer)new WaypointBeaconRenderer();
/*    */ 
/*    */   
/*    */   public void onRenderWaypoints(PoseStack poseStack, boolean shaderBeacon) {
/* 25 */     if (JourneymapClient.getInstance().enabled() && (JourneymapClient.getInstance().getWaypointProperties()).renderWaypoints.get().booleanValue() && !(this.mc.screen instanceof journeymap.client.ui.fullscreen.Fullscreen)) {
/*    */       
/* 27 */       boolean onlyBeacon = ((JourneymapClient.getInstance().getWaypointProperties()).shaderBeacon.get().booleanValue() && shaderBeacon);
/* 28 */       boolean skipBeacon = ((JourneymapClient.getInstance().getWaypointProperties()).shaderBeacon.get().booleanValue() && !shaderBeacon);
/*    */       
/* 30 */       if (this.mc.player != null && !this.mc.options.hideGui) {
/*    */         
/* 32 */         this.mc.getProfiler().push("journeymap");
/*    */         
/* 34 */         if (onlyBeacon || !skipBeacon) {
/*    */           
/* 36 */           this.mc.getProfiler().push("waypoint_beacons");
/* 37 */           this.beaconRenderer.render(poseStack);
/* 38 */           this.mc.getProfiler().pop();
/*    */         } 
/*    */         
/* 41 */         this.mc.getProfiler().pop();
/*    */       } 
/*    */     } 
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public void onRenderWaypoints(PoseStack poseStack) {
/* 49 */     if (JourneymapClient.getInstance().enabled())
/*    */     {
/* 51 */       onRenderWaypoints(poseStack, false);
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Users\Administrator\Downloads\journeymap-neoforge-1.21-6.0.0-beta.18.jar!\journeymap\client\event\handlers\WaypointBeaconHandler.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */