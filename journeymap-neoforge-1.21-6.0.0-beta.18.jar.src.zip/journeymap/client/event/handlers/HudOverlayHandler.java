/*     */ package journeymap.client.event.handlers;
/*     */ 
/*     */ import java.util.Collections;
/*     */ import java.util.List;
/*     */ import journeymap.client.Constants;
/*     */ import journeymap.client.JourneymapClient;
/*     */ import journeymap.client.log.JMLogger;
/*     */ import journeymap.client.log.StatTimer;
/*     */ import journeymap.client.task.multi.MapPlayerTask;
/*     */ import journeymap.client.ui.UIManager;
/*     */ import journeymap.client.ui.minimap.Effect;
/*     */ import net.minecraft.ChatFormatting;
/*     */ import net.minecraft.client.Minecraft;
/*     */ import net.minecraft.client.gui.GuiGraphics;
/*     */ import net.minecraft.world.phys.Vec2;
/*     */ 
/*     */ 
/*     */ public class HudOverlayHandler
/*     */ {
/*  20 */   private static final String DEBUG_PREFIX = String.valueOf(ChatFormatting.AQUA) + "[JM] " + String.valueOf(ChatFormatting.AQUA);
/*     */   private static final String DEBUG_SUFFIX = "";
/*  22 */   private final Minecraft mc = Minecraft.getInstance();
/*     */   private long statTimerCheck;
/*  24 */   private List<String> statTimerReport = Collections.EMPTY_LIST;
/*     */ 
/*     */ 
/*     */   
/*     */   private static HudOverlayHandler instance;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static HudOverlayHandler getInstance() {
/*  34 */     if (instance == null)
/*     */     {
/*  36 */       instance = new HudOverlayHandler();
/*     */     }
/*  38 */     return instance;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean preOverlay(GuiGraphics graphics) {
/*  43 */     if (JourneymapClient.getInstance().enabled())
/*     */     {
/*  45 */       if (!(Minecraft.getInstance()).options.hideGui && 
/*  46 */         Effect.getInstance().canPotionShift()) {
/*     */ 
/*     */         
/*  49 */         Vec2 location = Effect.getInstance().getPotionEffectsLocation();
/*  50 */         graphics.pose().pushPose();
/*  51 */         graphics.pose().translate(location.x, location.y, 0.0F);
/*  52 */         return true;
/*     */       } 
/*     */     }
/*  55 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void postOverlay(GuiGraphics graphics) {
/*  61 */     if (JourneymapClient.getInstance().enabled())
/*     */     {
/*  63 */       graphics.pose().popPose();
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public void onRenderOverlayDebug(List<String> leftText) {
/*  69 */     if (JourneymapClient.getInstance().enabled()) {
/*     */       
/*     */       try {
/*     */         
/*  73 */         if (this.mc.getDebugOverlay().showDebugScreen() && !"off".equalsIgnoreCase((JourneymapClient.getInstance().getCoreProperties()).logLevel.get())) {
/*     */           
/*  75 */           leftText.add(null);
/*  76 */           if ((JourneymapClient.getInstance().getCoreProperties()).mappingEnabled.get().booleanValue()) {
/*     */             
/*  78 */             for (String line : MapPlayerTask.getDebugStats())
/*     */             {
/*  80 */               leftText.add(DEBUG_PREFIX + DEBUG_PREFIX);
/*     */             }
/*     */           }
/*     */           else {
/*     */             
/*  85 */             leftText.add(Constants.getString("jm.common.enable_mapping_false_text"));
/*     */           } 
/*     */           
/*  88 */           if (this.mc.getDebugOverlay().showProfilerChart())
/*     */           {
/*  90 */             if (System.currentTimeMillis() - this.statTimerCheck > 3000L) {
/*     */               
/*  92 */               this.statTimerReport = StatTimer.getReportByTotalTime(DEBUG_PREFIX, "");
/*  93 */               this.statTimerCheck = System.currentTimeMillis();
/*     */             } 
/*     */             
/*  96 */             leftText.add(null);
/*  97 */             leftText.addAll(this.statTimerReport);
/*     */           }
/*     */         
/*     */         } 
/* 101 */       } catch (Throwable t) {
/*     */         
/* 103 */         JMLogger.throwLogOnce("Unexpected error during onRenderOverlayEarly: " + String.valueOf(t), t);
/*     */       } 
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void onRenderOverlay(GuiGraphics graphics) {
/* 111 */     if (JourneymapClient.getInstance().enabled() && this.mc.screen == null && this.mc.level != null)
/*     */       
/*     */       try {
/*     */ 
/*     */         
/* 116 */         UIManager.INSTANCE.drawWaypointDecorations(graphics.pose());
/* 117 */         if (!(Minecraft.getInstance()).options.hideGui)
/*     */         {
/* 119 */           UIManager.INSTANCE.drawMiniMap(graphics);
/*     */         }
/*     */       }
/* 122 */       catch (Throwable t) {
/*     */         
/* 124 */         JMLogger.throwLogOnce("Unexpected error during onRenderOverlayEarly: " + String.valueOf(t), t);
/*     */       }  
/*     */   }
/*     */ }


/* Location:              C:\Users\Administrator\Downloads\journeymap-neoforge-1.21-6.0.0-beta.18.jar!\journeymap\client\event\handlers\HudOverlayHandler.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */