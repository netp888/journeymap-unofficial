/*     */ package journeymap.client.event.handlers;
/*     */ 
/*     */ import com.google.common.collect.ListMultimap;
/*     */ import com.google.common.collect.Multimap;
/*     */ import com.google.common.collect.MultimapBuilder;
/*     */ import com.mojang.blaze3d.platform.InputConstants;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Comparator;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Objects;
/*     */ import java.util.stream.Collectors;
/*     */ import journeymap.api.common.waypoint.WaypointFactoryImpl;
/*     */ import journeymap.api.services.CommonPlatformService;
/*     */ import journeymap.api.services.Services;
/*     */ import journeymap.client.Constants;
/*     */ import journeymap.client.JourneymapClient;
/*     */ import journeymap.client.event.handlers.keymapping.KeyBindingAction;
/*     */ import journeymap.client.event.handlers.keymapping.KeyConflictContext;
/*     */ import journeymap.client.event.handlers.keymapping.KeyEvent;
/*     */ import journeymap.client.event.handlers.keymapping.KeyModifier;
/*     */ import journeymap.client.event.handlers.keymapping.UpdateAwareKeyBinding;
/*     */ import journeymap.client.ui.UIManager;
/*     */ import journeymap.client.ui.fullscreen.Fullscreen;
/*     */ import journeymap.client.ui.minimap.MiniMap;
/*     */ import journeymap.client.ui.option.ClientOptionsManager;
/*     */ import journeymap.client.ui.waypointmanager.legacy.LegacyWaypointManager;
/*     */ import journeymap.common.Journeymap;
/*     */ import journeymap.common.log.LogFormatter;
/*     */ import net.minecraft.client.KeyMapping;
/*     */ import net.minecraft.client.Minecraft;
/*     */ import net.minecraft.client.gui.screens.Screen;
/*     */ import org.apache.logging.log4j.Logger;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class KeyEventHandler
/*     */ {
/*     */   public UpdateAwareKeyBinding kbMapZoomin;
/*     */   public UpdateAwareKeyBinding kbMapZoomout;
/*     */   public UpdateAwareKeyBinding kbMapToggleType;
/*     */   public UpdateAwareKeyBinding kbCreateWaypoint;
/*     */   public UpdateAwareKeyBinding kbToggleAllWaypoints;
/*     */   public UpdateAwareKeyBinding kbFullscreenCreateWaypoint;
/*     */   public UpdateAwareKeyBinding kbFullscreenChatPosition;
/*     */   public UpdateAwareKeyBinding kbFullscreenToggle;
/*     */   public UpdateAwareKeyBinding kbWaypointManager;
/*     */   public UpdateAwareKeyBinding kbMinimapToggle;
/*     */   public UpdateAwareKeyBinding kbMinimapPreset;
/*     */   public UpdateAwareKeyBinding kbFullmapOptionsManager;
/*     */   public UpdateAwareKeyBinding kbFullmapPanNorth;
/*     */   public UpdateAwareKeyBinding kbFullmapPanSouth;
/*     */   public UpdateAwareKeyBinding kbFullmapPanEast;
/*     */   public UpdateAwareKeyBinding kbFullmapPanWest;
/*     */   public UpdateAwareKeyBinding kbFullmapButtonHide;
/*     */   public UpdateAwareKeyBinding kbEntityNameDisplay;
/*     */   public UpdateAwareKeyBinding kbFullmapFollowPlayer;
/* 134 */   protected Comparator<KeyBindingAction> kbaComparator = Comparator.comparingInt(KeyBindingAction::order);
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 139 */   protected final ListMultimap<Integer, KeyBindingAction> minimapPreviewActions = MultimapBuilder.hashKeys().arrayListValues(2).build();
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 144 */   protected final ListMultimap<Integer, KeyBindingAction> inGameActions = MultimapBuilder.hashKeys().arrayListValues(2).build();
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 149 */   protected final ListMultimap<Integer, KeyBindingAction> inGuiActions = MultimapBuilder.hashKeys().arrayListValues(2).build();
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 154 */   protected Minecraft mc = Minecraft.getInstance();
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean sortActionsNeeded = true;
/*     */ 
/*     */ 
/*     */   
/* 162 */   protected Logger logger = Journeymap.getLogger();
/*     */   
/*     */   protected final KeyEvent keyEvent;
/*     */   
/*     */   public KeyEventHandler(KeyEvent keyEvent) {
/* 167 */     this.keyEvent = keyEvent;
/*     */     
/* 169 */     this.kbMapZoomin = register("key.journeymap.zoom_in", KeyConflictContext.UNIVERSAL, KeyModifier.NONE, 61);
/*     */     
/* 171 */     this.kbMapZoomout = register("key.journeymap.zoom_out", KeyConflictContext.UNIVERSAL, KeyModifier.NONE, 45);
/*     */     
/* 173 */     this.kbMapToggleType = register("key.journeymap.minimap_type", KeyConflictContext.UNIVERSAL, KeyModifier.NONE, 91);
/*     */     
/* 175 */     this.kbMinimapPreset = register("key.journeymap.minimap_preset", KeyConflictContext.IN_GAME, KeyModifier.NONE, 92);
/*     */     
/* 177 */     this.kbCreateWaypoint = register("key.journeymap.create_waypoint", KeyConflictContext.IN_GAME, KeyModifier.NONE, 66);
/*     */     
/* 179 */     this.kbToggleAllWaypoints = register("key.journeymap.toggle_waypoints", KeyConflictContext.UNIVERSAL, KeyModifier.NONE, -1);
/*     */     
/* 181 */     this.kbFullscreenCreateWaypoint = register("key.journeymap.fullscreen_create_waypoint", KeyConflictContext.GUI, KeyModifier.NONE, 66);
/*     */     
/* 183 */     this.kbFullscreenChatPosition = register("key.journeymap.fullscreen_chat_position", KeyConflictContext.GUI, KeyModifier.NONE, 67);
/*     */     
/* 185 */     this.kbFullscreenToggle = register("key.journeymap.map_toggle_alt", KeyConflictContext.UNIVERSAL, KeyModifier.NONE, 74);
/*     */     
/* 187 */     this.kbWaypointManager = register("key.journeymap.fullscreen_waypoints", KeyConflictContext.UNIVERSAL, KeyModifier.NONE, 78);
/*     */     
/* 189 */     if (CommonPlatformService.Loader.FORGE.equals(Services.COMMON_SERVICE.getLoader())) {
/*     */ 
/*     */       
/* 192 */       this.kbMinimapToggle = register("key.journeymap.minimap_toggle_alt", KeyConflictContext.IN_GAME, KeyModifier.CONTROL, 74);
/*     */     
/*     */     }
/*     */     else {
/*     */       
/* 197 */       this.kbMinimapToggle = register("key.journeymap.minimap_toggle_alt", KeyConflictContext.IN_GAME, KeyModifier.NONE, 77);
/*     */     } 
/*     */     
/* 200 */     this.kbFullmapOptionsManager = register("key.journeymap.fullscreen_options", KeyConflictContext.GUI, KeyModifier.NONE, 79);
/*     */     
/* 202 */     this.kbFullmapPanNorth = register("key.journeymap.fullscreen.north", KeyConflictContext.GUI, KeyModifier.NONE, 265);
/*     */     
/* 204 */     this.kbFullmapPanSouth = register("key.journeymap.fullscreen.south", KeyConflictContext.GUI, KeyModifier.NONE, 264);
/*     */     
/* 206 */     this.kbFullmapPanEast = register("key.journeymap.fullscreen.east", KeyConflictContext.GUI, KeyModifier.NONE, 262);
/*     */     
/* 208 */     this.kbFullmapPanWest = register("key.journeymap.fullscreen.west", KeyConflictContext.GUI, KeyModifier.NONE, 263);
/*     */     
/* 210 */     this.kbFullmapFollowPlayer = register("key.journeymap.fullscreen_follow_player", KeyConflictContext.GUI, KeyModifier.NONE, 70);
/*     */     
/* 212 */     this.kbFullmapButtonHide = register("key.journeymap.fullscreen.disable_buttons", KeyConflictContext.GUI, KeyModifier.NONE, -1);
/*     */     
/* 214 */     this.kbEntityNameDisplay = register("key.journeymap.toggle_entity_names", KeyConflictContext.UNIVERSAL, KeyModifier.NONE, 71);
/*     */   }
/*     */ 
/*     */   
/*     */   public KeyEventHandler registerActions() {
/* 219 */     setAction(this.minimapPreviewActions, this.kbMapZoomin, () -> MiniMap.state().minimapZoomIn());
/* 220 */     setAction(this.inGuiActions, this.kbMapZoomin, fullscreenAction(() -> getFullscreen().zoomIn()));
/* 221 */     setAction(this.inGuiActions, this.kbFullmapFollowPlayer, fullscreenAction(() -> getFullscreen().setFollow(Boolean.valueOf(true))));
/* 222 */     setAction(this.minimapPreviewActions, this.kbMapZoomout, () -> MiniMap.state().minimapZoomOut());
/* 223 */     setAction(this.inGuiActions, this.kbMapZoomout, fullscreenAction(() -> getFullscreen().zoomOut()));
/* 224 */     setAction(this.minimapPreviewActions, this.kbMapToggleType, () -> MiniMap.state().toggleMapType());
/* 225 */     setAction(this.inGuiActions, this.kbMapToggleType, fullscreenAction(() -> getFullscreen().toggleMapType()));
/* 226 */     Objects.requireNonNull(UIManager.INSTANCE); setAction(this.minimapPreviewActions, this.kbMinimapPreset, UIManager.INSTANCE::switchMiniMapPreset);
/*     */     
/* 228 */     this.inGameActions.putAll((Multimap)this.minimapPreviewActions);
/* 229 */     setAction(this.inGameActions, this.kbCreateWaypoint, () -> UIManager.INSTANCE.openWaypointEditor(WaypointFactoryImpl.of(this.mc.player), true, true, null));
/* 230 */     setAction(this.inGameActions, this.kbToggleAllWaypoints, LegacyWaypointManager::toggleWaypointRendering);
/* 231 */     setAction(this.inGuiActions, this.kbToggleAllWaypoints, LegacyWaypointManager::toggleWaypointRendering);
/*     */     
/* 233 */     setAction(this.inGuiActions, this.kbFullscreenCreateWaypoint, fullscreenAction(() -> getFullscreen().createWaypointAtMouse()));
/* 234 */     setAction(this.inGuiActions, this.kbFullscreenChatPosition, fullscreenAction(() -> getFullscreen().chatPositionAtMouse()));
/* 235 */     Objects.requireNonNull(UIManager.INSTANCE); setAction(this.inGameActions, this.kbFullscreenToggle, UIManager.INSTANCE::openFullscreenMap);
/* 236 */     setAction(this.inGuiActions, this.kbFullscreenToggle, () -> {
/*     */           if (inFullscreenWithoutChat()) {
/*     */             UIManager.INSTANCE.closeAll();
/*     */           }
/*     */         });
/*     */     
/* 242 */     setAction(this.inGameActions, this.kbWaypointManager, () -> UIManager.INSTANCE.openWaypointManager(null, null));
/* 243 */     setAction(this.inGuiActions, this.kbWaypointManager, () -> {
/*     */           if (inFullscreenWithoutChat()) {
/*     */             UIManager.INSTANCE.openWaypointManager(null, (Screen)getFullscreen());
/*     */           } else if (inWaypointManager()) {
/*     */             UIManager.INSTANCE.closeWithKeyBind();
/*     */           } 
/*     */         });
/*     */ 
/*     */ 
/*     */     
/* 253 */     Objects.requireNonNull(UIManager.INSTANCE); setAction(this.inGameActions, this.kbMinimapToggle, UIManager.INSTANCE::toggleMinimap);
/* 254 */     setAction(this.inGuiActions, this.kbFullmapOptionsManager, () -> {
/*     */           if (inFullscreenWithoutChat()) {
/*     */             UIManager.INSTANCE.openOptionsManager((Screen)getFullscreen(), new journeymap.common.properties.catagory.Category[0]);
/*     */           } else if (inOptionsScreen()) {
/*     */             UIManager.INSTANCE.closeWithKeyBind();
/*     */           } 
/*     */         });
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 265 */     setAction(this.inGuiActions, this.kbFullmapPanNorth, fullscreenAction(() -> getFullscreen().moveCanvas(0.0D, -16.0D)));
/* 266 */     setAction(this.inGuiActions, this.kbFullmapPanSouth, fullscreenAction(() -> getFullscreen().moveCanvas(0.0D, 16.0D)));
/* 267 */     setAction(this.inGuiActions, this.kbFullmapPanEast, fullscreenAction(() -> getFullscreen().moveCanvas(16.0D, 0.0D)));
/* 268 */     setAction(this.inGuiActions, this.kbFullmapPanWest, fullscreenAction(() -> getFullscreen().moveCanvas(-16.0D, 0.0D)));
/* 269 */     setAction(this.inGuiActions, this.kbFullmapButtonHide, fullscreenAction(() -> getFullscreen().hideButtons()));
/* 270 */     setAction(this.inGuiActions, this.kbEntityNameDisplay, fullscreenAction(() -> getFullscreen().toggleEntityNames()));
/* 271 */     Objects.requireNonNull(UIManager.INSTANCE); setAction(this.inGameActions, this.kbEntityNameDisplay, UIManager.INSTANCE::toggleMiniMapEntityNames);
/* 272 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   Runnable fullscreenAction(Runnable action) {
/* 277 */     return () -> {
/*     */         if (inFullscreenWithoutChat()) {
/*     */           action.run();
/*     */         }
/*     */       };
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private UpdateAwareKeyBinding register(String description, KeyConflictContext keyConflictContext, KeyModifier keyModifier, int keyCode) {
/* 300 */     String category = (keyConflictContext == KeyConflictContext.GUI) ? Constants.getString("jm.common.hotkeys_keybinding_fullscreen_category") : Constants.getString("jm.common.hotkeys_keybinding_category");
/*     */     
/* 302 */     UpdateAwareKeyBinding kb = Services.CLIENT_SERVICE.getKeyBinding(description, keyConflictContext, keyModifier, InputConstants.Type.KEYSYM, keyCode, category, this);
/*     */     
/*     */     try {
/* 305 */       this.keyEvent.register((KeyMapping)kb);
/*     */     }
/* 307 */     catch (Throwable t) {
/*     */       
/* 309 */       this.logger.error("Unexpected error when registering keybinding : {} :", kb, t);
/*     */     } 
/* 311 */     return kb;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void setAction(ListMultimap<Integer, KeyBindingAction> multimap, UpdateAwareKeyBinding keyBinding, Runnable action) {
/* 324 */     multimap.put(Integer.valueOf(keyBinding.getKeyValue().getValue()), new KeyBindingAction(keyBinding, action));
/*     */   }
/*     */ 
/*     */   
/*     */   public List<UpdateAwareKeyBinding> getInGuiKeybindings() {
/* 329 */     List<UpdateAwareKeyBinding> list = (List<UpdateAwareKeyBinding>)this.inGuiActions.values().stream().map(KeyBindingAction::getKeyBinding).collect(Collectors.toList());
/* 330 */     list.sort(Comparator.comparing(kb -> Constants.getString(kb.getText())));
/* 331 */     return list;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void sortActions() {
/* 337 */     sortActions(this.minimapPreviewActions);
/* 338 */     sortActions(this.inGameActions);
/* 339 */     sortActions(this.inGuiActions);
/* 340 */     this.sortActionsNeeded = false;
/*     */   }
/*     */ 
/*     */   
/*     */   private void sortActions(ListMultimap<Integer, KeyBindingAction> multimap) {
/* 345 */     List<KeyBindingAction> copy = new ArrayList<>(multimap.values());
/* 346 */     multimap.clear();
/* 347 */     for (KeyBindingAction kba : copy)
/*     */     {
/* 349 */       multimap.put(Integer.valueOf(kba.getKeyBinding().getKeyValue().getValue()), kba);
/*     */     }
/* 351 */     for (Integer key : multimap.keySet()) {
/*     */       
/* 353 */       multimap.get(key).sort(this.kbaComparator);
/* 354 */       Journeymap.getLogger().debug(multimap.get(key));
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public int getPressedKey(ListMultimap<Integer, KeyBindingAction> actions) {
/* 360 */     for (Iterator<Integer> iterator = actions.keySet().iterator(); iterator.hasNext(); ) { int key = ((Integer)iterator.next()).intValue();
/*     */       
/* 362 */       for (KeyBindingAction action : actions.get(Integer.valueOf(key))) {
/*     */         
/* 364 */         if (key != -1 && (action.getKeyBinding().isKeyPressed() || InputConstants.isKeyDown(Minecraft.getInstance().getWindow().getWindow(), key)))
/*     */         {
/* 366 */           return action.getKeyBinding().getKeyValue().getValue();
/*     */         }
/*     */       }  }
/*     */     
/* 370 */     return -1;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean onGameKeyboardEvent(int key) {
/* 381 */     if (JourneymapClient.getInstance().enabled())
/*     */     {
/* 383 */       if (key != InputConstants.UNKNOWN.getValue() && !debugKeyDown()) {
/*     */         
/* 385 */         int pressed = getPressedKey(this.inGameActions);
/* 386 */         if (pressed == key && !isInChat() && emptyScreen())
/*     */         {
/* 388 */           return onInputEvent((Multimap<Integer, KeyBindingAction>)this.inGameActions, key, true, false);
/*     */         }
/*     */       } 
/*     */     }
/* 392 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean onGuiKeyboardEvent(Screen screen, int key) {
/* 402 */     if (JourneymapClient.getInstance().enabled())
/*     */     {
/* 404 */       if (key != InputConstants.UNKNOWN.getValue() && !debugKeyDown()) {
/*     */         
/* 406 */         if (screen == null)
/*     */         {
/* 408 */           return true;
/*     */         }
/* 410 */         int pressed = getPressedKey(this.inGuiActions);
/* 411 */         if (pressed == key) {
/*     */           
/* 413 */           if (inFullscreenWithoutChat() || inWaypointManager() || inOptionsScreen())
/*     */           {
/* 415 */             return onInputEvent((Multimap<Integer, KeyBindingAction>)this.inGuiActions, key, true, false);
/*     */           }
/* 417 */           if (inMinimapPreview())
/*     */           {
/* 419 */             if (onInputEvent((Multimap<Integer, KeyBindingAction>)this.minimapPreviewActions, key, false, false)) {
/*     */               
/* 421 */               ((ClientOptionsManager)this.mc.screen).refreshMinimapOptions();
/* 422 */               return true;
/*     */             } 
/*     */           }
/*     */         } 
/*     */       } 
/*     */     }
/* 428 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean onMouseEvent(int key, Screen screen) {
/* 439 */     if (JourneymapClient.getInstance().enabled()) {
/*     */       
/* 441 */       if (inFullscreenWithoutChat())
/*     */       {
/* 443 */         return onInputEvent((Multimap<Integer, KeyBindingAction>)this.inGuiActions, key, true, true);
/*     */       }
/* 445 */       if (inMinimapPreview()) {
/*     */         
/* 447 */         if (onInputEvent((Multimap<Integer, KeyBindingAction>)this.minimapPreviewActions, key, false, true))
/*     */         {
/* 449 */           ((ClientOptionsManager)this.mc.screen).refreshMinimapOptions();
/*     */         
/*     */         }
/*     */       }
/* 453 */       else if (screen == null) {
/*     */         
/* 455 */         return onInputEvent((Multimap<Integer, KeyBindingAction>)this.inGameActions, key, true, true);
/*     */       } 
/*     */     } 
/* 458 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected boolean onInputEvent(Multimap<Integer, KeyBindingAction> multimap, int key, boolean useContext, boolean mouse) {
/*     */     try {
/* 476 */       if (this.sortActionsNeeded)
/*     */       {
/* 478 */         sortActions();
/*     */       }
/*     */       
/* 481 */       for (KeyBindingAction kba : multimap.get(Integer.valueOf(key))) {
/*     */         
/* 483 */         if (kba.isActive(key, useContext, mouse ? InputConstants.Type.MOUSE : InputConstants.Type.KEYSYM) && (Minecraft.getInstance()).level != null && canUseKey())
/*     */         {
/* 485 */           this.logger.debug("Firing " + String.valueOf(kba));
/* 486 */           kba.getAction().run();
/* 487 */           return true;
/*     */         }
/*     */       
/*     */       } 
/* 491 */     } catch (Exception e) {
/*     */       
/* 493 */       this.logger.error("Error checking keybinding", LogFormatter.toPartialString(e));
/*     */     } 
/* 495 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   protected Fullscreen getFullscreen() {
/* 500 */     return UIManager.INSTANCE.openFullscreenMap();
/*     */   }
/*     */ 
/*     */   
/*     */   protected boolean isInChat() {
/* 505 */     return this.mc.screen instanceof net.minecraft.client.gui.screens.ChatScreen;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected boolean canUseKey() {
/* 511 */     return ((this.mc.screen instanceof journeymap.client.ui.component.screens.JmUILegacy | this.mc.screen instanceof journeymap.client.ui.component.screens.JmUI) != 0 || this.mc.screen == null);
/*     */   }
/*     */ 
/*     */   
/*     */   protected boolean emptyScreen() {
/* 516 */     return (this.mc.screen == null);
/*     */   }
/*     */ 
/*     */   
/*     */   protected boolean debugKeyDown() {
/* 521 */     return InputConstants.isKeyDown(Minecraft.getInstance().getWindow().getWindow(), 292);
/*     */   }
/*     */ 
/*     */   
/*     */   protected boolean inFullscreenWithoutChat() {
/* 526 */     return (this.mc.screen instanceof Fullscreen && !((Fullscreen)this.mc.screen).isChatOpen() && !((Fullscreen)this.mc.screen).isSearchFocused());
/*     */   }
/*     */ 
/*     */   
/*     */   protected boolean inFullscreenWithChatOpen() {
/* 531 */     return (this.mc.screen instanceof Fullscreen && ((Fullscreen)this.mc.screen).isChatOpen());
/*     */   }
/*     */ 
/*     */   
/*     */   protected boolean inWaypointManager() {
/* 536 */     return (this.mc.screen instanceof journeymap.client.ui.waypointmanager.WaypointManager || this.mc.screen instanceof LegacyWaypointManager);
/*     */   }
/*     */ 
/*     */   
/*     */   protected boolean inOptionsScreen() {
/* 541 */     return this.mc.screen instanceof journeymap.client.ui.option.OptionScreen;
/*     */   }
/*     */ 
/*     */   
/*     */   protected boolean inMinimapPreview() {
/* 546 */     return (this.mc.screen instanceof ClientOptionsManager && ((ClientOptionsManager)this.mc.screen).previewMiniMap());
/*     */   }
/*     */ }


/* Location:              C:\Users\Administrator\Downloads\journeymap-neoforge-1.21-6.0.0-beta.18.jar!\journeymap\client\event\handlers\KeyEventHandler.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */