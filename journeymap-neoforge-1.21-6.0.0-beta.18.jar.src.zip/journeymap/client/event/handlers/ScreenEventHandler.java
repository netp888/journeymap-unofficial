/*     */ package journeymap.client.event.handlers;
/*     */ 
/*     */ import journeymap.client.JourneymapClient;
/*     */ import journeymap.client.log.JMLogger;
/*     */ import journeymap.client.ui.UIManager;
/*     */ import journeymap.client.ui.component.screens.LayeredScreen;
/*     */ import journeymap.client.ui.minimap.MiniMap;
/*     */ import journeymap.client.ui.option.ClientOptionsManager;
/*     */ import net.minecraft.client.gui.GuiGraphics;
/*     */ import net.minecraft.client.gui.screens.Screen;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ScreenEventHandler
/*     */ {
/*     */   boolean clicked = false;
/*     */   boolean didDrag = false;
/*     */   static ScreenEventHandler instance;
/*     */   
/*     */   public static ScreenEventHandler getInstance() {
/*  30 */     if (instance == null)
/*     */     {
/*  32 */       instance = new ScreenEventHandler();
/*     */     }
/*  34 */     return instance;
/*     */   }
/*     */ 
/*     */   
/*     */   public void onScreenPreRender(Screen screen, GuiGraphics graphics, int mouseX, int mouseY) {
/*  39 */     if (JourneymapClient.getInstance().enabled()) {
/*     */       
/*     */       try {
/*     */         
/*  43 */         boolean preview = (screen instanceof ClientOptionsManager && ((ClientOptionsManager)screen).previewMiniMap());
/*  44 */         if (allowableDrawScreens(screen) && JourneymapClient.getInstance().isMapping().booleanValue() && (JourneymapClient.getInstance().getActiveMiniMapProperties()).enabled.get().booleanValue())
/*     */         {
/*  46 */           graphics.pose().pushPose();
/*  47 */           MiniMap miniMap = UIManager.INSTANCE.getMiniMap();
/*  48 */           miniMap.drawMap(graphics, true);
/*  49 */           graphics.pose().popPose();
/*     */         }
/*  51 */         else if (!preview)
/*     */         {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */           
/*  60 */           this.clicked = false;
/*     */         }
/*     */       
/*  63 */       } catch (Throwable t) {
/*     */         
/*  65 */         JMLogger.throwLogOnce("Unexpected error during onScreenPreRender: " + String.valueOf(t), t);
/*     */       } 
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean onScreenMousePressedEvent(Screen screen, double mouseX, double mouseY, int button) {
/*  72 */     if (JourneymapClient.getInstance().enabled())
/*     */     {
/*  74 */       if (!this.clicked && allowableDragScreens(screen) && JourneymapClient.getInstance().isMapping().booleanValue()) {
/*     */         
/*  76 */         this.clicked = UIManager.INSTANCE.getMiniMap().mouseClicked(mouseX, mouseY, 0);
/*  77 */         return this.clicked;
/*     */       } 
/*     */     }
/*  80 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean onScreenMouseDraggedEvent(Screen screen, double mouseX, double mouseY, double dragX, double dragY, int mouseButton) {
/*  85 */     if (JourneymapClient.getInstance().enabled())
/*     */     {
/*  87 */       if (this.clicked && allowableDragScreens(screen) && JourneymapClient.getInstance().isMapping().booleanValue()) {
/*     */         
/*  89 */         this.didDrag = UIManager.INSTANCE.getMiniMap().mouseDragged(mouseX, mouseY, mouseButton, dragX, dragY);
/*  90 */         return this.didDrag;
/*     */       } 
/*     */     }
/*  93 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean onScreenMouseReleasedEvent(Screen screen, double mouseX, double mouseY, int button) {
/*  98 */     if (JourneymapClient.getInstance().enabled())
/*     */     {
/* 100 */       if (UIManager.INSTANCE.getMiniMap() != null && UIManager.INSTANCE.getMiniMap().mouseReleased(mouseX, mouseY, button)) {
/*     */         
/* 102 */         this.clicked = false;
/* 103 */         return true;
/*     */       } 
/*     */     }
/* 106 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public void onScreenClosedEvent(Screen screen) {
/* 111 */     if (JourneymapClient.getInstance().enabled() && 
/* 112 */       JourneymapClient.getInstance().isMapping().booleanValue() && UIManager.INSTANCE
/* 113 */       .getMiniMap() != null) {
/*     */       
/* 115 */       UIManager.INSTANCE.getMiniMap().mouseReleased(0.0D, 0.0D, 0);
/* 116 */       this.clicked = false;
/* 117 */       this.didDrag = false;
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   private boolean allowableDragScreens(Screen screen) {
/* 123 */     return screen instanceof ClientOptionsManager;
/*     */   }
/*     */ 
/*     */   
/*     */   private boolean allowableDrawScreens(Screen screen) {
/* 128 */     if (screen instanceof LayeredScreen) { LayeredScreen layeredScreen = (LayeredScreen)screen;
/*     */       
/* 130 */       return allowableDrawScreens(layeredScreen.getBackgroundScreen()); }
/*     */     
/* 132 */     return (!(screen instanceof journeymap.client.ui.fullscreen.Fullscreen) && !(screen instanceof journeymap.client.ui.option.MinimapOptions) && !(screen instanceof journeymap.client.ui.option.OptionScreen) && !(screen instanceof journeymap.client.ui.fullscreen.MapChat));
/*     */   }
/*     */ }


/* Location:              C:\Users\Administrator\Downloads\journeymap-neoforge-1.21-6.0.0-beta.18.jar!\journeymap\client\event\handlers\ScreenEventHandler.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */