/*    */ package journeymap.client.event.handlers;
/*    */ 
/*    */ import journeymap.api.client.impl.ClientAPI;
/*    */ import journeymap.client.JourneymapClient;
/*    */ import journeymap.common.Journeymap;
/*    */ import journeymap.common.log.LogFormatter;
/*    */ import net.minecraft.client.Minecraft;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class StateTickHandler
/*    */ {
/* 19 */   Minecraft mc = Minecraft.getInstance();
/* 20 */   int counter = 0;
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void onClientTick() {
/* 26 */     this.mc.getProfiler().push("journeymap");
/*    */ 
/*    */ 
/*    */     
/*    */     try {
/* 31 */       if (this.counter == 20)
/*    */       {
/* 33 */         this.mc.getProfiler().push("mainTasks");
/* 34 */         JourneymapClient.getInstance().performMainThreadTasks();
/* 35 */         this.counter = 0;
/* 36 */         this.mc.getProfiler().pop();
/*    */       }
/* 38 */       else if (this.counter == 10 && JourneymapClient.getInstance().enabled())
/*    */       {
/* 40 */         this.mc.getProfiler().push("multithreadTasks");
/* 41 */         if (JourneymapClient.getInstance().isMapping().booleanValue() && this.mc.level != null)
/*    */         {
/* 43 */           JourneymapClient.getInstance().performMultithreadTasks();
/*    */         }
/* 45 */         this.counter++;
/* 46 */         this.mc.getProfiler().pop();
/*    */       }
/* 48 */       else if ((this.counter == 5 || this.counter == 15) && JourneymapClient.getInstance().enabled())
/*    */       {
/* 50 */         this.mc.getProfiler().push("clientApiEvents");
/* 51 */         ClientAPI.INSTANCE.getClientEventManager().fireNextClientEvents();
/* 52 */         this.counter++;
/* 53 */         this.mc.getProfiler().pop();
/*    */       }
/*    */       else
/*    */       {
/* 57 */         this.counter++;
/*    */       }
/*    */     
/* 60 */     } catch (Throwable t) {
/*    */       
/* 62 */       Journeymap.getLogger().warn("Error during onClientTick: " + LogFormatter.toPartialString(t));
/*    */     }
/*    */     finally {
/*    */       
/* 66 */       this.mc.getProfiler().pop();
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Users\Administrator\Downloads\journeymap-neoforge-1.21-6.0.0-beta.18.jar!\journeymap\client\event\handlers\StateTickHandler.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */