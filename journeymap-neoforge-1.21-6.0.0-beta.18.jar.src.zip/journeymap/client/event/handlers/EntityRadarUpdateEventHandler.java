/*     */ package journeymap.client.event.handlers;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import journeymap.api.v2.client.display.Context;
/*     */ import journeymap.api.v2.client.event.EntityRadarUpdateEvent;
/*     */ import journeymap.api.v2.client.util.UIState;
/*     */ import journeymap.api.v2.common.event.ClientEventRegistry;
/*     */ import journeymap.client.Constants;
/*     */ import journeymap.client.JourneymapClient;
/*     */ import journeymap.client.model.EntityDTO;
/*     */ import journeymap.client.properties.InGameMapProperties;
/*     */ import journeymap.client.ui.UIManager;
/*     */ import net.minecraft.network.chat.Component;
/*     */ import net.minecraft.network.chat.MutableComponent;
/*     */ import net.minecraft.network.chat.Style;
/*     */ import net.minecraft.world.entity.Entity;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class EntityRadarUpdateEventHandler
/*     */ {
/*     */   public static EntityRadarUpdateEventHandler INSTANCE;
/*     */   
/*     */   private EntityRadarUpdateEventHandler() {
/*  27 */     ClientEventRegistry.ENTITY_RADAR_UPDATE_EVENT.subscribe("journeymap", this::onRadarEntityUpdateEvent);
/*     */   }
/*     */ 
/*     */   
/*     */   public static EntityRadarUpdateEventHandler init() {
/*  32 */     if (INSTANCE == null)
/*     */     {
/*  34 */       INSTANCE = new EntityRadarUpdateEventHandler();
/*     */     }
/*  36 */     return INSTANCE;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private void onRadarEntityUpdateEvent(EntityRadarUpdateEvent event) {
/*  42 */     if (JourneymapClient.getInstance().enabled() && !event.isCancelled() && event.getActiveUiState() != null)
/*     */     {
/*  44 */       if (EntityRadarUpdateEvent.EntityType.MOB.equals(event.getType())) {
/*     */         
/*  46 */         Entity livingEntity = event.getWrappedEntity().getEntityRef().get();
/*  47 */         if (livingEntity != null) {
/*     */           
/*  49 */           boolean showNames = (getProperties(event.getActiveUiState())).showEntityNames.get().booleanValue();
/*  50 */           Component name = getEntityName((EntityDTO)event.getWrappedEntity(), event.getActiveUiState(), showNames);
/*  51 */           if (!event.getWrappedEntity().isSneaking() && name != null) {
/*     */             
/*  53 */             event.getWrappedEntity().setCustomName(name);
/*  54 */             addEntityToolTips((EntityDTO)event.getWrappedEntity(), event.getActiveUiState(), name, showNames);
/*     */           } 
/*     */         } 
/*     */       } 
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Component getEntityName(EntityDTO entity, UIState activeUiState, boolean showNames) {
/*  66 */     InGameMapProperties properties = getProperties(activeUiState);
/*  67 */     MutableComponent name = null;
/*  68 */     String baseName = null;
/*  69 */     Entity livingEntity = entity.entityRef.get();
/*  70 */     if (livingEntity != null) {
/*     */       
/*  72 */       if (showNames && properties.showHostileNames.get().booleanValue() && entity.getHostile().booleanValue()) {
/*     */         
/*  74 */         baseName = livingEntity.getName().getString();
/*     */       }
/*  76 */       else if (showNames && properties.showPassiveNames.get().booleanValue() && entity.isPassiveAnimal()) {
/*     */         
/*  78 */         baseName = livingEntity.getName().getString();
/*     */       }
/*  80 */       else if (showNames && properties.showPetNames.get().booleanValue() && entity.owner != null) {
/*     */         
/*  82 */         baseName = livingEntity.getName().getString();
/*     */       }
/*  84 */       else if (showNames && properties.showNpcNames.get().booleanValue() && entity.isNpc()) {
/*     */         
/*  86 */         baseName = livingEntity.getName().getString();
/*     */       }
/*  88 */       else if (showNames && properties.showVillagerNames.get().booleanValue() && entity.getProfession() != null) {
/*     */         
/*  90 */         baseName = livingEntity.getName().getString();
/*     */       }
/*  92 */       else if (showNames && properties.showAmbientNames.get().booleanValue() && entity.isAmbientCreature()) {
/*     */         
/*  94 */         baseName = livingEntity.getName().getString();
/*     */       }
/*  96 */       else if (properties.showNoIconNames.get().booleanValue() && entity.getEntityIconLocation() == null) {
/*     */         
/*  98 */         baseName = livingEntity.getName().getString();
/*     */       } 
/* 100 */       if (baseName != null) {
/*     */         
/* 102 */         name = Component.literal(baseName);
/* 103 */         name.withStyle(style -> style.withColor(entity.getLabelColor()).withBold(Boolean.valueOf(true)));
/*     */       } 
/*     */     } 
/* 106 */     return (Component)name;
/*     */   }
/*     */ 
/*     */   
/*     */   public static void addEntityToolTips(EntityDTO entity, UIState activeUiState, Component name, boolean showNames) {
/* 111 */     InGameMapProperties properties = getProperties(activeUiState);
/* 112 */     if (!entity.isSneaking() && name != null) {
/*     */       
/* 114 */       MutableComponent profession = null;
/* 115 */       Entity livingEntity = entity.getEntityRef().get();
/* 116 */       if (showNames && properties.showVillagerNames.get().booleanValue() && entity.getProfession() != null) {
/*     */         
/* 118 */         profession = Component.literal(Constants.getString("jm.common.profession.label") + Constants.getString("jm.common.profession.label"));
/* 119 */         int color = 16777215;
/* 120 */         profession.withStyle(style -> style.withColor(color));
/*     */       } 
/*     */       
/* 123 */       String id = livingEntity.getEncodeId();
/* 124 */       MutableComponent resource = null;
/* 125 */       if (id != null) {
/*     */         
/* 127 */         resource = Component.literal(id);
/* 128 */         int color = 16777215;
/* 129 */         resource.withStyle(style -> style.withColor(color));
/*     */       } 
/* 131 */       addToolTips(entity, new Component[] { name, (Component)profession, (Component)resource });
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   private static InGameMapProperties getProperties(UIState activeUiState) {
/* 137 */     if (Context.UI.Minimap.equals(activeUiState.ui))
/*     */     {
/* 139 */       return (InGameMapProperties)UIManager.INSTANCE.getMiniMap().getCurrentMinimapProperties();
/*     */     }
/* 141 */     return (InGameMapProperties)JourneymapClient.getInstance().getFullMapProperties();
/*     */   }
/*     */ 
/*     */   
/*     */   private static void addToolTips(EntityDTO entity, Component... toolTips) {
/* 146 */     ArrayList<Component> tips = new ArrayList<>();
/*     */     
/* 148 */     for (Component tt : toolTips) {
/*     */       
/* 150 */       if (tt != null)
/*     */       {
/* 152 */         tips.add(tt);
/*     */       }
/*     */     } 
/* 155 */     if (!tips.isEmpty())
/*     */     {
/* 157 */       entity.setEntityToolTips(tips);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\Administrator\Downloads\journeymap-neoforge-1.21-6.0.0-beta.18.jar!\journeymap\client\event\handlers\EntityRadarUpdateEventHandler.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */