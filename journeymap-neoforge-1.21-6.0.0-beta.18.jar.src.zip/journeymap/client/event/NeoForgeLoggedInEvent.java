/*    */ package journeymap.client.event;
/*    */ 
/*    */ import journeymap.client.event.handlers.PlayerConnectHandler;
/*    */ import net.neoforged.bus.api.SubscribeEvent;
/*    */ import net.neoforged.neoforge.client.event.ClientPlayerNetworkEvent;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class NeoForgeLoggedInEvent
/*    */   implements NeoForgeEventHandlerManager.EventHandler
/*    */ {
/* 14 */   private final PlayerConnectHandler playerConnectHandler = new PlayerConnectHandler();
/*    */ 
/*    */ 
/*    */   
/*    */   @SubscribeEvent
/*    */   public void onConnect(ClientPlayerNetworkEvent.LoggingIn event) {
/* 20 */     this.playerConnectHandler.onConnect();
/*    */   }
/*    */ }


/* Location:              C:\Users\Administrator\Downloads\journeymap-neoforge-1.21-6.0.0-beta.18.jar!\journeymap\client\event\NeoForgeLoggedInEvent.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */