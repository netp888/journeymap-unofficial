/*    */ package journeymap.client.event;
/*    */ 
/*    */ import journeymap.client.event.handlers.HudOverlayHandler;
/*    */ import journeymap.client.ui.minimap.Effect;
/*    */ import net.minecraft.client.Minecraft;
/*    */ import net.neoforged.bus.api.EventPriority;
/*    */ import net.neoforged.bus.api.SubscribeEvent;
/*    */ import net.neoforged.neoforge.client.event.CustomizeGuiOverlayEvent;
/*    */ import net.neoforged.neoforge.client.event.RenderGuiEvent;
/*    */ import net.neoforged.neoforge.client.event.RenderGuiLayerEvent;
/*    */ import net.neoforged.neoforge.client.gui.VanillaGuiLayers;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class NeoForgeHudOverlayEvents
/*    */   implements NeoForgeEventHandlerManager.EventHandler
/*    */ {
/*    */   private boolean shouldPop = false;
/*    */   
/*    */   @SubscribeEvent(priority = EventPriority.LOWEST)
/*    */   public void preOverlayLow(RenderGuiLayerEvent.Pre event) {
/* 23 */     if (VanillaGuiLayers.EFFECTS.equals(event.getName())) {
/*    */       
/* 25 */       this.shouldPop = HudOverlayHandler.getInstance().preOverlay(event.getGuiGraphics());
/*    */     }
/*    */     else {
/*    */       
/* 29 */       this.shouldPop = false;
/*    */     } 
/* 31 */     if (VanillaGuiLayers.DEBUG_OVERLAY.equals(event.getName()) && (Minecraft.getInstance()).gui.getDebugOverlay().showDebugScreen())
/*    */     {
/*    */       
/* 34 */       HudOverlayHandler.getInstance().onRenderOverlay(event.getGuiGraphics());
/*    */     }
/*    */   }
/*    */ 
/*    */   
/*    */   @SubscribeEvent(priority = EventPriority.NORMAL, receiveCanceled = true)
/*    */   public void postGuiOverlay(RenderGuiEvent.Post event) {
/* 41 */     if (Effect.getInstance().canPotionShift())
/*    */     {
/* 43 */       this.shouldPop = false;
/*    */     }
/*    */     
/* 46 */     if (!(Minecraft.getInstance()).gui.getDebugOverlay().showDebugScreen())
/*    */     {
/*    */       
/* 49 */       HudOverlayHandler.getInstance().onRenderOverlay(event.getGuiGraphics());
/*    */     }
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   @SubscribeEvent(priority = EventPriority.HIGHEST, receiveCanceled = true)
/*    */   public void postOverlayLayer(RenderGuiLayerEvent.Post event) {
/* 58 */     if (VanillaGuiLayers.EFFECTS.equals(event.getName()) && this.shouldPop)
/*    */     {
/* 60 */       if (Effect.getInstance().canPotionShift()) {
/*    */         
/* 62 */         HudOverlayHandler.getInstance().postOverlay(event.getGuiGraphics());
/* 63 */         this.shouldPop = false;
/*    */       } 
/*    */     }
/*    */   }
/*    */   
/*    */   @SubscribeEvent(priority = EventPriority.NORMAL)
/*    */   public void onRenderOverlayDebug(CustomizeGuiOverlayEvent.DebugText event) {
/* 70 */     HudOverlayHandler.getInstance().onRenderOverlayDebug(event.getLeft());
/*    */   }
/*    */ }


/* Location:              C:\Users\Administrator\Downloads\journeymap-neoforge-1.21-6.0.0-beta.18.jar!\journeymap\client\event\NeoForgeHudOverlayEvents.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */