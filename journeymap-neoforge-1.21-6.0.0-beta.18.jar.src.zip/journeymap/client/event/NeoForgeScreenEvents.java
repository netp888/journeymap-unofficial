/*    */ package journeymap.client.event;
/*    */ 
/*    */ import journeymap.client.event.handlers.ScreenEventHandler;
/*    */ import net.neoforged.bus.api.SubscribeEvent;
/*    */ import net.neoforged.neoforge.client.event.ScreenEvent;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class NeoForgeScreenEvents
/*    */   implements NeoForgeEventHandlerManager.EventHandler
/*    */ {
/*    */   @SubscribeEvent
/*    */   public void onScreenMousePressedEvent(ScreenEvent.MouseButtonPressed.Pre event) {
/* 17 */     boolean handled = ScreenEventHandler.getInstance().onScreenMousePressedEvent(event.getScreen(), event.getMouseX(), event.getMouseY(), event.getButton());
/* 18 */     event.setCanceled(handled);
/*    */   }
/*    */ 
/*    */   
/*    */   @SubscribeEvent
/*    */   public void onScreenMouseDraggedEvent(ScreenEvent.MouseDragged.Pre event) {
/* 24 */     boolean handled = ScreenEventHandler.getInstance().onScreenMouseDraggedEvent(event.getScreen(), event.getMouseX(), event.getMouseY(), event.getDragX(), event.getDragY(), event.getMouseButton());
/* 25 */     event.setCanceled(handled);
/*    */   }
/*    */ 
/*    */   
/*    */   @SubscribeEvent
/*    */   public void onScreenMouseReleasedEvent(ScreenEvent.MouseButtonReleased.Pre event) {
/* 31 */     boolean handled = ScreenEventHandler.getInstance().onScreenMouseReleasedEvent(event.getScreen(), event.getMouseX(), event.getMouseY(), event.getButton());
/* 32 */     event.setCanceled(handled);
/*    */   }
/*    */ 
/*    */   
/*    */   @SubscribeEvent
/*    */   public void onScreenMouseReleasedEvent(ScreenEvent.Closing event) {
/* 38 */     ScreenEventHandler.getInstance().onScreenClosedEvent(event.getScreen());
/*    */   }
/*    */ }


/* Location:              C:\Users\Administrator\Downloads\journeymap-neoforge-1.21-6.0.0-beta.18.jar!\journeymap\client\event\NeoForgeScreenEvents.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */