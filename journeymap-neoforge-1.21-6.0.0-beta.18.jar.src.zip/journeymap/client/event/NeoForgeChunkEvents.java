/*    */ package journeymap.client.event;
/*    */ 
/*    */ import journeymap.client.event.handlers.ChunkMonitorHandler;
/*    */ import net.minecraft.world.level.LevelAccessor;
/*    */ import net.neoforged.bus.api.SubscribeEvent;
/*    */ import net.neoforged.neoforge.event.level.BlockEvent;
/*    */ import net.neoforged.neoforge.event.level.ChunkEvent;
/*    */ import net.neoforged.neoforge.event.level.ChunkWatchEvent;
/*    */ 
/*    */ public class NeoForgeChunkEvents
/*    */   implements NeoForgeEventHandlerManager.EventHandler
/*    */ {
/*    */   @SubscribeEvent
/*    */   public void onBlockUpdate(BlockEvent.BreakEvent event) {
/* 15 */     ChunkMonitorHandler.getInstance().onBlockUpdate(event.getLevel(), event.getPos());
/*    */   }
/*    */ 
/*    */   
/*    */   @SubscribeEvent
/*    */   public void onBlockUpdate(BlockEvent.EntityMultiPlaceEvent event) {
/* 21 */     ChunkMonitorHandler.getInstance().onBlockUpdate(event.getLevel(), event.getPos());
/*    */   }
/*    */ 
/*    */   
/*    */   @SubscribeEvent
/*    */   public void onBlockUpdate(BlockEvent.NeighborNotifyEvent event) {
/* 27 */     ChunkMonitorHandler.getInstance().onBlockUpdate(event.getLevel(), event.getPos());
/*    */   }
/*    */ 
/*    */   
/*    */   @SubscribeEvent
/*    */   public void onBlockUpdate(BlockEvent.EntityPlaceEvent event) {
/* 33 */     ChunkMonitorHandler.getInstance().onBlockUpdate(event.getLevel(), event.getPos());
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   @SubscribeEvent
/*    */   public void onChunkUpdate(ChunkWatchEvent.Watch event) {
/* 40 */     ChunkMonitorHandler.getInstance().onChunkUpdate((LevelAccessor)event.getLevel(), event.getPos());
/*    */   }
/*    */ 
/*    */   
/*    */   @SubscribeEvent
/*    */   public void onChunkLoad(ChunkEvent.Load event) {
/* 46 */     ChunkMonitorHandler.getInstance().onChunkLoad(event.getLevel(), event.getChunk());
/*    */   }
/*    */ }


/* Location:              C:\Users\Administrator\Downloads\journeymap-neoforge-1.21-6.0.0-beta.18.jar!\journeymap\client\event\NeoForgeChunkEvents.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */