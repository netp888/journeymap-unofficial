/*     */ package journeymap.client.properties;
/*     */ 
/*     */ import journeymap.client.ui.minimap.Orientation;
/*     */ import journeymap.client.ui.minimap.Position;
/*     */ import journeymap.client.ui.minimap.ReticleOrientation;
/*     */ import journeymap.client.ui.minimap.Shape;
/*     */ import journeymap.client.ui.option.MapTypeProvider;
/*     */ import journeymap.client.ui.option.TimeFormat;
/*     */ import journeymap.client.ui.theme.ThemeLabelSource;
/*     */ import journeymap.common.properties.catagory.Category;
/*     */ import journeymap.common.properties.config.BooleanField;
/*     */ import journeymap.common.properties.config.EnumField;
/*     */ import journeymap.common.properties.config.FloatField;
/*     */ import journeymap.common.properties.config.IntegerField;
/*     */ import journeymap.common.properties.config.StringField;
/*     */ import journeymap.common.properties.config.custom.MinimapCaveLayerIntField;
/*     */ import net.minecraft.client.Minecraft;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MiniMapProperties
/*     */   extends InGameMapProperties
/*     */ {
/*  37 */   public final BooleanField enabled = new BooleanField(Category.Inherit, "jm.minimap.enable_minimap", true, true, 1);
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  42 */   public final BooleanField showDayNight = new BooleanField(Category.Inherit, "jm.common.show_day_night", true, 5);
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  47 */   public final StringField minimapLockedMapType = new StringField(Category.Inherit, "jm.minimap.map_type", MapTypeProvider.ANY.key(), MapTypeProvider.class, 150);
/*     */   
/*  49 */   public final IntegerField caveLayer = (IntegerField)new MinimapCaveLayerIntField(Category.Inherit, "jm.minimap.cave_slice.slider", -4, 15, 4, 1, 151);
/*     */ 
/*     */ 
/*     */   
/*  53 */   public final StringField info1Label = new StringField(Category.Inherit, "jm.minimap.info1_label.button", ThemeLabelSource.Blank.getKey(), ThemeLabelSource.class, 141);
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  58 */   public final StringField info2Label = new StringField(Category.Inherit, "jm.minimap.info2_label.button", ThemeLabelSource.GameTime.getKey(), ThemeLabelSource.class, 142);
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  63 */   public final StringField info3Label = new StringField(Category.Inherit, "jm.minimap.info3_label.button", ThemeLabelSource.Location.getKey(), ThemeLabelSource.class, 143);
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  68 */   public final StringField info4Label = new StringField(Category.Inherit, "jm.minimap.info4_label.button", ThemeLabelSource.Biome.getKey(), ThemeLabelSource.class, 144);
/*     */   
/*  70 */   public final FloatField infoSlotAlpha = new FloatField(Category.Inherit, "jm.minimap.info_slot.background_alpha", 0.0F, 1.0F, 0.7F, 145);
/*     */   
/*  72 */   public final FloatField infoSlotFontScale = new FloatField(Category.Inherit, "jm.minimap.info_slot.font_scale", 0.5F, 5.0F, 1.0F, 125);
/*     */   
/*  74 */   public final StringField gameTimeRealFormat = new StringField(Category.Inherit, "jm.common.time_format", TimeFormat.Provider.class, 146);
/*     */   
/*  76 */   public final StringField systemTimeRealFormat = new StringField(Category.Inherit, "jm.common.system_time_format", TimeFormat.Provider.class, 147);
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  81 */   public final EnumField<ReticleOrientation> reticleOrientation = new EnumField(Category.Inherit, "jm.minimap.reticle_orientation", (Enum)ReticleOrientation.Compass, 186);
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  86 */   public final EnumField<Shape> shape = new EnumField(Category.Inherit, "jm.minimap.shape", (Enum)Shape.Circle, 180);
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  91 */   public final IntegerField sizePercent = new IntegerField(Category.Inherit, "jm.minimap.size", 1, 100, 30, 205);
/*     */ 
/*     */ 
/*     */   
/*  95 */   public final IntegerField frameAlpha = new IntegerField(Category.Inherit, "jm.minimap.frame_alpha", 0, 100, 100, 190);
/*     */ 
/*     */ 
/*     */   
/*  99 */   public final IntegerField terrainAlpha = new IntegerField(Category.Inherit, "jm.minimap.terrain_alpha", 0, 100, 100, 195);
/* 100 */   public final FloatField backgroundAlpha = new FloatField(Category.Inherit, "jm.minimap.terrain_background_alpha", 0.0F, 1.0F, 0.8F, 200);
/*     */ 
/*     */ 
/*     */   
/* 104 */   public final EnumField<Orientation> orientation = new EnumField(Category.Inherit, "jm.minimap.orientation.button", (Enum)Orientation.North, 185);
/*     */ 
/*     */ 
/*     */   
/* 108 */   public final FloatField compassFontScale = new FloatField(Category.Inherit, "jm.minimap.compass_font_scale", 0.5F, 4.0F, 1.0F, 120);
/*     */ 
/*     */ 
/*     */   
/* 112 */   public final BooleanField showCompass = new BooleanField(Category.Inherit, "jm.minimap.show_compass", true, 10);
/*     */ 
/*     */ 
/*     */   
/* 116 */   public final BooleanField showReticle = new BooleanField(Category.Inherit, "jm.minimap.show_reticle", true, 15);
/*     */   
/* 118 */   public final FloatField positionX = new FloatField(Category.Hidden, "jm.minimap.position_x", 0.0F, 1.0F, 0.9F);
/*     */   
/* 120 */   public final FloatField positionY = new FloatField(Category.Hidden, "jm.minimap.position_y", 0.0F, 1.0F, 0.25F);
/*     */   
/* 122 */   public final BooleanField moveEffectIcons = new BooleanField(ClientCategory.MinimapPosition, "jm.hud.effects.enable", true);
/*     */   
/* 124 */   public final IntegerField effectTranslateX = new IntegerField(Category.Hidden, "jm.hud.effects.location.button", -10000, 10000, 0);
/* 125 */   public final IntegerField effectTranslateY = new IntegerField(Category.Hidden, "jm.hud.effects.location.button", -10000, 10000, 0);
/* 126 */   public final BooleanField effectVertical = new BooleanField(ClientCategory.MinimapPosition, "jm.hud.effects.style.vertical", false);
/* 127 */   public final BooleanField effectReversed = new BooleanField(ClientCategory.MinimapPosition, "jm.hud.effects.style.reverse", false);
/* 128 */   public final FloatField minimapKeyMovementSpeed = new FloatField(ClientCategory.MinimapPosition, "jm.hud.minimap.key_movement_speed", 0.001F, 0.025F, 0.001F, 0.001F, 3);
/* 129 */   public final EnumField<Position> position = new EnumField(ClientCategory.MinimapPosition, "jm.minimap.position", (Enum)Position.TopRight);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected final transient int id;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected boolean active = false;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MiniMapProperties(int id) {
/* 148 */     this.id = id;
/* 149 */     setPropertiesId(Integer.valueOf(id));
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String getName() {
/* 155 */     return String.format("minimap%s", new Object[] { (this.id > 1) ? Integer.valueOf(this.id) : "" });
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isActive() {
/* 165 */     return this.active;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setActive(boolean active) {
/* 175 */     if (this.active != active) {
/*     */       
/* 177 */       this.active = active;
/* 178 */       save();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getId() {
/* 189 */     return this.id;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public <T extends journeymap.common.properties.PropertiesBase> void updateFrom(T otherInstance) {
/* 195 */     super.updateFrom(otherInstance);
/* 196 */     if (otherInstance instanceof MiniMapProperties)
/*     */     {
/* 198 */       setActive(((MiniMapProperties)otherInstance).isActive());
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getSize() {
/* 209 */     return (int)Math.max(128.0D, Math.floor(this.sizePercent.get().intValue() / 100.0D * Minecraft.getInstance().getWindow().getScreenHeight()));
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected void postLoad(boolean isNew) {
/* 215 */     super.postLoad(isNew);
/*     */     
/* 217 */     if (isNew)
/*     */     {
/* 219 */       if (getId() == 1) {
/*     */         
/* 221 */         setActive(true);
/* 222 */         if (Minecraft.getInstance() != null && (Minecraft.getInstance()).font.isBidirectional())
/*     */         {
/* 224 */           this.fontScale.set(Float.valueOf(2.0F));
/* 225 */           this.infoSlotFontScale.set(Float.valueOf(2.0F));
/* 226 */           this.compassFontScale.set(Float.valueOf(2.0F));
/*     */         }
/*     */       
/*     */       }
/*     */       else {
/*     */         
/* 232 */         setActive(false);
/* 233 */         this.positionX.set(Float.valueOf(90.0F));
/* 234 */         this.positionY.set(Float.valueOf(25.0F));
/* 235 */         this.position.set((Enum)Position.TopRight);
/* 236 */         this.shape.set((Enum)Shape.Rectangle);
/* 237 */         this.frameAlpha.set(Integer.valueOf(100));
/* 238 */         this.terrainAlpha.set(Integer.valueOf(100));
/* 239 */         this.orientation.set((Enum)Orientation.North);
/* 240 */         this.reticleOrientation.set((Enum)ReticleOrientation.Compass);
/* 241 */         this.sizePercent.set(Integer.valueOf(30));
/* 242 */         if (Minecraft.getInstance() != null && (Minecraft.getInstance()).font.isBidirectional()) {
/*     */           
/* 244 */           this.fontScale.set(Float.valueOf(2.0F));
/* 245 */           this.infoSlotFontScale.set(Float.valueOf(2.0F));
/* 246 */           this.compassFontScale.set(Float.valueOf(2.0F));
/*     */         } 
/*     */       } 
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\Administrator\Downloads\journeymap-neoforge-1.21-6.0.0-beta.18.jar!\journeymap\client\properties\MiniMapProperties.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */