/*     */ package journeymap.client.command;
/*     */ 
/*     */ import com.mojang.authlib.GameProfile;
/*     */ import java.util.TreeSet;
/*     */ import journeymap.client.JourneymapClient;
/*     */ import journeymap.client.waypoint.ClientWaypointImpl;
/*     */ import journeymap.common.Journeymap;
/*     */ import journeymap.common.helper.DimensionHelper;
/*     */ import journeymap.common.log.LogFormatter;
/*     */ import net.minecraft.client.Minecraft;
/*     */ import net.minecraft.client.server.IntegratedServer;
/*     */ import net.minecraft.core.BlockPos;
/*     */ import net.minecraft.resources.ResourceKey;
/*     */ import net.minecraft.server.players.PlayerList;
/*     */ import net.minecraft.world.level.Level;
/*     */ import net.minecraft.world.level.storage.ServerLevelData;
/*     */ import org.jetbrains.annotations.Nullable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class CmdTeleportWaypoint
/*     */ {
/*  30 */   final Minecraft mc = Minecraft.getInstance();
/*     */   
/*     */   final ClientWaypointImpl waypoint;
/*     */   
/*     */   public CmdTeleportWaypoint(ClientWaypointImpl waypoint) {
/*  35 */     this.waypoint = waypoint;
/*     */   }
/*     */ 
/*     */   
/*     */   public static boolean isPermitted(Minecraft mc) {
/*  40 */     if (mc.getSingleplayerServer() != null) {
/*     */       
/*  42 */       IntegratedServer mcServer = mc.getSingleplayerServer();
/*  43 */       PlayerList configurationManager = null;
/*  44 */       GameProfile profile = null;
/*     */       
/*     */       try {
/*  47 */         profile = new GameProfile(mc.player.getUUID(), mc.player.getName().getString());
/*  48 */         configurationManager = mcServer.getPlayerList();
/*     */ 
/*     */         
/*  51 */         Journeymap.getLogger().debug("integrated server not null, can send commands: " + configurationManager.isOp(profile) + " is tp enabled: " + JourneymapClient.getInstance().getStateHandler().isTeleportEnabled());
/*  52 */         return (configurationManager.isOp(profile) || JourneymapClient.getInstance().getStateHandler().isTeleportEnabled());
/*     */       }
/*  54 */       catch (Exception e) {
/*     */         
/*  56 */         e.printStackTrace();
/*     */         
/*     */         try {
/*  59 */           if (profile != null && configurationManager != null) {
/*     */             
/*  61 */             Journeymap.getLogger().debug("Some Error happened: " + mcServer
/*  62 */                 .isSingleplayer() + " : " + ((ServerLevelData)mcServer
/*  63 */                 .getLevel(mc.player.level().dimension()).getLevelData()).isAllowCommands() + " : " + mcServer
/*  64 */                 .getSingleplayerProfile().getName().equalsIgnoreCase(profile.getName()));
/*  65 */             return (mcServer.isSingleplayer() && ((ServerLevelData)mcServer
/*  66 */               .getLevel(mc.player.level().dimension()).getLevelData()).isAllowCommands() && mcServer
/*  67 */               .getSingleplayerProfile().getName().equalsIgnoreCase(profile.getName()));
/*     */           } 
/*     */ 
/*     */           
/*  71 */           Journeymap.getLogger().warn("Failed to check teleport permission both ways: " + LogFormatter.toString(e) + ", and profile or configManager were null.");
/*     */         
/*     */         }
/*  74 */         catch (Exception e2) {
/*     */           
/*  76 */           Journeymap.getLogger().warn("Failed to check teleport permission. Both ways failed: " + LogFormatter.toString(e) + ", and " + LogFormatter.toString(e2));
/*     */         } 
/*     */       } 
/*     */     } 
/*     */ 
/*     */     
/*  82 */     if (JourneymapClient.getInstance().getStateHandler().isJourneyMapServerConnection()) {
/*     */       
/*  84 */       Journeymap.getLogger().debug("On a server with JM returning: " + JourneymapClient.getInstance().getStateHandler().isTeleportEnabled());
/*  85 */       return JourneymapClient.getInstance().getStateHandler().isTeleportEnabled();
/*     */     } 
/*  87 */     Journeymap.getLogger().debug("On a server without JM returning true by default");
/*     */     
/*  89 */     return true;
/*     */   }
/*     */ 
/*     */   
/*     */   public void run() {
/*  94 */     double x = this.waypoint.getRawCenterX();
/*  95 */     double z = this.waypoint.getRawCenterZ();
/*     */     
/*  97 */     TreeSet<String> dims = this.waypoint.getDimensions();
/*  98 */     String dim = this.mc.player.getCommandSenderWorld().dimension().location().toString();
/*     */ 
/*     */     
/* 101 */     if (!dims.isEmpty()) {
/*     */       
/* 103 */       dim = this.waypoint.getPos().getPrimaryDimension();
/* 104 */       if (!dims.contains(dim))
/*     */       {
/*     */         
/* 107 */         dim = dims.stream().filter(d -> this.mc.player.getCommandSenderWorld().dimension().equals(DimensionHelper.getWorldKeyForName(d))).findFirst().orElse(dims.first());
/*     */       }
/*     */     } 
/* 110 */     if (Level.NETHER.equals(DimensionHelper.getWorldKeyForName(dim)) && Level.NETHER.equals(this.mc.player.getCommandSenderWorld().dimension())) {
/*     */       
/* 112 */       x = this.waypoint.getRawCenterX();
/* 113 */       z = this.waypoint.getRawCenterZ();
/*     */     } 
/*     */     
/* 116 */     teleport(x, this.waypoint.getY(), z, dim, this.waypoint.getName());
/*     */   }
/*     */ 
/*     */   
/*     */   public static void teleport(BlockPos pos, ResourceKey<Level> dim, @Nullable String name) {
/* 121 */     teleport(pos.getX(), pos.getY(), pos.getZ(), (dim != null) ? dim.location().toString() : null, name);
/*     */   }
/*     */ 
/*     */   
/*     */   public static void teleport(double x, int y, double z, String dim, @Nullable String name) {
/* 126 */     Minecraft mc = Minecraft.getInstance();
/*     */     
/* 128 */     if (JourneymapClient.getInstance().getStateHandler().isJourneyMapServerConnection() || Minecraft.getInstance().hasSingleplayerServer()) {
/*     */       
/* 130 */       JourneymapClient.getInstance().getDispatcher().sendTeleportPacket(x, y, z, dim);
/*     */     }
/*     */     else {
/*     */       
/* 134 */       String teleportCommand = (JourneymapClient.getInstance().getWaypointProperties()).teleportCommand.getAsString();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 142 */       teleportCommand = teleportCommand.replace("{name}", mc.player.getName().getString()).replace("{x}", String.valueOf(x)).replace("{y}", String.valueOf(y)).replace("{z}", String.valueOf(z)).replace("{name}", (name != null) ? name : "").replace("{dim}", dim);
/*     */       
/* 144 */       if (teleportCommand.startsWith("/")) {
/*     */         
/* 146 */         Journeymap.getLogger().debug("Sending slash tp command: {}", teleportCommand);
/* 147 */         mc.player.connection.sendCommand(teleportCommand.substring(1));
/*     */       }
/*     */       else {
/*     */         
/* 151 */         Journeymap.getLogger().debug("Sending non-slash tp command: {}", teleportCommand);
/* 152 */         mc.player.connection.sendChat(teleportCommand);
/*     */       } 
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\Administrator\Downloads\journeymap-neoforge-1.21-6.0.0-beta.18.jar!\journeymap\client\command\CmdTeleportWaypoint.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */