/*    */ package journeymap.client.command;
/*    */ 
/*    */ import com.mojang.brigadier.exceptions.CommandSyntaxException;
/*    */ import com.mojang.brigadier.exceptions.SimpleCommandExceptionType;
/*    */ import journeymap.client.Constants;
/*    */ import net.minecraft.commands.CommandSource;
/*    */ 
/*    */ 
/*    */ 
/*    */ @Deprecated
/*    */ public interface JMCommand
/*    */ {
/*    */   String getName();
/*    */   
/*    */   int execute(CommandSource paramCommandSource, String[] paramArrayOfString) throws CommandSyntaxException;
/*    */   
/*    */   String getUsage(CommandSource paramCommandSource);
/*    */   
/*    */   default void exception(String err, Throwable t) throws CommandSyntaxException {
/* 20 */     throw (new SimpleCommandExceptionType(Constants.getStringTextComponent(err + err))).create();
/*    */   }
/*    */ }


/* Location:              C:\Users\Administrator\Downloads\journeymap-neoforge-1.21-6.0.0-beta.18.jar!\journeymap\client\command\JMCommand.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */