/*    */ package journeymap.client.data;
/*    */ 
/*    */ import java.util.ArrayList;
/*    */ import java.util.Collections;
/*    */ import java.util.Date;
/*    */ import java.util.List;
/*    */ import journeymap.client.model.RegionCoord;
/*    */ import journeymap.client.model.RegionImageCache;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ImagesData
/*    */ {
/*    */   public static final String PARAM_SINCE = "images.since";
/*    */   final long since;
/*    */   final List<Object[]> regions;
/*    */   final long queryTime;
/*    */   
/*    */   public ImagesData(Long since) {
/* 40 */     long now = (new Date()).getTime();
/* 41 */     this.queryTime = now;
/* 42 */     this.since = (since == null) ? now : since.longValue();
/*    */     
/* 44 */     List<RegionCoord> dirtyRegions = RegionImageCache.INSTANCE.getChangedSince(null, this.since);
/* 45 */     if (dirtyRegions.isEmpty()) {
/*    */       
/* 47 */       this.regions = Collections.EMPTY_LIST;
/*    */     }
/*    */     else {
/*    */       
/* 51 */       this.regions = new ArrayList(dirtyRegions.size());
/* 52 */       for (RegionCoord rc : dirtyRegions) {
/*    */         
/* 54 */         this.regions.add(new Integer[] { Integer.valueOf(rc.regionX), Integer.valueOf(rc.regionZ) });
/*    */       } 
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Users\Administrator\Downloads\journeymap-neoforge-1.21-6.0.0-beta.18.jar!\journeymap\client\data\ImagesData.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */