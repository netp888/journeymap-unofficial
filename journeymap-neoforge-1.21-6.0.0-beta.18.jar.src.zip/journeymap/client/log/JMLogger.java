/*     */ package journeymap.client.log;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.util.Arrays;
/*     */ import java.util.HashSet;
/*     */ import java.util.LinkedHashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.concurrent.atomic.AtomicInteger;
/*     */ import journeymap.api.services.Services;
/*     */ import journeymap.client.Constants;
/*     */ import journeymap.client.JourneymapClient;
/*     */ import journeymap.client.feature.FeatureManager;
/*     */ import journeymap.client.io.FileHandler;
/*     */ import journeymap.client.properties.ClientPropertiesBase;
/*     */ import journeymap.common.Journeymap;
/*     */ import journeymap.common.log.LogFormatter;
/*     */ import journeymap.common.properties.PropertiesBase;
/*     */ import journeymap.common.properties.config.StringField;
/*     */ import net.minecraft.client.Minecraft;
/*     */ import org.apache.logging.log4j.Level;
/*     */ import org.apache.logging.log4j.LogManager;
/*     */ import org.apache.logging.log4j.Logger;
/*     */ import org.apache.logging.log4j.MarkerManager;
/*     */ import org.apache.logging.log4j.core.Appender;
/*     */ import org.apache.logging.log4j.core.Layout;
/*     */ import org.apache.logging.log4j.core.LogEvent;
/*     */ import org.apache.logging.log4j.core.Logger;
/*     */ import org.apache.logging.log4j.core.appender.RandomAccessFileAppender;
/*     */ import org.apache.logging.log4j.core.impl.Log4jLogEvent;
/*     */ import org.apache.logging.log4j.core.layout.PatternLayout;
/*     */ import org.apache.logging.log4j.message.Message;
/*     */ import org.apache.logging.log4j.message.SimpleMessage;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class JMLogger
/*     */ {
/*     */   public static final String DEPRECATED_LOG_FILE = "journeyMap.log";
/*     */   public static final String LOG_FILE = "journeymap.log";
/*  43 */   private static final HashSet<Integer> singletonErrors = new HashSet<>();
/*  44 */   private static final AtomicInteger singletonErrorsCounter = new AtomicInteger(0);
/*     */   
/*     */   private static RandomAccessFileAppender fileAppender;
/*     */ 
/*     */   
/*     */   public static Logger init() {
/*  50 */     Logger logger = LogManager.getLogger("journeymap");
/*     */     
/*  52 */     if (!logger.isInfoEnabled())
/*     */     {
/*  54 */       logger.warn("Forge is surpressing INFO-level logging. If you need technical support for JourneyMap, you must return logging to INFO.");
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     try {
/*  60 */       File deprecatedLog = new File(FileHandler.getJourneyMapDir(), "journeyMap.log");
/*  61 */       if (deprecatedLog.exists())
/*     */       {
/*  63 */         deprecatedLog.delete();
/*     */       }
/*     */     }
/*  66 */     catch (Exception e) {
/*     */       
/*  68 */       logger.error("Error removing deprecated logfile: " + e.getMessage());
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/*     */     try {
/*  74 */       File logFile = getLogFile();
/*  75 */       if (logFile.exists()) {
/*     */         
/*  77 */         logFile.delete();
/*     */       }
/*     */       else {
/*     */         
/*  81 */         logFile.getParentFile().mkdirs();
/*     */       } 
/*     */       
/*  84 */       PatternLayout layout = PatternLayout.createLayout("[%d{HH:mm:ss}] [%t/%level] [%C{1}] %msg%n", null, null, null, null, true, false, null, null);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*  96 */       fileAppender = RandomAccessFileAppender.createAppender(logFile
/*  97 */           .getAbsolutePath(), "treu", "journeymap-logfile", "true", null, "true", (Layout)layout, null, "false", null, null);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 110 */       ((Logger)logger).addAppender((Appender)fileAppender);
/* 111 */       if (!fileAppender.isStarted())
/*     */       {
/* 113 */         fileAppender.start();
/*     */       }
/*     */       
/* 116 */       logger.info("JourneyMap log initialized.");
/*     */     
/*     */     }
/* 119 */     catch (SecurityException e) {
/*     */       
/* 121 */       logger.error("Error adding file handler: " + LogFormatter.toString(e));
/*     */     }
/* 123 */     catch (Throwable e) {
/*     */       
/* 125 */       logger.error("Error adding file handler: " + LogFormatter.toString(e));
/*     */     } 
/*     */     
/* 128 */     return logger;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static void setLevelFromProperties() {
/*     */     try {
/* 135 */       Logger logger = LogManager.getLogger("journeymap");
/* 136 */       ((Logger)logger).setLevel(Level.toLevel((JourneymapClient.getInstance().getCoreProperties()).logLevel.get(), Level.INFO));
/*     */     }
/* 138 */     catch (Throwable t) {
/*     */       
/* 140 */       t.printStackTrace();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void logProperties() {
/* 149 */     Log4jLogEvent log4jLogEvent = new Log4jLogEvent(JourneymapClient.MOD_NAME, MarkerManager.getMarker(JourneymapClient.MOD_NAME), null, Level.INFO, (Message)new SimpleMessage(getPropertiesSummary()), null);
/* 150 */     if (fileAppender != null)
/*     */     {
/* 152 */       fileAppender.append((LogEvent)log4jLogEvent);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String getPropertiesSummary() {
/* 161 */     LinkedHashMap<String, String> props = new LinkedHashMap<>();
/*     */ 
/*     */     
/* 164 */     props.put("Version", JourneymapClient.MOD_NAME + ", built with " + JourneymapClient.MOD_NAME + " " + Journeymap.LOADER_NAME);
/* 165 */     props.put(Journeymap.LOADER_NAME, Services.COMMON_SERVICE.getLoaderVersion());
/*     */ 
/*     */     
/* 168 */     List<String> envProps = Arrays.asList(new String[] { "os.name, os.arch, java.version, user.country, user.language" });
/* 169 */     StringBuilder sb = new StringBuilder();
/* 170 */     for (String env : envProps)
/*     */     {
/* 172 */       sb.append(env).append("=").append(System.getProperty(env)).append(", ");
/*     */     }
/* 174 */     sb.append("game language=").append((Minecraft.getInstance()).options.languageCode).append(", ");
/* 175 */     sb.append("locale=").append(Constants.getLocale());
/* 176 */     props.put("Environment", sb.toString());
/*     */ 
/*     */     
/* 179 */     sb = new StringBuilder();
/* 180 */     for (Map.Entry<String, String> prop : props.entrySet()) {
/*     */       
/* 182 */       if (!sb.isEmpty())
/*     */       {
/* 184 */         sb.append(LogFormatter.LINEBREAK);
/*     */       }
/* 186 */       sb.append(prop.getKey()).append(": ").append(prop.getValue());
/*     */     } 
/*     */ 
/*     */     
/* 190 */     sb.append(LogFormatter.LINEBREAK).append(FeatureManager.getInstance().getPolicyDetails());
/*     */ 
/*     */     
/* 193 */     JourneymapClient jm = JourneymapClient.getInstance();
/* 194 */     List<? extends PropertiesBase> configs = (List)Arrays.asList((Object[])new ClientPropertiesBase[] { (ClientPropertiesBase)jm
/* 195 */           .getMiniMapProperties1(), (ClientPropertiesBase)jm
/* 196 */           .getMiniMapProperties2(), (ClientPropertiesBase)jm
/* 197 */           .getFullMapProperties(), (ClientPropertiesBase)jm
/* 198 */           .getWaypointProperties(), (ClientPropertiesBase)jm
/* 199 */           .getWebMapProperties(), (ClientPropertiesBase)jm
/* 200 */           .getCoreProperties() });
/*     */ 
/*     */     
/* 203 */     for (PropertiesBase config : configs)
/*     */     {
/*     */       
/* 206 */       sb.append(LogFormatter.LINEBREAK).append(config);
/*     */     }
/*     */     
/* 209 */     return sb.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static File getLogFile() {
/* 219 */     return new File(FileHandler.getJourneyMapDir(), "journeymap.log");
/*     */   }
/*     */ 
/*     */   
/*     */   public static void logOnce(String text) {
/* 224 */     throwLogOnce(text, null, false);
/*     */   }
/*     */ 
/*     */   
/*     */   public static void throwLogOnce(String text, Throwable throwable) {
/* 229 */     throwLogOnce(text, throwable, true);
/*     */   }
/*     */ 
/*     */   
/*     */   public static void throwLogOnce(String text, Throwable throwable, boolean shouldThrow) {
/* 234 */     if (!singletonErrors.contains(Integer.valueOf(text.hashCode()))) {
/*     */       
/* 236 */       singletonErrors.add(Integer.valueOf(text.hashCode()));
/* 237 */       if (throwable != null)
/*     */       {
/* 239 */         Journeymap.getLogger().error(LogFormatter.toString(throwable));
/*     */       }
/* 241 */       else if (shouldThrow)
/*     */       {
/* 243 */         Journeymap.getLogger().warn(new Throwable(text));
/*     */       }
/*     */       else
/*     */       {
/* 247 */         Journeymap.getLogger().warn(text);
/*     */       }
/*     */     
/*     */     } else {
/*     */       
/* 252 */       int count = singletonErrorsCounter.incrementAndGet();
/* 253 */       if (count > 1000) {
/*     */         
/* 255 */         singletonErrors.clear();
/* 256 */         singletonErrorsCounter.set(0);
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public static class LogLevelStringProvider
/*     */     implements StringField.ValuesProvider
/*     */   {
/*     */     public List<String> getStrings() {
/* 266 */       Level[] levels = Level.values();
/* 267 */       String[] levelStrings = new String[levels.length];
/* 268 */       for (int i = 0; i < levels.length; i++)
/*     */       {
/* 270 */         levelStrings[i] = levels[i].toString();
/*     */       }
/* 272 */       return Arrays.asList(levelStrings);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public String getDefaultString() {
/* 278 */       return Level.INFO.toString();
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\Administrator\Downloads\journeymap-neoforge-1.21-6.0.0-beta.18.jar!\journeymap\client\log\JMLogger.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */