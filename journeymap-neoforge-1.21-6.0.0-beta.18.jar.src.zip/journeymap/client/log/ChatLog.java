/*     */ package journeymap.client.log;
/*     */ 
/*     */ import com.google.common.collect.Lists;
/*     */ import java.io.File;
/*     */ import java.util.Collections;
/*     */ import java.util.LinkedList;
/*     */ import java.util.List;
/*     */ import journeymap.api.services.WebMapService;
/*     */ import journeymap.client.Constants;
/*     */ import journeymap.client.JourneymapClient;
/*     */ import journeymap.common.Journeymap;
/*     */ import journeymap.common.log.LogFormatter;
/*     */ import journeymap.common.version.VersionCheck;
/*     */ import net.minecraft.client.Minecraft;
/*     */ import net.minecraft.network.chat.ClickEvent;
/*     */ import net.minecraft.network.chat.Component;
/*     */ import net.minecraft.network.chat.ComponentContents;
/*     */ import net.minecraft.network.chat.HoverEvent;
/*     */ import net.minecraft.network.chat.MutableComponent;
/*     */ import net.minecraft.network.chat.Style;
/*     */ import net.minecraft.network.chat.contents.PlainTextContents;
/*     */ import net.minecraft.network.chat.contents.TranslatableContents;
/*     */ import net.minecraft.util.FormattedCharSequence;
/*     */ import net.minecraft.util.StringUtil;
/*     */ import org.apache.logging.log4j.Level;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ChatLog
/*     */ {
/*  42 */   static final List<MutableComponent> announcements = Collections.synchronizedList(new LinkedList<>());
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean enableAnnounceMod = false;
/*     */ 
/*     */ 
/*     */   
/*     */   private static boolean initialized = false;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void queueAnnouncement(Component chat) {
/*  56 */     MutableComponent wrap = Component.translatable("jm.common.chat_announcement", new Object[] { chat });
/*  57 */     announcements.add(wrap);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void announceURL(String message, String url) {
/*  68 */     MutableComponent chat = Constants.getStringTextComponent(message);
/*  69 */     chat.withStyle(style -> style.withClickEvent(new ClickEvent(ClickEvent.Action.OPEN_URL, url)));
/*  70 */     chat.withStyle(style -> style.withHoverEvent(new HoverEvent(HoverEvent.Action.SHOW_TEXT, Constants.getStringTextComponent(url))));
/*     */     
/*  72 */     queueAnnouncement((Component)chat);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void announceFile(String message, File file) {
/*  83 */     MutableComponent chat = Constants.getStringTextComponent(message);
/*     */     
/*     */     try {
/*  86 */       String path = file.getCanonicalPath();
/*  87 */       chat.withStyle(style -> style.withClickEvent(new ClickEvent(ClickEvent.Action.OPEN_FILE, path)));
/*  88 */       chat.withStyle(style -> style.withHoverEvent(new HoverEvent(HoverEvent.Action.SHOW_TEXT, Constants.getStringTextComponent(path))));
/*     */     }
/*  90 */     catch (Exception e) {
/*     */       
/*  92 */       Journeymap.getLogger().warn("Couldn't build ClickEvent for file: " + LogFormatter.toString(e));
/*     */     } 
/*  94 */     queueAnnouncement((Component)chat);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void announceI18N(String key, Object... parms) {
/* 105 */     String text = Constants.getString(key, parms);
/* 106 */     MutableComponent chat = Constants.getStringTextComponent(text);
/* 107 */     queueAnnouncement((Component)chat);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void announceError(String text) {
/* 117 */     ErrorChat chat = new ErrorChat(text);
/* 118 */     queueAnnouncement(chat);
/*     */   }
/*     */ 
/*     */   
/*     */   public static void announceActionBar(Component message) {
/* 123 */     (Minecraft.getInstance()).player.displayClientMessage(message, true);
/*     */   }
/*     */ 
/*     */   
/*     */   public static void announceWaypointRendering(boolean enable) {
/* 128 */     String key = (JourneymapClient.getInstance().getKeyEvents().getHandler()).kbToggleAllWaypoints.getTranslatedName().getString().toUpperCase();
/*     */ 
/*     */     
/* 131 */     MutableComponent enabled = enable ? Component.translatable("jm.common.action_bar.waypoint_rendering.toggle.enable") : Component.translatable("jm.common.action_bar.waypoint_rendering.toggle.disabled");
/*     */ 
/*     */     
/* 134 */     MutableComponent opposite = enable ? Component.translatable("jm.common.action_bar.waypoint_rendering.toggle.opposite.disabled") : Component.translatable("jm.common.action_bar.waypoint_rendering.toggle.opposite.enable");
/*     */     
/* 136 */     MutableComponent message = Component.translatable("jm.common.action_bar.waypoint_rendering.message", new Object[] { enabled, "§e" + key + "§f", opposite });
/*     */     
/* 138 */     announceActionBar((Component)message);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void showChatAnnouncements(Minecraft mc) {
/* 150 */     if (!initialized) {
/*     */ 
/*     */       
/* 153 */       enableAnnounceMod = (JourneymapClient.getInstance().getCoreProperties()).announceMod.get().booleanValue();
/* 154 */       announceMod(enableAnnounceMod);
/*     */       
/* 156 */       VersionCheck.getVersionIsCurrent();
/* 157 */       initialized = true;
/*     */     } 
/*     */     
/* 160 */     while (!announcements.isEmpty()) {
/*     */       
/* 162 */       MutableComponent message = announcements.remove(0);
/* 163 */       if (message != null) {
/*     */         
/*     */         try {
/*     */           
/* 167 */           if (!(JourneymapClient.getInstance().getWaypointProperties()).renderWaypoints.get().booleanValue())
/*     */           {
/* 169 */             announceWaypointRendering(false);
/*     */           }
/*     */           
/* 172 */           mc.gui.getChat().addMessage((Component)message);
/*     */         }
/* 174 */         catch (Exception e) {
/*     */           
/* 176 */           Journeymap.getLogger().error("Could not display announcement in chat: " + LogFormatter.toString(e));
/*     */         }
/*     */         finally {
/*     */           
/* 180 */           Level logLevel = (((TranslatableContents)message.getContents()).getArgs()[0] instanceof ErrorChat) ? Level.ERROR : Level.INFO;
/* 181 */           Journeymap.getLogger().log(logLevel, StringUtil.stripColor(message.getString()));
/*     */         } 
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void announceMod(boolean forced) {
/* 194 */     if (enableAnnounceMod || forced) {
/*     */       
/* 196 */       String keyName = (JourneymapClient.getInstance().getKeyEvents().getHandler()).kbFullscreenToggle.getTranslatedName().getString().toUpperCase();
/* 197 */       WebMapService webServer = JourneymapClient.getInstance().getWebMap();
/* 198 */       if ((JourneymapClient.getInstance().getWebMapProperties()).enabled.get().booleanValue() && webServer != null) {
/*     */         
/*     */         try
/*     */         {
/* 202 */           String port = (webServer.getPort() == 80) ? "" : (":" + webServer.getPort());
/* 203 */           String message = Constants.getString("jm.common.webserver_and_mapgui_ready", new Object[] { keyName, port });
/* 204 */           announceURL(message, "http://localhost" + port);
/*     */         }
/* 206 */         catch (Throwable t)
/*     */         {
/* 208 */           Journeymap.getLogger().error("Couldn't check webserver: " + LogFormatter.toString(t));
/*     */         }
/*     */       
/*     */       } else {
/*     */         
/* 213 */         announceI18N("jm.common.mapgui_only_ready", new Object[] { keyName });
/*     */       } 
/*     */       
/* 216 */       if (!(JourneymapClient.getInstance().getCoreProperties()).mappingEnabled.get().booleanValue())
/*     */       {
/* 218 */         announceI18N("jm.common.enable_mapping_false_text", new Object[0]);
/*     */       }
/* 220 */       enableAnnounceMod = false;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static class ErrorChat
/*     */     implements Component
/*     */   {
/*     */     String text;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public ErrorChat(String text) {
/* 239 */       this.text = text;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public Style getStyle() {
/* 245 */       return Style.EMPTY;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public ComponentContents getContents() {
/* 251 */       return (ComponentContents)PlainTextContents.create(this.text);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public List<Component> getSiblings() {
/* 257 */       return Lists.newArrayList();
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public FormattedCharSequence getVisualOrderText() {
/* 263 */       return FormattedCharSequence.EMPTY;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\Administrator\Downloads\journeymap-neoforge-1.21-6.0.0-beta.18.jar!\journeymap\client\log\ChatLog.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */