/*     */ package journeymap.client.texture;
/*     */ 
/*     */ import com.mojang.blaze3d.platform.NativeImage;
/*     */ import java.util.HashSet;
/*     */ import java.util.Set;
/*     */ import net.minecraft.world.level.ChunkPos;
/*     */ 
/*     */ 
/*     */ 
/*     */ public class RegionMipmapGenerator
/*     */ {
/*  12 */   private static final float[] GAMMA_POW_2_2 = new float[256];
/*     */ 
/*     */   
/*     */   static {
/*  16 */     for (int i = 0; i < 256; i++)
/*     */     {
/*  18 */       GAMMA_POW_2_2[i] = (float)Math.pow((i / 255.0F), 2.2D);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public static NativeImage[] generateMipmaps(NativeImage baseImage, int mipmapLevel) {
/*  24 */     NativeImage[] mipmaps = new NativeImage[mipmapLevel + 1];
/*  25 */     mipmaps[0] = baseImage;
/*     */     
/*  27 */     for (int i = 1; i <= mipmapLevel; i++) {
/*     */       
/*  29 */       NativeImage image = mipmaps[i - 1];
/*  30 */       NativeImage nextImage = new NativeImage(image.getWidth() >> 1, image.getHeight() >> 1, false);
/*  31 */       int width = nextImage.getWidth();
/*  32 */       int height = nextImage.getHeight();
/*     */       
/*  34 */       for (int x = 0; x < width; x++) {
/*     */         
/*  36 */         for (int y = 0; y < height; y++)
/*     */         {
/*  38 */           nextImage.setPixelRGBA(x, y, alphaBlend(image
/*  39 */                 .getPixelRGBA(x * 2 + 0, y * 2 + 0), image
/*  40 */                 .getPixelRGBA(x * 2 + 1, y * 2 + 0), image
/*  41 */                 .getPixelRGBA(x * 2 + 0, y * 2 + 1), image
/*  42 */                 .getPixelRGBA(x * 2 + 1, y * 2 + 1)));
/*     */         }
/*     */       } 
/*     */ 
/*     */       
/*  47 */       mipmaps[i] = nextImage;
/*     */     } 
/*     */     
/*  50 */     return mipmaps;
/*     */   }
/*     */ 
/*     */   
/*     */   public static void updateMipmapsAndUpload(NativeImage[] mipmaps, Set<ChunkPos> dirtyChunks) {
/*  55 */     Set<ChunkPos> dirtyChunksPrev = new HashSet<>(dirtyChunks);
/*  56 */     int chunkSize = 16;
/*     */     
/*  58 */     for (int i = 1; i < mipmaps.length; i++) {
/*     */       
/*  60 */       HashSet<ChunkPos> dirtyChunksScaled = new HashSet<>();
/*  61 */       for (ChunkPos pos : dirtyChunksPrev)
/*     */       {
/*  63 */         dirtyChunksScaled.add(new ChunkPos(pos.x >> 1, pos.z >> 1));
/*     */       }
/*  65 */       dirtyChunksPrev = dirtyChunksScaled;
/*     */       
/*  67 */       NativeImage image = mipmaps[i - 1];
/*  68 */       NativeImage nextImage = mipmaps[i];
/*  69 */       chunkSize = Math.max(chunkSize >> 1, 1);
/*     */       
/*  71 */       for (ChunkPos pos : dirtyChunksScaled) {
/*     */         
/*  73 */         for (int x = pos.x; x < pos.x + chunkSize; x++) {
/*     */           
/*  75 */           for (int y = pos.z; y < pos.z + chunkSize; y++)
/*     */           {
/*  77 */             nextImage.setPixelRGBA(x, y, alphaBlend(image
/*  78 */                   .getPixelRGBA(x * 2 + 0, y * 2 + 0), image
/*  79 */                   .getPixelRGBA(x * 2 + 1, y * 2 + 0), image
/*  80 */                   .getPixelRGBA(x * 2 + 0, y * 2 + 1), image
/*  81 */                   .getPixelRGBA(x * 2 + 1, y * 2 + 1)));
/*     */           }
/*     */         } 
/*     */ 
/*     */         
/*  86 */         nextImage.upload(i, pos.x, pos.z, pos.x, pos.z, chunkSize, chunkSize, true, false);
/*     */       } 
/*     */       
/*  89 */       mipmaps[i] = nextImage;
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   private static int alphaBlend(int color1, int color2, int color3, int color4) {
/*  95 */     float r = 0.0F;
/*  96 */     float g = 0.0F;
/*  97 */     float b = 0.0F;
/*  98 */     int count = 0;
/*  99 */     if (color1 >> 24 != 0) {
/*     */       
/* 101 */       r += getPow22(color1 >> 0);
/* 102 */       g += getPow22(color1 >> 8);
/* 103 */       b += getPow22(color1 >> 16);
/* 104 */       count++;
/*     */     } 
/*     */     
/* 107 */     if (color2 >> 24 != 0) {
/*     */       
/* 109 */       r += getPow22(color2 >> 0);
/* 110 */       g += getPow22(color2 >> 8);
/* 111 */       b += getPow22(color2 >> 16);
/* 112 */       count++;
/*     */     } 
/*     */     
/* 115 */     if (color3 >> 24 != 0) {
/*     */       
/* 117 */       r += getPow22(color3 >> 0);
/* 118 */       g += getPow22(color3 >> 8);
/* 119 */       b += getPow22(color3 >> 16);
/* 120 */       count++;
/*     */     } 
/*     */     
/* 123 */     if (color4 >> 24 != 0) {
/*     */       
/* 125 */       r += getPow22(color4 >> 0);
/* 126 */       g += getPow22(color4 >> 8);
/* 127 */       b += getPow22(color4 >> 16);
/* 128 */       count++;
/*     */     } 
/*     */     
/* 131 */     if (count == 0)
/*     */     {
/* 133 */       return 0;
/*     */     }
/*     */     
/* 136 */     r /= count;
/* 137 */     g /= count;
/* 138 */     b /= count;
/* 139 */     int r2 = (int)(Math.pow(r, 0.45454545454545453D) * 255.0D);
/* 140 */     int g2 = (int)(Math.pow(g, 0.45454545454545453D) * 255.0D);
/* 141 */     int b2 = (int)(Math.pow(b, 0.45454545454545453D) * 255.0D);
/*     */     
/* 143 */     return 0xFF000000 | b2 << 16 | g2 << 8 | r2;
/*     */   }
/*     */ 
/*     */   
/*     */   private static float getPow22(int value) {
/* 148 */     return GAMMA_POW_2_2[value & 0xFF];
/*     */   }
/*     */ }


/* Location:              C:\Users\Administrator\Downloads\journeymap-neoforge-1.21-6.0.0-beta.18.jar!\journeymap\client\texture\RegionMipmapGenerator.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */