/*     */ package journeymap.client.texture;
/*     */ 
/*     */ import com.mojang.blaze3d.platform.NativeImage;
/*     */ import journeymap.client.cartography.color.RGB;
/*     */ import journeymap.common.Journeymap;
/*     */ import org.lwjgl.stb.STBImageResize;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ImageUtil
/*     */ {
/*     */   public static NativeImage getSizedImage(int width, int height, NativeImage from, boolean autoClose) {
/*  17 */     NativeImage scaledImage = new NativeImage(from.format(), width, height, false);
/*  18 */     STBImageResize.nstbir_resize_uint8_generic(from.pixels, from
/*     */         
/*  20 */         .getWidth(), from
/*  21 */         .getHeight(), 0, scaledImage.pixels, width, height, 0, from
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/*  27 */         .format().components(), -1, 0, 1, 1, 0, 0L);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  34 */     if (autoClose)
/*     */     {
/*  36 */       from.close();
/*     */     }
/*  38 */     return scaledImage;
/*     */   }
/*     */ 
/*     */   
/*     */   public static NativeImage getScaledImage(float scale, NativeImage from, boolean autoClose) {
/*  43 */     int scaledWidth = (int)(from.getWidth() * scale);
/*  44 */     int scaledHeight = (int)(from.getHeight() * scale);
/*  45 */     NativeImage scaledImage = new NativeImage(from.format(), scaledWidth, scaledHeight, false);
/*  46 */     STBImageResize.nstbir_resize_uint8_generic(from.pixels, from
/*     */         
/*  48 */         .getWidth(), from
/*  49 */         .getHeight(), 0, scaledImage.pixels, scaledWidth, scaledHeight, 0, from
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/*  55 */         .format().components(), -1, 0, 1, 1, 0, 0L);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  62 */     if (autoClose)
/*     */     {
/*  64 */       from.close();
/*     */     }
/*  66 */     return scaledImage;
/*     */   }
/*     */ 
/*     */   
/*     */   public static ComparableNativeImage getComparableSubImage(int x, int y, int width, int height, NativeImage from, boolean autoClose) {
/*  71 */     NativeImage to = new ComparableNativeImage(from.format(), width, height);
/*  72 */     return (ComparableNativeImage)getSubImage(x, y, width, height, from, to, autoClose);
/*     */   }
/*     */ 
/*     */   
/*     */   public static NativeImage getSubImage(int x, int y, int width, int height, NativeImage from, boolean autoClose) {
/*  77 */     NativeImage to = new NativeImage(width, height, false);
/*  78 */     return getSubImage(x, y, width, height, from, to, autoClose);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static NativeImage getSubImage(int x, int y, int width, int height, NativeImage from, NativeImage to, boolean autoClose) {
/*  84 */     if (from.pixels == 0L)
/*     */     {
/*  86 */       throw new IllegalStateException("Image is not allocated. " + String.valueOf(from));
/*     */     }
/*  88 */     if (to.format() != from.format())
/*     */     {
/*  90 */       throw new UnsupportedOperationException("getSubImage only works for images of the same format.");
/*     */     }
/*     */ 
/*     */     
/*  94 */     int i = from.format().components();
/*  95 */     STBImageResize.nstbir_resize_uint8_generic(from.pixels + (x + y * from
/*  96 */         .getWidth()) * i, width, height, from
/*     */ 
/*     */         
/*  99 */         .getWidth() * i, to.pixels, to
/*     */         
/* 101 */         .getWidth(), to
/* 102 */         .getHeight(), 0, from
/*     */         
/* 104 */         .format().components(), -1, 0, 1, 1, 0, 0L);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 112 */     if (autoClose)
/*     */     {
/* 114 */       from.close();
/*     */     }
/* 116 */     return to;
/*     */   }
/*     */ 
/*     */   
/*     */   public static NativeImage recolorImage(NativeImage image, int color) {
/* 121 */     NativeImage tintedImage = new NativeImage(image.getWidth(), image.getHeight(), false);
/* 122 */     tintedImage.copyFrom(image);
/* 123 */     for (int x = 0; x < image.getWidth(); x++) {
/*     */       
/* 125 */       for (int y = 0; y < image.getWidth(); y++) {
/*     */         
/* 127 */         int imgColor = image.getPixelRGBA(x, y);
/* 128 */         if (getAlpha(imgColor) > 1)
/*     */         {
/* 130 */           tintedImage.blendPixel(x, y, RGB.toRgba(color, 0.75F));
/*     */         }
/*     */       } 
/*     */     } 
/* 134 */     return tintedImage;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static NativeImage getNewBlankImage(int width, int height) {
/* 147 */     NativeImage image = new NativeImage(width, height, false);
/* 148 */     for (int x = 0; x < image.getWidth(); x++) {
/*     */       
/* 150 */       for (int y = 0; y < image.getHeight(); y++)
/*     */       {
/* 152 */         image.setPixelRGBA(x, y, RGB.toRgba(0, 0.0F));
/*     */       }
/*     */     } 
/* 155 */     return image;
/*     */   }
/*     */ 
/*     */   
/*     */   public static void closeSafely(NativeImage image) {
/* 160 */     if (image != null) {
/*     */       
/*     */       try {
/*     */         
/* 164 */         image.close();
/*     */       }
/* 166 */       catch (Throwable t) {
/*     */         
/* 168 */         Journeymap.getLogger().warn("Failed to clear and close image: ", t);
/*     */       } 
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public static int getAlpha(int color) {
/* 175 */     return color >> 24 & 0xFF;
/*     */   }
/*     */ }


/* Location:              C:\Users\Administrator\Downloads\journeymap-neoforge-1.21-6.0.0-beta.18.jar!\journeymap\client\texture\ImageUtil.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */