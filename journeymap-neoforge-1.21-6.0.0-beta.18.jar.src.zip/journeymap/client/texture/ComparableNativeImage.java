/*    */ package journeymap.client.texture;
/*    */ 
/*    */ import com.mojang.blaze3d.platform.NativeImage;
/*    */ import java.util.stream.IntStream;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ComparableNativeImage
/*    */   extends NativeImage
/*    */ {
/*    */   private boolean changed = false;
/*    */   
/*    */   public ComparableNativeImage(NativeImage other) {
/* 21 */     super(other.format(), other.getWidth(), other.getHeight(), false);
/* 22 */     copyFrom(other);
/*    */   }
/*    */ 
/*    */   
/*    */   public ComparableNativeImage(NativeImage.Format format, int width, int height) {
/* 27 */     super(format, width, height, false);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public synchronized void setPixelRGBA(int x, int y, int argb) {
/* 33 */     if (!this.changed)
/*    */     {
/* 35 */       if (getPixelRGBA(x, y) != argb)
/*    */       {
/* 37 */         this.changed = true;
/*    */       }
/*    */     }
/* 40 */     super.setPixelRGBA(x, y, argb);
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean isChanged() {
/* 45 */     return this.changed;
/*    */   }
/*    */ 
/*    */   
/*    */   public void setChanged(boolean val) {
/* 50 */     this.changed = val;
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean identicalTo(NativeImage other) {
/* 55 */     return areIdentical(getPixelData(), getPixelData(other));
/*    */   }
/*    */ 
/*    */   
/*    */   public static boolean areIdentical(int[] pixels, int[] otherPixels) {
/* 60 */     return IntStream.range(0, pixels.length)
/* 61 */       .map(i -> pixels[i] ^ 0xFFFFFFFF | otherPixels[i])
/* 62 */       .allMatch(n -> (n == -1));
/*    */   }
/*    */ 
/*    */   
/*    */   public int[] getPixelData() {
/* 67 */     return getPixelData(this);
/*    */   }
/*    */ 
/*    */   
/*    */   public static int[] getPixelData(NativeImage image) {
/* 72 */     return image.makePixelArray();
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public void close() {
/* 78 */     super.close();
/*    */   }
/*    */ }


/* Location:              C:\Users\Administrator\Downloads\journeymap-neoforge-1.21-6.0.0-beta.18.jar!\journeymap\client\texture\ComparableNativeImage.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */