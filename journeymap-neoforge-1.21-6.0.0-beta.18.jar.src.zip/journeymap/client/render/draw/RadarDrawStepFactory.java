package journeymap.client.render.draw;

import java.util.List;
import journeymap.client.model.EntityDTO;
import journeymap.client.properties.InGameMapProperties;
import journeymap.client.render.map.Renderer;

public class RadarDrawStepFactory {
  public List<DrawStep> prepareSteps(List<EntityDTO> entityDTOs, Renderer renderer, InGameMapProperties mapProperties) {
    // Byte code:
    //   0: aload_3
    //   1: getfield showAnimals : Ljourneymap/common/properties/config/BooleanField;
    //   4: invokevirtual get : ()Ljava/lang/Boolean;
    //   7: invokevirtual booleanValue : ()Z
    //   10: istore #4
    //   12: aload_3
    //   13: getfield showAmbientCreatures : Ljourneymap/common/properties/config/BooleanField;
    //   16: invokevirtual get : ()Ljava/lang/Boolean;
    //   19: invokevirtual booleanValue : ()Z
    //   22: istore #5
    //   24: aload_3
    //   25: getfield showPets : Ljourneymap/common/properties/config/BooleanField;
    //   28: invokevirtual get : ()Ljava/lang/Boolean;
    //   31: invokevirtual booleanValue : ()Z
    //   34: istore #6
    //   36: aload_3
    //   37: getfield showVillagers : Ljourneymap/common/properties/config/BooleanField;
    //   40: invokevirtual get : ()Ljava/lang/Boolean;
    //   43: invokevirtual booleanValue : ()Z
    //   46: istore #7
    //   48: aload_3
    //   49: getfield mobDisplay : Ljourneymap/common/properties/config/EnumField;
    //   52: invokevirtual get : ()Ljava/lang/Enum;
    //   55: checkcast journeymap/client/ui/minimap/EntityDisplay
    //   58: astore #8
    //   60: aload_3
    //   61: getfield playerDisplay : Ljourneymap/common/properties/config/EnumField;
    //   64: invokevirtual get : ()Ljava/lang/Enum;
    //   67: checkcast journeymap/client/ui/minimap/EntityDisplay
    //   70: astore #9
    //   72: aload_3
    //   73: getfield showMobHeading : Ljourneymap/common/properties/config/BooleanField;
    //   76: invokevirtual get : ()Ljava/lang/Boolean;
    //   79: invokevirtual booleanValue : ()Z
    //   82: istore #10
    //   84: aload_3
    //   85: getfield showPlayerHeading : Ljourneymap/common/properties/config/BooleanField;
    //   88: invokevirtual get : ()Ljava/lang/Boolean;
    //   91: invokevirtual booleanValue : ()Z
    //   94: istore #11
    //   96: aload_3
    //   97: getfield showTeamNames : Ljourneymap/common/properties/config/BooleanField;
    //   100: invokevirtual get : ()Ljava/lang/Boolean;
    //   103: invokevirtual booleanValue : ()Z
    //   106: istore #12
    //   108: aload_3
    //   109: getfield showPlayerNames : Ljourneymap/common/properties/config/BooleanField;
    //   112: invokevirtual get : ()Ljava/lang/Boolean;
    //   115: invokevirtual booleanValue : ()Z
    //   118: istore #13
    //   120: aload_3
    //   121: getfield mobDisplayScale : Ljourneymap/common/properties/config/FloatField;
    //   124: invokevirtual get : ()Ljava/lang/Float;
    //   127: invokevirtual floatValue : ()F
    //   130: fstore #14
    //   132: aload_3
    //   133: getfield playerDisplayScale : Ljourneymap/common/properties/config/FloatField;
    //   136: invokevirtual get : ()Ljava/lang/Float;
    //   139: invokevirtual floatValue : ()F
    //   142: fstore #15
    //   144: new java/util/ArrayList
    //   147: dup
    //   148: invokespecial <init> : ()V
    //   151: astore #16
    //   153: aload_1
    //   154: invokeinterface iterator : ()Ljava/util/Iterator;
    //   159: astore #17
    //   161: aload #17
    //   163: invokeinterface hasNext : ()Z
    //   168: ifeq -> 609
    //   171: aload #17
    //   173: invokeinterface next : ()Ljava/lang/Object;
    //   178: checkcast journeymap/client/model/EntityDTO
    //   181: astore #18
    //   183: aconst_null
    //   184: astore #19
    //   186: aconst_null
    //   187: astore #20
    //   189: aconst_null
    //   190: astore #21
    //   192: aload #18
    //   194: getfield entityRef : Ljava/lang/ref/WeakReference;
    //   197: invokevirtual get : ()Ljava/lang/Object;
    //   200: checkcast net/minecraft/world/entity/Entity
    //   203: astore #24
    //   205: aload #24
    //   207: instanceof net/minecraft/world/entity/player/Player
    //   210: istore #22
    //   212: aload #24
    //   214: ifnonnull -> 220
    //   217: goto -> 161
    //   220: aload_2
    //   221: aload #18
    //   223: getfield posX : D
    //   226: aload #18
    //   228: getfield posZ : D
    //   231: invokeinterface getPixel : (DD)Ljava/awt/geom/Point2D$Double;
    //   236: ifnonnull -> 242
    //   239: goto -> 161
    //   242: aload #18
    //   244: getfield owner : Ljava/lang/String;
    //   247: ifnull -> 261
    //   250: aload #18
    //   252: getfield owner : Ljava/lang/String;
    //   255: invokestatic isNullOrEmpty : (Ljava/lang/String;)Z
    //   258: ifeq -> 284
    //   261: aload #24
    //   263: instanceof net/minecraft/world/entity/animal/horse/AbstractHorse
    //   266: ifeq -> 288
    //   269: aload #24
    //   271: checkcast net/minecraft/world/entity/animal/horse/AbstractHorse
    //   274: astore #25
    //   276: aload #25
    //   278: invokevirtual isTamed : ()Z
    //   281: ifeq -> 288
    //   284: iconst_1
    //   285: goto -> 289
    //   288: iconst_0
    //   289: istore #23
    //   291: iload #6
    //   293: ifne -> 304
    //   296: iload #23
    //   298: ifeq -> 304
    //   301: goto -> 161
    //   304: iload #5
    //   306: ifne -> 335
    //   309: aload #18
    //   311: getfield ambientCreature : Z
    //   314: ifeq -> 335
    //   317: iload #22
    //   319: ifne -> 335
    //   322: iload #23
    //   324: ifeq -> 332
    //   327: iload #6
    //   329: ifne -> 335
    //   332: goto -> 161
    //   335: iload #4
    //   337: ifne -> 366
    //   340: aload #18
    //   342: getfield passiveAnimal : Z
    //   345: ifeq -> 366
    //   348: iload #22
    //   350: ifne -> 366
    //   353: iload #23
    //   355: ifeq -> 363
    //   358: iload #6
    //   360: ifne -> 366
    //   363: goto -> 161
    //   366: iload #7
    //   368: ifne -> 390
    //   371: aload #18
    //   373: getfield profession : Ljava/lang/String;
    //   376: ifnonnull -> 387
    //   379: aload #18
    //   381: getfield npc : Z
    //   384: ifeq -> 390
    //   387: goto -> 161
    //   390: getstatic journeymap/client/data/DataCache.INSTANCE : Ljourneymap/client/data/DataCache;
    //   393: aload #24
    //   395: invokevirtual getDrawEntityStep : (Lnet/minecraft/world/entity/Entity;)Ljourneymap/client/render/draw/DrawEntityStep;
    //   398: astore #25
    //   400: iload #22
    //   402: ifeq -> 495
    //   405: aload #9
    //   407: iload #11
    //   409: invokestatic getLocatorTexture : (Ljourneymap/client/ui/minimap/EntityDisplay;Z)Ljourneymap/client/texture/Texture;
    //   412: astore #20
    //   414: aload #9
    //   416: iload #11
    //   418: invokestatic getLocatorBGTexture : (Ljourneymap/client/ui/minimap/EntityDisplay;Z)Ljourneymap/client/texture/Texture;
    //   421: astore #21
    //   423: aload #24
    //   425: checkcast net/minecraft/world/entity/player/Player
    //   428: astore #26
    //   430: aload #9
    //   432: aload #26
    //   434: invokevirtual getGameProfile : ()Lcom/mojang/authlib/GameProfile;
    //   437: invokestatic getEntityTexture : (Ljourneymap/client/ui/minimap/EntityDisplay;Lcom/mojang/authlib/GameProfile;)Ljourneymap/client/texture/Texture;
    //   440: astore #19
    //   442: aload #9
    //   444: invokevirtual isOutlined : ()Z
    //   447: istore #27
    //   449: aload #25
    //   451: aload #9
    //   453: aload #20
    //   455: aload #21
    //   457: aload #19
    //   459: aload #18
    //   461: getfield color : I
    //   464: aload #18
    //   466: getfield labelColor : I
    //   469: iload #11
    //   471: iload #12
    //   473: iload #13
    //   475: iload #27
    //   477: fload #15
    //   479: invokevirtual update : (Ljourneymap/client/ui/minimap/EntityDisplay;Ljourneymap/client/texture/Texture;Ljourneymap/client/texture/Texture;Ljourneymap/client/texture/Texture;IIZZZZF)V
    //   482: aload #16
    //   484: aload #25
    //   486: invokeinterface add : (Ljava/lang/Object;)Z
    //   491: pop
    //   492: goto -> 583
    //   495: aload #8
    //   497: astore #26
    //   499: aload #26
    //   501: aload #18
    //   503: invokestatic hasEntityIcon : (Ljourneymap/client/ui/minimap/EntityDisplay;Ljourneymap/client/model/EntityDTO;)Z
    //   506: ifne -> 516
    //   509: aload #8
    //   511: invokevirtual getDot : ()Ljourneymap/client/ui/minimap/EntityDisplay;
    //   514: astore #26
    //   516: aload #26
    //   518: iload #10
    //   520: invokestatic getLocatorTexture : (Ljourneymap/client/ui/minimap/EntityDisplay;Z)Ljourneymap/client/texture/Texture;
    //   523: astore #20
    //   525: aload #26
    //   527: iload #10
    //   529: invokestatic getLocatorBGTexture : (Ljourneymap/client/ui/minimap/EntityDisplay;Z)Ljourneymap/client/texture/Texture;
    //   532: astore #21
    //   534: aload #26
    //   536: aload #18
    //   538: invokestatic getEntityTexture : (Ljourneymap/client/ui/minimap/EntityDisplay;Ljourneymap/client/model/EntityDTO;)Ljourneymap/client/texture/Texture;
    //   541: astore #19
    //   543: aload #25
    //   545: aload #26
    //   547: aload #20
    //   549: aload #21
    //   551: aload #19
    //   553: aload #18
    //   555: getfield color : I
    //   558: aload #18
    //   560: getfield labelColor : I
    //   563: iload #10
    //   565: iconst_0
    //   566: iconst_0
    //   567: iconst_0
    //   568: fload #14
    //   570: invokevirtual update : (Ljourneymap/client/ui/minimap/EntityDisplay;Ljourneymap/client/texture/Texture;Ljourneymap/client/texture/Texture;Ljourneymap/client/texture/Texture;IIZZZZF)V
    //   573: aload #16
    //   575: aload #25
    //   577: invokeinterface add : (Ljava/lang/Object;)Z
    //   582: pop
    //   583: goto -> 606
    //   586: astore #19
    //   588: invokestatic getLogger : ()Lorg/apache/logging/log4j/Logger;
    //   591: aload #19
    //   593: invokestatic toString : (Ljava/lang/Throwable;)Ljava/lang/String;
    //   596: <illegal opcode> makeConcatWithConstants : (Ljava/lang/String;)Ljava/lang/String;
    //   601: invokeinterface error : (Ljava/lang/String;)V
    //   606: goto -> 161
    //   609: goto -> 632
    //   612: astore #17
    //   614: invokestatic getLogger : ()Lorg/apache/logging/log4j/Logger;
    //   617: aload #17
    //   619: invokestatic toString : (Ljava/lang/Throwable;)Ljava/lang/String;
    //   622: <illegal opcode> makeConcatWithConstants : (Ljava/lang/String;)Ljava/lang/String;
    //   627: invokeinterface error : (Ljava/lang/String;)V
    //   632: aload #16
    //   634: areturn
    // Line number table:
    //   Java source line number -> byte code offset
    //   #34	-> 0
    //   #35	-> 12
    //   #36	-> 24
    //   #37	-> 36
    //   #38	-> 48
    //   #39	-> 60
    //   #40	-> 72
    //   #41	-> 84
    //   #42	-> 96
    //   #43	-> 108
    //   #44	-> 120
    //   #45	-> 132
    //   #46	-> 144
    //   #50	-> 153
    //   #54	-> 183
    //   #55	-> 186
    //   #56	-> 189
    //   #59	-> 192
    //   #60	-> 205
    //   #61	-> 212
    //   #63	-> 217
    //   #66	-> 220
    //   #68	-> 239
    //   #71	-> 242
    //   #72	-> 291
    //   #74	-> 301
    //   #77	-> 304
    //   #79	-> 322
    //   #81	-> 332
    //   #85	-> 335
    //   #87	-> 353
    //   #89	-> 363
    //   #93	-> 366
    //   #95	-> 387
    //   #99	-> 390
    //   #101	-> 400
    //   #103	-> 405
    //   #104	-> 414
    //   #106	-> 423
    //   #107	-> 430
    //   #108	-> 442
    //   #109	-> 449
    //   #110	-> 482
    //   #111	-> 492
    //   #114	-> 495
    //   #115	-> 499
    //   #117	-> 509
    //   #120	-> 516
    //   #121	-> 525
    //   #122	-> 534
    //   #124	-> 543
    //   #125	-> 573
    //   #132	-> 583
    //   #129	-> 586
    //   #131	-> 588
    //   #133	-> 606
    //   #138	-> 609
    //   #135	-> 612
    //   #137	-> 614
    //   #140	-> 632
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   276	8	25	horse	Lnet/minecraft/world/entity/animal/horse/AbstractHorse;
    //   430	62	26	entity	Lnet/minecraft/world/entity/player/Player;
    //   449	43	27	outlined	Z
    //   499	84	26	actualDisplay	Ljourneymap/client/ui/minimap/EntityDisplay;
    //   186	397	19	entityIcon	Ljourneymap/client/texture/Texture;
    //   189	394	20	locatorImg	Ljourneymap/client/texture/Texture;
    //   192	391	21	locatorBGImg	Ljourneymap/client/texture/Texture;
    //   212	371	22	isPlayer	Z
    //   291	292	23	isPet	Z
    //   205	378	24	entityLiving	Lnet/minecraft/world/entity/Entity;
    //   400	183	25	drawStep	Ljourneymap/client/render/draw/DrawEntityStep;
    //   588	18	19	e	Ljava/lang/Exception;
    //   183	423	18	dto	Ljourneymap/client/model/EntityDTO;
    //   614	18	17	t	Ljava/lang/Throwable;
    //   0	635	0	this	Ljourneymap/client/render/draw/RadarDrawStepFactory;
    //   0	635	1	entityDTOs	Ljava/util/List;
    //   0	635	2	renderer	Ljourneymap/client/render/map/Renderer;
    //   0	635	3	mapProperties	Ljourneymap/client/properties/InGameMapProperties;
    //   12	623	4	showAnimals	Z
    //   24	611	5	showAmbient	Z
    //   36	599	6	showPets	Z
    //   48	587	7	showVillagers	Z
    //   60	575	8	mobDisplay	Ljourneymap/client/ui/minimap/EntityDisplay;
    //   72	563	9	playerDisplay	Ljourneymap/client/ui/minimap/EntityDisplay;
    //   84	551	10	showMobHeading	Z
    //   96	539	11	showPlayerHeading	Z
    //   108	527	12	showTeamNames	Z
    //   120	515	13	showPlayerNames	Z
    //   132	503	14	mobDisplayDrawScale	F
    //   144	491	15	playerDisplayDrawScale	F
    //   153	482	16	drawStepList	Ljava/util/List;
    // Local variable type table:
    //   start	length	slot	name	signature
    //   0	635	1	entityDTOs	Ljava/util/List<Ljourneymap/client/model/EntityDTO;>;
    //   153	482	16	drawStepList	Ljava/util/List<Ljourneymap/client/render/draw/DrawStep;>;
    // Exception table:
    //   from	to	target	type
    //   153	609	612	java/lang/Throwable
    //   183	217	586	java/lang/Exception
    //   220	239	586	java/lang/Exception
    //   242	301	586	java/lang/Exception
    //   304	332	586	java/lang/Exception
    //   335	363	586	java/lang/Exception
    //   366	387	586	java/lang/Exception
    //   390	583	586	java/lang/Exception
  }
}


/* Location:              C:\Users\Administrator\Downloads\journeymap-neoforge-1.21-6.0.0-beta.18.jar!\journeymap\client\render\draw\RadarDrawStepFactory.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */