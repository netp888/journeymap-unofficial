/*     */ package journeymap.client.render;
/*     */ 
/*     */ import com.mojang.blaze3d.systems.RenderSystem;
/*     */ import com.mojang.blaze3d.vertex.DefaultVertexFormat;
/*     */ import com.mojang.blaze3d.vertex.VertexFormat;
/*     */ import it.unimi.dsi.fastutil.ints.Int2ObjectOpenHashMap;
/*     */ import it.unimi.dsi.fastutil.objects.Object2ObjectOpenHashMap;
/*     */ import java.util.OptionalDouble;
/*     */ import journeymap.client.JourneymapClient;
/*     */ import journeymap.client.texture.RegionTexture;
/*     */ import journeymap.client.texture.Texture;
/*     */ import net.minecraft.Util;
/*     */ import net.minecraft.client.renderer.RenderStateShard;
/*     */ import net.minecraft.client.renderer.RenderType;
/*     */ import net.minecraft.client.renderer.ShaderInstance;
/*     */ import net.minecraft.resources.ResourceLocation;
/*     */ 
/*     */ 
/*     */ public class JMRenderTypes
/*     */   extends RenderType
/*     */ {
/*  22 */   static final ResourceLocation WAYPOINT_DEFAULT_BEAM = ResourceLocation.parse("textures/entity/beacon_beam.png");
/*  23 */   static final Object2ObjectOpenHashMap<ResourceLocation, RenderType> GRID_LINES_RENDER_TYPE_MAP = new Object2ObjectOpenHashMap();
/*  24 */   static final Object2ObjectOpenHashMap<String, RenderType> REGION_TILE_RENDER_TYPE_MAP = new Object2ObjectOpenHashMap();
/*  25 */   static final Int2ObjectOpenHashMap<RenderType> ICON_RENDER_TYPE_MAP = new Int2ObjectOpenHashMap();
/*  26 */   static final Int2ObjectOpenHashMap<RenderType> ICON_UNMASKED_RENDER_TYPE_MAP = new Int2ObjectOpenHashMap();
/*  27 */   static final Int2ObjectOpenHashMap<RenderType> POLYGON_WITH_TEXTURE_RENDER_TYPE_MAP = new Int2ObjectOpenHashMap(); public static RenderStateShard.ShaderStateShard POSITION_TEX_COLOR_SHADER;
/*     */   static {
/*  29 */     REGION_SHADERS_MAP = (Object2ObjectOpenHashMap<String, RenderStateShard.ShaderStateShard>)Util.make(() -> {
/*     */           Object2ObjectOpenHashMap<String, RenderStateShard.ShaderStateShard> map = new Object2ObjectOpenHashMap();
/*     */           map.put("default", POSITION_TEX_COLOR_SHADER);
/*     */           return map;
/*     */         });
/*     */   }
/*     */   static final Object2ObjectOpenHashMap<String, RenderStateShard.ShaderStateShard> REGION_SHADERS_MAP;
/*     */   public static void registerMapShader(String key, ShaderInstance shader) {
/*  37 */     REGION_SHADERS_MAP.put(key, new RenderStateShard.ShaderStateShard(() -> shader));
/*     */     
/*  39 */     REGION_TILE_RENDER_TYPE_MAP.clear();
/*     */   }
/*     */ 
/*     */   
/*     */   public static void registerPosTexColorShader(ShaderInstance shader) {
/*  44 */     POLYGON_WITH_TEXTURE_RENDER_TYPE_MAP.clear();
/*  45 */     ICON_UNMASKED_RENDER_TYPE_MAP.clear();
/*  46 */     ICON_RENDER_TYPE_MAP.clear();
/*  47 */     REGION_TILE_RENDER_TYPE_MAP.clear();
/*  48 */     GRID_LINES_RENDER_TYPE_MAP.clear();
/*  49 */     POSITION_TEX_COLOR_SHADER = new RenderStateShard.ShaderStateShard(() -> shader);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public JMRenderTypes(String name, VertexFormat vertexFormat, VertexFormat.Mode drawMode, int bufferSize, boolean useDelegate, boolean needsSorting, Runnable pre, Runnable post) {
/*  55 */     super(name, vertexFormat, drawMode, bufferSize, useDelegate, needsSorting, pre, post);
/*     */   }
/*     */   
/*  58 */   protected static final RenderStateShard.TransparencyStateShard GRID_LINES_TRANSPARENCY = new RenderStateShard.TransparencyStateShard("grid_lines_transparency", () -> {
/*     */         RenderWrapper.enableBlend();
/*     */         RenderWrapper.blendFuncSeparate(770, 771, 1, 771);
/*     */         RenderWrapper.texParameter(3553, 10241, 9728);
/*     */         RenderWrapper.texParameter(3553, 10240, 9728);
/*     */         RenderWrapper.texParameter(3553, 10242, 10497);
/*     */         RenderWrapper.texParameter(3553, 10243, 10497);
/*     */       }() -> {
/*     */         RenderWrapper.disableBlend();
/*     */         RenderWrapper.defaultBlendFunc();
/*     */       });
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  74 */   protected static final RenderStateShard.TexturingStateShard MINIMAP_MASK_TRANSPARENCY = new RenderStateShard.TexturingStateShard("minimap_mask_texturing", () -> {
/*     */         RenderSystem.clearDepth(0.0D);
/*     */         RenderWrapper.clear(256);
/*     */         RenderSystem.clearDepth(1.0D);
/*     */         RenderWrapper.depthFunc(519);
/*     */       }() -> RenderWrapper.depthFunc(515));
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  87 */   protected static final RenderStateShard.TransparencyStateShard ICON_TRANSPARENCY = new RenderStateShard.TransparencyStateShard("icon_transparency", () -> {
/*     */         RenderWrapper.enableBlend();
/*     */         RenderWrapper.blendFuncSeparate(770, 771, 1, 0);
/*     */       }() -> {
/*     */         RenderWrapper.disableBlend();
/*     */         RenderWrapper.defaultBlendFunc();
/*     */       });
/*     */ 
/*     */ 
/*     */   
/*  97 */   protected static final RenderStateShard.TransparencyStateShard POLYGON_TRANSPARENCY = new RenderStateShard.TransparencyStateShard("polygon_transparency", () -> {
/*     */         RenderWrapper.enableBlend();
/*     */         RenderWrapper.blendFuncSeparate(770, 771, 1, 0);
/*     */         RenderWrapper.texParameter(3553, 10241, 9728);
/*     */         RenderWrapper.texParameter(3553, 10240, 9728);
/*     */         RenderWrapper.texParameter(3553, 10242, 10497);
/*     */         RenderWrapper.texParameter(3553, 10243, 10497);
/*     */       }() -> {
/*     */         RenderWrapper.disableBlend();
/*     */         RenderWrapper.defaultBlendFunc();
/*     */       });
/*     */ 
/*     */ 
/*     */   
/*     */   protected static class RegionTileStateShard
/*     */     extends RenderStateShard.EmptyTextureStateShard
/*     */   {
/*     */     private final int textureId;
/*     */ 
/*     */     
/*     */     public RegionTileStateShard(int textureId) {
/* 118 */       super(() -> {
/*     */             RenderWrapper.bindTexture(textureId);
/*     */             RenderWrapper.texParameter(3553, 10241, 9984);
/*     */             RenderWrapper.texParameter(3553, 10240, 9728);
/*     */             RenderWrapper.texParameter(3553, 10242, 33071);
/*     */             RenderWrapper.texParameter(3553, 10243, 33071);
/*     */             int mipmapLevels = (JourneymapClient.getInstance().getCoreProperties()).mipmapLevels.get().intValue();
/*     */             RenderWrapper.texParameter(3553, 33085, mipmapLevels);
/*     */             RenderWrapper.texParameter(3553, 33082, 0);
/*     */             RenderWrapper.texParameter(3553, 33083, mipmapLevels);
/*     */             RenderWrapper.texParameter(3553, 34049, 0);
/*     */             RenderWrapper.setShaderTexture(0, textureId);
/*     */           }() -> {
/*     */           
/*     */           });
/* 133 */       this.textureId = textureId;
/*     */     }
/*     */ 
/*     */     
/*     */     public String toString() {
/* 138 */       return this.name + "[" + this.name + ")]";
/*     */     }
/*     */   }
/*     */   
/*     */   protected static class IconStateShard
/*     */     extends RenderStateShard.EmptyTextureStateShard
/*     */   {
/*     */     private final int textureId;
/*     */     
/*     */     public IconStateShard(int textureId) {
/* 148 */       super(() -> {
/*     */             RenderWrapper.bindTexture(textureId); RenderWrapper.texParameter(3553, 10241, 9729);
/*     */             RenderWrapper.texParameter(3553, 10240, 9729);
/*     */             RenderWrapper.texParameter(3553, 10242, 10497);
/*     */             RenderWrapper.texParameter(3553, 10243, 10497);
/*     */             RenderWrapper.setShaderTexture(0, textureId);
/*     */           }() -> {
/*     */           
/*     */           });
/* 157 */       this.textureId = textureId;
/*     */     }
/*     */ 
/*     */     
/*     */     public String toString() {
/* 162 */       return this.name + "[" + this.name + ")]";
/*     */     }
/*     */   }
/*     */   
/*     */   public static RenderType getGridLines(ResourceLocation resourceLocation) {
/*     */     RenderType.CompositeRenderType compositeRenderType;
/* 168 */     RenderType type = (RenderType)GRID_LINES_RENDER_TYPE_MAP.get(resourceLocation);
/* 169 */     if (type == null) {
/*     */       
/* 171 */       compositeRenderType = create("grid_lines" + resourceLocation.toDebugFileName(), DefaultVertexFormat.POSITION_TEX_COLOR, VertexFormat.Mode.QUADS, 256, false, true, 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */           
/* 177 */           RenderType.CompositeState.builder()
/* 178 */           .setTextureState((RenderStateShard.EmptyTextureStateShard)new RenderStateShard.TextureStateShard(resourceLocation, false, false))
/* 179 */           .setDepthTestState(LEQUAL_DEPTH_TEST)
/* 180 */           .setLineState(new RenderStateShard.LineStateShard(OptionalDouble.empty()))
/* 181 */           .setLayeringState(NO_LAYERING)
/* 182 */           .setTransparencyState(GRID_LINES_TRANSPARENCY)
/* 183 */           .setLightmapState(NO_LIGHTMAP)
/* 184 */           .setCullState(NO_CULL)
/* 185 */           .setWriteMaskState(COLOR_WRITE)
/* 186 */           .setShaderState(POSITION_TEX_COLOR_SHADER)
/* 187 */           .createCompositeState(false));
/* 188 */       GRID_LINES_RENDER_TYPE_MAP.put(resourceLocation, compositeRenderType);
/*     */     } 
/* 190 */     return (RenderType)compositeRenderType;
/*     */   }
/*     */   
/*     */   public static RenderType getRegionTile(RegionTexture texture, String shader) {
/*     */     RenderType.CompositeRenderType compositeRenderType;
/* 195 */     int id = texture.getTextureId();
/* 196 */     String key = "" + id + "_" + id;
/* 197 */     RenderType type = (RenderType)REGION_TILE_RENDER_TYPE_MAP.get(key);
/* 198 */     if (type == null) {
/*     */       
/* 200 */       RenderStateShard.ShaderStateShard shaderState = (REGION_SHADERS_MAP.get(shader) == null) ? POSITION_TEX_COLOR_SHADER : (RenderStateShard.ShaderStateShard)REGION_SHADERS_MAP.get(shader);
/* 201 */       compositeRenderType = create("region_tile" + id, DefaultVertexFormat.POSITION_TEX_COLOR, VertexFormat.Mode.QUADS, 256, false, false, 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */           
/* 208 */           RenderType.CompositeState.builder()
/* 209 */           .setTextureState(new RegionTileStateShard(id))
/* 210 */           .setDepthTestState(LEQUAL_DEPTH_TEST)
/* 211 */           .setLineState(new RenderStateShard.LineStateShard(OptionalDouble.empty()))
/* 212 */           .setLayeringState(NO_LAYERING)
/* 213 */           .setTransparencyState(TRANSLUCENT_TRANSPARENCY)
/* 214 */           .setLightmapState(NO_LIGHTMAP)
/* 215 */           .setCullState(NO_CULL)
/* 216 */           .setWriteMaskState(COLOR_WRITE)
/* 217 */           .setShaderState(shaderState)
/* 218 */           .createCompositeState(false));
/* 219 */       REGION_TILE_RENDER_TYPE_MAP.put(key, compositeRenderType);
/*     */     } 
/* 221 */     return (RenderType)compositeRenderType;
/*     */   }
/*     */ 
/*     */   
/*     */   public static RenderType getMinimapCircleMask(Texture texture) {
/* 226 */     return (RenderType)create("minimap_circle_mask", DefaultVertexFormat.POSITION_TEX, VertexFormat.Mode.QUADS, 256, false, false, 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 233 */         RenderType.CompositeState.builder()
/* 234 */         .setTextureState(new RenderStateShard.EmptyTextureStateShard(() -> {
/*     */               RenderWrapper.bindTexture(texture.getTextureId());
/*     */ 
/*     */               
/*     */               RenderWrapper.setShaderTexture(0, texture.getTextureId());
/*     */             }() -> {
/*     */             
/* 241 */             })).setDepthTestState(LEQUAL_DEPTH_TEST)
/* 242 */         .setLineState(new RenderStateShard.LineStateShard(OptionalDouble.empty()))
/* 243 */         .setLayeringState(NO_LAYERING)
/* 244 */         .setTransparencyState(NO_TRANSPARENCY)
/* 245 */         .setLightmapState(NO_LIGHTMAP)
/* 246 */         .setCullState(NO_CULL)
/* 247 */         .setTexturingState(MINIMAP_MASK_TRANSPARENCY)
/* 248 */         .setWriteMaskState(DEPTH_WRITE)
/* 249 */         .setShaderState(POSITION_TEX_SHADER)
/* 250 */         .createCompositeState(false));
/*     */   }
/*     */ 
/*     */   
/*     */   public static RenderType getIcon(Texture texture) {
/*     */     RenderType.CompositeRenderType compositeRenderType;
/* 256 */     int id = texture.getTextureId();
/* 257 */     RenderType type = (RenderType)ICON_RENDER_TYPE_MAP.get(id);
/* 258 */     if (type == null) {
/*     */       
/* 260 */       compositeRenderType = create("icon" + id, DefaultVertexFormat.POSITION_TEX_COLOR, VertexFormat.Mode.QUADS, 256, false, false, 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */           
/* 267 */           RenderType.CompositeState.builder()
/* 268 */           .setTextureState(new IconStateShard(id))
/* 269 */           .setDepthTestState(LEQUAL_DEPTH_TEST)
/* 270 */           .setLineState(new RenderStateShard.LineStateShard(OptionalDouble.empty()))
/* 271 */           .setLayeringState(NO_LAYERING)
/* 272 */           .setTransparencyState(ICON_TRANSPARENCY)
/* 273 */           .setLightmapState(NO_LIGHTMAP)
/* 274 */           .setCullState(NO_CULL)
/* 275 */           .setWriteMaskState(COLOR_DEPTH_WRITE)
/* 276 */           .setShaderState(POSITION_TEX_COLOR_SHADER)
/* 277 */           .createCompositeState(false));
/* 278 */       ICON_RENDER_TYPE_MAP.put(id, compositeRenderType);
/*     */     } 
/* 280 */     return (RenderType)compositeRenderType;
/*     */   }
/*     */   
/*     */   public static RenderType getIconUnmasked(Texture texture) {
/*     */     RenderType.CompositeRenderType compositeRenderType;
/* 285 */     int id = texture.getTextureId();
/* 286 */     RenderType type = (RenderType)ICON_UNMASKED_RENDER_TYPE_MAP.get(id);
/* 287 */     if (type == null) {
/*     */       
/* 289 */       compositeRenderType = create("icon_unmasked" + id, DefaultVertexFormat.POSITION_TEX_COLOR, VertexFormat.Mode.QUADS, 256, false, false, 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */           
/* 296 */           RenderType.CompositeState.builder()
/* 297 */           .setTextureState(new IconStateShard(id))
/* 298 */           .setDepthTestState(NO_DEPTH_TEST)
/* 299 */           .setLineState(new RenderStateShard.LineStateShard(OptionalDouble.empty()))
/* 300 */           .setLayeringState(NO_LAYERING)
/* 301 */           .setTransparencyState(ICON_TRANSPARENCY)
/* 302 */           .setLightmapState(NO_LIGHTMAP)
/* 303 */           .setCullState(NO_CULL)
/* 304 */           .setWriteMaskState(COLOR_WRITE)
/* 305 */           .setShaderState(POSITION_TEX_COLOR_SHADER)
/* 306 */           .createCompositeState(false));
/* 307 */       ICON_UNMASKED_RENDER_TYPE_MAP.put(id, compositeRenderType);
/*     */     } 
/* 309 */     return (RenderType)compositeRenderType;
/*     */   }
/*     */   
/*     */   public static RenderType getPolygonWithTexture(Texture texture) {
/*     */     RenderType.CompositeRenderType compositeRenderType;
/* 314 */     int id = texture.getTextureId();
/* 315 */     RenderType type = (RenderType)POLYGON_WITH_TEXTURE_RENDER_TYPE_MAP.get(id);
/* 316 */     if (type == null) {
/*     */       
/* 318 */       compositeRenderType = create("polygon" + id, DefaultVertexFormat.POSITION_TEX_COLOR, VertexFormat.Mode.TRIANGLES, 256, false, false, 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */           
/* 325 */           RenderType.CompositeState.builder()
/* 326 */           .setTextureState(new RenderStateShard.EmptyTextureStateShard(() -> {
/*     */                 RenderWrapper.bindTexture(id);
/*     */ 
/*     */                 
/*     */                 RenderWrapper.setShaderTexture(0, id);
/*     */               }() -> {
/*     */               
/* 333 */               })).setDepthTestState(LEQUAL_DEPTH_TEST)
/* 334 */           .setLineState(new RenderStateShard.LineStateShard(OptionalDouble.empty()))
/* 335 */           .setLayeringState(NO_LAYERING)
/* 336 */           .setTransparencyState(POLYGON_TRANSPARENCY)
/* 337 */           .setLightmapState(NO_LIGHTMAP)
/* 338 */           .setCullState(NO_CULL)
/* 339 */           .setWriteMaskState(COLOR_WRITE)
/* 340 */           .setShaderState(POSITION_TEX_COLOR_SHADER)
/* 341 */           .createCompositeState(false));
/* 342 */       POLYGON_WITH_TEXTURE_RENDER_TYPE_MAP.put(id, compositeRenderType);
/*     */     } 
/* 344 */     return (RenderType)compositeRenderType;
/*     */   }
/*     */   
/* 347 */   public static final RenderType MINIMAP_RECTANGLE_MASK_RENDER_TYPE = (RenderType)create("minimap_rectangle_mask", DefaultVertexFormat.POSITION_COLOR, VertexFormat.Mode.QUADS, 256, false, false, 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 354 */       RenderType.CompositeState.builder()
/* 355 */       .setTextureState(NO_TEXTURE)
/* 356 */       .setDepthTestState(LEQUAL_DEPTH_TEST)
/* 357 */       .setLineState(new RenderStateShard.LineStateShard(OptionalDouble.empty()))
/* 358 */       .setLayeringState(NO_LAYERING)
/* 359 */       .setTransparencyState(NO_TRANSPARENCY)
/* 360 */       .setLightmapState(NO_LIGHTMAP)
/* 361 */       .setCullState(NO_CULL)
/* 362 */       .setTexturingState(MINIMAP_MASK_TRANSPARENCY)
/* 363 */       .setWriteMaskState(DEPTH_WRITE)
/* 364 */       .setShaderState(POSITION_COLOR_SHADER)
/* 365 */       .createCompositeState(false));
/*     */ 
/*     */   
/* 368 */   public static final RenderType BEAM_RENDER_TYPE = (RenderType)create("waypoint_beam", DefaultVertexFormat.POSITION_COLOR_TEX_LIGHTMAP, VertexFormat.Mode.QUADS, 256, false, false, 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 375 */       RenderType.CompositeState.builder()
/* 376 */       .setTextureState((RenderStateShard.EmptyTextureStateShard)new RenderStateShard.TextureStateShard(WAYPOINT_DEFAULT_BEAM, true, false))
/* 377 */       .setCullState(CULL)
/* 378 */       .setLineState(new RenderStateShard.LineStateShard(OptionalDouble.empty()))
/* 379 */       .setLayeringState(NO_LAYERING)
/* 380 */       .setTransparencyState(TRANSLUCENT_TRANSPARENCY)
/* 381 */       .setLightmapState(LIGHTMAP)
/* 382 */       .setWriteMaskState(COLOR_WRITE)
/* 383 */       .setShaderState(POSITION_COLOR_TEX_LIGHTMAP_SHADER)
/* 384 */       .createCompositeState(false));
/*     */ 
/*     */   
/* 387 */   public static final RenderType RECTANGLE_RENDER_TYPE = (RenderType)create("rectangle", DefaultVertexFormat.POSITION_COLOR, VertexFormat.Mode.QUADS, 256, false, false, 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 394 */       RenderType.CompositeState.builder()
/* 395 */       .setTextureState(NO_TEXTURE)
/* 396 */       .setDepthTestState(LEQUAL_DEPTH_TEST)
/* 397 */       .setCullState(NO_CULL)
/* 398 */       .setLineState(new RenderStateShard.LineStateShard(OptionalDouble.empty()))
/* 399 */       .setLayeringState(NO_LAYERING)
/* 400 */       .setTransparencyState(TRANSLUCENT_TRANSPARENCY)
/* 401 */       .setLightmapState(NO_LIGHTMAP)
/* 402 */       .setWriteMaskState(COLOR_DEPTH_WRITE)
/* 403 */       .setShaderState(POSITION_COLOR_SHADER)
/* 404 */       .createCompositeState(false));
/*     */ 
/*     */   
/* 407 */   public static final RenderType GRID_LINES_RENDER_TYPE = (RenderType)create("grid_lines", DefaultVertexFormat.POSITION_COLOR, VertexFormat.Mode.DEBUG_LINES, 256, false, true, 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 414 */       RenderType.CompositeState.builder()
/* 415 */       .setTextureState(NO_TEXTURE)
/* 416 */       .setDepthTestState(LEQUAL_DEPTH_TEST)
/* 417 */       .setLineState(new RenderStateShard.LineStateShard(OptionalDouble.of(1.0D)))
/* 418 */       .setLayeringState(NO_LAYERING)
/* 419 */       .setTransparencyState(TRANSLUCENT_TRANSPARENCY)
/* 420 */       .setLightmapState(NO_LIGHTMAP)
/* 421 */       .setCullState(NO_CULL)
/* 422 */       .setWriteMaskState(COLOR_WRITE)
/* 423 */       .setShaderState(POSITION_COLOR_SHADER)
/* 424 */       .createCompositeState(false));
/*     */ 
/*     */   
/* 427 */   public static final RenderType POLYGON_WITHOUT_TEXTURE_RENDER_TYPE = (RenderType)create("polygon", DefaultVertexFormat.POSITION_COLOR, VertexFormat.Mode.TRIANGLES, 256, false, false, 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 434 */       RenderType.CompositeState.builder()
/* 435 */       .setTextureState(NO_TEXTURE)
/* 436 */       .setDepthTestState(LEQUAL_DEPTH_TEST)
/* 437 */       .setCullState(NO_CULL)
/* 438 */       .setLineState(new RenderStateShard.LineStateShard(OptionalDouble.empty()))
/* 439 */       .setLayeringState(NO_LAYERING)
/* 440 */       .setTransparencyState(POLYGON_TRANSPARENCY)
/* 441 */       .setLightmapState(NO_LIGHTMAP)
/* 442 */       .setWriteMaskState(COLOR_WRITE)
/* 443 */       .setShaderState(POSITION_COLOR_SHADER)
/* 444 */       .createCompositeState(false));
/*     */ 
/*     */   
/* 447 */   public static final RenderType POLYGON_STROKE_RENDER_TYPE = (RenderType)create("polygon_stroke", DefaultVertexFormat.POSITION_COLOR, VertexFormat.Mode.TRIANGLE_STRIP, 256, false, false, 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 454 */       RenderType.CompositeState.builder()
/* 455 */       .setTextureState(NO_TEXTURE)
/* 456 */       .setDepthTestState(LEQUAL_DEPTH_TEST)
/* 457 */       .setCullState(NO_CULL)
/* 458 */       .setLineState(new RenderStateShard.LineStateShard(OptionalDouble.empty()))
/* 459 */       .setLayeringState(NO_LAYERING)
/* 460 */       .setTransparencyState(POLYGON_TRANSPARENCY)
/* 461 */       .setLightmapState(NO_LIGHTMAP)
/* 462 */       .setWriteMaskState(COLOR_WRITE)
/* 463 */       .setShaderState(POSITION_COLOR_SHADER)
/* 464 */       .createCompositeState(false));
/*     */ }


/* Location:              C:\Users\Administrator\Downloads\journeymap-neoforge-1.21-6.0.0-beta.18.jar!\journeymap\client\render\JMRenderTypes.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */