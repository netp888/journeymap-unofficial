/*     */ package journeymap.client.render.ingame;
/*     */ 
/*     */ import com.mojang.blaze3d.vertex.PoseStack;
/*     */ import journeymap.api.v2.common.waypoint.WaypointGroup;
/*     */ import journeymap.client.JourneymapClient;
/*     */ import journeymap.client.cartography.color.RGB;
/*     */ import journeymap.client.properties.WaypointProperties;
/*     */ import journeymap.client.render.draw.DrawStep;
/*     */ import journeymap.client.waypoint.ClientWaypointImpl;
/*     */ import journeymap.common.Journeymap;
/*     */ import journeymap.common.waypoint.WaypointGroupStore;
/*     */ import journeymap.common.waypoint.WaypointOrigin;
/*     */ import journeymap.common.waypoint.WaypointStore;
/*     */ import net.minecraft.client.Minecraft;
/*     */ import net.minecraft.client.renderer.MultiBufferSource;
/*     */ import net.minecraft.client.renderer.entity.EntityRenderDispatcher;
/*     */ import net.minecraft.world.phys.Vec3;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class WaypointRenderer
/*     */ {
/*     */   protected WaypointProperties waypointProperties;
/*  26 */   protected final Minecraft minecraft = Minecraft.getInstance();
/*  27 */   protected EntityRenderDispatcher renderManager = this.minecraft.getEntityRenderDispatcher();
/*     */ 
/*     */   
/*     */   public abstract void render(PoseStack paramPoseStack);
/*     */ 
/*     */   
/*     */   protected boolean canDrawWaypoint(ClientWaypointImpl waypoint, String playerDim) {
/*  34 */     WaypointGroup group = WaypointGroupStore.getInstance().get(waypoint.getGroupId());
/*  35 */     return ((WaypointOrigin.EXTERNAL_FORCE.getValue().equals(waypoint.getOrigin()) || (waypoint
/*  36 */       .isEnabled() && group != null && group
/*  37 */       .isEnabled() && 
/*  38 */       (JourneymapClient.getInstance().getWaypointProperties()).beaconEnabled.get().booleanValue() && 
/*  39 */       JourneymapClient.getInstance().getStateHandler().canShowInGameBeacons() && 
/*  40 */       JourneymapClient.getInstance().getStateHandler().isWaypointsAllowed())) && waypoint
/*  41 */       .getDimensions().contains(playerDim));
/*     */   }
/*     */ 
/*     */   
/*     */   protected void renderWaypoint(ClientWaypointImpl waypoint, PoseStack poseStack, DrawStep.Pass pass, MultiBufferSource buffers) {
/*  46 */     if (pass == DrawStep.Pass.Tooltip) {
/*     */       return;
/*     */     }
/*     */     
/*  50 */     if (this.renderManager == null)
/*     */     {
/*  52 */       this.renderManager = this.minecraft.getEntityRenderDispatcher();
/*     */     }
/*  54 */     float partialTicks = this.minecraft.getTimer().getGameTimeDeltaPartialTick(true);
/*  55 */     long gameTime = this.minecraft.level.getGameTime();
/*  56 */     float fadeAlpha = 1.0F;
/*     */     
/*  58 */     Vec3 waypointVec = waypoint.getPosition().add(0.0D, 0.118D, 0.0D);
/*     */ 
/*     */     
/*  61 */     Vec3 playerVec = this.minecraft.player.position();
/*     */ 
/*     */     
/*  64 */     double actualDistance = playerVec.distanceTo(waypointVec);
/*  65 */     int maxDistance = this.waypointProperties.maxDistance.get().intValue();
/*  66 */     int minDistance = this.waypointProperties.minDistance.get().intValue();
/*  67 */     float[] rgba = RGB.floats(waypoint.getColor(), fadeAlpha * 0.4F);
/*     */ 
/*     */     
/*  70 */     double viewX = this.renderManager.camera.getPosition().x();
/*  71 */     double viewY = this.renderManager.camera.getPosition().y();
/*  72 */     double viewZ = this.renderManager.camera.getPosition().z();
/*     */ 
/*     */ 
/*     */     
/*  76 */     double viewDistance = actualDistance;
/*  77 */     double maxRenderDistance = (((Integer)this.minecraft.options.renderDistance().get()).intValue() * 16);
/*     */ 
/*     */     
/*  80 */     if (maxDistance > 0 && actualDistance > maxDistance) {
/*     */       return;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*  86 */     if (waypoint.isDeathPoint() && this.waypointProperties.autoRemoveDeathpoints
/*  87 */       .get().booleanValue() && actualDistance < this.waypointProperties.autoRemoveDeathpointDistance
/*  88 */       .get().intValue() && actualDistance > 1.5D) {
/*     */ 
/*     */       
/*  91 */       Journeymap.getLogger().debug("Auto removing deathpoint " + String.valueOf(waypoint));
/*  92 */       WaypointStore.getInstance().remove(waypoint, true);
/*     */       
/*     */       return;
/*     */     } 
/*  96 */     if (WaypointOrigin.TEMP.getValue().equals(waypoint.getOrigin()) && (actualDistance <= this.waypointProperties.autoRemoveTempWaypoints
/*  97 */       .get().intValue() || actualDistance <= (minDistance + 4)) && actualDistance > 1.5D) {
/*     */ 
/*     */ 
/*     */       
/* 101 */       Journeymap.getLogger().debug("Auto removing temp waypoint " + String.valueOf(waypoint));
/* 102 */       WaypointStore.getInstance().remove(waypoint, true);
/*     */     } 
/*     */     
/* 105 */     if (minDistance > 0) {
/*     */ 
/*     */       
/* 108 */       if ((int)actualDistance <= minDistance) {
/*     */         return;
/*     */       }
/*     */ 
/*     */       
/* 113 */       if ((int)actualDistance <= minDistance + 4)
/*     */       {
/* 115 */         fadeAlpha = Math.min((float)(actualDistance - minDistance) / 3.0F, 1.0F);
/*     */       }
/*     */     } 
/*     */ 
/*     */     
/* 120 */     if (viewDistance > maxRenderDistance) {
/*     */       
/* 122 */       Vec3 delta = waypointVec.subtract(playerVec).normalize();
/* 123 */       waypointVec = playerVec.add(delta.x * maxRenderDistance, delta.y * maxRenderDistance, delta.z * maxRenderDistance);
/* 124 */       viewDistance = maxRenderDistance;
/*     */     } 
/* 126 */     double scale = 0.00390625D * (viewDistance + 4.0D) / 3.0D;
/* 127 */     double shiftX = waypointVec.x - viewX;
/* 128 */     double shiftY = waypointVec.y - viewY;
/* 129 */     double shiftZ = waypointVec.z - viewZ;
/*     */     
/* 131 */     render(poseStack, pass, buffers, waypoint, partialTicks, gameTime, rgba, fadeAlpha, shiftX, shiftY, shiftZ, playerVec, waypointVec, viewDistance, actualDistance, scale);
/*     */   }
/*     */   
/*     */   protected abstract void render(PoseStack paramPoseStack, DrawStep.Pass paramPass, MultiBufferSource paramMultiBufferSource, ClientWaypointImpl paramClientWaypointImpl, float paramFloat1, long paramLong, float[] paramArrayOffloat, float paramFloat2, double paramDouble1, double paramDouble2, double paramDouble3, Vec3 paramVec31, Vec3 paramVec32, double paramDouble4, double paramDouble5, double paramDouble6);
/*     */ }


/* Location:              C:\Users\Administrator\Downloads\journeymap-neoforge-1.21-6.0.0-beta.18.jar!\journeymap\client\render\ingame\WaypointRenderer.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */