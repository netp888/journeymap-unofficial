/*     */ package journeymap.client.render.ingame;
/*     */ 
/*     */ import com.mojang.blaze3d.platform.Window;
/*     */ import com.mojang.blaze3d.vertex.PoseStack;
/*     */ import com.mojang.blaze3d.vertex.VertexConsumer;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.List;
/*     */ import journeymap.client.Constants;
/*     */ import journeymap.client.JourneymapClient;
/*     */ import journeymap.client.render.JMRenderTypes;
/*     */ import journeymap.client.render.draw.DrawStep;
/*     */ import journeymap.client.render.draw.DrawUtil;
/*     */ import journeymap.client.texture.Texture;
/*     */ import journeymap.client.texture.TextureCache;
/*     */ import journeymap.client.waypoint.ClientWaypointImpl;
/*     */ import journeymap.common.Journeymap;
/*     */ import journeymap.common.waypoint.WaypointStore;
/*     */ import net.minecraft.ChatFormatting;
/*     */ import net.minecraft.client.renderer.GameRenderer;
/*     */ import net.minecraft.client.renderer.MultiBufferSource;
/*     */ import net.minecraft.client.renderer.RenderType;
/*     */ import net.minecraft.network.chat.Component;
/*     */ import net.minecraft.resources.ResourceLocation;
/*     */ import net.minecraft.world.phys.Vec3;
/*     */ import org.joml.Matrix4f;
/*     */ import org.joml.Matrix4fc;
/*     */ import org.joml.Quaternionf;
/*     */ import org.joml.Quaternionfc;
/*     */ import org.joml.Vector4f;
/*     */ 
/*     */ 
/*     */ 
/*     */ public class WaypointDecorationRenderer
/*     */   extends WaypointRenderer
/*     */ {
/*     */   public void render(PoseStack poseStack) {
/*  38 */     this.waypointProperties = JourneymapClient.getInstance().getWaypointProperties();
/*  39 */     MultiBufferSource.BufferSource buffers = this.minecraft.renderBuffers().bufferSource();
/*  40 */     Collection<ClientWaypointImpl> waypoints = WaypointStore.getInstance().getAll();
/*  41 */     List<ClientWaypointImpl> waypointsOrdered = waypointsToDraw(waypoints);
/*     */     
/*  43 */     if (waypointsOrdered.isEmpty()) {
/*     */       return;
/*     */     }
/*     */ 
/*     */     
/*  48 */     Window mainWindow = this.minecraft.getWindow();
/*  49 */     DrawUtil.sizeDisplay(mainWindow.getWidth(), mainWindow.getHeight());
/*     */     
/*  51 */     for (DrawStep.Pass pass : DrawStep.Pass.values()) {
/*     */       
/*  53 */       if (pass != DrawStep.Pass.PreObject && pass != DrawStep.Pass.PostObject && pass != DrawStep.Pass.Tooltip) {
/*     */ 
/*     */ 
/*     */ 
/*     */         
/*  58 */         int zLevel = 0;
/*  59 */         for (ClientWaypointImpl waypoint : waypointsOrdered) {
/*     */ 
/*     */           
/*     */           try {
/*  63 */             zLevel++;
/*  64 */             poseStack.pushPose();
/*  65 */             poseStack.translate(0.0F, 0.0F, zLevel);
/*  66 */             renderWaypoint(waypoint, poseStack, pass, (MultiBufferSource)buffers);
/*  67 */             poseStack.popPose();
/*     */           }
/*  69 */           catch (Exception t) {
/*     */             
/*  71 */             Journeymap.getLogger().error("Waypoint decoration failed to render for " + waypoint.getName() + ": ", t);
/*     */           } 
/*     */         } 
/*  74 */         buffers.endBatch();
/*     */       } 
/*     */     } 
/*  77 */     DrawUtil.sizeDisplay(mainWindow.getWidth() / mainWindow.getGuiScale(), mainWindow.getHeight() / mainWindow.getGuiScale());
/*     */   }
/*     */ 
/*     */   
/*     */   private List<ClientWaypointImpl> waypointsToDraw(Collection<ClientWaypointImpl> waypoints) {
/*  82 */     String playerDim = this.minecraft.player.getCommandSenderWorld().dimension().location().toString();
/*  83 */     List<ClientWaypointImpl> toDraw = new ArrayList<>();
/*     */ 
/*     */ 
/*     */     
/*  87 */     double closestAngle = 0.0D;
/*  88 */     ClientWaypointImpl closestHolder = null;
/*  89 */     for (ClientWaypointImpl waypoint : waypoints) {
/*     */       
/*  91 */       if (canDrawWaypoint(waypoint, playerDim) && (
/*  92 */         !this.waypointProperties.shaderBeacon.get().booleanValue() || this.waypointProperties.showRotatingBeam
/*  93 */         .get().booleanValue() || this.waypointProperties.showStaticBeam
/*  94 */         .get().booleanValue())) {
/*     */         
/*  96 */         double angle = angleToBeacon(waypoint.getPosition());
/*  97 */         if (!this.waypointProperties.autoHideLabel.get().booleanValue() || angle < 5.0D) {
/*     */           
/*  99 */           if (closestHolder == null || angle < closestAngle) {
/*     */             
/* 101 */             if (closestHolder != null)
/*     */             {
/* 103 */               toDraw.add(closestHolder);
/*     */             }
/* 105 */             closestHolder = waypoint;
/* 106 */             closestAngle = angle;
/*     */             
/*     */             continue;
/*     */           } 
/* 110 */           toDraw.add(waypoint);
/*     */         } 
/*     */       } 
/*     */     } 
/*     */ 
/*     */     
/* 116 */     if (closestHolder != null)
/*     */     {
/* 118 */       toDraw.add(closestHolder);
/*     */     }
/* 120 */     return toDraw;
/*     */   }
/*     */ 
/*     */   
/*     */   private double angleToBeacon(Vec3 waypointVec) {
/* 125 */     double yaw = Math.atan2(this.renderManager.camera.getPosition().z() - waypointVec.z, this.renderManager.camera.getPosition().x() - waypointVec.x);
/* 126 */     double degrees = Math.toDegrees(yaw) + 90.0D;
/* 127 */     if (degrees < 0.0D)
/*     */     {
/* 129 */       degrees += 360.0D;
/*     */     }
/* 131 */     double playerYaw = (this.minecraft.cameraEntity.getYHeadRot() % 360.0F);
/* 132 */     if (playerYaw < 0.0D)
/*     */     {
/* 134 */       playerYaw += 360.0D;
/*     */     }
/* 136 */     playerYaw = Math.toRadians(playerYaw);
/* 137 */     double playerDegrees = Math.toDegrees(playerYaw);
/*     */     
/* 139 */     double angle = Math.abs(degrees - playerDegrees);
/* 140 */     if (angle > 180.0D)
/*     */     {
/* 142 */       angle -= 180.0D;
/*     */     }
/*     */     
/* 145 */     return angle;
/*     */   }
/*     */ 
/*     */   
/*     */   protected void render(PoseStack poseStack, DrawStep.Pass pass, MultiBufferSource buffers, ClientWaypointImpl waypoint, float partialTicks, long gameTime, float[] rgba, float fadeAlpha, double shiftX, double shiftY, double shiftZ, Vec3 playerVec, Vec3 waypointVec, double viewDistance, double actualDistance, double scale) {
/* 150 */     GameRenderer gameRenderer = this.minecraft.gameRenderer;
/* 151 */     Vector4f position = new Vector4f((float)shiftX, (float)shiftY, (float)shiftZ, 1.0F);
/*     */     
/* 153 */     Quaternionf rotation = new Quaternionf();
/* 154 */     this.renderManager.camera.rotation().conjugate(rotation);
/* 155 */     position.rotate((Quaternionfc)rotation);
/* 156 */     position.rotateY(3.1415927F);
/* 157 */     if (position.z <= 0.0F) {
/*     */       return;
/*     */     }
/*     */     
/* 161 */     Matrix4f projection = gameRenderer.getProjectionMatrix(gameRenderer.getFov(this.renderManager.camera, partialTicks, true));
/* 162 */     position.mulProject((Matrix4fc)projection);
/*     */     
/* 164 */     Window mainWindow = this.minecraft.getWindow();
/* 165 */     int halfWidth = mainWindow.getWidth() / 2;
/* 166 */     int halfHeight = mainWindow.getHeight() / 2;
/* 167 */     double x = (position.x * halfWidth + halfWidth);
/* 168 */     double y = (position.y * halfHeight + halfHeight);
/*     */     
/* 170 */     if (pass == DrawStep.Pass.TextBG || pass == DrawStep.Pass.Text) {
/*     */ 
/*     */       
/* 173 */       if (actualDistance > 0.5D)
/*     */       {
/* 175 */         renderNameTag(waypoint, poseStack, pass, buffers, x, y, fadeAlpha, actualDistance);
/*     */       }
/*     */ 
/*     */       
/* 179 */       if (actualDistance > 0.5D && waypoint.showDeviation() && this.waypointProperties.showDeviationLabel.get().booleanValue())
/*     */       {
/* 181 */         renderDeviation(waypoint, poseStack, pass, buffers, x, y, fadeAlpha, playerVec, waypointVec);
/*     */       }
/*     */     } 
/*     */     
/* 185 */     if (pass == DrawStep.Pass.Object && actualDistance > 0.1D && this.waypointProperties.showTexture.get().booleanValue())
/*     */     {
/*     */       
/* 188 */       renderIcon(waypoint, poseStack, buffers, x, y, fadeAlpha);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected void renderIcon(ClientWaypointImpl waypoint, PoseStack poseStack, MultiBufferSource buffers, double iconX, double iconY, float alpha) {
/* 195 */     int scale = this.waypointProperties.textureSmall.get().booleanValue() ? 2 : 4;
/* 196 */     ResourceLocation location = waypoint.getTextureResource();
/* 197 */     Texture texture = TextureCache.getWaypointIcon(location);
/* 198 */     double width = (texture.getWidth() * scale);
/* 199 */     double height = (texture.getHeight() * scale);
/* 200 */     double drawX = iconX - (int)(width / 2.0D);
/* 201 */     double drawY = iconY - (int)(height / 2.0D);
/* 202 */     RenderType renderType = JMRenderTypes.getIcon(texture);
/* 203 */     VertexConsumer vertexBuilder = buffers.getBuffer(renderType);
/* 204 */     DrawUtil.drawQuad(poseStack, vertexBuilder, waypoint.getIconColor().intValue(), alpha, drawX, drawY, width, height, 0.0D, false);
/*     */   }
/*     */ 
/*     */   
/*     */   protected void renderWaypointLabel(String label, ClientWaypointImpl waypoint, PoseStack poseStack, DrawStep.Pass pass, MultiBufferSource buffers, double labelX, double labelY, float alpha) {
/* 209 */     float fontScale = this.waypointProperties.fontScale.get().floatValue();
/* 210 */     DrawUtil.drawBatchLabel(poseStack, (Component)Component.literal(label), pass, buffers, labelX, labelY, DrawUtil.HAlign.Center, DrawUtil.VAlign.Above, -16777216, 0.75F * alpha, waypoint.getSafeColor().intValue(), alpha, fontScale, false, 0.0D);
/*     */   }
/*     */ 
/*     */   
/*     */   protected void renderNameTag(ClientWaypointImpl waypoint, PoseStack poseStack, DrawStep.Pass pass, MultiBufferSource buffers, double labelX, double labelY, float alpha, double actualDistance) {
/* 215 */     String distanceLabel = Constants.getString("jm.waypoint.distance_meters", new Object[] { "%1.0f" });
/* 216 */     String label = waypoint.getName();
/* 217 */     boolean showName = (this.waypointProperties.showName.get().booleanValue() && label != null && label.length() > 0);
/* 218 */     boolean showDistance = this.waypointProperties.showDistance.get().booleanValue();
/* 219 */     if (showName || showDistance) {
/*     */ 
/*     */ 
/*     */       
/* 223 */       StringBuilder sb = new StringBuilder();
/*     */       
/* 225 */       if (this.waypointProperties.boldLabel.get().booleanValue())
/*     */       {
/* 227 */         sb.append(ChatFormatting.BOLD);
/*     */       }
/* 229 */       if (showName)
/*     */       {
/* 231 */         sb.append(label);
/*     */       }
/* 233 */       if (showName && showDistance)
/*     */       {
/* 235 */         sb.append(" ");
/*     */       }
/* 237 */       if (showDistance)
/*     */       {
/* 239 */         sb.append(String.format(distanceLabel, new Object[] { Double.valueOf(actualDistance) }));
/*     */       }
/*     */       
/* 242 */       if (sb.length() > 0) {
/*     */         
/* 244 */         label = sb.toString();
/*     */         
/* 246 */         labelY = labelY - (waypoint.getTexture().getHeight() >> 1) - 8.0D;
/* 247 */         renderWaypointLabel(label, waypoint, poseStack, pass, buffers, labelX, labelY, alpha);
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected void renderDeviation(ClientWaypointImpl waypoint, PoseStack poseStack, DrawStep.Pass pass, MultiBufferSource buffers, double labelX, double labelY, float alpha, Vec3 playerVec, Vec3 waypointVec) {
/* 255 */     StringBuilder sb = new StringBuilder();
/* 256 */     Vec3 vecTo = playerVec.vectorTo(waypointVec);
/* 257 */     if (this.waypointProperties.boldLabel.get().booleanValue())
/*     */     {
/* 259 */       sb.append(ChatFormatting.BOLD);
/*     */     }
/* 261 */     sb.append(String.format("x:%d, y:%d, z:%d", new Object[] { Integer.valueOf((int)vecTo.x), Integer.valueOf((int)vecTo.y), Integer.valueOf((int)vecTo.z) }));
/*     */     
/* 263 */     labelY = labelY + (waypoint.getTexture().getHeight() >> 1) + 35.0D;
/* 264 */     renderWaypointLabel(sb.toString(), waypoint, poseStack, pass, buffers, labelX, labelY, alpha);
/*     */   }
/*     */ }


/* Location:              C:\Users\Administrator\Downloads\journeymap-neoforge-1.21-6.0.0-beta.18.jar!\journeymap\client\render\ingame\WaypointDecorationRenderer.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */