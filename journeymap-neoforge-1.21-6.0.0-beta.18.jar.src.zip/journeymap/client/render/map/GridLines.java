/*    */ package journeymap.client.render.map;
/*    */ 
/*    */ import com.mojang.blaze3d.vertex.PoseStack;
/*    */ import com.mojang.blaze3d.vertex.VertexConsumer;
/*    */ import java.awt.geom.Point2D;
/*    */ import java.awt.geom.Rectangle2D;
/*    */ import journeymap.client.JourneymapClient;
/*    */ import journeymap.client.cartography.color.RGB;
/*    */ import journeymap.client.model.GridSpec;
/*    */ import journeymap.client.model.RegionCoord;
/*    */ import journeymap.client.render.draw.DrawUtil;
/*    */ import net.minecraft.client.gui.GuiGraphics;
/*    */ import net.minecraft.client.renderer.MultiBufferSource;
/*    */ import net.minecraft.client.renderer.RenderType;
/*    */ import org.joml.Matrix4f;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class GridLines
/*    */ {
/*    */   private final MapRenderer mapRenderer;
/*    */   
/*    */   public GridLines(MapRenderer mapRenderer) {
/* 26 */     this.mapRenderer = mapRenderer;
/*    */   }
/*    */ 
/*    */   
/*    */   public void draw(GuiGraphics graphics, MultiBufferSource buffers, RegionCoord centerRegion, Point2D.Double centerPixel, Rectangle2D.Double regionBounds, double pixelOffsetX, double pixelOffsetZ, double offsetX, double offsetZ, int zoom, float alpha, boolean showGrid) {
/* 31 */     if (showGrid) {
/*    */       
/* 33 */       GridSpec gridSpec = (JourneymapClient.getInstance().getCoreProperties()).gridSpecs.getSpec(this.mapRenderer.mapType);
/*    */       
/* 35 */       Point2D.Double distToCornerRegion = new Point2D.Double(centerRegion.regionX - regionBounds.x, centerRegion.regionZ - regionBounds.y);
/* 36 */       Point2D.Double upperLeftRegion = new Point2D.Double(centerPixel.x - ((int)distToCornerRegion.x * zoom) + pixelOffsetX + offsetX, centerPixel.y - ((int)distToCornerRegion.y * zoom) + pixelOffsetZ + offsetZ);
/* 37 */       int regionCols = (int)regionBounds.width;
/* 38 */       int regionRows = (int)regionBounds.height;
/*    */       
/* 40 */       if (zoom >= 512) {
/*    */         
/* 42 */         RenderType renderType = gridSpec.getRenderType(zoom);
/* 43 */         VertexConsumer gridLinesBuffer = buffers.getBuffer(renderType);
/* 44 */         DrawUtil.drawQuad(graphics.pose(), gridLinesBuffer, gridSpec.getColor().intValue(), alpha * gridSpec.alpha, upperLeftRegion.x, upperLeftRegion.y, (regionCols * zoom), (regionRows * zoom), 0.0D, 0.0D, regionCols, regionRows, 0.0D, false);
/*    */       }
/*    */       else {
/*    */         
/* 48 */         boolean drawChunkLines = (zoom >= 128 && gridSpec.style.hasChunkLines());
/* 49 */         boolean drawRegionLines = (zoom >= 8 && gridSpec.style.hasRegionLines());
/*    */         
/* 51 */         int chunkCols = regionCols * 32;
/* 52 */         int chunkRows = regionRows * 32;
/*    */         
/* 54 */         RenderType renderType = gridSpec.getRenderType(zoom);
/* 55 */         VertexConsumer gridLinesBuffer = buffers.getBuffer(renderType);
/* 56 */         PoseStack.Pose entry = graphics.pose().last();
/* 57 */         Matrix4f matrix4f = entry.pose();
/*    */         
/* 59 */         float gridAlpha = gridSpec.alpha * alpha;
/*    */         
/* 61 */         if (drawChunkLines) {
/*    */           
/* 63 */           int chunkColor = RGB.toArgb(gridSpec.getColor().intValue(), (zoom == 256) ? (gridAlpha * 0.6666F) : (gridAlpha * 0.3333F));
/* 64 */           for (int c = 0; c < chunkCols; c++) {
/*    */             
/* 66 */             boolean regionLine = (c % 32 == 0);
/* 67 */             if (!drawRegionLines || !regionLine) {
/*    */               
/* 69 */               gridLinesBuffer.addVertex(matrix4f, (float)(upperLeftRegion.x + (c * (zoom >> 5))), (float)upperLeftRegion.y, 0.0F).setColor(chunkColor);
/* 70 */               gridLinesBuffer.addVertex(matrix4f, (float)(upperLeftRegion.x + (c * (zoom >> 5))), (float)upperLeftRegion.y + (regionRows * zoom), 0.0F).setColor(chunkColor);
/*    */             } 
/*    */           } 
/*    */           
/* 74 */           for (int r = 0; r < chunkRows; r++) {
/*    */             
/* 76 */             boolean regionLine = (r % 32 == 0);
/* 77 */             if (!drawRegionLines || !regionLine) {
/*    */               
/* 79 */               gridLinesBuffer.addVertex(matrix4f, (float)upperLeftRegion.x, (float)(upperLeftRegion.y + (r * (zoom >> 5))), 0.0F).setColor(chunkColor);
/* 80 */               gridLinesBuffer.addVertex(matrix4f, (float)upperLeftRegion.x + (regionCols * zoom), (float)(upperLeftRegion.y + (r * (zoom >> 5))), 0.0F).setColor(chunkColor);
/*    */             } 
/*    */           } 
/*    */         } 
/*    */         
/* 85 */         if (drawRegionLines) {
/*    */           
/* 87 */           int baseColor = gridSpec.style.hasChunkLines() ? RGB.tint(gridSpec.getColor().intValue(), 16711680) : gridSpec.getColor().intValue();
/* 88 */           int regionColor = RGB.toArgb(baseColor, (zoom == 16) ? (gridAlpha * 0.6666F) : ((zoom == 8) ? (gridAlpha * 0.3333F) : gridAlpha));
/* 89 */           for (int c = 0; c < regionCols; c++) {
/*    */             
/* 91 */             gridLinesBuffer.addVertex(matrix4f, (float)(upperLeftRegion.x + (c * zoom)), (float)upperLeftRegion.y, 0.0F).setColor(regionColor);
/* 92 */             gridLinesBuffer.addVertex(matrix4f, (float)(upperLeftRegion.x + (c * zoom)), (float)upperLeftRegion.y + (regionRows * zoom), 0.0F).setColor(regionColor);
/*    */           } 
/*    */           
/* 95 */           for (int r = 0; r < regionRows; r++) {
/*    */             
/* 97 */             gridLinesBuffer.addVertex(matrix4f, (float)upperLeftRegion.x, (float)(upperLeftRegion.y + (r * zoom)), 0.0F).setColor(regionColor);
/* 98 */             gridLinesBuffer.addVertex(matrix4f, (float)upperLeftRegion.x + (regionCols * zoom), (float)(upperLeftRegion.y + (r * zoom)), 0.0F).setColor(regionColor);
/*    */           } 
/*    */         } 
/*    */       } 
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Users\Administrator\Downloads\journeymap-neoforge-1.21-6.0.0-beta.18.jar!\journeymap\client\render\map\GridLines.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */