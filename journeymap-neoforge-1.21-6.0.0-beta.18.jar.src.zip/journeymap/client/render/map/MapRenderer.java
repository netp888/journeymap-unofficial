/*     */ package journeymap.client.render.map;
/*     */ 
/*     */ import com.mojang.blaze3d.platform.Window;
/*     */ import java.awt.geom.Point2D;
/*     */ import java.awt.geom.Rectangle2D;
/*     */ import java.io.File;
/*     */ import java.nio.FloatBuffer;
/*     */ import java.util.HashSet;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Objects;
/*     */ import java.util.Set;
/*     */ import java.util.concurrent.CompletableFuture;
/*     */ import java.util.concurrent.ConcurrentHashMap;
/*     */ import journeymap.api.client.impl.ClientAPI;
/*     */ import journeymap.api.client.impl.ClientEventManager;
/*     */ import journeymap.api.services.EventBus;
/*     */ import journeymap.api.v2.client.display.Context;
/*     */ import journeymap.api.v2.client.event.DisplayUpdateEvent;
/*     */ import journeymap.api.v2.client.util.UIState;
/*     */ import journeymap.api.v2.common.event.impl.JourneyMapEvent;
/*     */ import journeymap.client.data.DataCache;
/*     */ import journeymap.client.io.RegionImageHandler;
/*     */ import journeymap.client.model.MapState;
/*     */ import journeymap.client.model.MapType;
/*     */ import journeymap.client.model.RegionCoord;
/*     */ import journeymap.client.model.RegionImageCache;
/*     */ import journeymap.client.model.RegionImageSet;
/*     */ import journeymap.client.render.RenderWrapper;
/*     */ import journeymap.client.render.draw.DrawStep;
/*     */ import journeymap.client.ui.UIManager;
/*     */ import journeymap.client.ui.fullscreen.Fullscreen;
/*     */ import journeymap.common.Journeymap;
/*     */ import net.minecraft.Util;
/*     */ import net.minecraft.client.Minecraft;
/*     */ import net.minecraft.client.gui.GuiGraphics;
/*     */ import net.minecraft.client.renderer.MultiBufferSource;
/*     */ import net.minecraft.core.BlockPos;
/*     */ import net.minecraft.util.Mth;
/*     */ import net.minecraft.world.phys.AABB;
/*     */ import org.apache.logging.log4j.Logger;
/*     */ import org.joml.Matrix4f;
/*     */ import org.joml.Matrix4fc;
/*     */ import org.joml.Vector3f;
/*     */ import org.lwjgl.BufferUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MapRenderer
/*     */   implements Renderer
/*     */ {
/*     */   protected static final int BLOCK_PAD = 32;
/*     */   protected int zoom;
/*     */   private static boolean enabled = true;
/*  56 */   private final Logger logger = Journeymap.getLogger();
/*     */   
/*  58 */   Map<RegionCoord, RegionTile> regions = new ConcurrentHashMap<>();
/*  59 */   Set<String> mapTypeImageFiles = new HashSet<>();
/*     */   private File worldDir;
/*     */   protected MapType mapType;
/*  62 */   private AABB blockBounds = null;
/*     */   private int gridSize;
/*     */   protected MapState state;
/*  65 */   protected int lastHeight = -1;
/*  66 */   protected int lastWidth = -1;
/*  67 */   private int glErrors = 0;
/*  68 */   private final int maxGlErrors = 20;
/*  69 */   protected Rectangle2D.Double viewPortBounds = null;
/*  70 */   protected Rectangle2D.Double screenBounds = null;
/*     */   
/*  72 */   protected Rectangle2D.Double regionBounds = null;
/*     */   
/*     */   protected UIState uiState;
/*     */   protected final Context.UI contextUi;
/*  76 */   private final Point2D.Double centerPixelOffset = new Point2D.Double();
/*     */   
/*     */   protected double centerBlockX;
/*     */   
/*     */   protected double centerBlockZ;
/*     */   protected RegionCoord centerRegion;
/*  82 */   protected final Minecraft mc = Minecraft.getInstance();
/*     */   
/*  84 */   public int mouseX = 0;
/*  85 */   public int mouseY = 0;
/*  86 */   public Fullscreen fullscreen = null;
/*     */   
/*     */   private final FloatBuffer modelMatrixBuf;
/*     */   
/*     */   private final FloatBuffer projMatrixBuf;
/*     */   
/*     */   private final Vector3f windowPos;
/*     */   private final Vector3f objPose;
/*     */   private final int[] viewport;
/*     */   private final Matrix4f modelMatrix;
/*     */   private final Matrix4f projectionMatrix;
/*     */   private double currentRotation;
/*     */   protected final GridLines gridLines;
/*     */   private CompletableFuture<Set<String>> mapTypeFileFuture;
/*     */   private boolean renderReady = false;
/*     */   
/*     */   public MapRenderer(Context.UI contextUi) {
/* 103 */     this.contextUi = contextUi;
/* 104 */     this.gridLines = new GridLines(this);
/* 105 */     this.modelMatrixBuf = BufferUtils.createFloatBuffer(16);
/* 106 */     this.projMatrixBuf = BufferUtils.createFloatBuffer(16);
/* 107 */     this.windowPos = new Vector3f();
/* 108 */     this.objPose = new Vector3f();
/* 109 */     this.viewport = new int[4];
/* 110 */     this.modelMatrix = new Matrix4f(this.modelMatrixBuf);
/* 111 */     this.projectionMatrix = new Matrix4f(this.projMatrixBuf);
/*     */     
/* 113 */     this.centerBlockX = this.mc.gameRenderer.getMainCamera().getBlockPosition().getX();
/* 114 */     this.centerBlockZ = this.mc.gameRenderer.getMainCamera().getBlockPosition().getZ();
/*     */     
/*     */     try {
/* 117 */       this.uiState = UIState.newInactive(contextUi, Minecraft.getInstance());
/*     */     }
/* 119 */     catch (Throwable t) {
/*     */       
/* 121 */       t.printStackTrace();
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   private void updateMapTypeImageFiles() {
/* 127 */     if (this.mapTypeFileFuture == null || this.mapTypeFileFuture.isDone()) {
/*     */       
/* 129 */       this.mapTypeFileFuture = CompletableFuture.supplyAsync(() -> RegionImageHandler.getImageFilesForMapType(Minecraft.getInstance(), this.mapType), 
/* 130 */           Util.backgroundExecutor());
/*     */       
/* 132 */       this.mapTypeFileFuture.whenCompleteAsync((set, throwable) -> {
/*     */             this.mapTypeImageFiles = set;
/*     */             updateGrid(this.centerRegion);
/* 135 */           }Util.backgroundExecutor());
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void loadInMemoryRegions() {
/* 145 */     List<RegionTile> regionsInMemory = RegionImageCache.INSTANCE.getRegionImageSets().stream().filter(set -> (set.getExistingHolder(this.mapType) != null && set.getExistingHolder(this.mapType).hasTexture() && this.regions.get(set.getRegionCoord()) == null)).map(set -> new RegionTile(set.getRegionCoord(), this.state)).toList();
/* 146 */     for (RegionTile tile : regionsInMemory)
/*     */     {
/* 148 */       this.regions.putIfAbsent(tile.getRegionCoord(), tile);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean setZoom(double zoom) {
/* 154 */     int minZoom = Context.UI.Fullscreen.equals(this.contextUi) ? 2 : 256;
/* 155 */     this.zoom = (int)Mth.clamp(zoom, minZoom, 16384.0D);
/* 156 */     return true;
/*     */   }
/*     */ 
/*     */   
/*     */   private void updateGrid(RegionCoord centerRegion) {
/* 161 */     this.gridSize = getCalculatedGridSize(this.zoom);
/* 162 */     int regionCount = this.gridSize / 2;
/* 163 */     loadInMemoryRegions();
/* 164 */     this.regionBounds = new Rectangle2D.Double((centerRegion.regionX - regionCount), (centerRegion.regionZ - regionCount), this.gridSize, this.gridSize);
/* 165 */     for (int x = centerRegion.regionX - regionCount; x <= centerRegion.regionX + regionCount; x++) {
/*     */       
/* 167 */       for (int z = centerRegion.regionZ - regionCount; z <= centerRegion.regionZ + regionCount; z++) {
/*     */         
/* 169 */         if (this.mapTypeImageFiles.contains("" + x + "," + x + ".png")) {
/*     */           
/* 171 */           RegionCoord rCoord = RegionCoord.fromRegionPos(this.worldDir, x, z, this.state.getDimension());
/* 172 */           if (this.regions.get(rCoord) == null)
/*     */           {
/* 174 */             this.regions.put(rCoord, new RegionTile(rCoord, this.state));
/*     */           }
/*     */         }
/* 177 */         else if (this.mc.getSingleplayerServer() == null || this.mc.getSingleplayerServer().isSingleplayer()) {
/*     */         
/*     */         } 
/*     */       } 
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 185 */     this.renderReady = true;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setContext(MapState state) {
/* 190 */     this.worldDir = state.getWorldDir();
/* 191 */     this.mapType = state.getMapType();
/* 192 */     this.state = state;
/*     */   }
/*     */ 
/*     */   
/*     */   public void render(GuiGraphics graphics, MultiBufferSource.BufferSource buffers, double offsetX, double offsetZ, float alpha, boolean showGrid) {
/* 197 */     if (enabled) {
/*     */       
/* 199 */       BlockPos cornerBlock = BlockPos.containing(this.centerBlockX - 256.0D, 0.0D, this.centerBlockZ - 256.0D);
/* 200 */       Point2D.Double cornerPixel = getBlockPixelInGrid(cornerBlock);
/*     */ 
/*     */       
/*     */       try {
/* 204 */         if (this.renderReady)
/*     */         {
/* 206 */           for (RegionTile region : this.regions.values())
/*     */           {
/* 208 */             region.setPosition(this.centerRegion, cornerPixel, this.regionBounds, offsetX, offsetZ, this.zoom);
/* 209 */             region.render(graphics, (MultiBufferSource)buffers, this.centerPixelOffset.x, this.centerPixelOffset.y, alpha);
/*     */           }
/*     */         
/*     */         }
/* 213 */       } catch (Throwable t) {
/*     */         
/* 215 */         t.printStackTrace();
/* 216 */         this.logger.error("Error drawing map tiles", t);
/*     */       } 
/* 218 */       this.gridLines.draw(graphics, (MultiBufferSource)buffers, this.centerRegion, cornerPixel, this.regionBounds, this.centerPixelOffset.x, this.centerPixelOffset.y, offsetX, offsetZ, this.zoom, alpha, showGrid);
/*     */     }
/*     */     else {
/*     */       
/* 222 */       this.regions.clear();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void draw(GuiGraphics graphics, MultiBufferSource.BufferSource buffers, List<? extends DrawStep> drawStepList, Fullscreen fullscreen, int mouseX, int mouseY, double xOffset, double yOffset, double fontScale, double rotation) {
/* 236 */     this.mouseX = mouseX;
/* 237 */     this.mouseY = mouseY;
/* 238 */     this.fullscreen = fullscreen;
/* 239 */     draw(graphics, buffers, drawStepList, xOffset, yOffset, fontScale, rotation);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void draw(GuiGraphics graphics, MultiBufferSource.BufferSource buffers, List<? extends DrawStep> drawStepList, double xOffset, double yOffset, double fontScale, double rotation) {
/* 245 */     if (!enabled || drawStepList == null || drawStepList.isEmpty()) {
/*     */       return;
/*     */     }
/*     */     
/* 249 */     draw(graphics, buffers, xOffset, yOffset, fontScale, rotation, drawStepList.<DrawStep>toArray(new DrawStep[drawStepList.size()]));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void draw(GuiGraphics graphics, MultiBufferSource.BufferSource buffers, double xOffset, double yOffset, double fontScale, double rotation, DrawStep... drawSteps) {
/* 258 */     if (enabled)
/*     */     {
/* 260 */       for (DrawStep.Pass pass : DrawStep.Pass.values()) {
/*     */         
/* 262 */         int zLevel = 0;
/* 263 */         for (DrawStep drawStep : drawSteps) {
/*     */           
/* 265 */           if (drawStep != null) {
/*     */             
/* 267 */             zLevel++;
/* 268 */             graphics.pose().pushPose();
/* 269 */             graphics.pose().translate(0.0F, 0.0F, zLevel);
/* 270 */             drawStep.draw(graphics, (MultiBufferSource)buffers, pass, xOffset, yOffset, this, fontScale, rotation);
/* 271 */             graphics.pose().popPose();
/*     */           } 
/*     */         } 
/* 274 */         buffers.endBatch();
/*     */       } 
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Point2D.Double getPixel(double blockX, double blockZ) {
/* 288 */     Point2D.Double pixel = getBlockPixelInGrid(blockX, blockZ);
/* 289 */     if (isOnScreen(pixel))
/*     */     {
/* 291 */       return pixel;
/*     */     }
/*     */ 
/*     */     
/* 295 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private RegionCoord getCenterRegion(double blockX, double blockZ) {
/* 301 */     return RegionCoord.fromChunkPos(this.worldDir, this.mapType, (int)blockX >> 4, (int)blockZ >> 4);
/*     */   }
/*     */ 
/*     */   
/*     */   private double roundToScreenPixel(double value) {
/* 306 */     double pixelSizeInBlocks = 512.0D / this.zoom;
/* 307 */     return pixelSizeInBlocks * value / pixelSizeInBlocks;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Point2D.Double getBlockPixelInGrid(BlockPos pos) {
/* 313 */     return getBlockPixelInGrid(pos.getX(), pos.getZ());
/*     */   }
/*     */ 
/*     */   
/*     */   public Point2D.Double getBlockPixelInGrid(double blockX, double blockZ) {
/* 318 */     double localBlockX = roundToScreenPixel(blockX) - this.centerBlockX;
/* 319 */     double localBlockZ = roundToScreenPixel(blockZ) - this.centerBlockZ;
/*     */     
/* 321 */     double blockSize = this.zoom / 512.0D;
/* 322 */     double pixelOffsetX = (this.mc.getWindow().getScreenWidth() / 2) + localBlockX * blockSize;
/* 323 */     double pixelOffsetZ = (this.mc.getWindow().getScreenHeight() / 2) + localBlockZ * blockSize;
/*     */     
/* 325 */     return new Point2D.Double(pixelOffsetX, pixelOffsetZ);
/*     */   }
/*     */   
/*     */   public BlockPos getBlockAtPixel(Point2D.Double pixel) {
/*     */     int y;
/* 330 */     double centerPixelX = this.lastWidth / 2.0D;
/* 331 */     double centerPixelZ = this.lastHeight / 2.0D;
/*     */     
/* 333 */     double deltaX = (centerPixelX - pixel.x) / this.zoom / 512.0D;
/* 334 */     double deltaZ = (centerPixelZ - this.lastHeight - pixel.y) / this.zoom / 512.0D;
/*     */     
/* 336 */     double x = this.centerBlockX - deltaX;
/* 337 */     double z = this.centerBlockZ + deltaZ;
/*     */ 
/*     */     
/* 340 */     if ((DataCache.getPlayer()).underground.booleanValue()) {
/*     */       
/* 342 */       y = Mth.floor((DataCache.getPlayer()).posY);
/*     */     }
/*     */     else {
/*     */       
/* 346 */       y = (Minecraft.getInstance()).level.getSeaLevel();
/*     */     } 
/* 348 */     return BlockPos.containing(x, y, z);
/*     */   }
/*     */ 
/*     */   
/*     */   protected void updateBounds() {
/* 353 */     int width = this.mc.getWindow().getScreenWidth();
/* 354 */     int height = this.mc.getWindow().getScreenHeight();
/*     */     
/* 356 */     if (this.screenBounds == null || this.lastWidth != width || this.lastHeight != height || this.blockBounds == null) {
/*     */       
/* 358 */       this.lastWidth = width;
/* 359 */       this.lastHeight = height;
/*     */       
/* 361 */       if (this.viewPortBounds == null) {
/*     */         
/* 363 */         this.screenBounds = new Rectangle2D.Double(-32.0D, -32.0D, (width + 32), (height + 32));
/*     */       }
/*     */       else {
/*     */         
/* 367 */         this.screenBounds = new Rectangle2D.Double((width - this.viewPortBounds.width) / 2.0D, (height - this.viewPortBounds.height) / 2.0D, this.viewPortBounds.width, this.viewPortBounds.height);
/*     */       } 
/*     */ 
/*     */       
/* 371 */       ClientAPI.INSTANCE.flagOverlaysForRerender();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void updateUIState(boolean isActive) {
/* 378 */     if (isActive && this.screenBounds == null) {
/*     */       return;
/*     */     }
/*     */ 
/*     */     
/* 383 */     UIState newState = null;
/* 384 */     if (isActive) {
/*     */ 
/*     */       
/* 387 */       int worldHeight = (Minecraft.getInstance()).level.dimensionType().logicalHeight();
/*     */       
/* 389 */       BlockPos upperLeft = getBlockAtPixel(new Point2D.Double(this.screenBounds.getMinX(), this.screenBounds.getMinY()));
/* 390 */       BlockPos lowerRight = getBlockAtPixel(new Point2D.Double(this.screenBounds.getMaxX(), this.screenBounds.getMaxY()));
/*     */       
/* 392 */       this.blockBounds = AABB.encapsulatingFullBlocks(upperLeft.offset(-32, 0, -32), lowerRight.offset(32, worldHeight, 32));
/*     */ 
/*     */       
/*     */       try {
/* 396 */         newState = new UIState(this.contextUi, true, this.mapType.dimension, this.zoom, this.mapType.apiMapType, BlockPos.containing(this.centerBlockX, 0.0D, this.centerBlockZ), this.mapType.vSlice, this.blockBounds, this.screenBounds);
/*     */       }
/* 398 */       catch (Exception e) {
/*     */         
/* 400 */         this.logger.error("Error Creating new UIState: ", e);
/*     */       }
/*     */     
/*     */     } else {
/*     */       
/* 405 */       newState = UIState.newInactive(this.uiState);
/*     */     } 
/*     */ 
/*     */     
/* 409 */     if ((this.uiState == null && newState != null) || (newState != null && !newState.equals(this.uiState))) {
/*     */       
/* 411 */       this.uiState = newState;
/* 412 */       ClientEventManager clientEventManager = ClientAPI.INSTANCE.getClientEventManager();
/* 413 */       DisplayUpdateEvent displayUpdateEvent = new DisplayUpdateEvent(this.uiState);
/* 414 */       if (EventBus.hasListeners((JourneyMapEvent)displayUpdateEvent))
/*     */       {
/* 416 */         clientEventManager.queueDisplayUpdateEvent(displayUpdateEvent);
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void updateTiles(MapType mapType, int zoom, boolean fullUpdate) {
/* 423 */     this.mapType = mapType;
/* 424 */     this.zoom = zoom;
/*     */     
/* 426 */     updateBounds();
/*     */ 
/*     */ 
/*     */     
/* 430 */     if (this.centerRegion == null || this.regions.get(this.centerRegion) == null || ((RegionTile)this.regions.get(this.centerRegion)).getZoom() != this.zoom) {
/*     */       
/* 432 */       this.centerRegion = getCenterRegion(this.centerBlockX, this.centerBlockZ);
/* 433 */       if (!fullUpdate)
/*     */       {
/* 435 */         CompletableFuture.runAsync(() -> updateGrid(this.centerRegion), Util.backgroundExecutor());
/*     */       }
/*     */     } 
/*     */ 
/*     */     
/* 440 */     Point2D blockPixelOffset = blockPixelOffsetInRegion(this.centerRegion, this.centerBlockX, this.centerBlockZ);
/*     */     
/* 442 */     double blockSizeOffset = this.uiState.blockSize / 2.0D;
/*     */     
/* 444 */     double displayOffsetX = 0.0D;
/* 445 */     double displayOffsetY = 0.0D;
/*     */     
/* 447 */     if (this.centerBlockZ < 0.0D) {
/*     */       
/* 449 */       displayOffsetX -= blockSizeOffset;
/*     */     }
/*     */     else {
/*     */       
/* 453 */       displayOffsetX += blockSizeOffset;
/*     */     } 
/*     */     
/* 456 */     if (this.centerBlockX > 0.0D) {
/*     */       
/* 458 */       displayOffsetY += blockSizeOffset;
/*     */     }
/*     */     else {
/*     */       
/* 462 */       displayOffsetY -= blockSizeOffset;
/*     */     } 
/*     */     
/* 465 */     this.centerPixelOffset.setLocation(displayOffsetX + blockPixelOffset.getX(), displayOffsetY + blockPixelOffset.getY());
/*     */     
/* 467 */     if (fullUpdate)
/*     */     {
/*     */       
/* 470 */       updateMapTypeImageFiles();
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public Point2D blockPixelOffsetInRegion(RegionCoord centerRegion, double centerBlockX, double centerBlockZ) {
/* 476 */     double blockSize = (getUIState()).blockSize;
/* 477 */     double localBlockX = centerRegion.getMinChunkCoord().getMinBlockX() - Math.floor(centerBlockX);
/* 478 */     double localBlockZ = centerRegion.getMinChunkCoord().getMinBlockZ() - Math.floor(centerBlockZ);
/* 479 */     if (centerBlockX < 0.0D)
/*     */     {
/* 481 */       localBlockZ++;
/*     */     }
/* 483 */     if (centerBlockZ < 0.0D)
/*     */     {
/* 485 */       localBlockX++;
/*     */     }
/* 487 */     double pixelOffsetX = (this.zoom >> 1) + localBlockX * blockSize - blockSize / 2.0D;
/* 488 */     double pixelOffsetZ = (this.zoom >> 1) + localBlockZ * blockSize - blockSize / 2.0D;
/* 489 */     return new Point2D.Double(pixelOffsetX, pixelOffsetZ);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean center() {
/* 494 */     return center(this.worldDir, this.mapType, this.centerBlockX, this.centerBlockZ, this.zoom);
/*     */   }
/*     */ 
/*     */   
/*     */   public void move(double deltaBlockX, double deltaBlockZ) {
/* 499 */     center(this.worldDir, this.mapType, this.centerBlockX + deltaBlockX, this.centerBlockZ + deltaBlockZ, this.zoom);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean center(File worldDir, MapType mapType, double blockX, double blockZ, int zoom) {
/* 504 */     boolean mapTypeChanged = (!Objects.equals(worldDir, this.worldDir) || !Objects.equals(mapType, this.mapType));
/*     */     
/* 506 */     if (!Objects.equals(worldDir, this.worldDir))
/*     */     {
/* 508 */       this.worldDir = worldDir;
/*     */     }
/*     */     
/* 511 */     blockX = roundToScreenPixel(blockX);
/* 512 */     blockZ = roundToScreenPixel(blockZ);
/*     */     
/* 514 */     if (blockX == this.centerBlockX && blockZ == this.centerBlockZ && zoom == this.zoom && !mapTypeChanged && !this.regions.isEmpty()) {
/*     */ 
/*     */       
/* 517 */       if (!Objects.equals(mapType.apiMapType, this.uiState.mapType))
/*     */       {
/* 519 */         updateUIState(true);
/*     */       }
/*     */       
/* 522 */       return false;
/*     */     } 
/*     */     
/* 525 */     this.centerBlockX = blockX;
/* 526 */     this.centerBlockZ = blockZ;
/* 527 */     this.zoom = zoom;
/*     */ 
/*     */     
/* 530 */     RegionCoord newCenterRegion = getCenterRegion(this.centerBlockX, this.centerBlockZ);
/* 531 */     boolean centerTileChanged = !newCenterRegion.equals(this.centerRegion);
/*     */     
/* 533 */     if (mapTypeChanged || centerTileChanged) {
/*     */ 
/*     */       
/* 536 */       this.centerRegion = newCenterRegion;
/* 537 */       CompletableFuture.runAsync(() -> updateGrid(this.centerRegion), Util.backgroundExecutor());
/*     */     } 
/*     */     
/* 540 */     updateUIState(true);
/* 541 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isOnScreen(Point2D.Double pixel) {
/* 552 */     return this.screenBounds.contains(pixel);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isOnScreen(Rectangle2D.Double bounds) {
/* 563 */     return this.screenBounds.intersects(bounds);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isOnScreen(double x, double y) {
/* 575 */     return this.screenBounds.contains(x, y);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isOnScreen(double startX, double startY, int width, int height) {
/* 589 */     if (this.screenBounds == null)
/*     */     {
/* 591 */       return false;
/*     */     }
/*     */     
/* 594 */     return this.screenBounds.intersects(startX, startY, width, height);
/*     */   }
/*     */ 
/*     */   
/*     */   public void clear() {
/* 599 */     if (this.mapTypeFileFuture != null) {
/*     */       
/* 601 */       this.mapTypeFileFuture.cancel(true);
/* 602 */       this.mapTypeFileFuture = null;
/*     */     } 
/* 604 */     this.renderReady = false;
/* 605 */     this.regions.clear();
/*     */   }
/*     */ 
/*     */   
/*     */   public UIState getUIState() {
/* 610 */     return this.uiState;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Fullscreen getFullscreen() {
/* 616 */     return this.fullscreen;
/*     */   }
/*     */ 
/*     */   
/*     */   public MapType getMapType() {
/* 621 */     return this.mapType;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void clearGlErrors(boolean report) {
/*     */     int err;
/* 630 */     while ((err = RenderWrapper.getError()) != 0) {
/*     */       
/* 632 */       if (report && this.glErrors <= 20) {
/*     */         
/* 634 */         this.glErrors++;
/* 635 */         if (this.glErrors < 20) {
/*     */           
/* 637 */           this.logger.warn("GL Error occurred during JourneyMap draw: " + err);
/*     */           
/*     */           continue;
/*     */         } 
/* 641 */         this.logger.warn("GL Error reporting during JourneyMap will be suppressed after max errors: 20");
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean hasUnloadedTile() {
/* 649 */     for (RegionTile tile : this.regions.values()) {
/*     */       
/* 651 */       if (this.mapTypeFileFuture == null || !this.mapTypeFileFuture.isDone())
/*     */       {
/* 653 */         return false;
/*     */       }
/* 655 */       if (isOnScreen(tile.getX(), tile.getY()))
/*     */       {
/* 657 */         if (tile.getTexture() != null && tile.getTexture().isDefunct() && tile.shouldRender())
/*     */         {
/* 659 */           return true;
/*     */         }
/*     */       }
/*     */     } 
/* 663 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void ensureOnScreen(Point2D pixel) {
/* 669 */     if (this.screenBounds == null) {
/*     */       return;
/*     */     }
/*     */ 
/*     */     
/* 674 */     double x = pixel.getX();
/* 675 */     if (x < this.screenBounds.x) {
/*     */       
/* 677 */       x = this.screenBounds.x;
/*     */     }
/* 679 */     else if (x > this.screenBounds.getMaxX()) {
/*     */       
/* 681 */       x = this.screenBounds.getMaxX();
/*     */     } 
/*     */     
/* 684 */     double y = pixel.getY();
/* 685 */     if (y < this.screenBounds.y) {
/*     */       
/* 687 */       y = this.screenBounds.y;
/*     */     }
/* 689 */     else if (y > this.screenBounds.getMaxY()) {
/*     */       
/* 691 */       y = this.screenBounds.getMaxY();
/*     */     } 
/*     */     
/* 694 */     pixel.setLocation(x, y);
/*     */   }
/*     */ 
/*     */   
/*     */   public void updateRotation(GuiGraphics graphics, double rotation) {
/* 699 */     this.currentRotation = rotation;
/* 700 */     this.viewport[0] = 0;
/* 701 */     this.viewport[1] = 0;
/* 702 */     this.viewport[2] = Minecraft.getInstance().getWindow().getWidth();
/* 703 */     this.viewport[3] = Minecraft.getInstance().getWindow().getHeight();
/* 704 */     graphics.pose().last().pose().get(this.modelMatrixBuf);
/* 705 */     RenderWrapper.getProjectionMatrix().get(this.projMatrixBuf);
/* 706 */     this.modelMatrix.set(this.modelMatrixBuf);
/* 707 */     this.projectionMatrix.set(this.projMatrixBuf).mul((Matrix4fc)this.modelMatrix);
/*     */   }
/*     */ 
/*     */   
/*     */   public Point2D shiftWindowPosition(double x, double y, int shiftX, int shiftY) {
/* 712 */     if (this.currentRotation % 360.0D == 0.0D)
/*     */     {
/* 714 */       return new Point2D.Double(x + shiftX, y + shiftY);
/*     */     }
/*     */ 
/*     */     
/* 718 */     this.projectionMatrix.project((float)x, (float)y, 0.0F, this.viewport, this.windowPos);
/* 719 */     this.projectionMatrix.unproject(this.windowPos.get(0) + shiftX, this.windowPos.get(1) + shiftY, 0.0F, this.viewport, this.objPose);
/* 720 */     return new Point2D.Float(this.objPose.get(0), this.objPose.get(1));
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Point2D.Double getWindowPosition(Point2D.Double matrixPixel) {
/* 726 */     if (this.currentRotation % 360.0D == 0.0D)
/*     */     {
/* 728 */       return matrixPixel;
/*     */     }
/*     */ 
/*     */     
/* 732 */     this.projectionMatrix.project((float)matrixPixel.getX(), (float)matrixPixel.getY(), 0.0F, this.viewport, this.windowPos);
/* 733 */     return new Point2D.Double(this.windowPos.get(0), this.windowPos.get(1));
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void setViewPortBounds(Rectangle2D.Double viewPortBounds) {
/* 739 */     this.viewPortBounds = viewPortBounds;
/* 740 */     this.screenBounds = null;
/* 741 */     updateBounds();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public int getZoom() {
/* 747 */     return this.zoom;
/*     */   }
/*     */ 
/*     */   
/*     */   public int getMouseX() {
/* 752 */     return this.mouseX;
/*     */   }
/*     */ 
/*     */   
/*     */   public int getMouseY() {
/* 757 */     return this.mouseY;
/*     */   }
/*     */ 
/*     */   
/*     */   public Context.UI getContext() {
/* 762 */     return this.contextUi;
/*     */   }
/*     */ 
/*     */   
/*     */   public int getWidth() {
/* 767 */     return this.lastWidth;
/*     */   }
/*     */ 
/*     */   
/*     */   public int getHeight() {
/* 772 */     return this.lastHeight;
/*     */   }
/*     */ 
/*     */   
/*     */   public int getGridSize() {
/* 777 */     return this.gridSize;
/*     */   }
/*     */ 
/*     */   
/*     */   public int getCalculatedGridSize(int zoom) {
/* 782 */     Window mainWindow = Minecraft.getInstance().getWindow();
/* 783 */     int width = Context.UI.Fullscreen.equals((getUIState()).ui) ? mainWindow.getWidth() : (UIManager.INSTANCE.getMiniMap().getDisplayVars()).minimapWidth;
/*     */     
/* 785 */     int gridSize = (int)Math.ceil(width / zoom);
/*     */ 
/*     */     
/* 788 */     gridSize++;
/*     */     
/* 790 */     if (gridSize % 2 == 0)
/*     */     {
/* 792 */       gridSize++;
/*     */     }
/* 794 */     return gridSize;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void setEnabled(boolean enabled) {
/* 804 */     MapRenderer.enabled = enabled;
/*     */   }
/*     */ }


/* Location:              C:\Users\Administrator\Downloads\journeymap-neoforge-1.21-6.0.0-beta.18.jar!\journeymap\client\render\map\MapRenderer.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */