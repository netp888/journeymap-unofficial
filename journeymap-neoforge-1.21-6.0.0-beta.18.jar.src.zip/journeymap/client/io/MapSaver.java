/*     */ package journeymap.client.io;
/*     */ 
/*     */ import com.google.common.base.Joiner;
/*     */ import java.io.File;
/*     */ import java.text.DateFormat;
/*     */ import java.text.SimpleDateFormat;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Date;
/*     */ import java.util.regex.Matcher;
/*     */ import java.util.regex.Pattern;
/*     */ import journeymap.client.Constants;
/*     */ import journeymap.client.data.WorldData;
/*     */ import journeymap.client.log.ChatLog;
/*     */ import journeymap.client.log.StatTimer;
/*     */ import journeymap.client.model.MapType;
/*     */ import journeymap.client.model.RegionCoord;
/*     */ import journeymap.client.model.RegionImageCache;
/*     */ import journeymap.common.Journeymap;
/*     */ import journeymap.common.log.LogFormatter;
/*     */ import net.minecraft.client.Minecraft;
/*     */ import org.apache.logging.log4j.Level;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MapSaver
/*     */ {
/*  36 */   private static final DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd_HH.mm.ss");
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   final File worldDir;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   final MapType mapType;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   File saveFile;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   int outputColumns;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   int outputRows;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   ArrayList<File> files;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MapSaver(File worldDir, MapType mapType) {
/*  72 */     this.worldDir = worldDir;
/*  73 */     this.mapType = mapType;
/*     */     
/*  75 */     prepareFiles();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public File saveMap() {
/*  86 */     StatTimer timer = StatTimer.get("MapSaver.saveMap");
/*     */ 
/*     */ 
/*     */     
/*     */     try {
/*  91 */       if (!isValid()) {
/*     */         
/*  93 */         Journeymap.getLogger().warn("No images found in " + String.valueOf(getImageDir()));
/*  94 */         return null;
/*     */       } 
/*     */ 
/*     */       
/*  98 */       RegionImageCache.INSTANCE.flushToDisk(false);
/*     */       
/* 100 */       timer.start();
/*     */ 
/*     */       
/* 103 */       File[] fileArray = this.files.<File>toArray(new File[this.files.size()]);
/* 104 */       PngjHelper.mergeFiles(fileArray, this.saveFile, this.outputColumns, 512);
/*     */       
/* 106 */       timer.stop();
/* 107 */       Journeymap.getLogger().info("Map filesize:" + this.saveFile.length());
/*     */       
/* 109 */       String message = Constants.getString("jm.common.map_saved", new Object[] { this.saveFile });
/* 110 */       ChatLog.announceFile(message, this.saveFile);
/*     */ 
/*     */     
/*     */     }
/* 114 */     catch (OutOfMemoryError e) {
/*     */       
/* 116 */       String error = "Out Of Memory: Increase Java Heap Size for Minecraft to save large maps.";
/* 117 */       Journeymap.getLogger().error(error);
/* 118 */       ChatLog.announceError(error);
/* 119 */       timer.cancel();
/*     */     }
/* 121 */     catch (Throwable t) {
/*     */       
/* 123 */       Journeymap.getLogger().error(LogFormatter.toString(t));
/* 124 */       timer.cancel();
/* 125 */       return null;
/*     */     } 
/*     */     
/* 128 */     return this.saveFile;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getSaveFileName() {
/* 138 */     return this.saveFile.getName();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isValid() {
/* 148 */     return (this.files != null && this.files.size() > 0);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private File getImageDir() {
/* 154 */     RegionCoord fakeRc = new RegionCoord(this.worldDir, 0, 0, this.mapType.dimension);
/* 155 */     return RegionImageHandler.getImageDir(fakeRc, this.mapType);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void prepareFiles() {
/*     */     try {
/* 166 */       Minecraft mc = Minecraft.getInstance();
/* 167 */       String date = dateFormat.format(new Date());
/* 168 */       String worldName = WorldData.getWorldName(mc).replaceAll("\\W+", "~");
/* 169 */       String dimName = WorldData.getSafeDimensionName((WorldData.DimensionProvider)new WorldData.WrappedProvider(mc.level.dimension())).replaceAll("\\W+", "~");
/* 170 */       String fileName = Joiner.on("_").skipNulls().join(date, worldName, new Object[] { dimName, this.mapType.name, this.mapType.vSlice }) + ".png";
/*     */ 
/*     */       
/* 173 */       File screenshotsDir = new File(FileHandler.getMinecraftDirectory(), "screenshots");
/* 174 */       if (!screenshotsDir.exists())
/*     */       {
/* 176 */         screenshotsDir.mkdir();
/*     */       }
/*     */ 
/*     */       
/* 180 */       this.saveFile = new File(screenshotsDir, fileName);
/*     */ 
/*     */       
/* 183 */       RegionImageCache.INSTANCE.flushToDisk(false);
/*     */ 
/*     */       
/* 186 */       File imageDir = getImageDir();
/* 187 */       File[] pngFiles = imageDir.listFiles();
/*     */       
/* 189 */       Pattern tilePattern = Pattern.compile("([^\\.]+)\\,([^\\.]+)\\.png");
/* 190 */       Integer minX = null, minZ = null, maxX = null, maxZ = null;
/*     */       
/* 192 */       for (File file : pngFiles) {
/*     */         
/* 194 */         Matcher matcher = tilePattern.matcher(file.getName());
/* 195 */         if (matcher.matches()) {
/*     */           
/*     */           try {
/*     */             
/* 199 */             Integer x = Integer.valueOf(Integer.parseInt(matcher.group(1)));
/* 200 */             Integer z = Integer.valueOf(Integer.parseInt(matcher.group(2)));
/* 201 */             if (minX == null || x.intValue() < minX.intValue())
/*     */             {
/* 203 */               minX = x;
/*     */             }
/* 205 */             if (minZ == null || z.intValue() < minZ.intValue())
/*     */             {
/* 207 */               minZ = z;
/*     */             }
/* 209 */             if (maxX == null || x.intValue() > maxX.intValue())
/*     */             {
/* 211 */               maxX = x;
/*     */             }
/* 213 */             if (maxZ == null || z.intValue() > maxZ.intValue())
/*     */             {
/* 215 */               maxZ = z;
/*     */             }
/*     */           }
/* 218 */           catch (Exception e) {
/*     */             
/* 220 */             Journeymap.getLogger().warn("Invalid file name {}", file.getName());
/*     */           } 
/*     */         }
/*     */       } 
/*     */       
/* 225 */       if (minX == null || maxX == null || minZ == null || maxZ == null) {
/*     */         
/* 227 */         Journeymap.getLogger().warn("No region files to save in " + String.valueOf(imageDir));
/*     */ 
/*     */         
/*     */         return;
/*     */       } 
/*     */       
/* 233 */       this.outputColumns = maxX.intValue() - minX.intValue() + 1;
/* 234 */       this.outputRows = maxZ.intValue() - minZ.intValue() + 1;
/* 235 */       this.files = new ArrayList<>(this.outputColumns * this.outputRows);
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 240 */       for (int rz = minZ.intValue(); rz <= maxZ.intValue(); rz++) {
/*     */         
/* 242 */         for (int rx = minX.intValue(); rx <= maxX.intValue(); rx++)
/*     */         {
/* 244 */           RegionCoord rc = new RegionCoord(this.worldDir, rx, rz, this.mapType.dimension);
/* 245 */           File rfile = RegionImageHandler.getRegionImageFile(rc, this.mapType);
/* 246 */           if (rfile.canRead())
/*     */           {
/* 248 */             this.files.add(rfile);
/*     */           }
/*     */           else
/*     */           {
/* 252 */             this.files.add(RegionImageHandler.getBlank512x512ImageFile());
/*     */           }
/*     */         
/*     */         }
/*     */       
/*     */       } 
/* 258 */     } catch (Throwable t) {
/*     */       
/* 260 */       Journeymap.getLogger().log(Level.ERROR, LogFormatter.toString(t));
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\Administrator\Downloads\journeymap-neoforge-1.21-6.0.0-beta.18.jar!\journeymap\client\io\MapSaver.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */