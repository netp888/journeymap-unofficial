/*    */ package journeymap.client.io.nbt;
/*    */ 
/*    */ import com.mojang.datafixers.DataFixer;
/*    */ import java.util.Optional;
/*    */ import journeymap.client.model.ChunkMD;
/*    */ import journeymap.common.Journeymap;
/*    */ import net.minecraft.client.Minecraft;
/*    */ import net.minecraft.client.server.IntegratedServer;
/*    */ import net.minecraft.nbt.CompoundTag;
/*    */ import net.minecraft.server.level.ServerLevel;
/*    */ import net.minecraft.util.datafix.DataFixTypes;
/*    */ import net.minecraft.world.level.ChunkPos;
/*    */ import net.minecraft.world.level.Level;
/*    */ import net.minecraft.world.level.chunk.ChunkSource;
/*    */ import net.minecraft.world.level.chunk.LevelChunk;
/*    */ import net.minecraft.world.level.chunk.storage.ChunkStorage;
/*    */ import org.apache.logging.log4j.Logger;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class JMChunkLoader
/*    */ {
/* 27 */   private static Logger logger = Journeymap.getLogger();
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static ChunkMD getChunkMD(ChunkStorage loader, Minecraft mc, ChunkPos coord, boolean forceRetain) {
/* 36 */     if (RegionLoader.getRegionFile(mc, coord.x, coord.z).exists()) {
/*    */       
/* 38 */       IntegratedServer integratedServer = mc.getSingleplayerServer();
/* 39 */       ServerLevel serverWorld = integratedServer.getLevel(mc.player.getCommandSenderWorld().dimension());
/* 40 */       return getChunkFromRegion(serverWorld, coord, loader, forceRetain);
/*    */     } 
/*    */ 
/*    */     
/* 44 */     logger.warn("Region doesn't exist for chunk: " + String.valueOf(coord));
/*    */     
/* 46 */     return null;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   private static ChunkMD getChunkFromRegion(ServerLevel world, ChunkPos coord, ChunkStorage loader, boolean forceRetain) {
/*    */     try {
/* 53 */       CompoundTag nbt = ((Optional<CompoundTag>)loader.read(coord).get()).get();
/*    */       
/* 55 */       if (nbt != null)
/*    */       {
/* 57 */         return getChunkFromNBT(world, coord, nbt, forceRetain);
/*    */       }
/*    */     }
/* 60 */     catch (Exception exception) {}
/*    */ 
/*    */ 
/*    */     
/* 64 */     return null;
/*    */   }
/*    */ 
/*    */   
/*    */   public static ChunkMD getChunkFromNBT(ServerLevel world, ChunkPos coord, CompoundTag nbt, boolean forceRetain) {
/* 69 */     DataFixer fixer = Minecraft.getInstance().getFixerUpper();
/* 70 */     int dataVersion = ChunkStorage.getVersion(nbt);
/* 71 */     nbt = DataFixTypes.CHUNK.updateToCurrentVersion(fixer, nbt, dataVersion);
/* 72 */     CustomChunkReader.ProcessedChunk processedChunk = CustomChunkReader.read(world, world.getPoiManager(), coord, nbt);
/* 73 */     if (processedChunk != null && processedChunk.chunk() != null)
/*    */     {
/* 75 */       return new ChunkMD(processedChunk.chunk(), forceRetain, processedChunk.light());
/*    */     }
/* 77 */     return null;
/*    */   }
/*    */ 
/*    */   
/*    */   public static ChunkMD getChunkMdFromMemory(Level level, int chunkX, int chunkZ) {
/* 82 */     if (level != null && level == (Minecraft.getInstance()).player.getCommandSenderWorld()) {
/*    */       
/* 84 */       ChunkSource provider = level.getChunkSource();
/* 85 */       if (provider != null) {
/*    */         
/* 87 */         LevelChunk theChunk = level.getChunk(chunkX, chunkZ);
/*    */         
/* 89 */         if (theChunk != null && !(theChunk instanceof net.minecraft.world.level.chunk.EmptyLevelChunk) && theChunk.getLevel() == (Minecraft.getInstance()).player.getCommandSenderWorld())
/*    */         {
/* 91 */           return new ChunkMD(theChunk);
/*    */         }
/*    */       } 
/*    */     } 
/* 95 */     return null;
/*    */   }
/*    */ }


/* Location:              C:\Users\Administrator\Downloads\journeymap-neoforge-1.21-6.0.0-beta.18.jar!\journeymap\client\io\nbt\JMChunkLoader.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */