/*     */ package journeymap.client.io;
/*     */ 
/*     */ import com.google.common.base.Joiner;
/*     */ import com.google.common.base.Strings;
/*     */ import com.google.common.io.ByteSink;
/*     */ import com.google.common.io.ByteSource;
/*     */ import com.google.common.io.Files;
/*     */ import com.google.gson.GsonBuilder;
/*     */ import com.mojang.blaze3d.platform.NativeImage;
/*     */ import java.io.File;
/*     */ import java.io.FileFilter;
/*     */ import java.io.FileInputStream;
/*     */ import java.io.FileOutputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.InputStreamReader;
/*     */ import java.io.OutputStream;
/*     */ import java.net.URI;
/*     */ import java.net.URL;
/*     */ import java.net.URLDecoder;
/*     */ import java.nio.charset.StandardCharsets;
/*     */ import java.nio.file.Path;
/*     */ import java.util.Properties;
/*     */ import java.util.zip.ZipEntry;
/*     */ import java.util.zip.ZipFile;
/*     */ import java.util.zip.ZipInputStream;
/*     */ import journeymap.api.services.Services;
/*     */ import journeymap.client.Constants;
/*     */ import journeymap.client.JourneymapClient;
/*     */ import journeymap.client.data.WorldData;
/*     */ import journeymap.client.log.JMLogger;
/*     */ import journeymap.common.CommonConstants;
/*     */ import journeymap.common.Journeymap;
/*     */ import journeymap.common.helper.DimensionHelper;
/*     */ import journeymap.common.log.LogFormatter;
/*     */ import net.minecraft.Util;
/*     */ import net.minecraft.client.Minecraft;
/*     */ import net.minecraft.resources.ResourceKey;
/*     */ import net.minecraft.resources.ResourceLocation;
/*     */ import net.minecraft.world.level.Level;
/*     */ import net.minecraft.world.level.dimension.DimensionType;
/*     */ import net.minecraft.world.level.storage.LevelResource;
/*     */ import org.apache.commons.io.FileUtils;
/*     */ import org.apache.logging.log4j.Level;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class FileHandler
/*     */ {
/*     */   public static final String DEV_MINECRAFT_DIR = "run/";
/*     */   public static final String ASSETS_JOURNEYMAP = "/assets/journeymap";
/*     */   public static final String ASSETS_JOURNEYMAP_UI = "/assets/journeymap/ui";
/*     */   public static final String ASSETS_WEBMAP = "/assets/journeymap/web";
/*  58 */   public static final File MinecraftDirectory = getMinecraftDirectory();
/*  59 */   public static final File JourneyMapDirectory = new File(MinecraftDirectory, Constants.JOURNEYMAP_DIR);
/*  60 */   public static final File StandardConfigDirectory = new File(MinecraftDirectory, Constants.CONFIG_DIR);
/*     */   private static Boolean oldOverworldDir;
/*     */   private static Boolean oldNetherDir;
/*     */   private static Boolean oldEndDir;
/*     */   private static File lastWorldDir;
/*     */   
/*     */   public static File getMinecraftDirectory() {
/*  67 */     Minecraft minecraft = Minecraft.getInstance();
/*  68 */     if (minecraft != null)
/*     */     {
/*  70 */       return minecraft.gameDirectory;
/*     */     }
/*     */ 
/*     */     
/*  74 */     return new File("run/");
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static Path getDimPath(File worldDir, ResourceKey<Level> dimensionKey) {
/*  80 */     return (new File(worldDir, getDimNameForPath(worldDir, dimensionKey))).toPath();
/*     */   }
/*     */ 
/*     */   
/*     */   public static String getDimNameForPath(File worldDir, ResourceKey<Level> dimensionKey) {
/*  85 */     if (oldEndDir == null || oldNetherDir == null || oldOverworldDir == null || lastWorldDir != worldDir) {
/*     */       
/*  87 */       lastWorldDir = worldDir;
/*  88 */       oldEndDir = Boolean.valueOf((new File(worldDir, "DIM1")).exists());
/*  89 */       oldNetherDir = Boolean.valueOf((new File(worldDir, "DIM-1")).exists());
/*  90 */       oldOverworldDir = Boolean.valueOf((new File(worldDir, "DIM0")).exists());
/*     */     } 
/*     */ 
/*     */     
/*  94 */     if (Level.OVERWORLD.equals(dimensionKey) && oldOverworldDir.booleanValue())
/*     */     {
/*  96 */       return "DIM0";
/*     */     }
/*  98 */     if (Level.END.equals(dimensionKey) && oldEndDir.booleanValue())
/*     */     {
/* 100 */       return "DIM1";
/*     */     }
/* 102 */     if (Level.NETHER.equals(dimensionKey) && oldNetherDir.booleanValue())
/*     */     {
/* 104 */       return "DIM-1";
/*     */     }
/* 106 */     return getPathDimensionName(dimensionKey);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static String getPathDimensionName(ResourceKey<Level> dimensionKey) {
/* 112 */     if ("minecraft".equals(dimensionKey.location().getNamespace()))
/*     */     {
/* 114 */       return DimensionHelper.getDimName(dimensionKey);
/*     */     }
/*     */     
/* 117 */     return CommonConstants.getSafeString(dimensionKey.location().toString(), "~");
/*     */   }
/*     */ 
/*     */   
/*     */   public static File getMCWorldDir(Minecraft minecraft) {
/* 122 */     if (minecraft.isLocalServer()) {
/*     */       
/* 124 */       String lastMCFolderName = (minecraft.getSingleplayerServer()).storageSource.getLevelId();
/* 125 */       File lastMCWorldDir = new File(getMinecraftDirectory(), "saves" + File.separator + lastMCFolderName);
/* 126 */       return lastMCWorldDir;
/*     */     } 
/* 128 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   public static File getWorldSaveDir(Minecraft minecraft) {
/* 133 */     if (minecraft.hasSingleplayerServer()) {
/*     */       
/*     */       try {
/*     */         
/* 137 */         ResourceKey<Level> provider = minecraft.level.dimension();
/* 138 */         File savesDir = new File(getMinecraftDirectory(), "saves");
/* 139 */         File worldSaveDir = new File(savesDir, (minecraft.getSingleplayerServer()).storageSource.getLevelId());
/* 140 */         DimensionType.getStorageFolder(provider, worldSaveDir.toPath());
/* 141 */         File dir = DimensionType.getStorageFolder(provider, worldSaveDir.toPath()).toFile();
/* 142 */         dir.mkdirs();
/* 143 */         return dir;
/*     */       }
/* 145 */       catch (Throwable t) {
/*     */         
/* 147 */         Journeymap.getLogger().error("Error getting world save dir: %s", t);
/*     */       } 
/*     */     }
/* 150 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   public static File getMCWorldDir(Minecraft minecraft, ResourceKey<Level> dimension) {
/* 155 */     File worldDir = getMCWorldDir(minecraft);
/* 156 */     return DimensionType.getStorageFolder(dimension, worldDir.toPath()).toFile();
/*     */   }
/*     */ 
/*     */   
/*     */   public static File getJourneyMapDir() {
/* 161 */     return JourneyMapDirectory;
/*     */   }
/*     */ 
/*     */   
/*     */   public static File getJMWorldDir(Minecraft minecraft) {
/* 166 */     if (minecraft.level == null)
/*     */     {
/* 168 */       return null;
/*     */     }
/* 170 */     return getJMWorldDir(minecraft, JourneymapClient.getInstance().getCurrentWorldId());
/*     */   }
/*     */ 
/*     */   
/*     */   public static File getAddonDataPath(Minecraft minecraft) {
/* 175 */     return new File(getJMWorldDir(minecraft), "addon-data");
/*     */   }
/*     */ 
/*     */   
/*     */   public static synchronized File getJMWorldDir(Minecraft minecraft, String worldId) {
/* 180 */     if (minecraft.level == null)
/*     */     {
/* 182 */       return null;
/*     */     }
/*     */     
/* 185 */     File worldDirectory = null;
/*     */ 
/*     */ 
/*     */     
/*     */     try {
/* 190 */       worldDirectory = getJMWorldDirForWorldId(minecraft, worldId);
/* 191 */       if (worldDirectory == null)
/*     */       {
/* 193 */         worldDirectory = getJMWorldDirForWorldId(minecraft, null);
/*     */       }
/*     */       
/* 196 */       if (worldDirectory != null && !worldDirectory.exists())
/*     */       {
/* 198 */         worldDirectory.mkdirs();
/*     */       }
/*     */     }
/* 201 */     catch (Exception e) {
/*     */       
/* 203 */       Journeymap.getLogger().log(Level.ERROR, LogFormatter.toString(e));
/* 204 */       throw new RuntimeException(e);
/*     */     } 
/*     */     
/* 207 */     return worldDirectory;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static File getJMWorldDirForWorldId(Minecraft minecraft, String worldId) {
/* 213 */     if (minecraft == null || minecraft.level == null)
/*     */     {
/* 215 */       return null;
/*     */     }
/*     */     
/* 218 */     File testWorldDirectory = null;
/*     */     
/*     */     try {
/* 221 */       String suffix = getWorldDirectoryName(minecraft, worldId);
/* 222 */       if (!minecraft.hasSingleplayerServer())
/*     */       {
/* 224 */         testWorldDirectory = new File(MinecraftDirectory, Constants.MP_DATA_DIR + Constants.MP_DATA_DIR);
/*     */       }
/*     */       else
/*     */       {
/* 228 */         File legacyDirectory = new File(MinecraftDirectory, Constants.SP_DATA_DIR + Constants.SP_DATA_DIR);
/* 229 */         testWorldDirectory = new File(MinecraftDirectory, Constants.SP_DATA_DIR + Constants.SP_DATA_DIR);
/* 230 */         if (!testWorldDirectory.exists() && legacyDirectory.exists())
/*     */         {
/* 232 */           testWorldDirectory = legacyDirectory;
/*     */         }
/*     */       }
/*     */     
/* 236 */     } catch (Exception e) {
/*     */       
/* 238 */       Journeymap.getLogger().log(Level.ERROR, LogFormatter.toString(e));
/*     */     } 
/*     */     
/* 241 */     return testWorldDirectory;
/*     */   }
/*     */ 
/*     */   
/*     */   public static String getWorldDirectoryName(Minecraft minecraft) {
/* 246 */     return getWorldDirectoryName(minecraft, JourneymapClient.getInstance().getCurrentWorldId());
/*     */   }
/*     */ 
/*     */   
/*     */   public static String getWorldDirectoryName(Minecraft minecraft, String worldId) {
/* 251 */     if (minecraft == null || minecraft.level == null)
/*     */     {
/* 253 */       return null;
/*     */     }
/*     */     
/* 256 */     String worldName = CommonConstants.getSafeString(WorldData.getWorldName(minecraft), "~");
/*     */     
/* 258 */     if (!Strings.isNullOrEmpty(worldId))
/*     */     {
/* 260 */       worldId = worldId.replaceAll("\\W+", "~");
/*     */     }
/* 262 */     String suffix = !Strings.isNullOrEmpty(worldId) ? ("_" + worldId) : "";
/* 263 */     return worldName + worldName;
/*     */   }
/*     */ 
/*     */   
/*     */   private static String getWorldSaveFolderName() {
/* 268 */     File file = Minecraft.getInstance().getSingleplayerServer().getWorldPath(LevelResource.ROOT).toFile();
/* 269 */     String worldName = file.getParent().substring(file.getParent().lastIndexOf(File.separator) + 1);
/* 270 */     String worldId = JourneymapClient.getInstance().getCurrentWorldId();
/* 271 */     if (!Strings.isNullOrEmpty(worldId))
/*     */     {
/* 273 */       worldId = worldId.replaceAll("\\W+", "~");
/*     */     }
/* 275 */     String suffix = !Strings.isNullOrEmpty(worldId) ? ("_" + worldId) : "";
/* 276 */     return worldName + worldName;
/*     */   }
/*     */ 
/*     */   
/*     */   public static File getWaypointDir() {
/* 281 */     return getWaypointDir(getJMWorldDir(Minecraft.getInstance()));
/*     */   }
/*     */ 
/*     */   
/*     */   public static File getWaypointDir(File jmWorldDir) {
/* 286 */     File waypointDir = new File(jmWorldDir, "waypoints");
/* 287 */     if (!waypointDir.isDirectory())
/*     */     {
/* 289 */       waypointDir.delete();
/*     */     }
/* 291 */     if (!waypointDir.exists())
/*     */     {
/* 293 */       waypointDir.mkdirs();
/*     */     }
/* 295 */     return waypointDir;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static Properties getLangFile(String fileName) {
/*     */     try {
/* 302 */       InputStream is = JourneymapClient.class.getResourceAsStream("/assets/journeymap/lang/" + fileName);
/* 303 */       if (is == null) {
/*     */ 
/*     */         
/* 306 */         File file = new File("../src/main/resources/assets/journeymap/lang/" + fileName);
/* 307 */         if (file.exists()) {
/*     */           
/* 309 */           is = new FileInputStream(file);
/*     */         }
/*     */         else {
/*     */           
/* 313 */           Journeymap.getLogger().warn("Language file not found: " + fileName);
/* 314 */           return null;
/*     */         } 
/*     */       } 
/* 317 */       Properties properties = new Properties();
/* 318 */       properties.load(is);
/* 319 */       is.close();
/* 320 */       return properties;
/*     */     }
/* 322 */     catch (IOException e) {
/*     */       
/* 324 */       String error = "Could not get language file " + fileName + ": " + e.getMessage();
/* 325 */       Journeymap.getLogger().error(error);
/* 326 */       return null;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static <M> M getMessageModel(Class<M> model, String filePrefix) {
/*     */     try {
/* 334 */       String lang = Minecraft.getInstance().getLanguageManager().getSelected();
/* 335 */       InputStream is = getMessageModelInputStream(filePrefix, lang);
/* 336 */       if (is == null && !lang.equals("en_US"))
/*     */       {
/* 338 */         is = getMessageModelInputStream(filePrefix, "en_US");
/*     */       }
/* 340 */       if (is == null) {
/*     */         
/* 342 */         Journeymap.getLogger().warn("Message file not found: " + filePrefix);
/* 343 */         return null;
/*     */       } 
/* 345 */       return (M)(new GsonBuilder()).create().fromJson(new InputStreamReader(is), model);
/*     */     }
/* 347 */     catch (Throwable e) {
/*     */       
/* 349 */       String error = "Could not get Message model " + filePrefix + ": " + e.getMessage();
/* 350 */       Journeymap.getLogger().error(error);
/* 351 */       return null;
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public static InputStream getMessageModelInputStream(String filePrefix, String lang) {
/* 357 */     String file = String.format("/assets/journeymap/lang/message/%s-%s.json", new Object[] { filePrefix, lang });
/* 358 */     return JourneymapClient.class.getResourceAsStream(file);
/*     */   }
/*     */ 
/*     */   
/*     */   public static File getWorldConfigDir(boolean fallbackToStandardConfigDir) {
/* 363 */     File worldDir = getJMWorldDirForWorldId(Minecraft.getInstance(), null);
/* 364 */     if (worldDir != null && worldDir.exists()) {
/*     */       
/* 366 */       File worldConfigDir = new File(worldDir, "config");
/* 367 */       if (worldConfigDir.exists())
/*     */       {
/* 369 */         return worldConfigDir;
/*     */       }
/*     */     } 
/*     */     
/* 373 */     return fallbackToStandardConfigDir ? StandardConfigDirectory : null;
/*     */   }
/*     */ 
/*     */   
/*     */   public static boolean isInJar() {
/* 378 */     return isInJar(JourneymapClient.class.getProtectionDomain().getCodeSource().getLocation());
/*     */   }
/*     */ 
/*     */   
/*     */   public static boolean isInJar(URL location) {
/* 383 */     if ("jar".equals(location.getProtocol()))
/*     */     {
/* 385 */       return true;
/*     */     }
/*     */     
/* 388 */     if ("file".equals(location.getProtocol())) {
/*     */       
/* 390 */       File file = new File(location.getFile());
/* 391 */       return (file.getName().endsWith(".jar") || file.getName().endsWith(".zip"));
/*     */     } 
/* 393 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static File copyColorPaletteHtmlFile(File toDir, String fileName) {
/*     */     try {
/* 400 */       final File outFile = new File(toDir, fileName);
/* 401 */       String htmlPath = "/assets/journeymap/ui/" + fileName;
/* 402 */       InputStream inputStream = JourneymapClient.class.getResource(htmlPath).openStream();
/*     */       
/* 404 */       ByteSink out = new ByteSink()
/*     */         {
/*     */           
/*     */           public OutputStream openStream() throws IOException
/*     */           {
/* 409 */             return new FileOutputStream(outFile);
/*     */           }
/*     */         };
/* 412 */       out.writeFrom(inputStream);
/*     */       
/* 414 */       return outFile;
/*     */     }
/* 416 */     catch (Throwable t) {
/*     */       
/* 418 */       Journeymap.getLogger().warn("Couldn't copy color palette html: " + String.valueOf(t));
/* 419 */       return null;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static void open(File file) {
/* 426 */     String path = file.getAbsolutePath();
/*     */     
/* 428 */     if (Util.getPlatform() == Util.OS.OSX) {
/*     */ 
/*     */       
/*     */       try {
/* 432 */         Runtime.getRuntime().exec(new String[] { "/usr/bin/open", path });
/*     */         
/*     */         return;
/* 435 */       } catch (IOException e) {
/*     */         
/* 437 */         Journeymap.getLogger().error("Could not open path with /usr/bin/open: " + path + " : " + LogFormatter.toString(e));
/*     */       
/*     */       }
/*     */     
/*     */     }
/* 442 */     else if (Util.getPlatform() == Util.OS.WINDOWS) {
/*     */ 
/*     */       
/* 445 */       String cmd = String.format("cmd.exe /C start \"Open file\" \"%s\"", new Object[] { path });
/*     */ 
/*     */       
/*     */       try {
/* 449 */         Runtime.getRuntime().exec(cmd);
/*     */         
/*     */         return;
/* 452 */       } catch (IOException e) {
/*     */         
/* 454 */         Journeymap.getLogger().error("Could not open path with cmd.exe: " + path + " : " + LogFormatter.toString(e));
/*     */       } 
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/*     */     try {
/* 461 */       Class<?> desktopClass = Class.forName("java.awt.Desktop");
/* 462 */       Object method = desktopClass.getMethod("getDesktop", new Class[0]).invoke(null, new Object[0]);
/* 463 */       desktopClass.getMethod("browse", new Class[] { URI.class }).invoke(method, new Object[] { file.toURI() });
/*     */     }
/* 465 */     catch (Throwable e) {
/*     */       
/* 467 */       Journeymap.getLogger().error("Could not open path with Desktop: " + path + " : " + LogFormatter.toString(e));
/* 468 */       String url = "file://" + path;
/* 469 */       Util.getPlatform().openUri(url);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public static boolean copyResources(File targetDirectory, ResourceLocation location, String setName, boolean overwrite) {
/* 475 */     String fromPath = null;
/* 476 */     File toDir = null;
/*     */     
/*     */     try {
/* 479 */       String domain = location.getNamespace();
/* 480 */       URL fileLocation = null;
/*     */       
/* 482 */       if (domain.equals("minecraft")) {
/*     */         
/* 484 */         fileLocation = Minecraft.class.getProtectionDomain().getCodeSource().getLocation();
/*     */       }
/*     */       else {
/*     */         
/* 488 */         fileLocation = Services.COMMON_SERVICE.getModFileLocation(domain);
/*     */       } 
/*     */       
/* 491 */       if (fileLocation != null) {
/*     */         String assetsPath;
/*     */         
/* 494 */         if (location.getPath().startsWith("assets/")) {
/*     */           
/* 496 */           assetsPath = location.getPath();
/*     */         
/*     */         }
/*     */         else {
/*     */           
/* 501 */           if ("journeymap_webmap".equals(domain))
/*     */           {
/* 503 */             domain = "journeymap";
/*     */           }
/* 505 */           assetsPath = String.format("assets/%s/%s", new Object[] { domain, location.getPath() });
/*     */         } 
/* 507 */         return copyResources(targetDirectory, fileLocation, assetsPath, setName, overwrite);
/*     */       }
/*     */     
/* 510 */     } catch (Throwable t) {
/*     */       
/* 512 */       Journeymap.getLogger().error(String.format("Couldn't get resource set from %s to %s: %s", new Object[] { fromPath, toDir, t }));
/*     */     } 
/* 514 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public static boolean copyResources(File targetDirectory, URL resourceDir, String assetsPath, String setName, boolean overwrite) {
/* 519 */     String fromPath = null;
/* 520 */     File toDir = null;
/*     */     
/*     */     try {
/* 523 */       toDir = new File(targetDirectory, setName);
/* 524 */       boolean inJar = isInJar(resourceDir);
/* 525 */       if (inJar) {
/*     */         
/* 527 */         if ("jar".equals(resourceDir.getProtocol()) || resourceDir.toString().endsWith(".jar")) {
/*     */ 
/*     */           
/* 530 */           fromPath = URLDecoder.decode(resourceDir.getPath(), StandardCharsets.UTF_8);
/* 531 */           if (fromPath.contains("file:"))
/*     */           {
/* 533 */             fromPath = fromPath.split("file:")[1];
/*     */           }
/* 535 */           if (fromPath.contains("!/"))
/*     */           {
/* 537 */             fromPath = fromPath.split("!/")[0];
/*     */           }
/* 539 */           if (fromPath.startsWith("/"))
/*     */           {
/* 541 */             fromPath = fromPath.substring(1);
/*     */           
/*     */           }
/*     */         }
/*     */         else {
/*     */           
/* 547 */           fromPath = (new File(resourceDir.getPath())).getPath();
/*     */         } 
/* 549 */         return copyFromZip(fromPath, assetsPath, toDir, overwrite);
/*     */       } 
/*     */ 
/*     */       
/* 553 */       File fromDir = new File(resourceDir.getFile(), assetsPath);
/* 554 */       if (fromDir.exists()) {
/*     */         
/* 556 */         fromPath = fromDir.getPath();
/* 557 */         return copyFromDirectory(fromDir, toDir, overwrite);
/*     */       } 
/*     */ 
/*     */       
/* 561 */       Journeymap.getLogger().error("Couldn't locate icons for {}: {}", setName, fromDir);
/*     */ 
/*     */     
/*     */     }
/* 565 */     catch (Throwable t) {
/*     */       
/* 567 */       Journeymap.getLogger().error("Couldn't unzip resource set from {} to {}:", fromPath, toDir, t);
/*     */     } 
/* 569 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static boolean copyFromZip(String zipFilePath, String zipEntryName, File destDir, boolean overWrite) throws Throwable {
/* 580 */     String fromPath = URLDecoder.decode(zipFilePath, StandardCharsets.UTF_8).replace("file://", "");
/* 581 */     if (zipEntryName.startsWith("/"))
/*     */     {
/* 583 */       zipEntryName = zipEntryName.substring(1);
/*     */     }
/*     */     
/* 586 */     if (Minecraft.ON_OSX && !fromPath.startsWith("//"))
/*     */     {
/* 588 */       if (fromPath.startsWith("/")) {
/*     */         
/* 590 */         fromPath = "/" + fromPath;
/*     */       }
/*     */       else {
/*     */         
/* 594 */         fromPath = "//" + fromPath;
/*     */       } 
/*     */     }
/*     */     
/* 598 */     ZipFile zipFile = new ZipFile(fromPath);
/* 599 */     ZipInputStream zipIn = new ZipInputStream(new FileInputStream(fromPath));
/* 600 */     ZipEntry entry = zipIn.getNextEntry();
/*     */     
/* 602 */     boolean success = false;
/*     */ 
/*     */     
/*     */     try {
/* 606 */       while (entry != null)
/*     */       {
/* 608 */         if (entry.getName().startsWith(zipEntryName)) {
/*     */           
/* 610 */           File toFile = new File(destDir, entry.getName().split(zipEntryName)[1]);
/* 611 */           if (overWrite || !toFile.exists())
/*     */           {
/* 613 */             if (!entry.isDirectory()) {
/*     */               
/* 615 */               Files.createParentDirs(toFile);
/* 616 */               (new ZipEntryByteSource(zipFile, entry)).copyTo(Files.asByteSink(toFile, new com.google.common.io.FileWriteMode[0]));
/* 617 */               success = true;
/*     */             } 
/*     */           }
/*     */         } 
/*     */         
/* 622 */         zipIn.closeEntry();
/* 623 */         entry = zipIn.getNextEntry();
/*     */       }
/*     */     
/*     */     } finally {
/*     */       
/* 628 */       zipIn.close();
/*     */     } 
/*     */     
/* 631 */     return success;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static boolean copyFromDirectory(File fromDir, File toDir, boolean overWrite) throws IOException {
/* 639 */     if (!toDir.exists())
/*     */     {
/* 641 */       if (!toDir.mkdirs())
/*     */       {
/* 643 */         throw new IOException("Couldn't create directory: " + String.valueOf(toDir));
/*     */       }
/*     */     }
/* 646 */     File[] files = fromDir.listFiles();
/*     */     
/* 648 */     if (files == null)
/*     */     {
/* 650 */       throw new IOException(String.valueOf(fromDir) + " nas no files");
/*     */     }
/*     */     
/* 653 */     boolean success = true;
/* 654 */     for (File from : files) {
/*     */       
/* 656 */       File to = new File(toDir, from.getName());
/* 657 */       if (from.isDirectory()) {
/*     */         
/* 659 */         if (!copyFromDirectory(from, to, overWrite))
/*     */         {
/* 661 */           success = false;
/*     */         }
/*     */       }
/* 664 */       else if (overWrite || !to.exists()) {
/*     */         
/* 666 */         Files.copy(from, to);
/* 667 */         if (!to.exists())
/*     */         {
/* 669 */           success = false;
/*     */         }
/*     */       } 
/*     */     } 
/* 673 */     return success;
/*     */   }
/*     */ 
/*     */   
/*     */   public static boolean delete(File file) {
/* 678 */     if (!file.exists())
/*     */     {
/* 680 */       return true;
/*     */     }
/*     */     
/* 683 */     if (file.isFile())
/*     */     {
/* 685 */       return file.delete();
/*     */     }
/*     */ 
/*     */     
/*     */     try {
/* 690 */       FileUtils.forceDelete(file);
/*     */     }
/* 692 */     catch (IOException e) {
/*     */       
/* 694 */       Journeymap.getLogger().error(String.format("Could not delete file:", new Object[] { LogFormatter.toString(e) }));
/*     */     } 
/* 696 */     return file.exists();
/*     */   }
/*     */ 
/*     */   
/*     */   public static NativeImage getIconFromFile(File parentdir, String setName, String iconPath) {
/* 701 */     NativeImage img = null;
/* 702 */     if (iconPath == null)
/*     */     {
/*     */       
/* 705 */       iconPath = "null";
/*     */     }
/*     */     
/* 708 */     File iconFile = null;
/*     */ 
/*     */     
/*     */     try {
/* 712 */       String filePath = Joiner.on(File.separatorChar).join(setName, iconPath.replace('/', File.separatorChar), new Object[0]);
/* 713 */       iconFile = new File(parentdir, filePath);
/*     */ 
/*     */       
/* 716 */       if (iconFile.exists())
/*     */       {
/* 718 */         InputStream is = new FileInputStream(iconFile.getPath());
/* 719 */         img = NativeImage.read(is);
/*     */       
/*     */       }
/*     */     
/*     */     }
/* 724 */     catch (Exception e) {
/*     */       
/* 726 */       JMLogger.throwLogOnce("Couldn't load iconset file: " + String.valueOf(iconFile), e);
/*     */     } 
/*     */     
/* 729 */     return img;
/*     */   }
/*     */ 
/*     */   
/*     */   private static File getMobIconsDir() {
/* 734 */     File dir = new File(getMinecraftDirectory(), Constants.ENTITY_ICON_DIR);
/* 735 */     if (!dir.exists())
/*     */     {
/* 737 */       dir.mkdirs();
/*     */     }
/* 739 */     return dir;
/*     */   }
/*     */ 
/*     */   
/*     */   public static File[] getMobIconsDomainsDirectories() {
/* 744 */     File parentDir = getMobIconsDir();
/* 745 */     File[] domainsDirs = parentDir.listFiles(new FileFilter()
/*     */         {
/*     */           
/*     */           public boolean accept(File pathname)
/*     */           {
/* 750 */             return pathname.isDirectory();
/*     */           }
/*     */         });
/* 753 */     return domainsDirs;
/*     */   }
/*     */ 
/*     */   
/*     */   public static File getMobIconsDomainsDirectory(ResourceLocation mobLocation) {
/* 758 */     File mobsDir = new File(getMinecraftDirectory(), Constants.ENTITY_ICON_DIR);
/* 759 */     if (!mobsDir.exists())
/*     */     {
/* 761 */       mobsDir.mkdirs();
/*     */     }
/*     */     
/* 764 */     File dir = new File(mobsDir, mobLocation.getNamespace());
/* 765 */     if (!dir.exists())
/*     */     {
/* 767 */       dir.mkdirs();
/*     */     }
/*     */     
/* 770 */     return dir;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static NativeImage getImageFromFile(File file) {
/*     */     try {
/* 777 */       InputStream is = new FileInputStream(file.getPath());
/* 778 */       return getImageFromStream(is);
/*     */     }
/* 780 */     catch (IOException e) {
/*     */       
/* 782 */       String error = "Could not get image from file: " + String.valueOf(file) + ": " + e.getMessage();
/* 783 */       Journeymap.getLogger().error(error);
/* 784 */       return null;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static NativeImage getImageFromStream(InputStream stream) {
/*     */     try {
/* 792 */       return NativeImage.read(stream);
/*     */     }
/* 794 */     catch (IOException e) {
/*     */       
/* 796 */       return null;
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   private static class ZipEntryByteSource
/*     */     extends ByteSource
/*     */   {
/*     */     final ZipFile file;
/*     */     final ZipEntry entry;
/*     */     
/*     */     ZipEntryByteSource(ZipFile file, ZipEntry entry) {
/* 808 */       this.file = file;
/* 809 */       this.entry = entry;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public InputStream openStream() throws IOException {
/* 815 */       return this.file.getInputStream(this.entry);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public String toString() {
/* 821 */       return String.format("ZipEntryByteSource( %s / %s )", new Object[] { this.file, this.entry });
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\Administrator\Downloads\journeymap-neoforge-1.21-6.0.0-beta.18.jar!\journeymap\client\io\FileHandler.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */