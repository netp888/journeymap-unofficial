/*     */ package journeymap.client.io;
/*     */ 
/*     */ import ar.com.hjg.pngj.IImageLine;
/*     */ import ar.com.hjg.pngj.ImageInfo;
/*     */ import ar.com.hjg.pngj.ImageLineInt;
/*     */ import ar.com.hjg.pngj.PngReader;
/*     */ import ar.com.hjg.pngj.PngWriter;
/*     */ import ar.com.hjg.pngj.chunks.ChunkLoadBehaviour;
/*     */ import java.io.File;
/*     */ import java.util.Arrays;
/*     */ import journeymap.client.JourneymapClient;
/*     */ import journeymap.common.Journeymap;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class PngjHelper
/*     */ {
/*     */   public static void mergeFiles(File[] tiles, File destFile, int tileColumns, int tileSize) {
/*  35 */     int ntiles = tiles.length;
/*  36 */     int tileRows = (ntiles + tileColumns - 1) / tileColumns;
/*  37 */     PngReader[] readers = new PngReader[tileColumns];
/*  38 */     ImageInfo destImgInfo = new ImageInfo(tileSize * tileColumns, tileSize * tileRows, 8, true);
/*  39 */     PngWriter pngw = new PngWriter(destFile, destImgInfo, true);
/*     */     
/*  41 */     pngw.getMetadata().setText("Author", "JourneyMap" + String.valueOf(Journeymap.JM_VERSION));
/*  42 */     pngw.getMetadata().setText("Comment", Journeymap.WEBSITE_URL);
/*     */     
/*  44 */     ImageLineInt destLine = new ImageLineInt(destImgInfo);
/*  45 */     int lineLen = tileSize * 4;
/*  46 */     int gridColor = 135;
/*  47 */     boolean showGrid = (JourneymapClient.getInstance().getFullMapProperties()).showGrid.get().booleanValue();
/*     */     
/*  49 */     int destRow = 0;
/*     */     
/*  51 */     for (int ty = 0; ty < tileRows; ty++) {
/*     */       
/*  53 */       int nTilesXcur = (ty < tileRows - 1) ? tileColumns : (ntiles - (tileRows - 1) * tileColumns);
/*  54 */       Arrays.fill(destLine.getScanline(), 0);
/*     */       
/*  56 */       for (int i = 0; i < nTilesXcur; i++) {
/*     */         
/*  58 */         readers[i] = new PngReader(tiles[i + ty * tileColumns]);
/*  59 */         readers[i].setChunkLoadBehaviour(ChunkLoadBehaviour.LOAD_CHUNK_NEVER);
/*     */       } 
/*     */       
/*     */       int srcRow;
/*     */       
/*  64 */       label50: for (srcRow = 0; srcRow < tileSize; srcRow++, destRow++) {
/*     */         
/*  66 */         for (int j = 0; j < nTilesXcur; j++) {
/*     */           
/*  68 */           ImageLineInt srcLine = (ImageLineInt)readers[j].readRow(srcRow);
/*  69 */           int[] src = srcLine.getScanline();
/*     */ 
/*     */           
/*  72 */           if (showGrid) {
/*     */             
/*  74 */             int skip = (srcRow % 16 == 0) ? 4 : 64; int k;
/*  75 */             for (k = 0; k <= src.length - skip; k += skip) {
/*     */               
/*  77 */               src[k] = (src[k] + src[k] + 135) / 3;
/*  78 */               src[k + 1] = (src[k + 1] + src[k + 1] + 135) / 3;
/*  79 */               src[k + 2] = (src[k + 2] + src[k + 2] + 135) / 3;
/*  80 */               src[k + 3] = 255;
/*     */             } 
/*     */           } 
/*     */           
/*  84 */           int[] dest = destLine.getScanline();
/*  85 */           int destPos = lineLen * j;
/*     */           
/*     */           try {
/*  88 */             System.arraycopy(src, 0, dest, destPos, lineLen);
/*     */           }
/*  90 */           catch (ArrayIndexOutOfBoundsException e) {
/*     */             
/*  92 */             Journeymap.getLogger().error("Bad image data. Src len=" + src.length + ", dest len=" + dest.length + ", destPos=" + destPos);
/*     */             break label50;
/*     */           } 
/*     */         } 
/*  96 */         pngw.writeRow((IImageLine)destLine, destRow);
/*     */       } 
/*     */       
/*  99 */       for (int tx = 0; tx < nTilesXcur; tx++)
/*     */       {
/* 101 */         readers[tx].end();
/*     */       }
/*     */     } 
/*     */     
/* 105 */     pngw.end();
/*     */   }
/*     */ }


/* Location:              C:\Users\Administrator\Downloads\journeymap-neoforge-1.21-6.0.0-beta.18.jar!\journeymap\client\io\PngjHelper.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */