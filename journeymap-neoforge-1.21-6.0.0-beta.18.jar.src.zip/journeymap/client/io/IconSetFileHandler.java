/*     */ package journeymap.client.io;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.HashSet;
/*     */ import java.util.List;
/*     */ import java.util.Set;
/*     */ import journeymap.client.Constants;
/*     */ import journeymap.common.Journeymap;
/*     */ import journeymap.common.log.LogFormatter;
/*     */ import journeymap.common.properties.config.StringField;
/*     */ import net.minecraft.client.Minecraft;
/*     */ import net.minecraft.resources.ResourceLocation;
/*     */ import net.minecraft.server.packs.PackResources;
/*     */ import net.minecraft.server.packs.PackType;
/*     */ import net.minecraft.server.packs.repository.Pack;
/*     */ import net.minecraft.server.packs.repository.PackRepository;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class IconSetFileHandler
/*     */ {
/*     */   public static final String MOB_ICON_SET_DEFAULT = "Default";
/*  33 */   private static final Set<String> modUpdatedSetNames = new HashSet<>();
/*  34 */   private static final Set<ResourceLocation> entityIconLocations = new HashSet<>();
/*     */ 
/*     */ 
/*     */   
/*     */   public static void initialize() {
/*  39 */     modUpdatedSetNames.add("Default");
/*     */   }
/*     */ 
/*     */   
/*     */   public static boolean registerEntityIconDirectory(ResourceLocation resourceLocation) {
/*  44 */     boolean valid = addEntityIcons(resourceLocation, "Default", false);
/*  45 */     if (valid)
/*     */     {
/*  47 */       entityIconLocations.add(resourceLocation);
/*     */     }
/*  49 */     return valid;
/*     */   }
/*     */ 
/*     */   
/*     */   public static void ensureEntityIconSet(String setName) {
/*  54 */     ensureEntityIconSet(setName, false);
/*     */   }
/*     */ 
/*     */   
/*     */   public static void ensureEntityIconSet(String setName, boolean overwrite) {
/*  59 */     if (!modUpdatedSetNames.contains(setName)) {
/*     */ 
/*     */       
/*  62 */       for (ResourceLocation resourceLocation : entityIconLocations)
/*     */       {
/*  64 */         addEntityIcons(resourceLocation, setName, overwrite);
/*     */       }
/*  66 */       modUpdatedSetNames.add(setName);
/*     */     } 
/*     */ 
/*     */     
/*     */     try {
/*  71 */       PackRepository rpr = Minecraft.getInstance().getResourcePackRepository();
/*  72 */       for (Pack entry : rpr.getAvailablePacks()) {
/*     */         
/*  74 */         PackResources pack = entry.open();
/*  75 */         for (String domain : pack.getNamespaces(PackType.CLIENT_RESOURCES))
/*     */         {
/*  77 */           ResourceLocation domainEntityIcons = ResourceLocation.fromNamespaceAndPath(domain, "textures/entity_icons");
/*  78 */           if (pack.getResource(PackType.CLIENT_RESOURCES, domainEntityIcons) != null)
/*     */           {
/*  80 */             addEntityIcons(domainEntityIcons, setName, true);
/*     */           }
/*     */         }
/*     */       
/*     */       } 
/*  85 */     } catch (Throwable t) {
/*     */       
/*  87 */       Journeymap.getLogger().error(String.format("Can't get entity icon from resource packs: %s", new Object[] { LogFormatter.toString(t) }));
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   private static boolean addEntityIcons(ResourceLocation resourceLocation, String setName, boolean overwrite) {
/*  93 */     boolean result = false;
/*     */     
/*     */     try {
/*  96 */       result = FileHandler.copyResources(getEntityIconDir(), resourceLocation, setName, overwrite);
/*     */     }
/*  98 */     catch (Throwable t) {
/*     */       
/* 100 */       Journeymap.getLogger().error("Error adding entity icons: " + t.getMessage(), t);
/*     */     } 
/* 102 */     Journeymap.getLogger().info(String.format("Added entity icons from %s. Success: %s", new Object[] { resourceLocation, Boolean.valueOf(result) }));
/* 103 */     return result;
/*     */   }
/*     */ 
/*     */   
/*     */   public static File getEntityIconDir() {
/* 108 */     File dir = new File(FileHandler.getMinecraftDirectory(), Constants.ENTITY_ICON_DIR);
/* 109 */     if (!dir.exists())
/*     */     {
/* 111 */       dir.mkdirs();
/*     */     }
/* 113 */     return dir;
/*     */   }
/*     */ 
/*     */   
/*     */   public static ArrayList<String> getEntityIconSetNames() {
/* 118 */     return getIconSetNames(getEntityIconDir(), Collections.singletonList("Default"));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ArrayList<String> getIconSetNames(File parentDir, List<String> defaultIconSets) {
/*     */     try {
/* 126 */       for (String iconSetName : defaultIconSets)
/*     */       {
/* 128 */         File iconSetDir = new File(parentDir, iconSetName);
/* 129 */         if (iconSetDir.exists() && !iconSetDir.isDirectory())
/*     */         {
/* 131 */           iconSetDir.delete();
/*     */         }
/* 133 */         iconSetDir.mkdirs();
/*     */       }
/*     */     
/* 136 */     } catch (Throwable t) {
/*     */       
/* 138 */       Journeymap.getLogger().error("Could not prepare iconset directories for " + String.valueOf(parentDir) + ": " + LogFormatter.toString(t));
/*     */     } 
/*     */ 
/*     */     
/* 142 */     ArrayList<String> names = new ArrayList<>();
/* 143 */     for (File iconSetDir : parentDir.listFiles()) {
/*     */       
/* 145 */       if (iconSetDir.isDirectory())
/*     */       {
/* 147 */         names.add(iconSetDir.getName());
/*     */       }
/*     */     } 
/* 150 */     Collections.sort(names);
/*     */     
/* 152 */     return names;
/*     */   }
/*     */ 
/*     */   
/*     */   public static class IconSetValuesProvider
/*     */     implements StringField.ValuesProvider
/*     */   {
/*     */     public List<String> getStrings() {
/* 160 */       if (Minecraft.getInstance() != null)
/*     */       {
/* 162 */         return IconSetFileHandler.getEntityIconSetNames();
/*     */       }
/*     */ 
/*     */       
/* 166 */       return Collections.singletonList("Default");
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public String getDefaultString() {
/* 173 */       return "Default";
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\Administrator\Downloads\journeymap-neoforge-1.21-6.0.0-beta.18.jar!\journeymap\client\io\IconSetFileHandler.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */