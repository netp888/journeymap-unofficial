/*     */ package journeymap.client.io;
/*     */ 
/*     */ import com.mojang.blaze3d.platform.NativeImage;
/*     */ import java.io.File;
/*     */ import java.io.FileInputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.nio.file.Files;
/*     */ import java.nio.file.Path;
/*     */ import java.nio.file.Paths;
/*     */ import java.util.HashSet;
/*     */ import java.util.Set;
/*     */ import java.util.stream.Collectors;
/*     */ import java.util.stream.Stream;
/*     */ import journeymap.client.Constants;
/*     */ import journeymap.client.cartography.color.RGB;
/*     */ import journeymap.client.model.MapType;
/*     */ import journeymap.client.model.RegionCoord;
/*     */ import journeymap.client.model.RegionImageCache;
/*     */ import journeymap.client.texture.ImageUtil;
/*     */ import journeymap.common.Journeymap;
/*     */ import journeymap.common.log.LogFormatter;
/*     */ import net.minecraft.client.Minecraft;
/*     */ import net.minecraft.world.level.ChunkPos;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class RegionImageHandler
/*     */ {
/*     */   public static Set<String> getImageFilesForMapType(Minecraft minecraft, MapType mapType) {
/*  49 */     File dir = FileHandler.getJMWorldDir(minecraft);
/*  50 */     String name = mapType.isUnderground() ? mapType.vSlice.toString() : mapType.name.name(); 
/*  51 */     try { Stream<Path> walk = Files.walk(Paths.get(dir.toURI()), new java.nio.file.FileVisitOption[0]);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*  61 */       try { Set<String> set = (Set)walk.filter(f -> { String path = f.toString(); return (path.endsWith("png") && path.contains(name) && path.contains(FileHandler.getPathDimensionName(mapType.dimension))); }).map(p -> p.getFileName().toString()).collect(Collectors.toSet());
/*  62 */         if (walk != null) walk.close();  return set; } catch (Throwable throwable) { if (walk != null)
/*  63 */           try { walk.close(); } catch (Throwable throwable1) { throwable.addSuppressed(throwable1); }   throw throwable; }  } catch (Throwable t)
/*     */     
/*  65 */     { Journeymap.getLogger().error("Unable to get images:", t);
/*  66 */       return new HashSet<>(); }
/*     */   
/*     */   }
/*     */ 
/*     */   
/*     */   public static File getImageDir(RegionCoord rCoord, MapType mapType) {
/*  72 */     File dimDir = rCoord.dimDir.toFile();
/*  73 */     File subDir = null;
/*  74 */     if (mapType.isUnderground()) {
/*     */       
/*  76 */       subDir = new File(dimDir, Integer.toString(mapType.vSlice.intValue()));
/*     */     }
/*     */     else {
/*     */       
/*  80 */       subDir = new File(dimDir, mapType.name());
/*     */     } 
/*  82 */     if (!subDir.exists())
/*     */     {
/*  84 */       subDir.mkdirs();
/*     */     }
/*  86 */     return subDir;
/*     */   }
/*     */ 
/*     */   
/*     */   public static File getRegionImageFile(RegionCoord rCoord, MapType mapType) {
/*  91 */     return new File(getImageDir(rCoord, mapType), rCoord.getFileName());
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static NativeImage readRegionImage(File regionFile) {
/*  97 */     if (regionFile.canRead()) {
/*     */       
/*     */       try {
/*     */         
/* 101 */         NativeImage image = getImage(regionFile);
/* 102 */         return image;
/*     */       }
/* 104 */       catch (Exception e) {
/*     */         
/* 106 */         String error = "Region file produced error: " + String.valueOf(regionFile) + ": " + LogFormatter.toPartialString(e);
/* 107 */         Journeymap.getLogger().error(error);
/*     */       } 
/*     */     }
/* 110 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static NativeImage getImage(File file) {
/*     */     try {
/* 117 */       InputStream is = new FileInputStream(file.getPath());
/* 118 */       return NativeImage.read(is);
/*     */     }
/* 120 */     catch (IOException e) {
/*     */       
/* 122 */       String error = "Could not get image from file: " + String.valueOf(file) + ": " + e.getMessage();
/* 123 */       Journeymap.getLogger().error(error);
/* 124 */       return null;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static synchronized NativeImage getMergedChunks(File worldDir, ChunkPos startCoord, ChunkPos endCoord, MapType mapType, Boolean useCache, NativeImage image, Integer imageWidth, Integer imageHeight, boolean allowNullImage, boolean showGrid) {
/* 148 */     int scale = 1;
/* 149 */     scale = Math.max(scale, 1);
/* 150 */     int initialWidth = Math.min(512, (endCoord.x - startCoord.x + 1) * 16 / scale);
/* 151 */     int initialHeight = Math.min(512, (endCoord.z - startCoord.z + 1) * 16 / scale);
/*     */     
/* 153 */     image = new NativeImage(initialWidth, initialHeight, false);
/*     */ 
/*     */     
/* 156 */     RegionImageCache cache = RegionImageCache.INSTANCE;
/*     */     
/* 158 */     RegionCoord rc = null;
/* 159 */     NativeImage regionImage = null;
/*     */     
/* 161 */     int rx1 = RegionCoord.getRegionPos(startCoord.x);
/* 162 */     int rx2 = RegionCoord.getRegionPos(endCoord.x);
/* 163 */     int rz1 = RegionCoord.getRegionPos(startCoord.z);
/* 164 */     int rz2 = RegionCoord.getRegionPos(endCoord.z);
/*     */ 
/*     */ 
/*     */     
/* 168 */     boolean imageDrawn = false;
/* 169 */     for (int rx = rx1; rx <= rx2; rx++) {
/*     */       
/* 171 */       for (int rz = rz1; rz <= rz2; rz++) {
/*     */         
/* 173 */         rc = new RegionCoord(worldDir, rx, rz, mapType.dimension);
/* 174 */         regionImage = cache.getRegionImageSet(rc).getImage(mapType);
/*     */         
/* 176 */         if (regionImage != null) {
/*     */ 
/*     */ 
/*     */ 
/*     */           
/* 181 */           int rminCx = Math.max(rc.getMinChunkX(), startCoord.x);
/* 182 */           int rminCz = Math.max(rc.getMinChunkZ(), startCoord.z);
/* 183 */           int rmaxCx = Math.min(rc.getMaxChunkX(), endCoord.x);
/* 184 */           int rmaxCz = Math.min(rc.getMaxChunkZ(), endCoord.z);
/*     */           
/* 186 */           int xoffset = rc.getMinChunkX() * 16;
/* 187 */           int yoffset = rc.getMinChunkZ() * 16;
/* 188 */           int sx1 = rminCx * 16 - xoffset;
/* 189 */           int sy1 = rminCz * 16 - yoffset;
/* 190 */           int sx2 = sx1 + (rmaxCx - rminCx + 1) * 16;
/* 191 */           int sy2 = sy1 + (rmaxCz - rminCz + 1) * 16;
/*     */           
/* 193 */           xoffset = startCoord.x * 16;
/* 194 */           yoffset = startCoord.z * 16;
/* 195 */           int dx1 = startCoord.x * 16 - xoffset;
/* 196 */           int dy1 = startCoord.z * 16 - yoffset;
/* 197 */           int dx2 = dx1 + (endCoord.x - startCoord.x + 1) * 16;
/* 198 */           int dy2 = dy1 + (endCoord.z - startCoord.z + 1) * 16;
/* 199 */           for (int x = 0; x < sx2; x++) {
/*     */             
/* 201 */             for (int y = 0; y < sy2; y++) {
/*     */               
/* 203 */               int pixel = regionImage.getPixelRGBA(x, y);
/* 204 */               image.setPixelRGBA(x, y, pixel);
/*     */             } 
/*     */           } 
/*     */           
/* 208 */           imageDrawn = true;
/*     */         } 
/*     */       } 
/*     */     } 
/*     */     
/* 213 */     if (imageDrawn)
/*     */     {
/* 215 */       if (showGrid) {
/*     */         int color;
/*     */         
/* 218 */         if (mapType.isDay()) {
/*     */           
/* 220 */           color = RGB.toArbg(0, 0.25F);
/*     */         }
/*     */         else {
/*     */           
/* 224 */           color = RGB.toArbg(8421504, 0.1F);
/*     */         } 
/*     */         
/* 227 */         for (int y = 0; y < initialHeight; y += 16) {
/*     */           
/* 229 */           for (int i = 0; i < initialWidth; i++)
/*     */           {
/* 231 */             image.blendPixel(i, y, color);
/*     */           }
/*     */         } 
/*     */         
/* 235 */         for (int x = 0; x < initialWidth; x += 16) {
/*     */           
/* 237 */           for (int i = 0; i < initialHeight; i++)
/*     */           {
/* 239 */             image.blendPixel(x, i, color);
/*     */           }
/*     */         } 
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/* 246 */     if (allowNullImage && !imageDrawn)
/*     */     {
/* 248 */       return null;
/*     */     }
/*     */ 
/*     */     
/* 252 */     if (imageHeight != null && imageWidth != null && (initialHeight != imageHeight.intValue() || initialWidth != imageWidth.intValue()))
/*     */     {
/* 254 */       return ImageUtil.getSizedImage(imageWidth.intValue(), imageHeight.intValue(), image, true);
/*     */     }
/*     */ 
/*     */     
/* 258 */     return image;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static File getBlank512x512ImageFile() {
/* 264 */     File dataDir = new File(FileHandler.MinecraftDirectory, Constants.DATA_DIR);
/* 265 */     File tmpFile = new File(dataDir, "blank512x512.png");
/* 266 */     if (!tmpFile.canRead()) {
/*     */       try {
/* 268 */         NativeImage image = new NativeImage(512, 512, false);
/*     */         
/* 270 */         try { dataDir.mkdirs();
/* 271 */           image.writeToFile(tmpFile);
/* 272 */           image.fillRect(0, 0, 512, 512, 0);
/* 273 */           tmpFile.setReadOnly();
/* 274 */           tmpFile.deleteOnExit();
/* 275 */           image.close(); } catch (Throwable throwable) { try { image.close(); } catch (Throwable throwable1) { throwable.addSuppressed(throwable1); }  throw throwable; } 
/* 276 */       } catch (IOException e) {
/*     */         
/* 278 */         Journeymap.getLogger().error("Could not create blank temp file " + String.valueOf(tmpFile) + ": " + LogFormatter.toString(e));
/*     */       } 
/*     */     }
/*     */     
/* 282 */     return tmpFile;
/*     */   }
/*     */ }


/* Location:              C:\Users\Administrator\Downloads\journeymap-neoforge-1.21-6.0.0-beta.18.jar!\journeymap\client\io\RegionImageHandler.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */