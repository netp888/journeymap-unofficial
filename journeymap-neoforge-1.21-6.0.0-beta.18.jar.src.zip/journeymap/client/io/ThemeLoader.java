/*     */ package journeymap.client.io;
/*     */ 
/*     */ import com.google.common.io.Files;
/*     */ import com.google.gson.Gson;
/*     */ import com.google.gson.GsonBuilder;
/*     */ import java.io.File;
/*     */ import java.io.FileFilter;
/*     */ import java.io.FilenameFilter;
/*     */ import java.nio.charset.Charset;
/*     */ import java.nio.file.Path;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.Comparator;
/*     */ import java.util.HashSet;
/*     */ import java.util.List;
/*     */ import java.util.Set;
/*     */ import java.util.stream.Collectors;
/*     */ import journeymap.client.Constants;
/*     */ import journeymap.client.JourneymapClient;
/*     */ import journeymap.client.log.JMLogger;
/*     */ import journeymap.client.texture.TextureCache;
/*     */ import journeymap.client.ui.UIManager;
/*     */ import journeymap.client.ui.theme.Theme;
/*     */ import journeymap.client.ui.theme.ThemePresets;
/*     */ import journeymap.common.Journeymap;
/*     */ import journeymap.common.log.LogFormatter;
/*     */ import journeymap.common.properties.config.StringField;
/*     */ import net.minecraft.client.Minecraft;
/*     */ import net.minecraft.resources.ResourceLocation;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ThemeLoader
/*     */ {
/*     */   public static final String THEME_FILE_SUFFIX = ".theme2.json";
/*     */   public static final String DEFAULT_THEME_FILE = "default.theme.config";
/*  55 */   public static final Gson GSON = (new GsonBuilder()).setPrettyPrinting().setVersion(2.0D).create();
/*     */   
/*  57 */   private static transient Theme currentTheme = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void initialize(boolean preLoadCurrentTheme) {
/*  66 */     Journeymap.getLogger().trace("Initializing themes ...");
/*     */ 
/*     */     
/*  69 */     Set<String> themeDirNames = new HashSet<>(ThemePresets.getPresetDirs());
/*  70 */     themeDirNames.add("vault");
/*  71 */     themeDirNames.add("vault_flat");
/*  72 */     themeDirNames.add("victorian_");
/*     */     
/*  74 */     for (String dirName : themeDirNames)
/*     */     {
/*  76 */       FileHandler.copyResources(getThemeIconDir(), ResourceLocation.fromNamespaceAndPath("journeymap", "theme/" + dirName), dirName, true);
/*     */     }
/*     */ 
/*     */     
/*  80 */     ThemePresets.getPresets().forEach(ThemeLoader::save);
/*     */ 
/*     */     
/*  83 */     ensureDefaultThemeFile();
/*     */ 
/*     */     
/*  86 */     if (preLoadCurrentTheme)
/*     */     {
/*  88 */       preloadCurrentTheme();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static File getThemeIconDir() {
/*  99 */     File dir = new File(FileHandler.getMinecraftDirectory(), Constants.THEME_ICON_DIR);
/* 100 */     if (!dir.exists())
/*     */     {
/* 102 */       dir.mkdirs();
/*     */     }
/* 104 */     return dir;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static File[] getThemeDirectories() {
/* 114 */     File parentDir = getThemeIconDir();
/* 115 */     File[] themeDirs = parentDir.listFiles(new FileFilter()
/*     */         {
/*     */           
/*     */           public boolean accept(File pathname)
/*     */           {
/* 120 */             return pathname.isDirectory();
/*     */           }
/*     */         });
/* 123 */     return themeDirs;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static List<Theme> getThemes() {
/* 133 */     File[] themeDirs = getThemeDirectories();
/* 134 */     if (themeDirs == null || themeDirs.length == 0) {
/*     */ 
/*     */       
/* 137 */       initialize(false);
/* 138 */       themeDirs = getThemeDirectories();
/* 139 */       if (themeDirs == null || themeDirs.length == 0) {
/*     */         
/* 141 */         Journeymap.getLogger().error("Couldn't find theme directories.");
/* 142 */         return Collections.emptyList();
/*     */       } 
/*     */     } 
/*     */ 
/*     */     
/* 147 */     ArrayList<Theme> themes = new ArrayList<>();
/* 148 */     for (File themeDir : themeDirs) {
/*     */       
/* 150 */       File[] themeFiles = themeDir.listFiles(new FilenameFilter()
/*     */           {
/*     */             
/*     */             public boolean accept(File dir, String name)
/*     */             {
/* 155 */               return name.endsWith(".theme2.json");
/*     */             }
/*     */           });
/*     */       
/* 159 */       if (themeFiles != null && themeFiles.length > 0)
/*     */       {
/* 161 */         for (File themeFile : themeFiles) {
/*     */           
/* 163 */           Theme theme = loadThemeFromFile(themeFile, false);
/* 164 */           if (theme != null)
/*     */           {
/* 166 */             themes.add(theme);
/*     */           }
/*     */         } 
/*     */       }
/*     */     } 
/*     */     
/* 172 */     if (themes.isEmpty())
/*     */     {
/* 174 */       themes.addAll(ThemePresets.getPresets());
/*     */     }
/*     */     
/* 177 */     Collections.sort(themes, Comparator.comparing(theme -> theme.name));
/* 178 */     return themes;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static List<String> getThemeNames() {
/* 188 */     List<Theme> themes = null;
/*     */     
/*     */     try {
/* 191 */       themes = getThemes();
/*     */     }
/* 193 */     catch (Exception e) {
/*     */       
/* 195 */       themes = ThemePresets.getPresets();
/*     */     } 
/*     */     
/* 198 */     return (List<String>)themes.stream().map(theme -> theme.name).collect(Collectors.toList());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Theme getCurrentTheme() {
/* 208 */     return getCurrentTheme(false);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static synchronized void setCurrentTheme(Theme theme) {
/* 218 */     if (currentTheme == theme) {
/*     */       return;
/*     */     }
/*     */     
/* 222 */     (JourneymapClient.getInstance().getCoreProperties()).themeName.set(theme.name);
/* 223 */     getCurrentTheme(true);
/* 224 */     UIManager.INSTANCE.getMiniMap().reset();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static synchronized Theme getCurrentTheme(boolean forceReload) {
/* 235 */     if (forceReload)
/*     */     {
/* 237 */       TextureCache.purgeThemeImages(TextureCache.themeImages);
/*     */     }
/*     */     
/* 240 */     String themeName = (JourneymapClient.getInstance().getCoreProperties()).themeName.get();
/* 241 */     if (forceReload || currentTheme == null || !themeName.equals(currentTheme.name)) {
/*     */       
/* 243 */       currentTheme = getThemeByName(themeName);
/* 244 */       (JourneymapClient.getInstance().getCoreProperties()).themeName.set(currentTheme.name);
/*     */     } 
/* 246 */     return currentTheme;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Theme getThemeByName(String themeName) {
/* 257 */     for (Theme theme : getThemes()) {
/*     */       
/* 259 */       if (theme.name.equals(themeName))
/*     */       {
/* 261 */         return theme;
/*     */       }
/*     */     } 
/* 264 */     Journeymap.getLogger().warn(String.format("Theme '%s' not found, reverting to default", new Object[] { themeName }));
/* 265 */     return ThemePresets.getDefault();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Theme loadThemeFromFile(File themeFile, boolean createIfMissing) {
/*     */     try {
/* 279 */       if (themeFile != null && themeFile.exists()) {
/*     */         
/* 281 */         Charset UTF8 = Charset.forName("UTF-8");
/* 282 */         String json = Files.toString(themeFile, UTF8);
/* 283 */         Theme theme = (Theme)GSON.fromJson(json, Theme.class);
/* 284 */         if (theme.schema < 2.0D) {
/*     */           
/* 286 */           Journeymap.getLogger().error("Theme file schema is obsolete, cannot be used: " + String.valueOf(themeFile));
/* 287 */           return null;
/*     */         } 
/* 289 */         return theme;
/*     */       } 
/* 291 */       if (createIfMissing)
/*     */       {
/* 293 */         Journeymap.getLogger().info("Generating Theme json file: " + String.valueOf(themeFile));
/* 294 */         Theme theme = new Theme();
/* 295 */         theme.name = themeFile.getName();
/* 296 */         save(theme);
/* 297 */         return theme;
/*     */       }
/*     */     
/* 300 */     } catch (Throwable t) {
/*     */       
/* 302 */       Journeymap.getLogger().error("Could not load Theme json file: " + LogFormatter.toString(t));
/*     */     } 
/* 304 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   private static File getThemeFile(String themeDirName, String themeFileName) {
/* 309 */     File themeDir = new File(getThemeIconDir(), themeDirName);
/* 310 */     String fileName = String.format("%s%s", new Object[] { themeFileName.replaceAll("[\\\\/:\"*?<>|]", "_"), ".theme2.json" });
/* 311 */     return new File(themeDir, fileName);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void save(Theme theme) {
/*     */     try {
/* 323 */       File themeFile = getThemeFile(theme.directory, theme.name);
/* 324 */       Files.createParentDirs(themeFile);
/* 325 */       Charset UTF8 = Charset.forName("UTF-8");
/* 326 */       Files.write(GSON.toJson(theme), themeFile, UTF8);
/*     */     }
/* 328 */     catch (Throwable t) {
/*     */       
/* 330 */       Journeymap.getLogger().error("Could not save Theme json file: " + String.valueOf(t));
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static void ensureDefaultThemeFile() {
/* 339 */     File defaultThemeFile = new File(getThemeIconDir(), "default.theme.config");
/* 340 */     if (!defaultThemeFile.exists()) {
/*     */       
/*     */       try {
/*     */         
/* 344 */         Theme.DefaultPointer defaultPointer = new Theme.DefaultPointer(ThemePresets.getDefault());
/* 345 */         Charset UTF8 = Charset.forName("UTF-8");
/* 346 */         Files.write(GSON.toJson(defaultPointer), defaultThemeFile, UTF8);
/*     */       }
/* 348 */       catch (Throwable t) {
/*     */         
/* 350 */         Journeymap.getLogger().error("Could not save DefaultTheme json file: " + String.valueOf(t));
/*     */       } 
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Theme getDefaultTheme() {
/* 362 */     if (Minecraft.getInstance() == null)
/*     */     {
/* 364 */       return ThemePresets.getDefault();
/*     */     }
/*     */     
/* 367 */     Theme theme = null;
/* 368 */     File themeFile = null;
/* 369 */     Theme.DefaultPointer pointer = null;
/*     */     
/*     */     try {
/* 372 */       pointer = loadDefaultPointer();
/* 373 */       pointer.filename = pointer.filename.replace(".theme2.json", "");
/*     */       
/* 375 */       themeFile = getThemeFile(pointer.directory, pointer.filename);
/* 376 */       theme = loadThemeFromFile(themeFile, false);
/*     */     }
/* 378 */     catch (Exception e) {
/*     */       
/* 380 */       JMLogger.throwLogOnce("Default theme not found in files", e);
/*     */     } 
/*     */     
/* 383 */     if (theme == null)
/*     */     {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 390 */       theme = ThemePresets.getDefault();
/*     */     }
/* 392 */     return theme;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static synchronized void loadNextTheme() {
/* 400 */     List<String> themeNames = getThemeNames();
/* 401 */     int index = themeNames.indexOf((getCurrentTheme()).name);
/* 402 */     if (index < 0 || index >= themeNames.size() - 1) {
/*     */       
/* 404 */       index = 0;
/*     */     }
/*     */     else {
/*     */       
/* 408 */       index++;
/*     */     } 
/*     */     
/* 411 */     setCurrentTheme(getThemes().get(index));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static Theme.DefaultPointer loadDefaultPointer() {
/*     */     try {
/* 421 */       ensureDefaultThemeFile();
/* 422 */       File defaultThemeFile = new File(getThemeIconDir(), "default.theme.config");
/* 423 */       if (defaultThemeFile.exists()) {
/*     */         
/* 425 */         Charset UTF8 = Charset.forName("UTF-8");
/* 426 */         String json = Files.toString(defaultThemeFile, UTF8);
/* 427 */         return (Theme.DefaultPointer)GSON.fromJson(json, Theme.DefaultPointer.class);
/*     */       } 
/*     */ 
/*     */       
/* 431 */       return new Theme.DefaultPointer(ThemePresets.getDefault());
/*     */     
/*     */     }
/* 434 */     catch (Throwable t) {
/*     */       
/* 436 */       Journeymap.getLogger().error("Could not load Theme.DefaultTheme json file: " + LogFormatter.toString(t));
/*     */       
/* 438 */       return null;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void preloadCurrentTheme() {
/* 447 */     int count = 0;
/*     */     
/*     */     try {
/* 450 */       Theme theme = getCurrentTheme();
/* 451 */       File themeDir = (new File(getThemeIconDir(), theme.directory)).getCanonicalFile();
/* 452 */       Path themePath = themeDir.toPath();
/* 453 */       for (File file : Files.fileTraverser().breadthFirst(themeDir)) {
/*     */         
/* 455 */         if (file.isFile() && file.getName().toLowerCase().endsWith(".png"))
/*     */         {
/* 457 */           String relativePath = themePath.relativize(file.toPath()).toString().replaceAll("\\\\", "/");
/* 458 */           TextureCache.getThemeTexture(theme, relativePath);
/* 459 */           count++;
/*     */         }
/*     */       
/*     */       } 
/* 463 */     } catch (Throwable t) {
/*     */       
/* 465 */       Journeymap.getLogger().error("Error preloading theme textures: " + LogFormatter.toString(t));
/*     */     } 
/* 467 */     Journeymap.getLogger().info("Preloaded theme textures: " + count);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static class ThemeValuesProvider
/*     */     implements StringField.ValuesProvider
/*     */   {
/*     */     public List<String> getStrings() {
/* 478 */       return ThemeLoader.getThemeNames();
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public String getDefaultString() {
/* 484 */       return (ThemeLoader.getDefaultTheme()).name;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public String getTooltip(String value) {
/* 490 */       for (Theme theme : ThemeLoader.getThemes()) {
/*     */         
/* 492 */         if (theme.name.equals(value))
/*     */         {
/* 494 */           return Constants.getString("jm.common.ui_theme_author", new Object[] { theme.author });
/*     */         }
/*     */       } 
/*     */       
/* 498 */       return null;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\Administrator\Downloads\journeymap-neoforge-1.21-6.0.0-beta.18.jar!\journeymap\client\io\ThemeLoader.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */