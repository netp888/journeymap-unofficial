/*     */ package journeymap.client.cartography.color;
/*     */ 
/*     */ import com.mojang.blaze3d.platform.NativeImage;
/*     */ import javax.annotation.Nullable;
/*     */ import javax.annotation.ParametersAreNonnullByDefault;
/*     */ import journeymap.client.texture.TextureCache;
/*     */ import journeymap.common.Journeymap;
/*     */ import journeymap.common.log.LogFormatter;
/*     */ import net.minecraft.client.renderer.block.model.BakedQuad;
/*     */ import net.minecraft.client.renderer.texture.TextureAtlasSprite;
/*     */ import net.minecraft.resources.ResourceLocation;
/*     */ import org.apache.logging.log4j.Logger;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @ParametersAreNonnullByDefault
/*     */ public class ColoredSprite
/*     */ {
/*  28 */   private static Logger logger = Journeymap.getLogger();
/*     */   
/*     */   private final Integer color;
/*     */   private final TextureAtlasSprite sprite;
/*     */   
/*     */   public ColoredSprite(TextureAtlasSprite sprite, @Nullable Integer color) {
/*  34 */     this.sprite = sprite;
/*  35 */     this.color = null;
/*     */   }
/*     */ 
/*     */   
/*     */   public ColoredSprite(BakedQuad quad) {
/*  40 */     this.sprite = quad.getSprite();
/*  41 */     this.color = null;
/*     */   }
/*     */ 
/*     */   
/*     */   public String getIconName() {
/*  46 */     return this.sprite.contents().name().getPath();
/*     */   }
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public Integer getColor() {
/*  52 */     return this.color;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean hasColor() {
/*  57 */     return (this.color != null);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public NativeImage getColoredImage() {
/*     */     try {
/*  65 */       ResourceLocation resourceLocation = ResourceLocation.parse(getIconName());
/*     */ 
/*     */       
/*  68 */       if (resourceLocation.equals(ResourceLocation.parse("missingno")))
/*     */       {
/*  70 */         return null;
/*     */       }
/*     */ 
/*     */       
/*  74 */       NativeImage image = (this.sprite.contents()).byMipLevel[0];
/*  75 */       if (image == null || image.getWidth() == 0)
/*     */       {
/*     */         
/*  78 */         image = getImageResource(this.sprite);
/*     */       }
/*  80 */       if (image == null || image.getWidth() == 0)
/*     */       {
/*  82 */         return null;
/*     */       }
/*  84 */       return image;
/*     */     }
/*  86 */     catch (Throwable e1) {
/*     */       
/*  88 */       if (logger.isDebugEnabled())
/*     */       {
/*  90 */         logger.error("ColoredSprite: Error getting image for " + getIconName() + ": " + LogFormatter.toString(e1));
/*     */       }
/*  92 */       return null;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private NativeImage getImageResource(TextureAtlasSprite tas) {
/*     */     try {
/* 103 */       ResourceLocation iconNameLoc = ResourceLocation.parse(tas.contents().name().getPath());
/* 104 */       ResourceLocation fileLoc = ResourceLocation.fromNamespaceAndPath(iconNameLoc.getNamespace(), "textures/" + iconNameLoc.getPath() + ".png");
/* 105 */       return TextureCache.resolveImage(fileLoc);
/*     */     }
/* 107 */     catch (Throwable t) {
/*     */       
/* 109 */       logger.error(String.format("ColoredSprite: Unable to use texture file for %s: %s", new Object[] { tas.contents().name().getPath(), t.getMessage() }));
/*     */       
/* 111 */       return null;
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\Administrator\Downloads\journeymap-neoforge-1.21-6.0.0-beta.18.jar!\journeymap\client\cartography\color\ColoredSprite.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */