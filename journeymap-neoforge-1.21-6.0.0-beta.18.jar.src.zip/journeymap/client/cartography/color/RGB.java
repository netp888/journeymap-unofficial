/*     */ package journeymap.client.cartography.color;
/*     */ 
/*     */ import com.google.common.base.Strings;
/*     */ import java.awt.Color;
/*     */ import java.util.Random;
/*     */ import journeymap.common.Journeymap;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class RGB
/*     */ {
/*     */   public static final int ALPHA_OPAQUE = -16777216;
/*     */   public static final int BLACK_ARGB = -16777216;
/*     */   public static final int BLACK_RGB = 0;
/*     */   public static final int WHITE_ARGB = -1;
/*     */   public static final int WHITE_RGB = 16777215;
/*     */   public static final int GREEN_RGB = 65280;
/*     */   public static final int RED_RGB = 16711680;
/*     */   public static final int BLUE_RGB = 255;
/*     */   public static final int CYAN_RGB = 65535;
/*     */   public static final int GRAY_RGB = 8421504;
/*     */   public static final int DARK_GRAY_RGB = 4210752;
/*     */   public static final int LIGHT_GRAY_RGB = 12632256;
/*     */   
/*     */   public static boolean isBlack(int rgb) {
/*  83 */     return (rgb == -16777216 || rgb == 0);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean isWhite(int rgb) {
/*  94 */     return (rgb == -1 || rgb == 16777215);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Integer max(Integer... colors) {
/* 105 */     int[] out = { 0, 0, 0 };
/*     */     
/* 107 */     int used = 0;
/* 108 */     for (Integer color : colors) {
/*     */       
/* 110 */       if (color != null) {
/*     */ 
/*     */ 
/*     */         
/* 114 */         int[] cInts = ints(color.intValue());
/* 115 */         out[0] = Math.max(out[0], cInts[0]);
/* 116 */         out[1] = Math.max(out[1], cInts[1]);
/* 117 */         out[2] = Math.max(out[2], cInts[2]);
/*     */         
/* 119 */         used++;
/*     */       } 
/*     */     } 
/* 122 */     if (used == 0)
/*     */     {
/* 124 */       return null;
/*     */     }
/*     */     
/* 127 */     return Integer.valueOf(toInteger(out));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static int toInteger(float r, float g, float b) {
/* 140 */     return 0xFF000000 | ((int)((r * 255.0F) + 0.5D) & 0xFF) << 16 | ((int)((g * 255.0F) + 0.5D) & 0xFF) << 8 | (int)((b * 255.0F) + 0.5D) & 0xFF;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static int toInteger(float[] rgb) {
/* 154 */     return 0xFF000000 | ((int)((rgb[0] * 255.0F) + 0.5D) & 0xFF) << 16 | ((int)((rgb[1] * 255.0F) + 0.5D) & 0xFF) << 8 | (int)((rgb[2] * 255.0F) + 0.5D) & 0xFF;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static int toArbg(int rgbInt, float alpha) {
/* 170 */     int[] rgba = ints(rgbInt, alpha);
/*     */     
/* 172 */     return (rgba[3] & 0xFF) << 24 | (rgba[0] & 0xFF) << 16 | (rgba[2] & 0xFF) << 8 | rgba[1] & 0xFF;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static int toArgb(int rgbInt, float alpha) {
/* 188 */     int[] rgba = ints(rgbInt, alpha);
/*     */     
/* 190 */     return (rgba[3] & 0xFF) << 24 | (rgba[0] & 0xFF) << 16 | (rgba[1] & 0xFF) << 8 | rgba[2] & 0xFF;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static int toRgba(int rgbInt, float alpha) {
/* 199 */     int[] rgba = ints(rgbInt, alpha);
/*     */     
/* 201 */     return (rgba[3] & 0xFF) << 24 | (rgba[2] & 0xFF) << 16 | (rgba[1] & 0xFF) << 8 | rgba[0] & 0xFF;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static int toInteger(int r, int g, int b) {
/* 217 */     return 0xFF000000 | (r & 0xFF) << 16 | (g & 0xFF) << 8 | b & 0xFF;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static int toInteger(int[] rgb) {
/* 231 */     return 0xFF000000 | (rgb[0] & 0xFF) << 16 | (rgb[1] & 0xFF) << 8 | rgb[2] & 0xFF;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static int rgbaToRgb(int rgba) {
/* 245 */     return toInteger(rgba & 0xFF, rgba >>> 8 & 0xFF, rgba >>> 16 & 0xFF);
/*     */   }
/*     */ 
/*     */   
/*     */   public static int tint(int rgb, int rgbTint) {
/* 250 */     float[] tint = floats(rgbTint);
/* 251 */     float[] old = floats(rgb);
/*     */     
/* 253 */     float newR = old[0] * tint[0];
/* 254 */     float newG = old[1] * tint[1];
/* 255 */     float newB = old[2] * tint[2];
/* 256 */     return toInteger(newR, newG, newB);
/*     */   }
/*     */ 
/*     */   
/*     */   public static int tintRgba(int rgba, int rgbTint) {
/* 261 */     float[] tint = floats(rgbTint);
/* 262 */     float[] old = floats(rgbaToRgb(rgba));
/*     */     
/* 264 */     float newR = old[0] * tint[0];
/* 265 */     float newG = old[1] * tint[1];
/* 266 */     float newB = old[2] * tint[2];
/* 267 */     return toInteger(newB, newG, newR) & 0xFFFFFF | rgba & 0xFF000000;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Color toColor(Integer rgb) {
/* 278 */     return (rgb == null) ? null : new Color(rgb.intValue());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String toString(Integer rgb) {
/* 289 */     if (rgb == null)
/*     */     {
/* 291 */       return "null";
/*     */     }
/* 293 */     int[] ints = ints(rgb.intValue());
/* 294 */     return String.format("r=%s,g=%s,b=%s", new Object[] { Integer.valueOf(ints[0]), Integer.valueOf(ints[1]), Integer.valueOf(ints[2]) });
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String toHexString(Integer rgb) {
/* 305 */     int[] ints = ints(rgb.intValue());
/* 306 */     return String.format("#%02x%02x%02x", new Object[] { Integer.valueOf(ints[0]), Integer.valueOf(ints[1]), Integer.valueOf(ints[2]) });
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String toHexStringRGBA(Integer rgba) {
/* 317 */     int[] ints = ints(rgba.intValue());
/* 318 */     return String.format("#%02x%02x%02x%02x", new Object[] { Integer.valueOf(rgba.intValue() >> 24 & 0xFF), Integer.valueOf(ints[0]), Integer.valueOf(ints[1]), Integer.valueOf(ints[2]) });
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static int adjustBrightness(int rgb, float factor) {
/* 330 */     if (factor == 1.0F)
/*     */     {
/* 332 */       return rgb;
/*     */     }
/* 334 */     return toInteger(clampFloats(floats(rgb), factor));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static int greyScale(int rgb) {
/* 345 */     int[] ints = ints(rgb);
/* 346 */     int avg = clampInt((ints[0] + ints[1] + ints[2]) / 3);
/* 347 */     return toInteger(avg, avg, avg);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static int bevelSlope(int rgb, float factor) {
/* 360 */     float bluer = (factor < 1.0F) ? 0.85F : 1.0F;
/* 361 */     float[] floats = floats(rgb);
/* 362 */     floats[0] = floats[0] * bluer * factor;
/* 363 */     floats[1] = floats[1] * bluer * factor;
/* 364 */     floats[2] = floats[2] * factor;
/* 365 */     return toInteger(clampFloats(floats, 1.0F));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static int darkenAmbient(int rgb, float factor, float[] ambient) {
/* 378 */     float[] floats = floats(rgb);
/* 379 */     floats[0] = floats[0] * (factor + ambient[0]);
/* 380 */     floats[1] = floats[1] * (factor + ambient[1]);
/* 381 */     floats[2] = floats[2] * (factor + ambient[2]);
/* 382 */     return toInteger(clampFloats(floats, 1.0F));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static int[] ints(int rgb) {
/* 393 */     return new int[] { rgb >> 16 & 0xFF, rgb >> 8 & 0xFF, rgb & 0xFF };
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static int[] ints(int rgb, int alpha) {
/* 405 */     return new int[] { rgb >> 16 & 0xFF, rgb >> 8 & 0xFF, rgb & 0xFF, alpha & 0xFF };
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static int[] ints(int rgb, float alpha) {
/* 417 */     return new int[] { rgb >> 16 & 0xFF, rgb >> 8 & 0xFF, rgb & 0xFF, (int)((alpha * 255.0F) + 0.5D) & 0xFF };
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static float[] floats(int rgb) {
/* 428 */     return new float[] { (rgb >> 16 & 0xFF) / 255.0F, (rgb >> 8 & 0xFF) / 255.0F, (rgb & 0xFF) / 255.0F };
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static float[] floats(int rgb, float alpha) {
/* 440 */     return new float[] { (rgb >> 16 & 0xFF) / 255.0F, (rgb >> 8 & 0xFF) / 255.0F, (rgb & 0xFF) / 255.0F, clampFloat(alpha) };
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static int blendWith(int rgb, int otherRgb, float otherAlpha) {
/* 453 */     if (otherAlpha == 1.0F)
/*     */     {
/* 455 */       return otherRgb;
/*     */     }
/* 457 */     if (otherAlpha == 0.0F)
/*     */     {
/* 459 */       return rgb;
/*     */     }
/*     */     
/* 462 */     float[] floats = floats(rgb);
/* 463 */     float[] otherFloats = floats(otherRgb);
/*     */     
/* 465 */     floats[0] = otherFloats[0] * otherAlpha / 1.0F + floats[0] * (1.0F - otherAlpha);
/* 466 */     floats[1] = otherFloats[1] * otherAlpha / 1.0F + floats[1] * (1.0F - otherAlpha);
/* 467 */     floats[2] = otherFloats[2] * otherAlpha / 1.0F + floats[2] * (1.0F - otherAlpha);
/*     */     
/* 469 */     return toInteger(floats);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static int multiply(int rgb, int multiplier) {
/* 481 */     float[] rgbFloats = floats(rgb);
/* 482 */     float[] multFloats = floats(multiplier);
/*     */     
/* 484 */     rgbFloats[0] = rgbFloats[0] * multFloats[0];
/* 485 */     rgbFloats[1] = rgbFloats[1] * multFloats[1];
/* 486 */     rgbFloats[2] = rgbFloats[2] * multFloats[2];
/*     */     
/* 488 */     return toInteger(rgbFloats);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static float clampFloat(float value) {
/* 499 */     return (value < 0.0F) ? 0.0F : ((value > 1.0F) ? 1.0F : value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static float[] clampFloats(float[] rgbFloats, float factor) {
/* 511 */     float r = rgbFloats[0] * factor;
/* 512 */     float g = rgbFloats[1] * factor;
/* 513 */     float b = rgbFloats[2] * factor;
/* 514 */     rgbFloats[0] = (r < 0.0F) ? 0.0F : ((r > 1.0F) ? 1.0F : r);
/* 515 */     rgbFloats[1] = (g < 0.0F) ? 0.0F : ((g > 1.0F) ? 1.0F : g);
/* 516 */     rgbFloats[2] = (b < 0.0F) ? 0.0F : ((b > 1.0F) ? 1.0F : b);
/*     */     
/* 518 */     return rgbFloats;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static int clampInt(int value) {
/* 529 */     return (value < 0) ? 0 : ((value > 255) ? 255 : value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static int toClampedInt(float value) {
/* 540 */     return clampInt((int)(value * 255.0F));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static float toScaledFloat(int value) {
/* 551 */     return clampInt(value) / 255.0F;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static int hexToInt(String hexColor) {
/* 562 */     if (!Strings.isNullOrEmpty(hexColor)) {
/*     */       
/*     */       try {
/*     */         
/* 566 */         String hex = hexColor.replaceFirst("#", "");
/* 567 */         int color = (int)Long.parseLong(hex, 16);
/* 568 */         if (hex.length() <= 6)
/*     */         {
/* 570 */           color = 0xFF000000 | color;
/*     */         }
/* 572 */         return color;
/*     */       }
/* 574 */       catch (Exception e) {
/*     */         
/* 576 */         Journeymap.getLogger().warn("Invalid color string: " + hexColor);
/*     */       } 
/*     */     }
/* 579 */     return 0;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static int randomColor() {
/* 589 */     Random random = new Random();
/* 590 */     int r = random.nextInt(255);
/* 591 */     int g = random.nextInt(255);
/* 592 */     int b = random.nextInt(255);
/*     */     
/* 594 */     int min = 100;
/* 595 */     int max = Math.max(r, Math.max(g, b));
/* 596 */     if (max < min)
/*     */     {
/* 598 */       if (r == max) {
/*     */         
/* 600 */         r = min;
/*     */       }
/* 602 */       else if (g == max) {
/*     */         
/* 604 */         g = min;
/*     */       }
/*     */       else {
/*     */         
/* 608 */         b = min;
/*     */       } 
/*     */     }
/*     */     
/* 612 */     return toInteger(r, g, b);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Integer subtract(int minuend, int subtrahend) {
/* 624 */     int[] larger = ints(minuend);
/* 625 */     int[] smaller = ints(subtrahend);
/* 626 */     return Integer.valueOf(toInteger(larger[0] - smaller[0], larger[1] - smaller[1], larger[2] - smaller[2]));
/*     */   }
/*     */ }


/* Location:              C:\Users\Administrator\Downloads\journeymap-neoforge-1.21-6.0.0-beta.18.jar!\journeymap\client\cartography\color\RGB.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */