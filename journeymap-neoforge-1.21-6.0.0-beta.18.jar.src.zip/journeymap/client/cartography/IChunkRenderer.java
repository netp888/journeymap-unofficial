package journeymap.client.cartography;

import journeymap.client.model.ChunkMD;
import journeymap.client.texture.ComparableNativeImage;
import journeymap.common.nbt.RegionData;

public interface IChunkRenderer {
  boolean render(ComparableNativeImage paramComparableNativeImage, RegionData paramRegionData, ChunkMD paramChunkMD, Integer paramInteger);
  
  void setStratumColors(Stratum paramStratum, int paramInt, Integer paramInteger, boolean paramBoolean1, boolean paramBoolean2, boolean paramBoolean3);
  
  float[] getAmbientColor();
}


/* Location:              C:\Users\Administrator\Downloads\journeymap-neoforge-1.21-6.0.0-beta.18.jar!\journeymap\client\cartography\IChunkRenderer.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */