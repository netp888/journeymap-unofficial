/*     */ package journeymap.client.cartography.render;
/*     */ 
/*     */ import com.mojang.blaze3d.platform.NativeImage;
/*     */ import journeymap.client.JourneymapClient;
/*     */ import journeymap.client.cartography.IChunkRenderer;
/*     */ import journeymap.client.cartography.Strata;
/*     */ import journeymap.client.cartography.Stratum;
/*     */ import journeymap.client.cartography.color.RGB;
/*     */ import journeymap.client.log.JMLogger;
/*     */ import journeymap.client.log.StatTimer;
/*     */ import journeymap.client.model.BlockFlag;
/*     */ import journeymap.client.model.BlockMD;
/*     */ import journeymap.client.model.ChunkMD;
/*     */ import journeymap.client.model.MapType;
/*     */ import journeymap.client.model.RegionImageCache;
/*     */ import journeymap.client.model.RegionImageSet;
/*     */ import journeymap.client.texture.ComparableNativeImage;
/*     */ import journeymap.common.Journeymap;
/*     */ import journeymap.common.log.LogFormatter;
/*     */ import journeymap.common.nbt.RegionData;
/*     */ import net.minecraft.core.BlockPos;
/*     */ import net.minecraft.nbt.CompoundTag;
/*     */ import net.minecraft.world.level.Level;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class CaveRenderer
/*     */   extends BaseRenderer
/*     */   implements IChunkRenderer
/*     */ {
/*     */   protected SurfaceRenderer surfaceRenderer;
/*  43 */   protected StatTimer renderCaveTimer = StatTimer.get("CaveRenderer.render");
/*     */ 
/*     */ 
/*     */   
/*  47 */   protected Strata strata = new Strata("Cave", 40, 8, true);
/*     */ 
/*     */ 
/*     */   
/*  51 */   protected float defaultDim = 0.2F;
/*     */ 
/*     */ 
/*     */   
/*     */   protected boolean mapSurfaceAboveCaves;
/*     */ 
/*     */ 
/*     */   
/*     */   protected boolean clearBlacks;
/*     */ 
/*     */ 
/*     */   
/*     */   RegionData regionData;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public CaveRenderer(SurfaceRenderer surfaceRenderer) {
/*  69 */     this.surfaceRenderer = surfaceRenderer;
/*  70 */     updateOptions((ChunkMD)null, (MapType)null);
/*     */ 
/*     */     
/*  73 */     this.shadingSlopeMin = 0.2F;
/*  74 */     this.shadingSlopeMax = 1.1F;
/*  75 */     this.shadingPrimaryDownslopeMultiplier = 0.7F;
/*  76 */     this.shadingPrimaryUpslopeMultiplier = 1.05F;
/*  77 */     this.shadingSecondaryDownslopeMultiplier = 0.99F;
/*  78 */     this.shadingSecondaryUpslopeMultiplier = 1.01F;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected boolean updateOptions(ChunkMD chunkMd, MapType mapType) {
/*  84 */     if (super.updateOptions(chunkMd, mapType)) {
/*     */       
/*  86 */       this.mapSurfaceAboveCaves = (JourneymapClient.getInstance().getCoreProperties()).mapSurfaceAboveCaves.get().booleanValue();
/*  87 */       this.clearBlacks = (JourneymapClient.getInstance().getCoreProperties()).caveBlackAsClear.get().booleanValue();
/*  88 */       return true;
/*     */     } 
/*  90 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public int getBlockHeight(ChunkMD chunkMd, BlockPos blockPos) {
/*  96 */     if (chunkMd.fromNbt())
/*     */     {
/*  98 */       return chunkMd.getPrecipitationHeight(blockPos.getX(), blockPos.getZ());
/*     */     }
/* 100 */     Integer vSlice = Integer.valueOf(blockPos.getY() >> 4);
/* 101 */     int[] sliceBounds = getVSliceBounds(chunkMd, vSlice);
/* 102 */     int sliceMinY = sliceBounds[0];
/* 103 */     int sliceMaxY = sliceBounds[1];
/* 104 */     Integer y = getBlockHeight(chunkMd, blockPos.getX() & 0xF, vSlice, blockPos.getZ() & 0xF, Integer.valueOf(sliceMinY), Integer.valueOf(sliceMaxY));
/*     */     
/* 106 */     return (y == null) ? blockPos.getY() : y.intValue();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public synchronized boolean render(ComparableNativeImage chunkImage, RegionData regionData, ChunkMD chunkMd, Integer vSlice) {
/* 115 */     if (vSlice == null) {
/*     */       
/* 117 */       Journeymap.getLogger().warn("ChunkOverworldCaveRenderer is for caves. vSlice can't be null");
/* 118 */       return false;
/*     */     } 
/*     */     
/* 121 */     this.regionData = regionData;
/* 122 */     updateOptions(chunkMd, MapType.underground(vSlice, chunkMd.getDimension()));
/*     */     
/* 124 */     this.renderCaveTimer.start();
/*     */     
/*     */     try {
/*     */       ComparableNativeImage comparableNativeImage;
/* 128 */       if (!hasSlopes(chunkMd, vSlice))
/*     */       {
/* 130 */         populateSlopes(chunkMd, vSlice, getSlopes(chunkMd, vSlice));
/*     */       }
/*     */ 
/*     */       
/* 134 */       NativeImage chunkSurfaceImage = null;
/* 135 */       if (this.mapSurfaceAboveCaves) {
/*     */         
/* 137 */         MapType mapType = MapType.day(chunkMd.getDimension());
/* 138 */         RegionImageSet ris = RegionImageCache.INSTANCE.getRegionImageSet(chunkMd, mapType);
/* 139 */         if (ris != null && ris.getHolder(mapType).hasTexture())
/*     */         {
/* 141 */           comparableNativeImage = ris.getChunkImage(chunkMd, mapType);
/*     */         }
/*     */       } 
/*     */       
/* 145 */       boolean success = renderUnderground((NativeImage)comparableNativeImage, (NativeImage)chunkImage, regionData, chunkMd, vSlice.intValue());
/* 146 */       if (comparableNativeImage != null)
/*     */       {
/* 148 */         comparableNativeImage.close();
/*     */       }
/* 150 */       return success;
/*     */     }
/* 152 */     catch (Throwable t) {
/*     */       
/* 154 */       JMLogger.throwLogOnce("Chunk Error", t);
/* 155 */       return false;
/*     */     }
/*     */     finally {
/*     */       
/* 159 */       this.renderCaveTimer.stop();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void mask(NativeImage chunkSurfaceImage, NativeImage chunkImage, RegionData regionData, CompoundTag blockNbt, ChunkMD chunkMd, int x, int y, int z) {
/* 176 */     if (chunkSurfaceImage == null || !this.mapSurfaceAboveCaves) {
/*     */       
/* 178 */       if (this.clearBlacks)
/*     */       {
/* 180 */         paintClearBlock(chunkImage, x, z);
/*     */       }
/*     */       else
/*     */       {
/* 184 */         paintBlackBlock(chunkImage, x, z);
/*     */       }
/*     */     
/*     */     } else {
/*     */       
/* 189 */       BlockPos pos = chunkMd.getBlockPos(x, y, z);
/* 190 */       int surfaceY = Math.max(chunkMd.getMinY().intValue(), chunkMd.getHeight(new BlockPos(x, y, z)));
/* 191 */       int distance = Math.max(0, surfaceY - y);
/* 192 */       if (distance > 16) {
/*     */         
/* 194 */         int minY = getBlockHeight(chunkMd, new BlockPos(x, y, z));
/* 195 */         BlockMD blockMD = chunkMd.getBlockMD(pos);
/*     */         
/* 197 */         boolean isAir = blockMD.getBlockState().isAir();
/* 198 */         if ((y > chunkMd.getMinY().intValue() && minY > chunkMd.getMinY().intValue()) || (!isAir && y == chunkMd.getMinY().intValue() && minY == chunkMd.getMinY().intValue())) {
/*     */           
/* 200 */           if (this.clearBlacks)
/*     */           {
/* 202 */             paintClearBlock(chunkImage, x, z);
/*     */           }
/*     */           else
/*     */           {
/* 206 */             paintBlackBlock(chunkImage, x, z);
/*     */           }
/*     */         
/*     */         } else {
/*     */           
/* 211 */           int i = paintVoidBlock(chunkImage, x, z);
/*     */         }
/*     */       
/*     */       }
/*     */       else {
/*     */         
/* 217 */         int i = paintDimOverlay(chunkSurfaceImage, chunkImage, x, z, 0.5F);
/*     */       } 
/*     */     } 
/* 220 */     regionData.setBlockState(blockNbt, chunkMd, chunkMd.getBlockPos(x, y, z));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected boolean renderUnderground(NativeImage chunkSurfaceImage, NativeImage chunkSliceImage, RegionData regionData, ChunkMD chunkMd, int vSlice) {
/* 234 */     int[] sliceBounds = getVSliceBounds(chunkMd, Integer.valueOf(vSlice));
/* 235 */     int sliceMinY = sliceBounds[0];
/* 236 */     int sliceMaxY = sliceBounds[1];
/*     */ 
/*     */ 
/*     */     
/* 240 */     boolean chunkOk = false;
/* 241 */     CompoundTag chunkNbt = regionData.getChunkNbt(chunkMd.getCoord());
/* 242 */     for (int z = 0; z < 16; z++) {
/*     */       
/* 244 */       for (int x = 0; x < 16; x++) {
/*     */ 
/*     */         
/*     */         try {
/* 248 */           this.strata.reset();
/* 249 */           CompoundTag blockNbt = regionData.getBlockDataFromBlockPos(chunkMd.getCoord(), chunkNbt, x, z);
/* 250 */           regionData.setSurfaceY(blockNbt, chunkMd.getHeight(new BlockPos(x, 0, z)));
/* 251 */           int ceiling = chunkMd.fromNbt() ? chunkMd.getPrecipitationHeight(x, z) : getBlockHeight(chunkMd, x, Integer.valueOf(vSlice), z, Integer.valueOf(sliceMinY), Integer.valueOf(sliceMaxY)).intValue();
/*     */ 
/*     */           
/* 254 */           if (ceiling < chunkMd.getMinY().intValue()) {
/*     */             
/* 256 */             int voidColor = paintVoidBlock(chunkSliceImage, x, z);
/* 257 */             chunkOk = true;
/*     */           }
/*     */           else {
/*     */             
/* 261 */             int y = Math.min(ceiling, sliceMaxY);
/*     */             
/* 263 */             buildStrata(this.strata, regionData, blockNbt, sliceMinY - 1, chunkMd, x, y, z);
/*     */             
/* 265 */             if (this.strata.isEmpty() && !chunkMd.fromNbt()) {
/*     */ 
/*     */               
/* 268 */               mask(chunkSurfaceImage, chunkSliceImage, regionData, blockNbt, chunkMd, x, y, z);
/* 269 */               chunkOk = true;
/*     */             
/*     */             }
/*     */             else {
/*     */               
/* 274 */               chunkOk = (paintStrata(this.strata, chunkSliceImage, regionData, blockNbt, chunkMd, Integer.valueOf(vSlice), x, ceiling, z) || chunkOk);
/*     */             } 
/*     */           } 
/* 277 */         } catch (Throwable t) {
/*     */           
/* 279 */           paintBadBlock(chunkSliceImage, x, vSlice, z);
/*     */           
/* 281 */           String error = "CaveRenderer error at x,vSlice,z = " + x + "," + vSlice + "," + z + " : " + LogFormatter.toString(t);
/* 282 */           Journeymap.getLogger().error(error);
/*     */         } 
/*     */       } 
/*     */     } 
/* 286 */     regionData.writeChunk(chunkMd.getCoord(), chunkNbt);
/* 287 */     this.strata.reset();
/* 288 */     return chunkOk;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void buildStrata(Strata strata, RegionData regionData, CompoundTag blockNbt, int minY, ChunkMD chunkMd, int x, int topY, int z) {
/* 305 */     BlockMD blockMD = null;
/* 306 */     BlockMD blockAboveMD = null;
/* 307 */     BlockMD lavaBlockMD = null;
/*     */ 
/*     */ 
/*     */     
/*     */     try {
/* 312 */       int y = getBlockHeight(chunkMd, x, Integer.valueOf(topY >> 4), z, Integer.valueOf(minY), Integer.valueOf(topY)).intValue();
/* 313 */       while (y >= chunkMd.getMinY().intValue()) {
/*     */         
/* 315 */         blockMD = BlockMD.getBlockMDFromChunkLocal(chunkMd, x, y, z);
/* 316 */         if (!blockMD.isIgnore() && !blockMD.hasFlag(BlockFlag.OpenToSky)) {
/*     */           
/* 318 */           strata.setBlocksFound(true);
/* 319 */           blockAboveMD = BlockMD.getBlockMDFromChunkLocal(chunkMd, x, y + 1, z);
/*     */           
/* 321 */           if (blockMD.isLava() && blockAboveMD.isLava())
/*     */           {
/*     */             
/* 324 */             lavaBlockMD = blockMD;
/*     */           }
/*     */           
/* 327 */           if (blockAboveMD.isIgnore() || blockAboveMD.hasFlag(BlockFlag.OpenToSky) || chunkMd.fromNbt()) {
/*     */             
/* 329 */             if (chunkMd.hasNoSky().booleanValue() || !chunkMd.canBlockSeeTheSky(x, y + 1, z)) {
/*     */               
/* 331 */               int lightLevel = getSliceLightLevel(chunkMd, x, y, z, true);
/*     */               
/* 333 */               if (lightLevel > 0)
/*     */               {
/*     */                 
/* 336 */                 strata.push(chunkMd, blockMD, x, y, z, Integer.valueOf(lightLevel));
/* 337 */                 BlockPos pos = chunkMd.getBlockPos(x, strata.getTopY().intValue(), z);
/* 338 */                 regionData.setY(blockNbt, strata.getTopY().intValue());
/* 339 */                 regionData.setBlockState(blockNbt, chunkMd, pos);
/* 340 */                 regionData.setLightValue(blockNbt, lightLevel);
/* 341 */                 if (!blockMD.hasTransparency() || !this.mapTransparency)
/*     */                 {
/*     */                   break;
/*     */                 }
/*     */               }
/* 346 */               else if (y < minY)
/*     */               {
/*     */                 break;
/*     */               }
/*     */             
/*     */             } 
/* 352 */           } else if (strata.isEmpty() && y < minY) {
/*     */             break;
/*     */           } 
/*     */         } 
/*     */         
/* 357 */         y--;
/*     */       } 
/*     */       
/* 360 */       regionData.setBiome(blockNbt, chunkMd.getBiome(chunkMd.getBlockPos(z, y, z)));
/*     */     
/*     */     }
/*     */     finally {
/*     */ 
/*     */       
/* 366 */       if (strata.isEmpty() && lavaBlockMD != null && chunkMd.getWorld().dimension().equals(Level.END)) {
/*     */         
/* 368 */         strata.push(chunkMd, lavaBlockMD, x, topY, z, Integer.valueOf(14));
/* 369 */         BlockPos pos = chunkMd.getBlockPos(x, strata.getTopY().intValue(), z);
/* 370 */         regionData.setBlockState(blockNbt, chunkMd, pos);
/* 371 */         regionData.setY(blockNbt, strata.getTopY().intValue());
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected boolean paintStrata(Strata strata, NativeImage chunkSliceImage, RegionData regionData, CompoundTag blockNbt, ChunkMD chunkMd, Integer vSlice, int x, int y, int z) {
/* 390 */     if (strata.isEmpty() && !chunkMd.fromNbt()) {
/*     */       
/* 392 */       paintBadBlock(chunkSliceImage, x, y, z);
/* 393 */       return false;
/*     */     } 
/*     */ 
/*     */     
/*     */     try {
/* 398 */       if (chunkMd.fromNbt() && strata.isEmpty()) {
/*     */         
/* 400 */         paintBlackBlock(chunkSliceImage, x, z);
/* 401 */         return true;
/*     */       } 
/*     */       
/* 404 */       Stratum stratum = null;
/* 405 */       BlockMD blockMD = null;
/* 406 */       while (!strata.isEmpty()) {
/*     */         
/* 408 */         stratum = strata.nextUp(this, true);
/*     */ 
/*     */         
/* 411 */         if (strata.getRenderCaveColor() == null) {
/*     */           
/* 413 */           strata.setRenderCaveColor(Integer.valueOf(stratum.getCaveColor()));
/*     */         }
/*     */         else {
/*     */           
/* 417 */           strata.setRenderCaveColor(Integer.valueOf(RGB.blendWith(strata.getRenderCaveColor().intValue(), stratum.getCaveColor(), stratum.getBlockMD().getAlpha())));
/*     */         } 
/*     */         
/* 420 */         blockMD = stratum.getBlockMD();
/* 421 */         strata.release(stratum);
/*     */       } 
/*     */ 
/*     */ 
/*     */       
/* 426 */       if (strata.getRenderCaveColor() == null) {
/*     */         
/* 428 */         paintBadBlock(chunkSliceImage, x, y, z);
/* 429 */         return false;
/*     */       } 
/*     */ 
/*     */       
/* 433 */       if (blockMD != null && !blockMD.hasNoShadow()) {
/*     */         
/* 435 */         float slope = getSlope(chunkMd, x, vSlice, z);
/* 436 */         if (slope != 1.0F)
/*     */         {
/* 438 */           strata.setRenderCaveColor(Integer.valueOf(RGB.bevelSlope(strata.getRenderCaveColor().intValue(), slope)));
/*     */         }
/*     */       } 
/*     */ 
/*     */       
/* 443 */       int i = paintBlock(chunkSliceImage, x, z, strata.getRenderCaveColor().intValue());
/*     */     }
/* 445 */     catch (RuntimeException e) {
/*     */       
/* 447 */       paintBadBlock(chunkSliceImage, x, y, z);
/* 448 */       throw e;
/*     */     } 
/*     */     
/* 451 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected Integer getBlockHeight(ChunkMD chunkMd, int x, Integer vSlice, int z, Integer sliceMinY, Integer sliceMaxY) {
/* 460 */     Integer[][] blockSliceHeights = getHeights(chunkMd, vSlice);
/* 461 */     if (blockSliceHeights == null)
/*     */     {
/* 463 */       return null;
/*     */     }
/* 465 */     Integer y = blockSliceHeights[x][z];
/*     */     
/* 467 */     if (y != null)
/*     */     {
/* 469 */       return y;
/*     */     }
/*     */ 
/*     */     
/*     */     try {
/* 474 */       y = Integer.valueOf(Math.min(chunkMd.getHeight(new BlockPos(x, chunkMd.getMinY().intValue(), z)), sliceMaxY.intValue()) - 1);
/* 475 */       if (y.intValue() <= sliceMinY.intValue())
/*     */       {
/* 477 */         return y;
/*     */       }
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 483 */       if (y.intValue() + 1 < sliceMaxY.intValue())
/*     */       {
/*     */         
/* 486 */         while (y.intValue() > chunkMd.getMinY().intValue() && y.intValue() > sliceMinY.intValue()) {
/*     */           
/* 488 */           BlockMD blockMD1 = BlockMD.getBlockMDFromChunkLocal(chunkMd, x, y.intValue() + 1, z);
/* 489 */           if (!blockMD1.isIgnore() && !blockMD1.hasFlag(BlockFlag.OpenToSky)) {
/*     */             break;
/*     */           }
/*     */           
/* 493 */           Integer integer = y; y = Integer.valueOf(y.intValue() - 1);
/*     */         } 
/*     */       }
/* 496 */       BlockMD blockMDAbove = BlockMD.getBlockMDFromChunkLocal(chunkMd, x, y.intValue() + 1, z);
/* 497 */       BlockMD blockMD = BlockMD.getBlockMDFromChunkLocal(chunkMd, x, y.intValue(), z);
/*     */       
/* 499 */       boolean inAirPocket = false;
/*     */       
/* 501 */       while (y.intValue() > chunkMd.getMinY().intValue() && y.intValue() > sliceMinY.intValue())
/*     */       {
/*     */         
/* 504 */         if (this.mapBathymetry && blockMD.isWater()) {
/*     */           
/* 506 */           Integer integer1 = y; y = Integer.valueOf(y.intValue() - 1);
/*     */         } 
/*     */         
/* 509 */         inAirPocket = blockMD.isIgnore();
/*     */         
/* 511 */         if (blockMDAbove.isIgnore() || blockMDAbove.hasTransparency() || blockMDAbove.hasFlag(BlockFlag.OpenToSky))
/*     */         {
/* 513 */           if (!blockMD.isIgnore() || !blockMD.hasTransparency() || !blockMD.hasFlag(BlockFlag.OpenToSky)) {
/*     */             break;
/*     */           }
/*     */         }
/*     */ 
/*     */         
/* 519 */         Integer integer = y; y = Integer.valueOf(y.intValue() - 1);
/*     */         
/* 521 */         blockMD = BlockMD.getBlockMDFromChunkLocal(chunkMd, x, y.intValue(), z);
/* 522 */         blockMDAbove = BlockMD.getBlockMDFromChunkLocal(chunkMd, x, y.intValue() + 1, z);
/*     */         
/* 524 */         if (y.intValue() < sliceMinY.intValue() && !inAirPocket) {
/*     */           break;
/*     */         }
/*     */       }
/*     */     
/*     */     }
/* 530 */     catch (Exception e) {
/*     */       
/* 532 */       Journeymap.getLogger().warn("Couldn't get safe slice block height at " + x + "," + z + ": " + String.valueOf(e));
/* 533 */       y = sliceMaxY;
/*     */     } 
/*     */     
/* 536 */     y = Integer.valueOf(Math.max(chunkMd.getMinY().intValue(), y.intValue()));
/*     */     
/* 538 */     blockSliceHeights[x][z] = y;
/* 539 */     return y;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected int getSliceLightLevel(ChunkMD chunkMd, int x, int y, int z, boolean adjusted) {
/* 554 */     return this.mapCaveLighting ? chunkMd.getSavedLightValue(x, y + 1, z) : 15;
/*     */   }
/*     */ }


/* Location:              C:\Users\Administrator\Downloads\journeymap-neoforge-1.21-6.0.0-beta.18.jar!\journeymap\client\cartography\render\CaveRenderer.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */