/*    */ package journeymap.client.cartography.render;
/*    */ 
/*    */ import journeymap.client.cartography.IChunkRenderer;
/*    */ import journeymap.client.cartography.color.RGB;
/*    */ import journeymap.client.model.ChunkMD;
/*    */ import journeymap.client.model.MapType;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class NetherSurfaceRenderer
/*    */   extends SurfaceRenderer
/*    */   implements IChunkRenderer
/*    */ {
/*    */   protected boolean updateOptions(ChunkMD chunkMd, MapType mapType) {
/* 17 */     if (super.updateOptions(chunkMd, mapType)) {
/*    */       
/* 19 */       this.ambientColor = RGB.floats(this.tweakNetherAmbientColor);
/* 20 */       return true;
/*    */     } 
/* 22 */     return false;
/*    */   }
/*    */ }


/* Location:              C:\Users\Administrator\Downloads\journeymap-neoforge-1.21-6.0.0-beta.18.jar!\journeymap\client\cartography\render\NetherSurfaceRenderer.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */