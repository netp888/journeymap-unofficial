/*     */ package journeymap.client.cartography.render;
/*     */ 
/*     */ import com.mojang.blaze3d.platform.NativeImage;
/*     */ import journeymap.client.cartography.IChunkRenderer;
/*     */ import journeymap.client.cartography.color.RGB;
/*     */ import journeymap.client.log.JMLogger;
/*     */ import journeymap.client.log.StatTimer;
/*     */ import journeymap.client.model.BlockMD;
/*     */ import journeymap.client.model.ChunkMD;
/*     */ import journeymap.client.model.MapType;
/*     */ import journeymap.client.texture.ComparableNativeImage;
/*     */ import journeymap.common.Journeymap;
/*     */ import journeymap.common.log.LogFormatter;
/*     */ import journeymap.common.nbt.RegionData;
/*     */ import net.minecraft.core.BlockPos;
/*     */ import net.minecraft.nbt.CompoundTag;
/*     */ import net.minecraft.world.level.Level;
/*     */ import net.minecraft.world.level.biome.Biome;
/*     */ import org.apache.logging.log4j.Level;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class BiomeRenderer
/*     */   extends SurfaceRenderer
/*     */   implements IChunkRenderer
/*     */ {
/*     */   private static final String DEFAULT_LAND_CONTOUR_COLOR = "#3F250B";
/*  33 */   protected StatTimer renderTopoTimer = StatTimer.get("BiomeRenderer.renderSurface");
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean render(ComparableNativeImage chunkImage, RegionData regionData, ChunkMD chunkMd, Integer vSlice) {
/*  47 */     StatTimer timer = this.renderTopoTimer;
/*     */     
/*     */     try {
/*  50 */       timer.start();
/*     */       
/*  52 */       updateOptions(chunkMd, MapType.from(MapType.Name.biome, null, chunkMd.getDimension()));
/*  53 */       return renderSurface((NativeImage)chunkImage, regionData, chunkMd, vSlice, false);
/*     */     }
/*  55 */     catch (Throwable t) {
/*     */       
/*  57 */       JMLogger.throwLogOnce("Chunk Error", t);
/*  58 */       return false;
/*     */     
/*     */     }
/*     */     finally {
/*     */       
/*  63 */       timer.stop();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected boolean renderSurface(NativeImage chunkImage, RegionData regionData, ChunkMD chunkMd, Integer vSlice, boolean cavePrePass) {
/*  72 */     boolean chunkOk = false;
/*     */ 
/*     */ 
/*     */     
/*     */     try {
/*  77 */       CompoundTag chunkNbt = regionData.getChunkNbt(chunkMd.getCoord());
/*  78 */       for (int x = 0; x < 16; x++) {
/*     */ 
/*     */         
/*  81 */         for (int z = 0; z < 16; z++) {
/*     */ 
/*     */ 
/*     */           
/*  85 */           CompoundTag blockNbt = regionData.getBlockDataFromBlockPos(chunkMd.getCoord(), chunkNbt, x, z);
/*  86 */           BlockMD topBlockMd = null;
/*  87 */           int y = Math.max(0, getBlockHeight(chunkMd, x, (Integer)null, z, (Integer)null, (Integer)null).intValue());
/*     */           
/*  89 */           topBlockMd = chunkMd.getBlockMD(x, y, z);
/*  90 */           if (topBlockMd == null) {
/*     */             
/*  92 */             paintBadBlock(chunkImage, x, y, z);
/*     */           }
/*     */           else {
/*     */             
/*  96 */             chunkOk = (paintBiome(chunkImage, regionData, blockNbt, chunkMd, topBlockMd, x, y, z) || chunkOk);
/*     */           } 
/*     */         } 
/*     */       } 
/* 100 */       regionData.writeChunk(chunkMd.getCoord(), chunkNbt);
/*     */     }
/* 102 */     catch (Throwable t) {
/*     */       
/* 104 */       Journeymap.getLogger().log(Level.WARN, "Error in renderSurface: " + LogFormatter.toString(t));
/*     */     } 
/*     */     
/* 107 */     return chunkOk;
/*     */   }
/*     */ 
/*     */   
/*     */   private boolean paintBiome(NativeImage chunkImage, RegionData regionData, CompoundTag blockNbt, ChunkMD chunkMd, BlockMD topBlockMd, int x, int y, int z) {
/* 112 */     if (!chunkMd.hasChunk())
/*     */     {
/* 114 */       return false;
/*     */     }
/* 116 */     BlockPos blockPos = chunkMd.getBlockPos(x, y, z);
/* 117 */     Biome biome = chunkMd.getBiome(blockPos);
/* 118 */     if (biome == null)
/*     */     {
/* 120 */       return false;
/*     */     }
/*     */     
/*     */     try {
/*     */       Integer color;
/* 125 */       boolean isWater = (topBlockMd.isWater() || topBlockMd.isIce());
/* 126 */       boolean isFoliage = topBlockMd.isFoliage();
/* 127 */       int contourColor = RGB.hexToInt("#3F250B");
/*     */ 
/*     */       
/* 130 */       if (isBiomeEdge(chunkMd, blockPos, biome)) {
/*     */         
/* 132 */         color = Integer.valueOf(contourColor);
/*     */       }
/* 134 */       else if (topBlockMd.isLava()) {
/*     */ 
/*     */         
/* 137 */         color = Integer.valueOf(topBlockMd.getTextureColor());
/*     */       }
/* 139 */       else if (isWater) {
/*     */         
/* 141 */         color = Integer.valueOf(biome.getWaterColor());
/*     */       
/*     */       }
/* 144 */       else if (isFoliage) {
/*     */         
/* 146 */         color = Integer.valueOf(biome.getFoliageColor());
/*     */       }
/* 148 */       else if (chunkMd.getDimension().equals(Level.NETHER)) {
/*     */         
/* 150 */         color = Integer.valueOf(biome.getFogColor());
/*     */       }
/*     */       else {
/*     */         
/* 154 */         color = Integer.valueOf(biome.getGrassColor((chunkMd.getCoord()).x, (chunkMd.getCoord()).z));
/*     */       } 
/*     */       
/* 157 */       int blockColor = paintBlock(chunkImage, x, z, color.intValue());
/* 158 */       regionData.setBlockColor(blockNbt, blockColor, MapType.Name.biome);
/*     */     }
/* 160 */     catch (Exception e) {
/*     */       
/* 162 */       e.printStackTrace();
/*     */     } 
/*     */     
/* 165 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean isBiomeEdge(ChunkMD chunkMD, BlockPos pos, Biome blockBiome) {
/* 191 */     return false;
/*     */   }
/*     */ }


/* Location:              C:\Users\Administrator\Downloads\journeymap-neoforge-1.21-6.0.0-beta.18.jar!\journeymap\client\cartography\render\BiomeRenderer.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */