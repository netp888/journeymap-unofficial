/*     */ package journeymap.client.cartography.render;
/*     */ 
/*     */ import com.mojang.blaze3d.platform.NativeImage;
/*     */ import java.awt.Color;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.concurrent.atomic.AtomicLong;
/*     */ import journeymap.client.JourneymapClient;
/*     */ import journeymap.client.cartography.IChunkRenderer;
/*     */ import journeymap.client.cartography.Stratum;
/*     */ import journeymap.client.cartography.color.RGB;
/*     */ import journeymap.client.data.DataCache;
/*     */ import journeymap.client.model.BlockCoordIntPair;
/*     */ import journeymap.client.model.ChunkMD;
/*     */ import journeymap.client.model.MapType;
/*     */ import journeymap.client.properties.CoreProperties;
/*     */ import journeymap.client.properties.RenderingProperties;
/*     */ import journeymap.common.Journeymap;
/*     */ import net.minecraft.core.BlockPos;
/*     */ import net.minecraft.world.level.ChunkPos;
/*     */ import net.minecraft.world.level.block.Block;
/*     */ import net.minecraft.world.level.block.Blocks;
/*     */ import net.minecraft.world.level.block.RedstoneLampBlock;
/*     */ import net.minecraft.world.level.block.state.BlockState;
/*     */ import net.minecraft.world.level.block.state.properties.Property;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class BaseRenderer
/*     */   implements IChunkRenderer
/*     */ {
/*  43 */   public static final int COLOR_BLACK = Color.black.getRGB();
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  48 */   public static volatile AtomicLong badBlockCount = new AtomicLong(0L);
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  53 */   protected static final float[] DEFAULT_FOG = new float[] { 0.0F, 0.0F, 0.1F };
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  58 */   protected final DataCache dataCache = DataCache.INSTANCE;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected CoreProperties coreProperties;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected boolean mapBathymetry;
/*     */ 
/*     */ 
/*     */   
/*     */   protected boolean mapTransparency;
/*     */ 
/*     */ 
/*     */   
/*     */   protected boolean mapCaveLighting;
/*     */ 
/*     */ 
/*     */   
/*     */   protected boolean mapAntialiasing;
/*     */ 
/*     */ 
/*     */   
/*     */   protected float[] ambientColor;
/*     */ 
/*     */ 
/*     */   
/*     */   protected long lastPropFileUpdate;
/*     */ 
/*     */ 
/*     */   
/*  92 */   protected ArrayList<BlockCoordIntPair> primarySlopeOffsets = new ArrayList<>(3);
/*     */ 
/*     */ 
/*     */   
/*  96 */   protected ArrayList<BlockCoordIntPair> secondarySlopeOffsets = new ArrayList<>(4);
/*     */ 
/*     */ 
/*     */   
/*     */   protected float shadingSlopeMin;
/*     */ 
/*     */ 
/*     */   
/*     */   protected float shadingSlopeMax;
/*     */ 
/*     */ 
/*     */   
/*     */   protected float shadingPrimaryDownslopeMultiplier;
/*     */ 
/*     */ 
/*     */   
/*     */   protected float shadingPrimaryUpslopeMultiplier;
/*     */ 
/*     */ 
/*     */   
/*     */   protected float shadingSecondaryDownslopeMultiplier;
/*     */ 
/*     */ 
/*     */   
/*     */   protected float shadingSecondaryUpslopeMultiplier;
/*     */ 
/*     */ 
/*     */   
/*     */   protected float tweakMoonlightLevel;
/*     */ 
/*     */ 
/*     */   
/*     */   protected float tweakBrightenDaylightDiff;
/*     */ 
/*     */ 
/*     */   
/*     */   protected float tweakBrightenLightsourceBlock;
/*     */ 
/*     */ 
/*     */   
/*     */   protected float tweakMinimumDarkenNightWater;
/*     */ 
/*     */ 
/*     */   
/*     */   protected float tweakWaterColorBlend;
/*     */ 
/*     */ 
/*     */   
/*     */   protected int tweakSurfaceAmbientColor;
/*     */ 
/*     */ 
/*     */   
/*     */   protected int tweakNetherAmbientColor;
/*     */ 
/*     */   
/*     */   protected int tweakEndAmbientColor;
/*     */ 
/*     */   
/*     */   private static final String PROP_SLOPES = "slopes";
/*     */ 
/*     */   
/*     */   private static final String PROP_HEIGHTS = "heights";
/*     */ 
/*     */   
/*     */   private static final String PROP_WATER_HEIGHTS = "waterHeights";
/*     */ 
/*     */   
/*     */   private MapType currentMapType;
/*     */ 
/*     */ 
/*     */   
/*     */   public BaseRenderer() {
/* 168 */     updateOptions(null, null);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 188 */     this.primarySlopeOffsets.add(new BlockCoordIntPair(0, -1));
/* 189 */     this.primarySlopeOffsets.add(new BlockCoordIntPair(-1, -1));
/* 190 */     this.primarySlopeOffsets.add(new BlockCoordIntPair(-1, 0));
/*     */     
/* 192 */     this.secondarySlopeOffsets.add(new BlockCoordIntPair(-1, -2));
/* 193 */     this.secondarySlopeOffsets.add(new BlockCoordIntPair(-2, -1));
/* 194 */     this.secondarySlopeOffsets.add(new BlockCoordIntPair(-2, -2));
/* 195 */     this.secondarySlopeOffsets.add(new BlockCoordIntPair(-2, 0));
/* 196 */     this.secondarySlopeOffsets.add(new BlockCoordIntPair(0, -2));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected boolean updateOptions(ChunkMD chunkMd, MapType mapType) {
/* 208 */     this.currentMapType = mapType;
/*     */     
/* 210 */     boolean updateNeeded = false;
/* 211 */     this.coreProperties = JourneymapClient.getInstance().getCoreProperties();
/* 212 */     RenderingProperties renderingProperties = JourneymapClient.getInstance().getRenderingProperties();
/* 213 */     long lastUpdate = Math.max(this.coreProperties.lastModified(), renderingProperties.lastModified());
/* 214 */     if (lastUpdate == 0L || this.lastPropFileUpdate != lastUpdate) {
/*     */       
/* 216 */       updateNeeded = true;
/* 217 */       this.lastPropFileUpdate = lastUpdate;
/* 218 */       this.mapBathymetry = this.coreProperties.mapBathymetry.get().booleanValue();
/* 219 */       this.mapTransparency = this.coreProperties.mapTransparency.get().booleanValue();
/* 220 */       this.mapAntialiasing = this.coreProperties.mapAntialiasing.get().booleanValue();
/* 221 */       this.mapCaveLighting = this.coreProperties.mapCaveLighting.get().booleanValue();
/*     */       
/* 223 */       this.shadingSlopeMin = renderingProperties.shadingSlopeMin.get().floatValue();
/* 224 */       this.shadingSlopeMax = renderingProperties.shadingSlopeMax.get().floatValue();
/* 225 */       this.shadingPrimaryDownslopeMultiplier = renderingProperties.shadingPrimaryDownslopeMultiplier.get().floatValue();
/* 226 */       this.shadingPrimaryUpslopeMultiplier = renderingProperties.shadingPrimaryUpslopeMultiplier.get().floatValue();
/* 227 */       this.shadingSecondaryDownslopeMultiplier = renderingProperties.shadingSecondaryDownslopeMultiplier.get().floatValue();
/* 228 */       this.shadingSecondaryUpslopeMultiplier = renderingProperties.shadingSecondaryUpslopeMultiplier.get().floatValue();
/*     */       
/* 230 */       this.tweakMoonlightLevel = renderingProperties.tweakMoonlightLevel.get().floatValue();
/* 231 */       this.tweakBrightenDaylightDiff = renderingProperties.tweakBrightenDaylightDiff.get().floatValue();
/* 232 */       this.tweakBrightenLightsourceBlock = renderingProperties.tweakBrightenLightsourceBlock.get().floatValue();
/* 233 */       this.tweakMinimumDarkenNightWater = renderingProperties.tweakMinimumDarkenNightWater.get().floatValue();
/* 234 */       this.tweakWaterColorBlend = renderingProperties.tweakWaterColorBlend.get().floatValue();
/* 235 */       this.tweakSurfaceAmbientColor = RGB.hexToInt(renderingProperties.tweakSurfaceAmbientColor.getAsString());
/* 236 */       this.tweakNetherAmbientColor = RGB.hexToInt(renderingProperties.tweakNetherAmbientColor.getAsString());
/* 237 */       this.tweakEndAmbientColor = RGB.hexToInt(renderingProperties.tweakEndAmbientColor.getAsString());
/*     */ 
/*     */       
/* 240 */       this.ambientColor = new float[] { 0.0F, 0.0F, 0.0F };
/*     */     } 
/*     */     
/* 243 */     if (chunkMd != null) {
/*     */       
/* 245 */       Long lastChunkUpdate = (Long)chunkMd.getProperty("lastPropFileUpdate", Long.valueOf(this.lastPropFileUpdate));
/* 246 */       updateNeeded = true;
/* 247 */       chunkMd.resetBlockData(getCurrentMapType());
/* 248 */       chunkMd.setProperty("lastPropFileUpdate", lastChunkUpdate);
/*     */     } 
/*     */     
/* 251 */     return updateNeeded;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public float[] getAmbientColor() {
/* 257 */     return DEFAULT_FOG;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setStratumColors(Stratum stratum, int lightAttenuation, Integer waterColor, boolean waterAbove, boolean underground, boolean mapCaveLighting) {
/*     */     float daylightDiff, nightLightDiff;
/* 263 */     if (stratum.isUninitialized())
/*     */     {
/* 265 */       throw new IllegalStateException("Stratum wasn't initialized for setStratumColors");
/*     */     }
/*     */ 
/*     */     
/* 269 */     float dayAmbient = 15.0F;
/*     */ 
/*     */     
/* 272 */     boolean noSky = stratum.getWorldHasNoSky();
/* 273 */     if (noSky) {
/*     */       
/* 275 */       dayAmbient = stratum.getWorldAmbientLight();
/* 276 */       daylightDiff = Math.max(1.0F, Math.max(stratum.getLightLevel(), dayAmbient - lightAttenuation)) / 15.0F;
/* 277 */       nightLightDiff = daylightDiff;
/*     */     }
/*     */     else {
/*     */       
/* 281 */       daylightDiff = Math.max(1.0F, Math.max(stratum.getLightLevel(), dayAmbient - lightAttenuation)) / 15.0F;
/* 282 */       daylightDiff += this.tweakBrightenDaylightDiff;
/*     */       
/* 284 */       nightLightDiff = Math.max(this.tweakMoonlightLevel, Math.max(stratum.getLightLevel(), this.tweakMoonlightLevel - lightAttenuation)) / 15.0F;
/*     */     } 
/*     */     
/* 287 */     int basicColor = stratum.getBlockMD().getBlockColor(stratum.getChunkMd(), stratum.getBlockPos());
/*     */     
/* 289 */     Block block = stratum.getBlockMD().getBlockState().getBlock();
/* 290 */     BlockState state = stratum.getBlockMD().getBlockState();
/* 291 */     if (block == Blocks.GLOWSTONE || (block == Blocks.REDSTONE_LAMP && ((Boolean)state.getValue((Property)RedstoneLampBlock.LIT)).booleanValue()))
/*     */     {
/* 293 */       basicColor = RGB.adjustBrightness(basicColor, this.tweakBrightenLightsourceBlock);
/*     */     }
/*     */     
/* 296 */     if (waterAbove && waterColor != null) {
/*     */ 
/*     */ 
/*     */       
/* 300 */       int adjustedWaterColor = waterColor.intValue();
/* 301 */       int adjustedBasicColor = RGB.adjustBrightness(basicColor, Math.max(daylightDiff, nightLightDiff));
/* 302 */       stratum.setDayColor(RGB.blendWith(adjustedBasicColor, adjustedWaterColor, this.tweakWaterColorBlend));
/*     */       
/* 304 */       if (noSky)
/*     */       {
/* 306 */         stratum.setNightColor(stratum.getDayColor());
/*     */       
/*     */       }
/*     */       else
/*     */       {
/* 311 */         stratum.setNightColor(RGB.adjustBrightness(stratum.getDayColor(), Math.max(nightLightDiff, this.tweakMinimumDarkenNightWater)));
/*     */       }
/*     */     
/*     */     } else {
/*     */       
/* 316 */       stratum.setDayColor(RGB.adjustBrightness(basicColor, daylightDiff));
/* 317 */       if (noSky) {
/*     */         
/* 319 */         stratum.setNightColor(stratum.getDayColor());
/*     */       
/*     */       }
/*     */       else {
/*     */         
/* 324 */         stratum.setNightColor(RGB.darkenAmbient(basicColor, nightLightDiff, getAmbientColor()));
/*     */       } 
/*     */     } 
/*     */     
/* 328 */     if (underground)
/*     */     {
/* 330 */       stratum.setCaveColor(mapCaveLighting ? stratum.getNightColor() : stratum.getDayColor());
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected Float[][] populateSlopes(ChunkMD chunkMd, Integer vSlice, Float[][] slopes) {
/* 346 */     int sliceMinY = 0, sliceMaxY = 0;
/* 347 */     boolean isSurface = (vSlice == null);
/*     */ 
/*     */     
/* 350 */     if (!isSurface) {
/*     */       
/* 352 */       int[] sliceBounds = getVSliceBounds(chunkMd, vSlice);
/* 353 */       sliceMinY = sliceBounds[0];
/* 354 */       sliceMaxY = sliceBounds[1];
/*     */     } 
/*     */     
/* 357 */     for (int z = 0; z < 16; z++) {
/*     */       
/* 359 */       for (int x = 0; x < 16; x++) {
/*     */         
/* 361 */         int y = getBlockHeight(chunkMd, x, vSlice, z, Integer.valueOf(sliceMinY), Integer.valueOf(sliceMaxY)).intValue();
/*     */ 
/*     */         
/* 364 */         float primarySlope = calculateSlope(chunkMd, this.primarySlopeOffsets, x, y, z, isSurface, vSlice, sliceMinY, sliceMaxY);
/*     */ 
/*     */         
/* 367 */         float slope = primarySlope;
/* 368 */         if (slope < 1.0F) {
/*     */           
/* 370 */           slope *= this.shadingPrimaryDownslopeMultiplier;
/*     */         }
/* 372 */         else if (slope > 1.0F) {
/*     */           
/* 374 */           slope *= this.shadingPrimaryUpslopeMultiplier;
/*     */         } 
/*     */ 
/*     */         
/* 378 */         if (this.mapAntialiasing && primarySlope == 1.0F) {
/*     */           
/* 380 */           float secondarySlope = calculateSlope(chunkMd, this.secondarySlopeOffsets, x, y, z, isSurface, vSlice, sliceMinY, sliceMaxY);
/*     */           
/* 382 */           if (secondarySlope > primarySlope) {
/*     */             
/* 384 */             slope *= this.shadingSecondaryUpslopeMultiplier;
/*     */           }
/* 386 */           else if (secondarySlope < primarySlope) {
/*     */             
/* 388 */             slope *= this.shadingSecondaryDownslopeMultiplier;
/*     */           } 
/*     */         } 
/*     */ 
/*     */         
/* 393 */         if (Float.isNaN(slope))
/*     */         {
/* 395 */           slope = 1.0F;
/*     */         }
/*     */         
/* 398 */         slopes[x][z] = Float.valueOf(Math.min(this.shadingSlopeMax, Math.max(this.shadingSlopeMin, slope)));
/*     */       } 
/*     */     } 
/*     */     
/* 402 */     return slopes;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected MapType getCurrentMapType() {
/* 413 */     return this.currentMapType;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public abstract int getBlockHeight(ChunkMD paramChunkMD, BlockPos paramBlockPos);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected abstract Integer getBlockHeight(ChunkMD paramChunkMD, int paramInt1, Integer paramInteger1, int paramInt2, Integer paramInteger2, Integer paramInteger3);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected int getOffsetBlockHeight(ChunkMD chunkMd, int x, Integer vSlice, int z, Integer sliceMinY, Integer sliceMaxY, BlockCoordIntPair offset, int defaultVal) {
/*     */     ChunkMD targetChunkMd;
/* 454 */     int blockX = ((chunkMd.getCoord()).x << 4) + x + offset.x;
/* 455 */     int blockZ = ((chunkMd.getCoord()).z << 4) + z + offset.z;
/*     */     
/* 457 */     long targetCoord = ChunkPos.asLong(blockX >> 4, blockZ >> 4);
/*     */ 
/*     */     
/* 460 */     if (targetCoord == chunkMd.getLongCoord()) {
/*     */       
/* 462 */       targetChunkMd = chunkMd;
/*     */     }
/*     */     else {
/*     */       
/* 466 */       targetChunkMd = this.dataCache.getChunkMD(targetCoord);
/*     */     } 
/*     */     
/* 469 */     if (targetChunkMd != null)
/*     */     {
/* 471 */       return getBlockHeight(targetChunkMd, blockX & 0xF, vSlice, blockZ & 0xF, sliceMinY, sliceMaxY).intValue();
/*     */     }
/*     */ 
/*     */     
/* 475 */     return defaultVal;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected float calculateSlope(ChunkMD chunkMd, Collection<BlockCoordIntPair> offsets, int x, int y, int z, boolean isSurface, Integer vSlice, int sliceMinY, int sliceMaxY) {
/* 496 */     if (y <= chunkMd.getMinY().intValue())
/*     */     {
/*     */       
/* 499 */       return 1.0F;
/*     */     }
/* 501 */     int relY = y - chunkMd.getMinY().intValue();
/*     */ 
/*     */     
/* 504 */     float slopeSum = 0.0F;
/*     */     
/* 506 */     for (BlockCoordIntPair offset : offsets) {
/*     */       
/* 508 */       float offsetHeight = getOffsetBlockHeight(chunkMd, x, vSlice, z, Integer.valueOf(sliceMinY), Integer.valueOf(sliceMaxY), offset, y);
/*     */       
/* 510 */       if (offsetHeight < 0.0F) {
/*     */         
/* 512 */         slopeSum += (offsetHeight - relY) / (y - relY) * 1.0F;
/*     */         
/*     */         continue;
/*     */       } 
/* 516 */       slopeSum += (y + relY) * 1.0F / (offsetHeight + relY);
/*     */     } 
/*     */     
/* 519 */     float slope = slopeSum / offsets.size();
/* 520 */     if (Float.isNaN(slope))
/*     */     {
/* 522 */       slope = 1.0F;
/*     */     }
/* 524 */     return slope;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected int[] getVSliceBounds(ChunkMD chunkMd, Integer vSlice) {
/* 537 */     if (vSlice == null)
/*     */     {
/* 539 */       return null;
/*     */     }
/*     */ 
/*     */     
/* 543 */     int sliceMinY = vSlice.intValue() << 4;
/* 544 */     int hardSliceMaxY = (vSlice.intValue() + 1 << 4) - 1;
/* 545 */     int sliceMaxY = Math.min(hardSliceMaxY, chunkMd.getWorld().dimensionType().logicalHeight());
/* 546 */     if (sliceMinY >= sliceMaxY)
/*     */     {
/* 548 */       sliceMaxY = sliceMinY + 2;
/*     */     }
/*     */     
/* 551 */     return new int[] { sliceMinY, sliceMaxY };
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected float getSlope(ChunkMD chunkMd, int x, Integer vSlice, int z) {
/* 565 */     Float[][] slopes = getSlopes(chunkMd, vSlice);
/*     */     
/* 567 */     Float slope = slopes[x][z];
/* 568 */     if (slope == null) {
/*     */       
/* 570 */       populateSlopes(chunkMd, vSlice, slopes);
/* 571 */       slope = slopes[x][z];
/*     */     } 
/*     */     
/* 574 */     if (slope == null || slope.isNaN()) {
/*     */       
/* 576 */       Journeymap.getLogger().warn(String.format("Bad slope for %s at %s,%s: %s", new Object[] { chunkMd.getCoord(), Integer.valueOf(x), Integer.valueOf(z), slope }));
/* 577 */       slope = Float.valueOf(1.0F);
/*     */     } 
/* 579 */     return slope.floatValue();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected final String getKey(String propName, Integer vSlice) {
/* 591 */     return (vSlice == null) ? propName : (propName + propName);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected final Integer[][] getHeights(ChunkMD chunkMd, Integer vSlice) {
/* 603 */     return (Integer[][])chunkMd.getBlockDataInts(getCurrentMapType()).get(getKey("heights", vSlice));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected final boolean hasHeights(ChunkMD chunkMd, Integer vSlice) {
/* 615 */     return chunkMd.getBlockDataInts(getCurrentMapType()).has(getKey("heights", vSlice));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected final void resetHeights(ChunkMD chunkMd, Integer vSlice) {
/* 626 */     chunkMd.getBlockDataInts(getCurrentMapType()).clear(getKey("heights", vSlice));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected final Float[][] getSlopes(ChunkMD chunkMd, Integer vSlice) {
/* 638 */     return (Float[][])chunkMd.getBlockDataFloats(getCurrentMapType()).get(getKey("slopes", vSlice));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected final boolean hasSlopes(ChunkMD chunkMd, Integer vSlice) {
/* 650 */     return chunkMd.getBlockDataFloats(getCurrentMapType()).has(getKey("slopes", vSlice));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected final void resetSlopes(ChunkMD chunkMd, Integer vSlice) {
/* 661 */     chunkMd.getBlockDataFloats(getCurrentMapType()).clear(getKey("slopes", vSlice));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected final Integer[][] getFluidHeights(ChunkMD chunkMd, Integer vSlice) {
/* 673 */     return (Integer[][])chunkMd.getBlockDataInts(getCurrentMapType()).get(getKey("waterHeights", vSlice));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected final boolean hasWaterHeights(ChunkMD chunkMd, Integer vSlice) {
/* 685 */     return chunkMd.getBlockDataInts(getCurrentMapType()).has(getKey("waterHeights", vSlice));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected final void resetWaterHeights(ChunkMD chunkMd, Integer vSlice) {
/* 696 */     chunkMd.getBlockDataInts(getCurrentMapType()).clear(getKey("waterHeights", vSlice));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ChunkMD getOffsetChunk(ChunkMD chunkMd, int x, int z, BlockCoordIntPair offset) {
/* 710 */     int blockX = ((chunkMd.getCoord()).x << 4) + x + offset.x;
/* 711 */     int blockZ = ((chunkMd.getCoord()).z << 4) + z + offset.z;
/*     */     
/* 713 */     long targetCoord = ChunkPos.asLong(blockX >> 4, blockZ >> 4);
/*     */     
/* 715 */     if (targetCoord == chunkMd.getLongCoord())
/*     */     {
/* 717 */       return chunkMd;
/*     */     }
/*     */ 
/*     */     
/* 721 */     return this.dataCache.getChunkMD(targetCoord);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void paintDimOverlay(NativeImage image, int x, int z, float alpha) {
/* 735 */     int color = image.getPixelRGBA(x, z);
/* 736 */     paintBlock(image, x, z, RGB.adjustBrightness(color, alpha));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int paintDimOverlay(NativeImage sourceImage, NativeImage targetImage, int x, int z, float alpha) {
/* 750 */     int color = sourceImage.getPixelRGBA(x, z);
/* 751 */     targetImage.blendPixel(x, z, RGB.adjustBrightness(color, alpha));
/* 752 */     return RGB.adjustBrightness(color, alpha);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int paintBlock(NativeImage image, int x, int z, int color) {
/* 766 */     image.setPixelRGBA(x, z, RGB.toRgba(color, 1.0F));
/* 767 */     return 0xFF000000 | color;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int paintVoidBlock(NativeImage image, int x, int z) {
/* 779 */     paintBlock(image, x, z, RGB.toInteger(getAmbientColor()));
/* 780 */     return RGB.toInteger(getAmbientColor());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int paintBlackBlock(NativeImage image, int x, int z) {
/* 792 */     paintBlock(image, x, z, COLOR_BLACK);
/* 793 */     return COLOR_BLACK;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int paintClearBlock(NativeImage image, int x, int z) {
/* 805 */     int clear = RGB.toRgba(COLOR_BLACK, 0.0F);
/* 806 */     image.setPixelRGBA(x, z, clear);
/* 807 */     return clear;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void paintBadBlock(NativeImage image, int x, int y, int z) {
/* 820 */     long count = badBlockCount.incrementAndGet();
/* 821 */     if (count == 1L || count % 2046L == 0L)
/*     */     {
/* 823 */       Journeymap.getLogger().warn("Bad block at " + x + "," + y + "," + z + ". Total bad blocks: " + count);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\Administrator\Downloads\journeymap-neoforge-1.21-6.0.0-beta.18.jar!\journeymap\client\cartography\render\BaseRenderer.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */