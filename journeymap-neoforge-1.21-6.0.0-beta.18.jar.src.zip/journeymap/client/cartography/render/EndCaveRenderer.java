/*    */ package journeymap.client.cartography.render;
/*    */ 
/*    */ import journeymap.client.cartography.IChunkRenderer;
/*    */ import journeymap.client.cartography.color.RGB;
/*    */ import journeymap.client.model.ChunkMD;
/*    */ import journeymap.client.model.MapType;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class EndCaveRenderer
/*    */   extends CaveRenderer
/*    */   implements IChunkRenderer
/*    */ {
/*    */   public EndCaveRenderer(SurfaceRenderer endSurfaceRenderer) {
/* 25 */     super(endSurfaceRenderer);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   protected boolean updateOptions(ChunkMD chunkMd, MapType mapType) {
/* 31 */     if (super.updateOptions(chunkMd, mapType)) {
/*    */       
/* 33 */       this.ambientColor = RGB.floats(this.tweakEndAmbientColor);
/* 34 */       return true;
/*    */     } 
/* 36 */     return false;
/*    */   }
/*    */ 
/*    */   
/*    */   protected int getSliceLightLevel(ChunkMD chunkMd, int x, int y, int z, boolean adjusted) {
/* 41 */     return this.mapCaveLighting ? Math.max(adjusted ? (int)this.surfaceRenderer.tweakMoonlightLevel : 0, chunkMd.getSavedLightValue(x, y + 1, z)) : 15;
/*    */   }
/*    */ }


/* Location:              C:\Users\Administrator\Downloads\journeymap-neoforge-1.21-6.0.0-beta.18.jar!\journeymap\client\cartography\render\EndCaveRenderer.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */