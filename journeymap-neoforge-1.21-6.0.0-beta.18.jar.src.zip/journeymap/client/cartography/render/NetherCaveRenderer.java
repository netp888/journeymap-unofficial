/*     */ package journeymap.client.cartography.render;
/*     */ 
/*     */ import journeymap.client.cartography.IChunkRenderer;
/*     */ import journeymap.client.cartography.color.RGB;
/*     */ import journeymap.client.model.BlockFlag;
/*     */ import journeymap.client.model.BlockMD;
/*     */ import journeymap.client.model.ChunkMD;
/*     */ import journeymap.client.model.MapType;
/*     */ import journeymap.common.Journeymap;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class NetherCaveRenderer
/*     */   extends CaveRenderer
/*     */   implements IChunkRenderer
/*     */ {
/*     */   public NetherCaveRenderer() {
/*  26 */     super((SurfaceRenderer)null);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected boolean updateOptions(ChunkMD chunkMd, MapType mapType) {
/*  32 */     if (super.updateOptions(chunkMd, mapType)) {
/*     */       
/*  34 */       this.ambientColor = RGB.floats(this.tweakNetherAmbientColor);
/*  35 */       this.mapSurfaceAboveCaves = false;
/*  36 */       return true;
/*     */     } 
/*  38 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected Integer getBlockHeight(ChunkMD chunkMd, int x, Integer vSlice, int z, Integer sliceMinY, Integer sliceMaxY) {
/*  47 */     Integer[][] blockSliceHeights = getHeights(chunkMd, vSlice);
/*  48 */     if (blockSliceHeights == null)
/*     */     {
/*  50 */       return null;
/*     */     }
/*     */     
/*  53 */     Integer intY = blockSliceHeights[x][z];
/*     */     
/*  55 */     if (intY != null)
/*     */     {
/*  57 */       return intY;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     try {
/*  64 */       y = sliceMaxY.intValue();
/*     */       
/*  66 */       BlockMD blockMD = BlockMD.getBlockMDFromChunkLocal(chunkMd, x, y, z);
/*  67 */       BlockMD blockMDAbove = BlockMD.getBlockMDFromChunkLocal(chunkMd, x, Math.min(y + 1, sliceMaxY.intValue()), z);
/*     */       
/*  69 */       while (y > 0)
/*     */       {
/*  71 */         if (blockMD.isLava()) {
/*     */           break;
/*     */         }
/*     */ 
/*     */         
/*  76 */         if (blockMDAbove.isIgnore() || blockMDAbove.hasTransparency() || blockMDAbove.hasFlag(BlockFlag.OpenToSky)) {
/*     */           
/*  78 */           if (!blockMD.isIgnore() && !blockMD.hasTransparency() && !blockMD.hasFlag(BlockFlag.OpenToSky))
/*     */           {
/*     */             break;
/*     */           }
/*     */         }
/*  83 */         else if (y == sliceMinY.intValue()) {
/*     */           
/*  85 */           y = sliceMaxY.intValue();
/*     */           
/*     */           break;
/*     */         } 
/*  89 */         y--;
/*     */         
/*  91 */         blockMD = BlockMD.getBlockMDFromChunkLocal(chunkMd, x, y, z);
/*  92 */         blockMDAbove = BlockMD.getBlockMDFromChunkLocal(chunkMd, x, y + 1, z);
/*     */       }
/*     */     
/*  95 */     } catch (Exception e) {
/*     */       
/*  97 */       Journeymap.getLogger().warn("Couldn't get safe slice block height at " + x + "," + z + ": " + String.valueOf(e));
/*  98 */       y = sliceMaxY.intValue();
/*     */     } 
/*     */     
/* 101 */     int y = Math.max(0, y);
/*     */     
/* 103 */     blockSliceHeights[x][z] = Integer.valueOf(y);
/* 104 */     return Integer.valueOf(y);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected int getSliceLightLevel(ChunkMD chunkMd, int x, int y, int z, boolean adjusted) {
/* 113 */     if (y + 1 >= chunkMd.getWorldActualHeight())
/*     */     {
/* 115 */       return 0;
/*     */     }
/*     */     
/* 118 */     return this.mapCaveLighting ? Math.max(adjusted ? 2 : 0, chunkMd.getSavedLightValue(x, y + 1, z)) : 15;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public float[] getAmbientColor() {
/* 124 */     return this.ambientColor;
/*     */   }
/*     */ }


/* Location:              C:\Users\Administrator\Downloads\journeymap-neoforge-1.21-6.0.0-beta.18.jar!\journeymap\client\cartography\render\NetherCaveRenderer.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */