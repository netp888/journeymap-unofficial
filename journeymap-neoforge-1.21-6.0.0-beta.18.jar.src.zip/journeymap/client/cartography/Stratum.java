/*     */ package journeymap.client.cartography;
/*     */ 
/*     */ import java.awt.Color;
/*     */ import java.util.concurrent.atomic.AtomicInteger;
/*     */ import journeymap.client.model.BlockMD;
/*     */ import journeymap.client.model.ChunkMD;
/*     */ import net.minecraft.core.BlockPos;
/*     */ import net.minecraft.core.Vec3i;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Stratum
/*     */ {
/*  21 */   private static AtomicInteger IDGEN = new AtomicInteger(0);
/*     */   
/*     */   private final int id;
/*     */   
/*     */   private ChunkMD chunkMd;
/*     */   
/*     */   private BlockMD blockMD;
/*     */   
/*     */   private int localX;
/*     */   
/*     */   private int y;
/*     */   
/*     */   private int localZ;
/*     */   private int lightLevel;
/*     */   private int lightOpacity;
/*     */   private boolean isFluid;
/*     */   private int dayColor;
/*     */   private int nightColor;
/*     */   private int caveColor;
/*     */   private float worldAmbientLight;
/*     */   private boolean worldHasNoSky;
/*     */   private boolean uninitialized = true;
/*     */   
/*     */   Stratum() {
/*  45 */     this.id = IDGEN.incrementAndGet();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   Stratum set(ChunkMD chunkMd, BlockMD blockMD, int localX, int y, int localZ, Integer lightLevel) {
/*  61 */     if (chunkMd == null || blockMD == null)
/*     */     {
/*  63 */       throw new IllegalStateException(String.format("Can't have nulls: %s, %s", new Object[] { chunkMd, blockMD }));
/*     */     }
/*     */     
/*     */     try {
/*  67 */       setChunkMd(chunkMd);
/*  68 */       setBlockMD(blockMD);
/*  69 */       setX(localX);
/*  70 */       setY(y);
/*  71 */       setZ(localZ);
/*  72 */       setFluid((blockMD.isFluid() || blockMD.isFluid()));
/*  73 */       if (blockMD.isLava()) {
/*     */         
/*  75 */         setLightLevel(14);
/*     */       }
/*     */       else {
/*     */         
/*  79 */         setLightLevel((lightLevel != null) ? lightLevel.intValue() : chunkMd.getSavedLightValue(localX, y + 1, localZ));
/*     */       } 
/*  81 */       setLightOpacity(chunkMd.getLightOpacity(blockMD, localX, y, localZ));
/*  82 */       setDayColor(-1);
/*  83 */       setNightColor(-1);
/*  84 */       setCaveColor(-1);
/*  85 */       this.uninitialized = false;
/*     */ 
/*     */     
/*     */     }
/*  89 */     catch (RuntimeException t) {
/*     */       
/*  91 */       throw t;
/*     */     } 
/*  93 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean equals(Object o) {
/*  99 */     if (this == o)
/*     */     {
/* 101 */       return true;
/*     */     }
/* 103 */     if (o == null || getClass() != o.getClass())
/*     */     {
/* 105 */       return false;
/*     */     }
/*     */     
/* 108 */     Stratum that = (Stratum)o;
/*     */     
/* 110 */     if (getY() != that.getY())
/*     */     {
/* 112 */       return false;
/*     */     }
/* 114 */     if ((getBlockMD() != null) ? !getBlockMD().equals(that.getBlockMD()) : (that.getBlockMD() != null))
/*     */     {
/* 116 */       return false;
/*     */     }
/*     */     
/* 119 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 125 */     int result = (getBlockMD() != null) ? getBlockMD().hashCode() : 0;
/* 126 */     result = 31 * result + getY();
/* 127 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 133 */     String common = "Stratum{id=" + this.id + ", uninitialized=" + this.uninitialized + "%s}";
/*     */     
/* 135 */     if (!this.uninitialized)
/*     */     {
/* 137 */       return String.format(common, new Object[] {
/* 138 */             ", localX=" + getX() + ", y=" + 
/* 139 */             getY() + ", localZ=" + 
/* 140 */             getZ() + ", lightLevel=" + 
/* 141 */             getLightLevel() + ", worldAmbientLight=" + 
/* 142 */             getWorldAmbientLight() + ", lightOpacity=" + 
/* 143 */             getLightOpacity() + ", isFluid=" + 
/* 144 */             isFluid() + ", dayColor=" + 
/* 145 */             String.valueOf((getDayColor() == -1) ? null : new Color(getDayColor())) + ", nightColor=" + 
/* 146 */             String.valueOf((getNightColor() == -1) ? null : new Color(getNightColor())) + ", caveColor=" + 
/* 147 */             String.valueOf((getCaveColor() == -1) ? null : new Color(getCaveColor()))
/*     */           });
/*     */     }
/*     */     
/* 151 */     return String.format(common, new Object[] { "" });
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ChunkMD getChunkMd() {
/* 162 */     return this.chunkMd;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setChunkMd(ChunkMD chunkMd) {
/* 172 */     this.chunkMd = chunkMd;
/* 173 */     if (chunkMd != null) {
/*     */       
/* 175 */       this.worldAmbientLight = chunkMd.getWorld().getSkyDarken(1.0F) * 15.0F;
/* 176 */       this.worldHasNoSky = chunkMd.hasNoSky().booleanValue();
/*     */     }
/*     */     else {
/*     */       
/* 180 */       this.worldAmbientLight = 15.0F;
/* 181 */       this.worldHasNoSky = false;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public BlockMD getBlockMD() {
/* 192 */     if (this.blockMD.isFluid())
/*     */     {
/* 194 */       boolean bool = false;
/*     */     }
/* 196 */     return this.blockMD;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setBlockMD(BlockMD blockMD) {
/* 206 */     this.blockMD = blockMD;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public float getWorldAmbientLight() {
/* 216 */     return this.worldAmbientLight;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean getWorldHasNoSky() {
/* 226 */     return this.worldHasNoSky;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getX() {
/* 236 */     return this.localX;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setX(int x) {
/* 246 */     this.localX = x;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getY() {
/* 256 */     return this.y;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setY(int y) {
/* 266 */     this.y = y;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getZ() {
/* 276 */     return this.localZ;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setZ(int z) {
/* 286 */     this.localZ = z;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getLightLevel() {
/* 296 */     return this.lightLevel;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setLightLevel(int lightLevel) {
/* 306 */     this.lightLevel = lightLevel;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getLightOpacity() {
/* 316 */     return this.lightOpacity;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setLightOpacity(int lightOpacity) {
/* 326 */     this.lightOpacity = lightOpacity;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isFluid() {
/* 336 */     return this.isFluid;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setFluid(boolean isFluid) {
/* 346 */     this.isFluid = isFluid;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getDayColor() {
/* 356 */     return this.dayColor;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setDayColor(int dayColor) {
/* 366 */     this.dayColor = dayColor;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getNightColor() {
/* 376 */     return this.nightColor;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setNightColor(int nightColor) {
/* 386 */     this.nightColor = nightColor;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getCaveColor() {
/* 396 */     return this.caveColor;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setCaveColor(int caveColor) {
/* 406 */     this.caveColor = caveColor;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public BlockPos getBlockPos() {
/* 416 */     return new BlockPos((Vec3i)this.chunkMd.getBlockPos(this.localX, this.y, this.localZ));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isUninitialized() {
/* 426 */     return this.uninitialized;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void clear() {
/* 434 */     this.uninitialized = true;
/* 435 */     this.worldAmbientLight = 15.0F;
/* 436 */     this.worldHasNoSky = false;
/* 437 */     setChunkMd(null);
/* 438 */     setBlockMD(null);
/* 439 */     setX(0);
/* 440 */     setY(-1);
/* 441 */     setZ(0);
/* 442 */     setFluid(false);
/* 443 */     setLightLevel(-1);
/* 444 */     setLightOpacity(-1);
/* 445 */     setDayColor(-1);
/* 446 */     setNightColor(-1);
/* 447 */     setCaveColor(-1);
/*     */   }
/*     */ }


/* Location:              C:\Users\Administrator\Downloads\journeymap-neoforge-1.21-6.0.0-beta.18.jar!\journeymap\client\cartography\Stratum.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */