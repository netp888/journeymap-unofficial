package journeymap.client.mod;

import java.util.Collection;
import javax.annotation.Nullable;
import journeymap.client.cartography.color.ColoredSprite;
import journeymap.client.model.BlockMD;
import journeymap.client.model.ChunkMD;
import net.minecraft.core.BlockPos;

public interface IBlockSpritesProxy {
  @Nullable
  Collection<ColoredSprite> getSprites(BlockMD paramBlockMD, @Nullable ChunkMD paramChunkMD, @Nullable BlockPos paramBlockPos);
}


/* Location:              C:\Users\Administrator\Downloads\journeymap-neoforge-1.21-6.0.0-beta.18.jar!\journeymap\client\mod\IBlockSpritesProxy.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */