/*    */ package journeymap.client.mod.impl;
/*    */ 
/*    */ import com.google.common.base.Strings;
/*    */ import java.util.ArrayList;
/*    */ import java.util.Collection;
/*    */ import java.util.Collections;
/*    */ import java.util.List;
/*    */ import javax.annotation.Nullable;
/*    */ import journeymap.client.cartography.color.ColoredSprite;
/*    */ import journeymap.client.mod.IBlockSpritesProxy;
/*    */ import journeymap.client.mod.IModBlockHandler;
/*    */ import journeymap.client.mod.ModBlockDelegate;
/*    */ import journeymap.client.mod.ModPropertyEnum;
/*    */ import journeymap.client.model.BlockMD;
/*    */ import journeymap.client.model.ChunkMD;
/*    */ import journeymap.common.Journeymap;
/*    */ import journeymap.common.log.LogFormatter;
/*    */ import net.minecraft.client.Minecraft;
/*    */ import net.minecraft.client.renderer.texture.TextureAtlas;
/*    */ import net.minecraft.client.renderer.texture.TextureAtlasSprite;
/*    */ import net.minecraft.core.BlockPos;
/*    */ import net.minecraft.resources.ResourceLocation;
/*    */ import net.minecraft.world.level.block.state.BlockState;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Bibliocraft
/*    */   implements IModBlockHandler, IBlockSpritesProxy
/*    */ {
/* 36 */   List<ModPropertyEnum<String>> colorProperties = new ArrayList<>(2);
/*    */ 
/*    */   
/*    */   public Bibliocraft() {
/* 40 */     this.colorProperties.add(new ModPropertyEnum("jds.bibliocraft.blocks.BiblioColorBlock", "COLOR", "getWoolTextureString", String.class));
/* 41 */     this.colorProperties.add(new ModPropertyEnum("jds.bibliocraft.blocks.BiblioWoodBlock", "WOOD_TYPE", "getTextureString", String.class));
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public void initialize(BlockMD blockMD) {
/* 47 */     blockMD.setBlockSpritesProxy(this);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   @Nullable
/*    */   public Collection<ColoredSprite> getSprites(BlockMD blockMD, @Nullable ChunkMD chunkMD, @Nullable BlockPos blockPos) {
/* 54 */     BlockState blockState = blockMD.getBlockState();
/* 55 */     String textureString = (String)ModPropertyEnum.getFirstValue(this.colorProperties, blockState, new Object[0]);
/* 56 */     if (!Strings.isNullOrEmpty(textureString)) {
/*    */       
/*    */       try {
/*    */         
/* 60 */         ResourceLocation loc = ResourceLocation.parse(textureString);
/* 61 */         TextureAtlasSprite tas = Minecraft.getInstance().getModelManager().getAtlas(TextureAtlas.LOCATION_BLOCKS).getSprite(loc);
/* 62 */         return Collections.singletonList(new ColoredSprite(tas, null));
/*    */       }
/* 64 */       catch (Exception e) {
/*    */         
/* 66 */         Journeymap.getLogger().error(String.format("Error getting sprite from %s: %s", new Object[] { textureString, LogFormatter.toPartialString(e) }));
/*    */       } 
/*    */     }
/* 69 */     return ModBlockDelegate.INSTANCE.getDefaultBlockSpritesProxy().getSprites(blockMD, chunkMD, blockPos);
/*    */   }
/*    */ }


/* Location:              C:\Users\Administrator\Downloads\journeymap-neoforge-1.21-6.0.0-beta.18.jar!\journeymap\client\mod\impl\Bibliocraft.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */