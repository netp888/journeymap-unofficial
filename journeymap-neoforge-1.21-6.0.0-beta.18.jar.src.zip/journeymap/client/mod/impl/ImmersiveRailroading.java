/*    */ package journeymap.client.mod.impl;
/*    */ 
/*    */ import journeymap.client.mod.IBlockColorProxy;
/*    */ import journeymap.client.mod.IModBlockHandler;
/*    */ import journeymap.client.mod.ModBlockDelegate;
/*    */ import journeymap.client.model.BlockMD;
/*    */ import journeymap.client.model.ChunkMD;
/*    */ import net.minecraft.client.Minecraft;
/*    */ import net.minecraft.core.BlockPos;
/*    */ import net.minecraft.world.level.Level;
/*    */ import org.jetbrains.annotations.Nullable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ImmersiveRailroading
/*    */   implements IModBlockHandler, IBlockColorProxy
/*    */ {
/*    */   private static final int RAIL_COLOR = 14474460;
/*    */   private static final int RAIL_COLOR_PREVIEW = 8224125;
/*    */   
/*    */   public void initialize(BlockMD blockMD) {
/* 24 */     blockMD.setBlockColorProxy(this);
/* 25 */     String name = blockMD.getBlockId().toLowerCase();
/* 26 */     if (name.equalsIgnoreCase("block_rail_preview")) {
/*    */       
/* 28 */       blockMD.setColor(8224125);
/*    */     }
/* 30 */     else if (name.contains("block_rail") || name.contains("multiblock")) {
/*    */       
/* 32 */       blockMD.setColor(14474460);
/*    */     } 
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   @Nullable
/*    */   public int deriveBlockColor(BlockMD blockMD, @Nullable ChunkMD chunkMD, @Nullable BlockPos blockPos) {
/* 40 */     return ModBlockDelegate.INSTANCE.getDefaultBlockColorProxy().deriveBlockColor(blockMD, chunkMD, blockPos);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public int getBlockColor(ChunkMD chunkMD, BlockMD blockMD, BlockPos blockPos) {
/* 46 */     String name = blockMD.getBlockId().toLowerCase();
/* 47 */     if (name.equalsIgnoreCase("block_rail_preview"))
/*    */     {
/* 49 */       return 8224125;
/*    */     }
/* 51 */     if (name.contains("block_rail") || name.contains("multiblock"))
/*    */     {
/* 53 */       return 14474460;
/*    */     }
/* 55 */     return Minecraft.getInstance().getBlockColors().getColor(blockMD.getBlockState(), (Level)chunkMD.getWorld(), blockPos);
/*    */   }
/*    */ }


/* Location:              C:\Users\Administrator\Downloads\journeymap-neoforge-1.21-6.0.0-beta.18.jar!\journeymap\client\mod\impl\ImmersiveRailroading.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */