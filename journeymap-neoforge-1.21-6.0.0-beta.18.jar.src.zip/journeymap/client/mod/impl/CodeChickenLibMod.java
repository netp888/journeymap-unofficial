/*    */ package journeymap.client.mod.impl;
/*    */ 
/*    */ import javax.annotation.Nullable;
/*    */ import journeymap.client.mod.IBlockColorProxy;
/*    */ import journeymap.client.mod.IModBlockHandler;
/*    */ import journeymap.client.mod.ModBlockDelegate;
/*    */ import journeymap.client.model.BlockMD;
/*    */ import journeymap.client.model.ChunkMD;
/*    */ import net.minecraft.client.Minecraft;
/*    */ import net.minecraft.core.BlockPos;
/*    */ import net.minecraft.world.level.BlockAndTintGetter;
/*    */ import net.minecraft.world.level.block.state.BlockState;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Deprecated
/*    */ public class CodeChickenLibMod
/*    */   implements IModBlockHandler, IBlockColorProxy
/*    */ {
/*    */   public void initialize(BlockMD blockMD) {
/* 25 */     blockMD.setBlockColorProxy(this);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public int deriveBlockColor(BlockMD blockMD, @Nullable ChunkMD chunkMD, @Nullable BlockPos blockPos) {
/* 31 */     return ModBlockDelegate.INSTANCE.getDefaultBlockColorProxy().deriveBlockColor(blockMD, chunkMD, blockPos);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public int getBlockColor(ChunkMD chunkMD, BlockMD blockMD, BlockPos blockPos) {
/* 37 */     BlockState blockState = blockMD.getBlockState();
/*    */ 
/*    */ 
/*    */ 
/*    */     
/*    */     try {
/* 43 */       blockState = chunkMD.getWorld().getBlockState(blockPos);
/*    */     }
/* 45 */     catch (Exception exception) {}
/*    */ 
/*    */ 
/*    */ 
/*    */     
/* 50 */     return Minecraft.getInstance().getBlockColors().getColor(blockState, (BlockAndTintGetter)chunkMD
/*    */         
/* 52 */         .getWorld(), blockPos, blockMD
/*    */         
/* 54 */         .getBlockState().getRenderShape().ordinal());
/*    */   }
/*    */ }


/* Location:              C:\Users\Administrator\Downloads\journeymap-neoforge-1.21-6.0.0-beta.18.jar!\journeymap\client\mod\impl\CodeChickenLibMod.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */