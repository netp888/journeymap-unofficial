/*    */ package journeymap.client.mod.impl;
/*    */ 
/*    */ import journeymap.client.mod.IModBlockHandler;
/*    */ import journeymap.client.model.BlockFlag;
/*    */ import journeymap.client.model.BlockMD;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Streams
/*    */   implements IModBlockHandler
/*    */ {
/*    */   private static final int WATER_COLOR = 4210943;
/*    */   
/*    */   public void initialize(BlockMD blockMD) {
/* 20 */     String name = blockMD.getBlockId().toLowerCase();
/* 21 */     if (name.contains("water")) {
/*    */       
/* 23 */       blockMD.setAlpha(0.25F);
/* 24 */       blockMD.addFlags(new BlockFlag[] { BlockFlag.Water, BlockFlag.NoShadow });
/* 25 */       blockMD.setColor(4210943);
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Users\Administrator\Downloads\journeymap-neoforge-1.21-6.0.0-beta.18.jar!\journeymap\client\mod\impl\Streams.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */