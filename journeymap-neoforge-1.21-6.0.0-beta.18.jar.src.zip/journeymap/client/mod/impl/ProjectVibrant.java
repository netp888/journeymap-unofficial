/*    */ package journeymap.client.mod.impl;
/*    */ 
/*    */ import journeymap.client.mod.IModBlockHandler;
/*    */ import journeymap.client.model.BlockFlag;
/*    */ import journeymap.client.model.BlockMD;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ProjectVibrant
/*    */   implements IModBlockHandler
/*    */ {
/*    */   public void initialize(BlockMD blockMD) {
/* 14 */     blockMD.addFlags(new BlockFlag[] { BlockFlag.Ignore });
/*    */   }
/*    */ }


/* Location:              C:\Users\Administrator\Downloads\journeymap-neoforge-1.21-6.0.0-beta.18.jar!\journeymap\client\mod\impl\ProjectVibrant.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */