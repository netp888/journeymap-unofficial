/*    */ package journeymap.client.mod.impl;
/*    */ 
/*    */ import java.util.Arrays;
/*    */ import java.util.List;
/*    */ import journeymap.client.mod.IBlockColorProxy;
/*    */ import journeymap.client.mod.IModBlockHandler;
/*    */ import journeymap.client.mod.ModBlockDelegate;
/*    */ import journeymap.client.model.BlockFlag;
/*    */ import journeymap.client.model.BlockMD;
/*    */ import journeymap.client.model.ChunkMD;
/*    */ import net.minecraft.core.BlockPos;
/*    */ import org.jetbrains.annotations.Nullable;
/*    */ 
/*    */ public class CreateMod
/*    */   implements IModBlockHandler, IBlockColorProxy
/*    */ {
/* 17 */   private final List<String> blocks = Arrays.asList(new String[] { "railway_casing", "bell", "valve_handle" });
/*    */ 
/*    */ 
/*    */   
/*    */   public void initialize(BlockMD blockMD) {
/* 22 */     String blockId = blockMD.getBlockId();
/* 23 */     for (String block : this.blocks) {
/*    */       
/* 25 */       if (blockId.contains(block))
/*    */       {
/* 27 */         blockMD.setBlockColorProxy(this);
/*    */       }
/*    */     } 
/*    */     
/* 31 */     if (blockMD.getBlockId().contains("fake_track")) {
/*    */       
/* 33 */       blockMD.addFlags(new BlockFlag[] { BlockFlag.Force });
/* 34 */       blockMD.setBlockColorProxy(this);
/*    */     } 
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   @Nullable
/*    */   public int deriveBlockColor(BlockMD blockMD, @Nullable ChunkMD chunkMD, @Nullable BlockPos blockPos) {
/* 42 */     return ModBlockDelegate.INSTANCE.getDefaultBlockColorProxy().deriveBlockColor(blockMD, chunkMD, blockPos);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public int getBlockColor(ChunkMD chunkMD, BlockMD blockMD, BlockPos blockPos) {
/* 48 */     return ModBlockDelegate.INSTANCE.getMaterialBlockColorProxy().getBlockColor(chunkMD, blockMD, blockPos);
/*    */   }
/*    */ }


/* Location:              C:\Users\Administrator\Downloads\journeymap-neoforge-1.21-6.0.0-beta.18.jar!\journeymap\client\mod\impl\CreateMod.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */