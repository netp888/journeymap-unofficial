/*    */ package journeymap.client.mod.impl;
/*    */ 
/*    */ import journeymap.client.mod.IBlockColorProxy;
/*    */ import journeymap.client.mod.IModBlockHandler;
/*    */ import journeymap.client.mod.ModBlockDelegate;
/*    */ import journeymap.client.model.BlockFlag;
/*    */ import journeymap.client.model.BlockMD;
/*    */ import journeymap.client.model.ChunkMD;
/*    */ import net.minecraft.client.Minecraft;
/*    */ import net.minecraft.core.BlockPos;
/*    */ import net.minecraft.world.level.Level;
/*    */ import org.jetbrains.annotations.Nullable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class TerraFirmaCraft
/*    */   implements IModBlockHandler, IBlockColorProxy
/*    */ {
/*    */   private static final int WATER_COLOR = 727360;
/*    */   
/*    */   public void initialize(BlockMD blockMD) {
/* 39 */     blockMD.setBlockColorProxy(this);
/* 40 */     String name = blockMD.getBlockId().toLowerCase();
/* 41 */     if (name.contains("loose") || name.contains("looserock") || name.contains("loose_rock") || name.contains("rubble") || name.contains("vegetation")) {
/*    */       
/* 43 */       blockMD.addFlags(new BlockFlag[] { BlockFlag.Ignore, BlockFlag.NoShadow, BlockFlag.NoTopo });
/*    */     }
/* 45 */     else if (name.contains("seagrass")) {
/*    */       
/* 47 */       blockMD.addFlags(new BlockFlag[] { BlockFlag.Plant });
/*    */     }
/* 49 */     else if (name.contains("grass")) {
/*    */       
/* 51 */       blockMD.addFlags(new BlockFlag[] { BlockFlag.Grass });
/*    */     }
/* 53 */     else if (name.contains("water")) {
/*    */       
/* 55 */       blockMD.setAlpha(0.3F);
/* 56 */       blockMD.addFlags(new BlockFlag[] { BlockFlag.Water, BlockFlag.NoShadow });
/*    */     
/*    */     }
/* 59 */     else if (name.contains("leaves")) {
/*    */       
/* 61 */       blockMD.addFlags(new BlockFlag[] { BlockFlag.NoTopo, BlockFlag.Foliage });
/*    */     } 
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   @Nullable
/*    */   public int deriveBlockColor(BlockMD blockMD, @Nullable ChunkMD chunkMD, @Nullable BlockPos blockPos) {
/* 69 */     return ModBlockDelegate.INSTANCE.getDefaultBlockColorProxy().deriveBlockColor(blockMD, chunkMD, blockPos);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public int getBlockColor(ChunkMD chunkMD, BlockMD blockMD, BlockPos blockPos) {
/* 75 */     int color = Minecraft.getInstance().getBlockColors().getColor(blockMD.getBlockState(), (Level)chunkMD.getWorld(), blockPos);
/* 76 */     if (color == -1)
/*    */     {
/* 78 */       color = (blockMD.getBlock().defaultMapColor()).col;
/*    */     }
/* 80 */     return color;
/*    */   }
/*    */ }


/* Location:              C:\Users\Administrator\Downloads\journeymap-neoforge-1.21-6.0.0-beta.18.jar!\journeymap\client\mod\impl\TerraFirmaCraft.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */