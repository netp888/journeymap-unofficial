/*    */ package journeymap.client.mod.impl;
/*    */ 
/*    */ import java.util.Collection;
/*    */ import java.util.Collections;
/*    */ import journeymap.client.cartography.color.ColoredSprite;
/*    */ import journeymap.client.mod.IBlockSpritesProxy;
/*    */ import journeymap.client.mod.IModBlockHandler;
/*    */ import journeymap.client.model.BlockMD;
/*    */ import journeymap.client.model.ChunkMD;
/*    */ import net.minecraft.client.Minecraft;
/*    */ import net.minecraft.client.renderer.block.BlockModelShaper;
/*    */ import net.minecraft.client.resources.model.BakedModel;
/*    */ import net.minecraft.core.BlockPos;
/*    */ import org.jetbrains.annotations.Nullable;
/*    */ 
/*    */ 
/*    */ public class ChinjufuMod
/*    */   implements IModBlockHandler, IBlockSpritesProxy
/*    */ {
/* 20 */   BlockModelShaper bms = Minecraft.getInstance().getBlockRenderer().getBlockModelShaper();
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void initialize(BlockMD blockMD) {
/* 29 */     if (blockMD.getBlockId().contains("oakkare_leaf") || blockMD.getBlockId().contains("kaede_leaf"))
/*    */     {
/* 31 */       blockMD.setBlockSpritesProxy(this);
/*    */     }
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   @Nullable
/*    */   public Collection<ColoredSprite> getSprites(BlockMD blockMD, @Nullable ChunkMD chunkMD, @Nullable BlockPos blockPos) {
/* 40 */     BakedModel model = this.bms.getBlockModel(blockMD.getBlockState());
/* 41 */     return Collections.singletonList(new ColoredSprite(model.getParticleIcon(), null));
/*    */   }
/*    */ }


/* Location:              C:\Users\Administrator\Downloads\journeymap-neoforge-1.21-6.0.0-beta.18.jar!\journeymap\client\mod\impl\ChinjufuMod.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */