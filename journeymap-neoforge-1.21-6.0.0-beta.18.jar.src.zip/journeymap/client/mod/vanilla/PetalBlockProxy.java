/*    */ package journeymap.client.mod.vanilla;
/*    */ 
/*    */ import journeymap.client.mod.IBlockColorProxy;
/*    */ import journeymap.client.mod.ModBlockDelegate;
/*    */ import journeymap.client.model.BlockMD;
/*    */ import journeymap.client.model.ChunkMD;
/*    */ import net.minecraft.core.BlockPos;
/*    */ import org.jetbrains.annotations.Nullable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class PetalBlockProxy
/*    */   implements IBlockColorProxy
/*    */ {
/*    */   private static PetalBlockProxy INSTANCE;
/*    */   
/*    */   public static PetalBlockProxy getInstance() {
/* 21 */     if (INSTANCE == null)
/*    */     {
/* 23 */       INSTANCE = new PetalBlockProxy();
/*    */     }
/* 25 */     return INSTANCE;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   @Nullable
/*    */   public int deriveBlockColor(BlockMD blockMD, @Nullable ChunkMD chunkMD, @Nullable BlockPos blockPos) {
/* 32 */     return ModBlockDelegate.INSTANCE.getDefaultBlockColorProxy().deriveBlockColor(blockMD, chunkMD, blockPos);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public int getBlockColor(ChunkMD chunkMD, BlockMD blockMD, BlockPos blockPos) {
/* 38 */     int result = blockMD.getTextureColor(chunkMD, blockPos);
/* 39 */     if (blockMD.getBlock() instanceof net.minecraft.world.level.block.PinkPetalsBlock)
/*    */     {
/* 41 */       return result;
/*    */     }
/* 43 */     return ModBlockDelegate.INSTANCE.getDefaultBlockColorProxy().getBlockColor(chunkMD, blockMD, blockPos);
/*    */   }
/*    */ }


/* Location:              C:\Users\Administrator\Downloads\journeymap-neoforge-1.21-6.0.0-beta.18.jar!\journeymap\client\mod\vanilla\PetalBlockProxy.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */