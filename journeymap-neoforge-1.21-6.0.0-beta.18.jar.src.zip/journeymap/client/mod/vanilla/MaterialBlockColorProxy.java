/*    */ package journeymap.client.mod.vanilla;
/*    */ 
/*    */ import journeymap.client.mod.IBlockColorProxy;
/*    */ import journeymap.client.mod.ModBlockDelegate;
/*    */ import journeymap.client.model.BlockMD;
/*    */ import journeymap.client.model.ChunkMD;
/*    */ import net.minecraft.client.Minecraft;
/*    */ import net.minecraft.client.multiplayer.ClientLevel;
/*    */ import net.minecraft.core.BlockPos;
/*    */ import net.minecraft.world.level.BlockGetter;
/*    */ import net.minecraft.world.level.Level;
/*    */ import net.minecraft.world.level.block.state.BlockState;
/*    */ import org.jetbrains.annotations.Nullable;
/*    */ 
/*    */ public class MaterialBlockColorProxy
/*    */   implements IBlockColorProxy {
/*    */   @Nullable
/*    */   public int deriveBlockColor(BlockMD blockMD, @Nullable ChunkMD chunkMD, @Nullable BlockPos blockPos) {
/* 19 */     return ModBlockDelegate.INSTANCE.getDefaultBlockColorProxy().deriveBlockColor(blockMD, chunkMD, blockPos);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public int getBlockColor(ChunkMD chunkMD, BlockMD blockMD, BlockPos blockPos) {
/* 25 */     int color = Minecraft.getInstance().getBlockColors().getColor(blockMD.getBlockState(), (Level)chunkMD.getWorld(), blockPos);
/* 26 */     if (color == -1) {
/*    */       
/* 28 */       BlockState blockState = blockMD.getBlockState();
/*    */       
/* 30 */       ClientLevel level = (Minecraft.getInstance()).level;
/* 31 */       return (blockState.getMapColor((BlockGetter)level, blockPos)).col;
/*    */     } 
/* 33 */     return color;
/*    */   }
/*    */ }


/* Location:              C:\Users\Administrator\Downloads\journeymap-neoforge-1.21-6.0.0-beta.18.jar!\journeymap\client\mod\vanilla\MaterialBlockColorProxy.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */