/*     */ package journeymap.client.mod.vanilla;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.Collections;
/*     */ import java.util.HashMap;
/*     */ import java.util.HashSet;
/*     */ import java.util.List;
/*     */ import javax.annotation.Nullable;
/*     */ import journeymap.api.services.Services;
/*     */ import journeymap.client.cartography.color.ColoredSprite;
/*     */ import journeymap.client.mod.IBlockSpritesProxy;
/*     */ import journeymap.client.model.BlockMD;
/*     */ import journeymap.client.model.ChunkMD;
/*     */ import journeymap.common.Journeymap;
/*     */ import journeymap.common.log.LogFormatter;
/*     */ import net.minecraft.client.Minecraft;
/*     */ import net.minecraft.client.renderer.RenderType;
/*     */ import net.minecraft.client.renderer.block.BlockModelShaper;
/*     */ import net.minecraft.client.renderer.block.model.BakedQuad;
/*     */ import net.minecraft.client.renderer.texture.TextureAtlasSprite;
/*     */ import net.minecraft.client.resources.model.BakedModel;
/*     */ import net.minecraft.core.BlockPos;
/*     */ import net.minecraft.core.Direction;
/*     */ import net.minecraft.core.registries.BuiltInRegistries;
/*     */ import net.minecraft.resources.ResourceLocation;
/*     */ import net.minecraft.world.level.block.Block;
/*     */ import net.minecraft.world.level.block.DoublePlantBlock;
/*     */ import net.minecraft.world.level.block.RenderShape;
/*     */ import net.minecraft.world.level.block.state.BlockState;
/*     */ import net.minecraft.world.level.block.state.properties.DoubleBlockHalf;
/*     */ import net.minecraft.world.level.block.state.properties.Property;
/*     */ import org.apache.logging.log4j.Logger;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class VanillaBlockSpriteProxy
/*     */   implements IBlockSpritesProxy
/*     */ {
/*  63 */   private static Logger logger = Journeymap.getLogger();
/*  64 */   BlockModelShaper bms = Minecraft.getInstance().getBlockRenderer().getBlockModelShaper();
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public Collection<ColoredSprite> getSprites(BlockMD blockMD, @Nullable ChunkMD chunkMD, @Nullable BlockPos blockPos) {
/*  70 */     BlockState blockState = blockMD.getBlockState();
/*  71 */     Block block = blockState.getBlock();
/*     */     
/*  73 */     if (block instanceof net.minecraft.world.level.block.LiquidBlock) {
/*     */       
/*  75 */       TextureAtlasSprite tas = Services.CLIENT_SERVICE.getTextureAtlasSprite(blockMD);
/*  76 */       return Collections.singletonList(new ColoredSprite(tas, null));
/*     */     } 
/*     */ 
/*     */     
/*  80 */     if (blockState.getProperties().contains(DoublePlantBlock.HALF))
/*     */     {
/*  82 */       blockState = (BlockState)blockState.setValue((Property)DoublePlantBlock.HALF, (Comparable)DoubleBlockHalf.UPPER);
/*     */     }
/*     */     
/*  85 */     HashMap<String, ColoredSprite> map = new HashMap<>();
/*     */     
/*     */     try {
/*  88 */       BakedModel model = this.bms.getBlockModel(blockState);
/*     */       
/*  90 */       label33: for (BlockState state : new BlockState[] { blockState, null }) {
/*     */         
/*  92 */         for (Direction facing : new Direction[] { Direction.UP, null }) {
/*     */           
/*  94 */           if (getSprites(blockMD, model, state, facing, map, chunkMD, blockPos)) {
/*     */             break label33;
/*     */           }
/*     */         } 
/*     */       } 
/*     */ 
/*     */       
/* 101 */       if (map.isEmpty()) {
/*     */ 
/*     */         
/* 104 */         TextureAtlasSprite defaultSprite = this.bms.getParticleIcon(blockState);
/*     */         
/* 106 */         if (defaultSprite != null)
/*     */         {
/* 108 */           map.put(defaultSprite.contents().name().getPath(), new ColoredSprite(defaultSprite, null));
/* 109 */           if (!blockMD.isVanillaBlock() && logger.isDebugEnabled())
/*     */           {
/* 111 */             logger.debug(String.format("Resorted to using BlockModelStates.getTexture() to use %s as color for %s", new Object[] { defaultSprite.contents().name().getPath(), blockState }));
/*     */           }
/*     */         }
/*     */         else
/*     */         {
/* 116 */           logger.warn(String.format("Unable to get any texture to use as color for %s", new Object[] { blockState }));
/*     */         }
/*     */       
/*     */       } 
/* 120 */     } catch (Exception e) {
/*     */       
/* 122 */       logger.error("Unexpected error during getSprites(): " + String.valueOf(BuiltInRegistries.BLOCK.getKey(blockMD.getBlock())) + " - " + LogFormatter.toPartialString(e));
/*     */     } 
/*     */     
/* 125 */     return map.values();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean getSprites(BlockMD blockMD, BakedModel model, @Nullable BlockState blockState, @Nullable Direction facing, HashMap<String, ColoredSprite> map, @Nullable ChunkMD chunkMD, @Nullable BlockPos blockPos) {
/* 131 */     if (blockPos != null && chunkMD != null && chunkMD.getWorld() != null) {
/*     */       
/*     */       try {
/*     */ 
/*     */         
/* 136 */         blockState = chunkMD.getWorld().getBlockState(blockPos);
/* 137 */         model = this.bms.getBlockModel(blockState);
/*     */       
/*     */       }
/* 140 */       catch (Exception exception) {}
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 146 */     boolean success = false;
/*     */     
/*     */     try {
/* 149 */       for (RenderType type : RenderType.chunkBufferLayers()) {
/*     */         
/* 151 */         if (RenderShape.MODEL.equals(blockMD.getBlockState().getRenderShape())) {
/*     */ 
/*     */           
/* 154 */           List<BakedQuad> quads = Services.CLIENT_SERVICE.getQuads(model, blockState, facing, blockPos, type);
/* 155 */           if (addSprites(map, quads))
/*     */           {
/* 157 */             if (!blockMD.isVanillaBlock() && logger.isDebugEnabled())
/*     */             {
/* 159 */               logger.debug(String.format("Success during [%s] %s.getQuads(%s, %s, %s)", new Object[] { type, model.getClass(), blockState, facing, Integer.valueOf(0) }));
/*     */             }
/* 161 */             success = true;
/*     */           }
/*     */         
/*     */         } 
/*     */       } 
/* 166 */     } catch (Exception e) {
/*     */       
/* 168 */       if (logger.isDebugEnabled())
/*     */       {
/* 170 */         logger.error(String.format("Error during [] %s.getQuads(%s, %s, %s): %s", new Object[] { model.getClass(), blockState, facing, Integer.valueOf(0), LogFormatter.toPartialString(e) }));
/*     */       }
/*     */     } 
/* 173 */     return success;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean addSprites(HashMap<String, ColoredSprite> sprites, List<BakedQuad> quads) {
/* 178 */     if (quads == null || quads.isEmpty())
/*     */     {
/* 180 */       return false;
/*     */     }
/*     */     
/* 183 */     if (quads.size() > 1) {
/*     */       
/* 185 */       HashSet<BakedQuad> culled = new HashSet<>(quads.size());
/*     */ 
/*     */       
/* 188 */       culled.addAll(quads);
/*     */       
/* 190 */       quads = new ArrayList<>(culled);
/*     */     } 
/*     */     
/* 193 */     boolean added = false;
/* 194 */     for (BakedQuad quad : quads) {
/*     */       
/* 196 */       TextureAtlasSprite sprite = quad.getSprite();
/* 197 */       if (sprite != null) {
/*     */         
/* 199 */         String iconName = sprite.contents().name().getPath();
/* 200 */         if (!sprites.containsKey(iconName)) {
/*     */           
/* 202 */           ResourceLocation resourceLocation = ResourceLocation.parse(iconName);
/* 203 */           if (resourceLocation.equals(ResourceLocation.parse("missingno"))) {
/*     */             continue;
/*     */           }
/*     */ 
/*     */           
/* 208 */           sprites.put(iconName, new ColoredSprite(quad));
/* 209 */           added = true;
/*     */         } 
/*     */       } 
/*     */     } 
/* 213 */     return added;
/*     */   }
/*     */ }


/* Location:              C:\Users\Administrator\Downloads\journeymap-neoforge-1.21-6.0.0-beta.18.jar!\journeymap\client\mod\vanilla\VanillaBlockSpriteProxy.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */