package journeymap.client.mod;

import journeymap.client.model.BlockMD;

public interface IModBlockHandler {
  void initialize(BlockMD paramBlockMD);
}


/* Location:              C:\Users\Administrator\Downloads\journeymap-neoforge-1.21-6.0.0-beta.18.jar!\journeymap\client\mod\IModBlockHandler.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */