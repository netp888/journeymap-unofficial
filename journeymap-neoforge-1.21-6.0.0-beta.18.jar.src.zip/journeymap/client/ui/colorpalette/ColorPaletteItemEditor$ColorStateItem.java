/*     */ package journeymap.client.ui.colorpalette;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.EnumSet;
/*     */ import java.util.List;
/*     */ import java.util.Objects;
/*     */ import journeymap.client.Constants;
/*     */ import journeymap.client.cartography.color.BlockStateColor;
/*     */ import journeymap.client.cartography.color.ColorManager;
/*     */ import journeymap.client.cartography.color.ColorPalette;
/*     */ import journeymap.client.cartography.color.RGB;
/*     */ import journeymap.client.model.BlockFlag;
/*     */ import journeymap.client.render.draw.DrawUtil;
/*     */ import journeymap.client.ui.component.Slot;
/*     */ import journeymap.client.ui.component.buttons.Button;
/*     */ import journeymap.client.ui.component.popupscreenbutton.blockflags.BlockFlagsButton;
/*     */ import journeymap.client.ui.component.popupscreenbutton.blockflags.BlockFlagsScreen;
/*     */ import journeymap.client.ui.component.popupscreenbutton.colorpicker.ColorPickerButton;
/*     */ import journeymap.client.ui.component.popupscreenbutton.colorpicker.ColorPickerScreen;
/*     */ import journeymap.client.ui.option.SlotMetadata;
/*     */ import journeymap.common.Journeymap;
/*     */ import net.minecraft.Util;
/*     */ import net.minecraft.client.gui.ComponentPath;
/*     */ import net.minecraft.client.gui.Font;
/*     */ import net.minecraft.client.gui.GuiGraphics;
/*     */ import net.minecraft.client.gui.components.Button;
/*     */ import net.minecraft.client.gui.components.events.ContainerEventHandler;
/*     */ import net.minecraft.client.gui.components.events.GuiEventListener;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class ColorStateItem
/*     */   extends Slot
/*     */ {
/*     */   private final Font fontRenderer;
/*     */   private final String blockId;
/*     */   private final String state;
/*     */   private EnumSet<BlockFlag> flags;
/*     */   private String flagsString;
/*     */   private int color;
/*     */   private final EnumSet<BlockFlag> originalFlags;
/*     */   private final int originalColor;
/*     */   private final ColorPaletteItemEditor editor;
/*     */   private final Button buttonDefault;
/*     */   private final Button buttonUndo;
/*     */   private BlockFlagsButton buttonBlockFlags;
/*     */   private ColorPickerButton buttonColorPicker;
/* 266 */   private final List<GuiEventListener> children = new ArrayList<>();
/* 267 */   private long lastClick = 0L;
/*     */ 
/*     */ 
/*     */   
/*     */   ColorStateItem(Font fontRenderer, String blockId, String state, BlockStateColor blockState, boolean isVanilla, ColorPaletteItemEditor editor) {
/* 272 */     this.fontRenderer = fontRenderer;
/* 273 */     this.blockId = blockId;
/* 274 */     this.state = state;
/* 275 */     this.originalFlags = (blockState.flags == null) ? EnumSet.<BlockFlag>noneOf(BlockFlag.class) : blockState.flags;
/* 276 */     this.originalColor = RGB.hexToInt(blockState.color) & 0xFFFFFF | (int)(blockState.alpha.floatValue() * 255.0F) << 24;
/* 277 */     this.flags = this.originalFlags.clone();
/* 278 */     this.flagsString = this.flags.toString();
/* 279 */     this.color = this.originalColor;
/* 280 */     this.editor = editor;
/* 281 */     this.buttonDefault = new Button(Constants.getString("jm.colorpalette.default"), b -> resetItemToDefault());
/* 282 */     this.buttonDefault.fitWidth(fontRenderer);
/* 283 */     this.buttonUndo = new Button(Constants.getString("jm.colorpalette.undo"), b -> undoItem());
/* 284 */     this.buttonUndo.fitWidth(fontRenderer);
/* 285 */     if (!isVanilla)
/*     */     {
/* 287 */       this.buttonBlockFlags = new BlockFlagsButton(24, 24, () -> this.flags, this::flagsChanged);
/*     */     }
/* 289 */     this.buttonColorPicker = new ColorPickerButton(24, 24, () -> this.color, () -> this.flags.contains(BlockFlag.Transparency), this::colorPicked);
/*     */     
/* 291 */     this.children.add(this.buttonColorPicker);
/* 292 */     this.children.add(this.buttonUndo);
/* 293 */     this.children.add(this.buttonDefault);
/* 294 */     if (!isVanilla)
/*     */     {
/* 296 */       this.children.add(this.buttonBlockFlags);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   private void flagsChanged(BlockFlagsScreen.BlockFlagsResponse response) {
/* 302 */     if (response.canceled()) {
/*     */       return;
/*     */     }
/*     */ 
/*     */     
/* 307 */     this.editor.editFlagsOfSelected(response.flags());
/*     */   }
/*     */ 
/*     */   
/*     */   private void colorPicked(ColorPickerScreen.ColorPickerResponse response) {
/* 312 */     if (response.canceled()) {
/*     */       return;
/*     */     }
/*     */ 
/*     */     
/* 317 */     this.editor.editColorsOfSelected(response.color());
/*     */   }
/*     */ 
/*     */   
/*     */   public void setFlags(EnumSet<BlockFlag> flags) {
/* 322 */     this.flags = flags.clone();
/* 323 */     this.flagsString = flags.toString();
/*     */   }
/*     */ 
/*     */   
/*     */   public void setColor(int color) {
/* 328 */     this.color = color;
/*     */   }
/*     */ 
/*     */   
/*     */   public void resetItemToDefault() {
/* 333 */     ColorPalette defaultPalette = ColorManager.INSTANCE.getDefaultPalette();
/* 334 */     BlockStateColor defaultBSC = defaultPalette.getBlockStateColor(this.blockId, this.state);
/* 335 */     EnumSet<BlockFlag> flags = (defaultBSC.flags == null) ? EnumSet.<BlockFlag>noneOf(BlockFlag.class) : defaultBSC.flags;
/* 336 */     int color = RGB.hexToInt(defaultBSC.color) & 0xFFFFFF | (int)(defaultBSC.alpha.floatValue() * 255.0F) << 24;
/* 337 */     setColor(color);
/* 338 */     setFlags(flags);
/* 339 */     this.editor.validate();
/*     */   }
/*     */ 
/*     */   
/*     */   public void undoItem() {
/* 344 */     setColor(this.originalColor);
/* 345 */     setFlags(this.originalFlags);
/* 346 */     this.editor.validate();
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isEdited() {
/* 351 */     return (this.color != this.originalColor || !this.flags.equals(this.originalFlags));
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Collection<SlotMetadata> getMetadata() {
/* 357 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean mouseClicked(double mouseX, double mouseY, int mouseEvent) {
/*     */     try {
/* 365 */       if (this.buttonDefault.mouseClicked(mouseX, mouseY, mouseEvent))
/*     */       {
/* 367 */         return true;
/*     */       }
/* 369 */       if (this.buttonUndo.mouseClicked(mouseX, mouseY, mouseEvent))
/*     */       {
/* 371 */         return true;
/*     */       }
/* 373 */       if (this.buttonBlockFlags != null && this.buttonBlockFlags.mouseClicked(mouseX, mouseY, mouseEvent)) {
/*     */         
/* 375 */         this.editor.popupButtonPressed(this);
/* 376 */         return false;
/*     */       } 
/* 378 */       if (this.buttonColorPicker.mouseClicked(mouseX, mouseY, mouseEvent)) {
/*     */         
/* 380 */         this.editor.popupButtonPressed(this);
/* 381 */         ColorPaletteItemEditor.access$000(this.editor, ComponentPath.path((ContainerEventHandler)this, ComponentPath.leaf((GuiEventListener)this.buttonColorPicker)));
/* 382 */         return false;
/*     */       } 
/*     */       
/* 385 */       if (mouseEvent == 0) {
/*     */         
/* 387 */         long sysTime = Util.getMillis();
/* 388 */         boolean doubleClick = (sysTime - this.lastClick < 200L);
/* 389 */         this.lastClick = sysTime;
/* 390 */         if (doubleClick) {
/*     */           
/* 392 */           this.buttonColorPicker.onPress();
/* 393 */           this.editor.selectOnly(this);
/* 394 */           return false;
/*     */         } 
/*     */       } 
/*     */       
/* 398 */       ColorPaletteItemEditor.access$100(this.editor, ComponentPath.path((ContainerEventHandler)this, ComponentPath.leaf((GuiEventListener)this.buttonColorPicker)));
/*     */       
/* 400 */       return true;
/*     */     }
/* 402 */     catch (Exception e) {
/*     */       
/* 404 */       Journeymap.getLogger().error("WARNING: Problem with mouseClicked.");
/* 405 */       throw new RuntimeException("mouseClicked", e);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public List<? extends Slot> getChildSlots(int listWidth, int columnWidth) {
/* 412 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public SlotMetadata getLastPressed() {
/* 418 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public SlotMetadata getCurrentTooltip() {
/* 424 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setEnabled(boolean enabled) {}
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getColumnWidth() {
/* 436 */     return 0;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean contains(SlotMetadata slotMetadata) {
/* 442 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void render(GuiGraphics graphics, int slotIndex, int y, int x, int rowWidth, int itemHeight, int mouseX, int mouseY, boolean isMouseOver, float partialTicks) {
/* 448 */     DrawUtil.drawRectangle(graphics, x, y, (rowWidth - 4), itemHeight, this.color, 1.0F);
/*     */     
/* 450 */     Objects.requireNonNull(this.fontRenderer); graphics.drawString(this.fontRenderer, this.state, x + 5, y + (itemHeight - 9) / 2 - 3, -1, true);
/* 451 */     if (!this.flags.isEmpty()) {
/*     */       
/* 453 */       Objects.requireNonNull(this.fontRenderer); graphics.drawString(this.fontRenderer, this.flagsString, x + 5, y + (itemHeight + 9) / 2 - 2, 12632256, true);
/*     */     } 
/*     */     
/* 456 */     this.buttonDefault.leftOf(x + rowWidth - 57);
/* 457 */     this.buttonDefault.below(y + 3);
/* 458 */     this.buttonDefault.render(graphics, mouseX, mouseY, partialTicks);
/*     */     
/* 460 */     this.buttonUndo.setVisible(isEdited());
/* 461 */     this.buttonUndo.leftOf(x + rowWidth - 59 - this.buttonDefault.getWidth());
/* 462 */     this.buttonUndo.below(y + 3);
/* 463 */     this.buttonUndo.render(graphics, mouseX, mouseY, partialTicks);
/*     */     
/* 465 */     if (isMouseOver || isFocused()) {
/*     */       
/* 467 */       if (this.buttonBlockFlags != null) {
/*     */         
/* 469 */         this.buttonBlockFlags.leftOf(x + rowWidth - 30);
/* 470 */         this.buttonBlockFlags.below(y + 1);
/* 471 */         this.buttonBlockFlags.render(graphics, mouseX, mouseY, partialTicks);
/*     */       } 
/*     */ 
/*     */       
/* 475 */       this.buttonColorPicker.leftOf(x + rowWidth - 5);
/* 476 */       this.buttonColorPicker.below(y + 1);
/* 477 */       this.buttonColorPicker.render(graphics, mouseX, mouseY, partialTicks);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public List<? extends GuiEventListener> children() {
/* 484 */     return this.children;
/*     */   }
/*     */ }


/* Location:              C:\Users\Administrator\Downloads\journeymap-neoforge-1.21-6.0.0-beta.18.jar!\journeymap\clien\\ui\colorpalette\ColorPaletteItemEditor$ColorStateItem.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */