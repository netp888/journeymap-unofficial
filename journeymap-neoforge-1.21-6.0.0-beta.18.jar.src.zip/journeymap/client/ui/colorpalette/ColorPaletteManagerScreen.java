/*     */ package journeymap.client.ui.colorpalette;
/*     */ import journeymap.client.Constants;
/*     */ import journeymap.client.cartography.color.ColorManager;
/*     */ import journeymap.client.cartography.color.ColorPalette;
/*     */ import journeymap.client.ui.component.buttons.Button;
/*     */ import journeymap.client.ui.component.popupscreenbutton.PopupButton;
/*     */ import journeymap.client.ui.component.popupscreenbutton.PopupButtonScreen;
/*     */ import journeymap.client.ui.component.popupscreenbutton.simple.ConfirmationPopup;
/*     */ import net.minecraft.ChatFormatting;
/*     */ import net.minecraft.client.gui.Font;
/*     */ import net.minecraft.client.gui.GuiGraphics;
/*     */ import net.minecraft.client.gui.components.Button;
/*     */ import net.minecraft.client.gui.components.StringWidget;
/*     */ import net.minecraft.client.gui.layouts.LayoutElement;
/*     */ import net.minecraft.client.gui.layouts.LinearLayout;
/*     */ import net.minecraft.client.gui.layouts.SpacerElement;
/*     */ import net.minecraft.network.chat.Component;
/*     */ import net.minecraft.resources.ResourceLocation;
/*     */ 
/*     */ public class ColorPaletteManagerScreen extends JmUI {
/*  21 */   private static final ResourceLocation BACKGROUND_SPRITE = ResourceLocation.parse("popup/background");
/*     */   
/*  23 */   private final Component labelBlocks = (Component)Component.translatable("jm.colorpalette.total_blocks");
/*  24 */   private final Component labelStates = (Component)Component.translatable("jm.colorpalette.total_states");
/*  25 */   private final Component labelClose = (Component)Component.translatable("jm.common.close");
/*     */   
/*     */   ColorPaletteScreen colorPaletteScreen;
/*     */   
/*     */   Palette globalPalette;
/*     */   Palette worldPalette;
/*     */   
/*     */   public ColorPaletteManagerScreen(ColorPaletteScreen returnDisplay) {
/*  33 */     super(Constants.getString("jm.colorpalette.manage_palettes_title"), true, (Screen)returnDisplay);
/*  34 */     this.colorPaletteScreen = returnDisplay;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void init() {
/*  40 */     super.init();
/*     */     
/*  42 */     LinearLayout linearLayout = LinearLayout.vertical();
/*  43 */     linearLayout.spacing(6).defaultCellSetting().alignHorizontallyCenter();
/*     */     
/*  45 */     ColorPalette defaultPalette = ColorManager.INSTANCE.getDefaultPalette();
/*  46 */     linearLayout.addChild((LayoutElement)new StringWidget((Component)this.labelBlocks.copy().append(String.valueOf(defaultPalette.blockCount())), this.font));
/*  47 */     linearLayout.addChild((LayoutElement)new StringWidget((Component)this.labelStates.copy().append(String.valueOf(defaultPalette.stateCount())), this.font));
/*  48 */     linearLayout.addChild((LayoutElement)new SpacerElement(0, 10));
/*     */     
/*  50 */     LinearLayout paletteLayout = LinearLayout.horizontal();
/*  51 */     paletteLayout.spacing(30).defaultCellSetting().alignVerticallyTop();
/*  52 */     this.globalPalette = (Palette)paletteLayout.addChild((LayoutElement)new Palette(ColorManager.INSTANCE.getGlobalPalette(), this.font, this));
/*  53 */     this.worldPalette = (Palette)paletteLayout.addChild((LayoutElement)new Palette(ColorManager.INSTANCE.getWorldPalette(), this.font, this));
/*  54 */     linearLayout.addChild((LayoutElement)paletteLayout);
/*  55 */     this.contentLayout.addChild((LayoutElement)linearLayout);
/*     */     
/*  57 */     this.footerLayout.addChild((LayoutElement)Button.builder(this.labelClose, b -> closeAndReturn()).width(this.font.width((FormattedText)this.labelClose) + 10).build());
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void renderBackground(GuiGraphics graphics, int mouseX, int mouseY, float partialTick) {
/*  63 */     renderTransparentBackground(graphics);
/*  64 */     graphics.blitSprite(BACKGROUND_SPRITE, this.globalPalette.getX() - 8, this.globalPalette.getY() - 8, this.globalPalette.getWidth() + 16, this.globalPalette.getHeight() + 16);
/*  65 */     graphics.blitSprite(BACKGROUND_SPRITE, this.worldPalette.getX() - 8, this.worldPalette.getY() - 8, this.worldPalette.getWidth() + 16, this.worldPalette.getHeight() + 16);
/*     */   }
/*     */ 
/*     */   
/*     */   private void deleteAll(ColorPalette.Type type) {
/*  70 */     ColorPalette palette = (type == ColorPalette.Type.Global) ? ColorManager.INSTANCE.getGlobalPalette() : ColorManager.INSTANCE.getWorldPalette();
/*  71 */     palette.clear();
/*  72 */     this.colorPaletteScreen.setRemapNeeded();
/*  73 */     rebuildWidgets();
/*     */   }
/*     */ 
/*     */   
/*     */   private void copyPalette(CopyPalettePopup.Mode mode, boolean globalToWorld) {
/*  78 */     ColorPalette global = ColorManager.INSTANCE.getGlobalPalette();
/*  79 */     ColorPalette world = ColorManager.INSTANCE.getWorldPalette();
/*  80 */     if (world == null) {
/*     */       return;
/*     */     }
/*     */ 
/*     */     
/*  85 */     switch (mode) {
/*     */       
/*     */       case CopyAllAndReplace:
/*  88 */         if (globalToWorld) {
/*     */           
/*  90 */           world.copyAllFromPalette(global);
/*     */           
/*     */           break;
/*     */         } 
/*  94 */         global.copyAllFromPalette(world);
/*     */         break;
/*     */       
/*     */       case CopyExistingAndReplace:
/*  98 */         if (globalToWorld) {
/*     */           
/* 100 */           world.copyExistingFromPalette(global);
/*     */           
/*     */           break;
/*     */         } 
/* 104 */         global.copyExistingFromPalette(world);
/*     */         break;
/*     */       
/*     */       default:
/* 108 */         if (globalToWorld) {
/*     */           
/* 110 */           world.copyNonExistingFromPalette(global);
/*     */           
/*     */           break;
/*     */         } 
/* 114 */         global.copyNonExistingFromPalette(world);
/*     */         break;
/*     */     } 
/*     */ 
/*     */     
/* 119 */     this.colorPaletteScreen.setRemapNeeded();
/* 120 */     rebuildWidgets();
/*     */   }
/*     */   
/*     */   static class Palette
/*     */     extends LinearLayout
/*     */   {
/* 126 */     private final Component labelGlobal = (Component)Component.translatable("jm.colorpalette.global").withStyle(ChatFormatting.BOLD);
/* 127 */     private final Component labelWorld = (Component)Component.translatable("jm.colorpalette.world").withStyle(ChatFormatting.BOLD);
/* 128 */     private final Component labelBlocks = (Component)Component.translatable("jm.colorpalette.blocks");
/* 129 */     private final Component labelStates = (Component)Component.translatable("jm.colorpalette.states");
/* 130 */     private final String deleteLabel = Constants.getString("jm.colorpalette.delete_all");
/* 131 */     private final String labelCopyToRight = "  " + Constants.getString("jm.colorpalette.copy") + " >";
/* 132 */     private final String labelCopyToLeft = "< " + Constants.getString("jm.colorpalette.copy") + "  ";
/*     */     
/*     */     private final ColorPalette colorPalette;
/*     */     
/*     */     private final ColorPaletteManagerScreen screen;
/*     */     
/*     */     public Palette(ColorPalette colorPalette, Font font, ColorPaletteManagerScreen screen) {
/* 139 */       super(0, 0, LinearLayout.Orientation.VERTICAL);
/* 140 */       this.colorPalette = colorPalette;
/* 141 */       this.screen = screen;
/*     */       
/* 143 */       spacing(4).defaultCellSetting().alignHorizontallyCenter();
/* 144 */       addChild((LayoutElement)new SpacerElement(100, 0));
/* 145 */       addChild((LayoutElement)new StringWidget((colorPalette.getType() == ColorPalette.Type.Global) ? this.labelGlobal : this.labelWorld, font));
/* 146 */       addChild((LayoutElement)new SpacerElement(0, 0));
/* 147 */       addChild((LayoutElement)new StringWidget((Component)this.labelBlocks.copy().append(String.valueOf(colorPalette.blockCount())), font));
/* 148 */       addChild((LayoutElement)new StringWidget((Component)this.labelStates.copy().append(String.valueOf(colorPalette.stateCount())), font));
/*     */       
/* 150 */       if (colorPalette.isEmpty()) {
/*     */         
/* 152 */         addChild((LayoutElement)new SpacerElement(0, 44));
/*     */       }
/*     */       else {
/*     */         
/* 156 */         String labelCopy = (colorPalette.getType() == ColorPalette.Type.Global) ? this.labelCopyToRight : this.labelCopyToLeft;
/* 157 */         addChild((LayoutElement)new PopupButton(font
/* 158 */               .width(labelCopy) + 10, 0, labelCopy, CopyPalettePopup::new, this::copyPalette));
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 164 */         addChild((LayoutElement)new PopupButton(font
/* 165 */               .width(this.deleteLabel) + 10, 0, this.deleteLabel, () -> new ConfirmationPopup("jm.colorpalette.delete_all_dialog", "jm.colorpalette.delete_all", "jm.colorpalette.cancel"), this::deletePalette));
/*     */       } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 175 */       addChild((LayoutElement)new SpacerElement(0, 0));
/*     */     }
/*     */ 
/*     */     
/*     */     public void copyPalette(CopyPalettePopup.Mode mode) {
/* 180 */       if (mode != null)
/*     */       {
/* 182 */         this.screen.copyPalette(mode, (this.colorPalette.getType() == ColorPalette.Type.Global));
/*     */       }
/*     */     }
/*     */ 
/*     */     
/*     */     public void deletePalette(boolean delete) {
/* 188 */       if (delete)
/*     */       {
/* 190 */         this.screen.deleteAll(this.colorPalette.getType());
/*     */       }
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\Administrator\Downloads\journeymap-neoforge-1.21-6.0.0-beta.18.jar!\journeymap\clien\\ui\colorpalette\ColorPaletteManagerScreen.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */