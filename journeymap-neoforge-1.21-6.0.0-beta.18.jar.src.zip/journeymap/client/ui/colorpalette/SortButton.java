/*    */ package journeymap.client.ui.colorpalette;
/*    */ 
/*    */ import journeymap.client.Constants;
/*    */ import journeymap.client.ui.component.buttons.OnOffButton;
/*    */ import net.minecraft.client.gui.GuiGraphics;
/*    */ import net.minecraft.client.gui.components.Button;
/*    */ import net.minecraft.network.chat.Component;
/*    */ 
/*    */ 
/*    */ class SortButton
/*    */   extends OnOffButton
/*    */ {
/*    */   final ColorPaletteItem.Sort sort;
/*    */   final String labelInactive;
/*    */   
/*    */   public SortButton(String label, ColorPaletteItem.Sort sort, Button.OnPress onPress) {
/* 17 */     super(String.format("%s %s", new Object[] { label, "▲" }), String.format("%s %s", new Object[] { label, "▼" }), sort.ascending, onPress);
/* 18 */     this.labelInactive = label;
/* 19 */     this.sort = sort;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public void toggle() {
/* 25 */     this.sort.ascending = !this.sort.ascending;
/* 26 */     setActive(true);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public void renderWidget(GuiGraphics graphics, int mouseX, int mouseY, float f) {
/* 32 */     super.renderWidget(graphics, mouseX, mouseY, f);
/* 33 */     drawUnderline(graphics);
/*    */   }
/*    */ 
/*    */   
/*    */   public void setActive(boolean active) {
/* 38 */     if (active) {
/*    */       
/* 40 */       setToggled(Boolean.valueOf(this.sort.ascending));
/*    */     }
/*    */     else {
/*    */       
/* 44 */       setMessage((Component)Constants.getStringTextComponent(String.format("%s %s", new Object[] { this.labelInactive, " " })));
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Users\Administrator\Downloads\journeymap-neoforge-1.21-6.0.0-beta.18.jar!\journeymap\clien\\ui\colorpalette\SortButton.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */