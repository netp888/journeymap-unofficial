/*     */ package journeymap.client.ui.minimap;
/*     */ 
/*     */ import com.mojang.blaze3d.platform.InputConstants;
/*     */ import com.mojang.blaze3d.vertex.VertexConsumer;
/*     */ import com.mojang.math.Axis;
/*     */ import java.awt.geom.Point2D;
/*     */ import java.awt.geom.Rectangle2D;
/*     */ import journeymap.api.client.impl.ClientAPI;
/*     */ import journeymap.api.v2.client.display.Context;
/*     */ import journeymap.api.v2.client.util.UIState;
/*     */ import journeymap.client.JourneymapClient;
/*     */ import journeymap.client.data.DataCache;
/*     */ import journeymap.client.feature.Feature;
/*     */ import journeymap.client.feature.FeatureManager;
/*     */ import journeymap.client.log.JMLogger;
/*     */ import journeymap.client.log.StatTimer;
/*     */ import journeymap.client.model.EntityDTO;
/*     */ import journeymap.client.model.MapState;
/*     */ import journeymap.client.model.MapType;
/*     */ import journeymap.client.properties.CoreProperties;
/*     */ import journeymap.client.properties.InGameMapProperties;
/*     */ import journeymap.client.properties.MapProperties;
/*     */ import journeymap.client.properties.MiniMapProperties;
/*     */ import journeymap.client.render.JMRenderTypes;
/*     */ import journeymap.client.render.RenderWrapper;
/*     */ import journeymap.client.render.draw.DrawEntityStep;
/*     */ import journeymap.client.render.draw.DrawStep;
/*     */ import journeymap.client.render.draw.DrawUtil;
/*     */ import journeymap.client.render.draw.DrawWayPointStep;
/*     */ import journeymap.client.render.draw.RadarDrawStepFactory;
/*     */ import journeymap.client.render.draw.WaypointDrawStepFactory;
/*     */ import journeymap.client.render.map.MapRenderer;
/*     */ import journeymap.client.render.map.Renderer;
/*     */ import journeymap.client.texture.Texture;
/*     */ import journeymap.client.texture.TextureCache;
/*     */ import journeymap.client.ui.UIManager;
/*     */ import journeymap.client.ui.component.screens.JmUI;
/*     */ import journeymap.client.ui.option.MapTypeProvider;
/*     */ import net.minecraft.client.Minecraft;
/*     */ import net.minecraft.client.gui.GuiGraphics;
/*     */ import net.minecraft.client.renderer.MultiBufferSource;
/*     */ import net.minecraft.core.BlockPos;
/*     */ import net.minecraft.util.Mth;
/*     */ import net.minecraft.world.entity.player.Player;
/*     */ import net.minecraft.world.level.Level;
/*     */ import net.minecraft.world.phys.Vec2;
/*     */ import net.minecraft.world.phys.Vec3;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MiniMap
/*     */   implements Selectable
/*     */ {
/*  60 */   private static final MapState state = new MapState();
/*     */   
/*  62 */   private static final MapRenderer mapRenderer = new MapRenderer(Context.UI.Minimap);
/*  63 */   private final Minecraft mc = Minecraft.getInstance();
/*  64 */   private final WaypointDrawStepFactory waypointRenderer = new WaypointDrawStepFactory();
/*  65 */   private final RadarDrawStepFactory radarRenderer = new RadarDrawStepFactory();
/*     */   
/*     */   private Texture playerArrowFg;
/*     */   private Texture playerArrowBg;
/*     */   private int playerArrowColor;
/*     */   private MiniMapProperties miniMapProperties;
/*     */   private StatTimer drawTimer;
/*     */   private StatTimer refreshStateTimer;
/*     */   private DisplayVars dv;
/*     */   private boolean minimapDragging = false;
/*  75 */   private int mouseDragOffsetX = 0;
/*  76 */   private int mouseDragOffsetY = 0;
/*     */   
/*     */   private Point2D.Double centerPoint;
/*     */   
/*     */   private Rectangle2D.Double centerRect;
/*     */   private long initTime;
/*  82 */   private long lastAutoDayNightTime = -1L;
/*     */ 
/*     */   
/*     */   private Boolean lastPlayerUnderground;
/*     */ 
/*     */   
/*     */   private boolean drawingInPreviewMode = false;
/*     */ 
/*     */   
/*     */   private boolean preview = false;
/*     */ 
/*     */ 
/*     */   
/*     */   public MiniMap(MiniMapProperties miniMapProperties) {
/*  96 */     this.initTime = System.currentTimeMillis();
/*  97 */     setMiniMapProperties(miniMapProperties);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static synchronized MapState state() {
/* 107 */     return state;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static synchronized UIState uiState() {
/* 117 */     return mapRenderer.getUIState();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void updateUIState(boolean isActive) {
/* 127 */     if ((Minecraft.getInstance()).level != null)
/*     */     {
/* 129 */       mapRenderer.updateUIState(isActive);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public DisplayVars getDisplayVars() {
/* 135 */     return this.dv;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean withinBounds(double mouseX, double mouseY) {
/* 140 */     double scale = JmUI.calculateScaleFactor();
/* 141 */     double posX = mouseX * scale;
/* 142 */     double posY = mouseY * scale;
/* 143 */     DisplayVars vars = UIManager.INSTANCE.getMiniMap().getDisplayVars();
/* 144 */     return (posX > vars.textureX && posX < (vars.textureX + vars.minimapWidth) && posY > vars.textureY && posY < (vars.textureY + vars.minimapHeight));
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private void initGridRenderer() {
/* 150 */     mapRenderer.clear();
/* 151 */     state.requireRefresh();
/* 152 */     if (this.mc.player == null || !this.mc.player.isAlive()) {
/*     */       return;
/*     */     }
/*     */     
/* 156 */     int zoom = this.miniMapProperties.zoomLevel.get().intValue();
/*     */     
/* 158 */     state.refresh(this.mc, (Player)this.mc.player, (InGameMapProperties)this.miniMapProperties);
/*     */     
/* 160 */     MapType mapType = state.getMapType();
/* 161 */     BlockPos playerCamera = this.mc.gameRenderer.getMainCamera().getBlockPosition();
/* 162 */     mapRenderer.setContext(state);
/* 163 */     mapRenderer.center(state.getWorldDir(), mapType, playerCamera.getX(), playerCamera.getZ(), zoom);
/*     */ 
/*     */     
/* 166 */     mapRenderer.updateTiles(state.getMapType(), zoom, true);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void resetInitTime() {
/* 174 */     this.initTime = System.currentTimeMillis();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setMiniMapProperties(MiniMapProperties miniMapProperties) {
/* 184 */     this.miniMapProperties = miniMapProperties;
/* 185 */     state().requireRefresh();
/* 186 */     reset();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MiniMapProperties getCurrentMinimapProperties() {
/* 196 */     return this.miniMapProperties;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void drawMap(GuiGraphics graphics) {
/* 204 */     drawMap(graphics, false);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void drawMap(GuiGraphics graphics, boolean preview) {
/* 214 */     StatTimer timer = this.drawTimer;
/*     */ 
/*     */     
/*     */     try {
/* 218 */       this.preview = preview;
/* 219 */       MultiBufferSource.BufferSource buffers = graphics.bufferSource();
/* 220 */       graphics.pose().pushPose();
/*     */       
/* 222 */       if (this.mc.player == null || !this.mc.player.isAlive()) {
/*     */         return;
/*     */       }
/*     */ 
/*     */ 
/*     */       
/* 228 */       mapRenderer.clearGlErrors(false);
/*     */ 
/*     */       
/* 231 */       boolean doStateRefresh = state.shouldRefresh(this.mc, (MapProperties)this.miniMapProperties);
/*     */ 
/*     */       
/* 234 */       if (doStateRefresh) {
/*     */         
/* 236 */         timer = this.refreshStateTimer.start();
/* 237 */         autoDayNight();
/* 238 */         mapRenderer.setContext(state);
/* 239 */         if (!preview)
/*     */         {
/* 241 */           state.refresh(this.mc, (Player)this.mc.player, (InGameMapProperties)this.miniMapProperties);
/*     */         }
/* 243 */         ClientAPI.INSTANCE.flagOverlaysForRerender();
/*     */       }
/*     */       else {
/*     */         
/* 247 */         timer.start();
/*     */       } 
/*     */       
/* 250 */       int width = this.mc.getWindow().getScreenWidth();
/* 251 */       int height = this.mc.getWindow().getScreenHeight();
/*     */       
/* 253 */       if (height == 0 || width == 0) {
/*     */         return;
/*     */       }
/*     */       
/* 257 */       Vec3 playerCamera = this.mc.gameRenderer.getMainCamera().getPosition();
/* 258 */       int zoom = this.miniMapProperties.zoomLevel.get().intValue();
/*     */       
/* 260 */       boolean moved = mapRenderer.center(state.getWorldDir(), state.getMapType(), playerCamera.x(), playerCamera
/* 261 */           .z(), zoom);
/* 262 */       if (moved || doStateRefresh)
/*     */       {
/*     */         
/* 265 */         mapRenderer.updateTiles(state.getMapType(), zoom, (doStateRefresh || preview));
/*     */       }
/*     */ 
/*     */       
/* 269 */       if (doStateRefresh) {
/*     */ 
/*     */         
/* 272 */         boolean checkWaypointDistance = ((JourneymapClient.getInstance().getWaypointProperties()).maxDistance.get().intValue() > 0);
/* 273 */         state.generateDrawSteps(this.mc, (Renderer)mapRenderer, this.waypointRenderer, this.radarRenderer, (InGameMapProperties)this.miniMapProperties, checkWaypointDistance);
/*     */         
/* 275 */         state.updateLastRefresh();
/*     */       } 
/*     */ 
/*     */       
/* 279 */       updateDisplayVars(false);
/*     */ 
/*     */       
/* 282 */       long now = System.currentTimeMillis();
/*     */ 
/*     */       
/* 285 */       DrawUtil.sizeDisplay(width, height);
/*     */ 
/*     */       
/* 288 */       RenderWrapper.enableBlend();
/* 289 */       RenderWrapper.blendFunc(770, 0);
/* 290 */       RenderWrapper.setColor4f(1.0F, 1.0F, 1.0F, 1.0F);
/* 291 */       RenderWrapper.enableDepthTest();
/*     */       
/* 293 */       this.dv.minimapFrame.drawMask(graphics, (MultiBufferSource)buffers);
/*     */ 
/*     */       
/* 296 */       double rotation = 0.0D;
/* 297 */       switch (this.dv.orientation) {
/*     */ 
/*     */         
/*     */         case North:
/* 301 */           rotation = 0.0D;
/*     */           break;
/*     */ 
/*     */         
/*     */         case OldNorth:
/* 306 */           rotation = 90.0D;
/*     */           break;
/*     */ 
/*     */         
/*     */         case PlayerHeading:
/* 311 */           if (this.dv.shape == Shape.Circle)
/*     */           {
/* 313 */             rotation = (180.0F - this.mc.gameRenderer.getMainCamera().getYRot());
/*     */           }
/*     */           break;
/*     */       } 
/*     */ 
/*     */ 
/*     */       
/* 320 */       startMapRotation(graphics, rotation);
/*     */ 
/*     */       
/*     */       try {
/* 324 */         VertexConsumer vertexBuilder = buffers.getBuffer(JMRenderTypes.RECTANGLE_RENDER_TYPE);
/* 325 */         DrawUtil.drawRectangle(graphics.pose(), vertexBuilder, this.dv.textureX, this.dv.textureY, this.dv.minimapWidth, this.dv.minimapHeight, 2236962, this.miniMapProperties.backgroundAlpha
/* 326 */             .get().floatValue());
/*     */ 
/*     */         
/* 329 */         graphics.pose().translate(this.dv.translateX, this.dv.translateY, 0.0F);
/*     */ 
/*     */         
/* 332 */         mapRenderer.render(graphics, buffers, 0.0D, 0.0D, this.dv.terrainAlpha, this.miniMapProperties.showGrid
/* 333 */             .get().booleanValue());
/*     */ 
/*     */         
/* 336 */         this.centerPoint = mapRenderer.getPixel(playerCamera.x(), playerCamera.z());
/*     */         
/* 338 */         this.centerRect = new Rectangle2D.Double(this.centerPoint.x - (this.dv.minimapWidth / 2), this.centerPoint.y - (this.dv.minimapHeight / 2), this.dv.minimapWidth, this.dv.minimapHeight);
/*     */ 
/*     */ 
/*     */         
/* 342 */         drawOnMapEntities(graphics, (MultiBufferSource)buffers, rotation);
/*     */ 
/*     */         
/* 345 */         graphics.pose().translate(-this.dv.translateX, -this.dv.translateY, 0.0F);
/*     */ 
/*     */         
/* 348 */         ReticleOrientation reticleOrientation = null;
/* 349 */         if (this.dv.showReticle) {
/*     */           
/* 351 */           reticleOrientation = this.dv.minimapFrame.getReticleOrientation();
/* 352 */           if (reticleOrientation == ReticleOrientation.Compass) {
/*     */             
/* 354 */             this.dv.minimapFrame.drawReticle(graphics);
/*     */           
/*     */           }
/*     */           else {
/*     */             
/* 359 */             startMapRotation(graphics, this.mc.gameRenderer.getMainCamera().getYRot());
/* 360 */             this.dv.minimapFrame.drawReticle(graphics);
/*     */             
/* 362 */             stopMapRotation(graphics, this.mc.gameRenderer.getMainCamera().getYRot());
/*     */           } 
/*     */         } 
/*     */ 
/*     */         
/* 367 */         long lastMapChangeTime = state.getLastMapTypeChange();
/* 368 */         if (now - lastMapChangeTime <= 1000L) {
/*     */           
/* 370 */           stopMapRotation(graphics, rotation);
/* 371 */           graphics.pose().translate(this.dv.translateX, this.dv.translateY, 0.0F);
/* 372 */           float alpha = (float)Math.min(255L, Math.max(0L, 1100L - now - lastMapChangeTime)) / 255.0F;
/* 373 */           Point2D.Double windowCenter = mapRenderer.getWindowPosition(this.centerPoint);
/* 374 */           this.dv.getMapTypeStatus(state.getMapType()).draw(graphics, windowCenter, alpha, 0.0D);
/* 375 */           graphics.pose().translate(-this.dv.translateX, -this.dv.translateY, 0.0F);
/* 376 */           startMapRotation(graphics, rotation);
/*     */         } 
/*     */ 
/*     */         
/* 380 */         if (now - this.initTime <= 1000L) {
/*     */           
/* 382 */           stopMapRotation(graphics, rotation);
/* 383 */           graphics.pose().translate(this.dv.translateX, this.dv.translateY, 1000.0F);
/* 384 */           float alpha = (float)Math.min(255L, Math.max(0L, 1100L - now - this.initTime)) / 255.0F;
/* 385 */           Point2D.Double windowCenter = mapRenderer.getWindowPosition(this.centerPoint);
/* 386 */           this.dv.getMapPresetStatus(state.getMapType(), this.miniMapProperties.getId())
/* 387 */             .draw(graphics, windowCenter, alpha, 0.0D);
/* 388 */           graphics.pose().translate(-this.dv.translateX, -this.dv.translateY, -1000.0F);
/* 389 */           startMapRotation(graphics, rotation);
/*     */         } 
/*     */ 
/*     */         
/* 393 */         endMasking(graphics);
/*     */ 
/*     */         
/* 396 */         if (!this.dv.frameRotates && rotation != 0.0D)
/*     */         {
/* 398 */           stopMapRotation(graphics, rotation);
/*     */         }
/*     */         
/* 401 */         this.dv.minimapFrame.drawFrame(graphics);
/*     */         
/* 403 */         if (!this.dv.frameRotates && rotation != 0.0D)
/*     */         {
/* 405 */           startMapRotation(graphics, rotation);
/*     */         }
/*     */ 
/*     */         
/* 409 */         if (this.dv.showCompass)
/*     */         {
/* 411 */           this.dv.minimapCompassPoints.drawPoints(graphics, rotation);
/*     */         }
/*     */ 
/*     */         
/* 415 */         graphics.pose().translate(this.dv.translateX, this.dv.translateY, 0.0F);
/*     */ 
/*     */         
/* 418 */         drawWaypoints(graphics, buffers, rotation);
/*     */ 
/*     */         
/* 421 */         if (this.miniMapProperties.showSelf.get().booleanValue() && this.playerArrowFg != null) {
/*     */           
/* 423 */           float playerArrowScale = this.miniMapProperties.selfDisplayScale.get().floatValue();
/* 424 */           if (this.centerPoint != null) {
/*     */             
/* 426 */             DrawUtil.drawColoredEntity(graphics.pose(), this.centerPoint.getX(), this.centerPoint.getY(), this.playerArrowBg, 16777215, 1.0F, playerArrowScale / 5.0F, this.mc.gameRenderer
/*     */                 
/* 428 */                 .getMainCamera().getYRot());
/* 429 */             DrawUtil.drawColoredEntity(graphics.pose(), this.centerPoint.getX(), this.centerPoint.getY(), this.playerArrowFg, this.playerArrowColor, 1.0F, playerArrowScale / 5.0F, this.mc.gameRenderer
/*     */                 
/* 431 */                 .getMainCamera().getYRot());
/*     */           } 
/*     */         } 
/*     */ 
/*     */         
/* 436 */         if (this.dv.showCompass) {
/*     */ 
/*     */           
/* 439 */           graphics.pose().translate(-this.dv.translateX, -this.dv.translateY, 0.0F);
/* 440 */           this.dv.minimapCompassPoints.drawLabels(graphics, (MultiBufferSource)buffers, rotation);
/*     */         } 
/* 442 */         graphics.pose().popPose();
/*     */         
/* 444 */         this.dv.drawInfoLabels(graphics, (MultiBufferSource)buffers, now);
/*     */       
/*     */       }
/*     */       finally {
/*     */ 
/*     */         
/* 450 */         stopMapRotation(graphics, rotation);
/* 451 */         buffers.endBatch();
/*     */       } 
/*     */ 
/*     */       
/* 455 */       DrawUtil.sizeDisplay(this.dv.mainWindow.getWidth() / this.dv.mainWindow.getGuiScale(), this.dv.mainWindow
/* 456 */           .getHeight() / this.dv.mainWindow.getGuiScale());
/*     */     }
/* 458 */     catch (Throwable t) {
/*     */       
/* 460 */       JMLogger.throwLogOnce("Error during MiniMap.drawMap(): " + t.getMessage(), t);
/*     */     
/*     */     }
/*     */     finally {
/*     */       
/* 465 */       timer.stop();
/*     */ 
/*     */       
/* 468 */       mapRenderer.clearGlErrors(true);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private void drawOnMapEntities(GuiGraphics graphics, MultiBufferSource buffers, double rotation) {
/* 475 */     for (DrawStep.Pass pass : DrawStep.Pass.values()) {
/*     */       
/* 477 */       int zLevel = 0;
/* 478 */       for (DrawStep drawStep : state.getDrawSteps()) {
/*     */         boolean onScreen;
/*     */         
/* 481 */         if (drawStep instanceof DrawEntityStep) {
/*     */           
/* 483 */           Point2D.Double position = ((DrawEntityStep)drawStep).getPosition(0.0D, 0.0D, (Renderer)mapRenderer, true);
/*     */           
/* 485 */           onScreen = isOnScreen(position, this.centerPoint, this.centerRect);
/*     */         }
/*     */         else {
/*     */           
/* 489 */           onScreen = true;
/*     */         } 
/*     */         
/* 492 */         if (onScreen) {
/*     */           
/* 494 */           zLevel++;
/* 495 */           graphics.pose().pushPose();
/* 496 */           graphics.pose().translate(0.0F, 0.0F, zLevel);
/* 497 */           drawStep.draw(graphics, buffers, pass, 0.0D, 0.0D, (Renderer)mapRenderer, this.dv.fontScale, rotation);
/* 498 */           graphics.pose().popPose();
/*     */         } 
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private void drawWaypoints(GuiGraphics graphics, MultiBufferSource.BufferSource buffers, double rotation) {
/* 507 */     boolean showLabel = this.miniMapProperties.showWaypointLabels.get().booleanValue();
/*     */     
/* 509 */     for (DrawStep.Pass pass : DrawStep.Pass.values()) {
/*     */       
/* 511 */       for (DrawWayPointStep drawWayPointStep : state.getDrawWaypointSteps()) {
/*     */         
/* 513 */         drawWayPointStep.setIconScale(this.miniMapProperties.waypointIconScale.get().floatValue());
/* 514 */         boolean onScreen = false;
/*     */         
/* 516 */         if (pass == DrawStep.Pass.PreObject || pass == DrawStep.Pass.Object || pass == DrawStep.Pass.PostObject) {
/*     */ 
/*     */           
/* 519 */           Point2D.Double waypointPos = drawWayPointStep.getPosition(0.0D, 0.0D, (Renderer)mapRenderer, true);
/* 520 */           onScreen = isOnScreen(waypointPos, this.centerPoint, this.centerRect);
/* 521 */           drawWayPointStep.setOnScreen(onScreen);
/*     */         }
/*     */         else {
/*     */           
/* 525 */           onScreen = drawWayPointStep.isOnScreen();
/*     */         } 
/*     */         
/* 528 */         if (onScreen) {
/*     */           
/* 530 */           drawWayPointStep.setLabelScale(this.miniMapProperties.waypointLabelScale.get().floatValue());
/* 531 */           drawWayPointStep.setShowLabel(showLabel);
/* 532 */           drawWayPointStep.draw(graphics, (MultiBufferSource)buffers, pass, 0.0D, 0.0D, (Renderer)mapRenderer, this.dv.fontScale, rotation); continue;
/*     */         } 
/* 534 */         if ((JourneymapClient.getInstance().getWaypointProperties()).renderWaypoints.get().booleanValue()) {
/*     */           
/* 536 */           Point2D.Double point = getPointOnFrame(drawWayPointStep
/* 537 */               .getPosition(0.0D, 0.0D, (Renderer)mapRenderer, true), this.centerPoint, 8.0D);
/*     */ 
/*     */ 
/*     */           
/* 541 */           drawWayPointStep.drawOffscreen(graphics, (MultiBufferSource)buffers, DrawStep.Pass.Object, point, rotation);
/*     */         } 
/*     */       } 
/* 544 */       buffers.endBatch();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private void endMasking(GuiGraphics graphics) {
/* 551 */     graphics.bufferSource().endBatch();
/* 552 */     RenderWrapper.clear(256);
/*     */   }
/*     */ 
/*     */   
/*     */   private void startMapRotation(GuiGraphics graphics, double rotation) {
/* 557 */     graphics.pose().pushPose();
/* 558 */     if (rotation % 360.0D != 0.0D) {
/*     */       
/* 560 */       double width = ((this.dv.displayWidth >> 1) + this.dv.translateX);
/* 561 */       double height = ((this.dv.displayHeight >> 1) + this.dv.translateY);
/*     */       
/* 563 */       graphics.pose().translate(width, height, 0.0D);
/* 564 */       graphics.pose().mulPose(Axis.ZP.rotationDegrees((float)rotation));
/* 565 */       graphics.pose().translate(-width, -height, 0.0D);
/*     */     } 
/*     */     
/* 568 */     mapRenderer.updateRotation(graphics, rotation);
/*     */   }
/*     */ 
/*     */   
/*     */   private void stopMapRotation(GuiGraphics graphics, double rotation) {
/* 573 */     graphics.pose().popPose();
/* 574 */     mapRenderer.updateRotation(graphics, rotation);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean isOnScreen(Point2D.Double objectPixel, Point2D centerPixel, Rectangle2D.Double centerRect) {
/* 580 */     if (this.dv.shape == Shape.Circle)
/*     */     {
/* 582 */       return (centerPixel.distance(objectPixel) < (this.dv.minimapWidth / 2));
/*     */     }
/*     */ 
/*     */     
/* 586 */     return centerRect.contains(mapRenderer.getWindowPosition(objectPixel));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private Point2D.Double getPointOnFrame(Point2D.Double objectPixel, Point2D centerPixel, double offset) {
/* 593 */     if (this.dv.shape == Shape.Circle) {
/*     */       
/* 595 */       Point2D.Double point1 = new Point2D.Double(centerPixel.getX() + offset, centerPixel.getY() + offset);
/*     */       
/* 597 */       double bearing = Math.atan2(objectPixel
/* 598 */           .getY() - point1.getY(), objectPixel
/* 599 */           .getX() - point1.getX());
/*     */ 
/*     */       
/* 602 */       return new Point2D.Double((this.dv.minimapWidth >> 1) * 
/* 603 */           Math.cos(bearing) + point1.getX(), (this.dv.minimapHeight >> 1) * 
/* 604 */           Math.sin(bearing) + point1.getY());
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 609 */     Rectangle2D.Double rect = new Rectangle2D.Double((this.dv.textureX - this.dv.translateX), (this.dv.textureY - this.dv.translateY), this.dv.minimapWidth, this.dv.minimapHeight);
/*     */ 
/*     */     
/* 612 */     if (objectPixel.x > rect.getMaxX()) {
/*     */       
/* 614 */       objectPixel.x = rect.getMaxX() + offset;
/*     */     }
/* 616 */     else if (objectPixel.x < rect.getMinX()) {
/*     */       
/* 618 */       objectPixel.x = rect.getMinX() + offset;
/*     */     } 
/*     */     
/* 621 */     if (objectPixel.y > rect.getMaxY()) {
/*     */       
/* 623 */       objectPixel.y = rect.getMaxY() + offset;
/*     */     }
/* 625 */     else if (objectPixel.y < rect.getMinY()) {
/*     */       
/* 627 */       objectPixel.y = rect.getMinY() + offset;
/*     */     } 
/* 629 */     return objectPixel;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private void autoDayNight() {
/* 635 */     if (this.mc.level != null) {
/*     */       
/* 637 */       EntityDTO player = DataCache.getPlayer();
/* 638 */       boolean any = (MapTypeProvider.from((getCurrentMinimapProperties()).minimapLockedMapType.get()) == MapType.Name.any);
/*     */ 
/*     */       
/* 641 */       boolean forceCave = (MapTypeProvider.from((getCurrentMinimapProperties()).minimapLockedMapType.get()) == MapType.Name.underground);
/*     */       
/* 643 */       int forceSlice = (getCurrentMinimapProperties()).caveLayer.get().intValue();
/* 644 */       if (any || (Level.NETHER == player.dimension && !forceCave)) {
/*     */ 
/*     */         
/* 647 */         boolean wasInCaves = false;
/* 648 */         if (this.miniMapProperties.showCaves.get().booleanValue() && FeatureManager.getInstance()
/* 649 */           .isAllowed(Feature.MapCaves)) {
/*     */           
/* 651 */           boolean neverChecked = (this.lastPlayerUnderground == null);
/* 652 */           boolean playerUnderground = player.underground.booleanValue();
/* 653 */           if (neverChecked || playerUnderground != this.lastPlayerUnderground.booleanValue()) {
/*     */             
/* 655 */             this.lastPlayerUnderground = Boolean.valueOf(playerUnderground);
/* 656 */             if (playerUnderground) {
/*     */               
/* 658 */               state.setMapType(MapType.underground(player));
/*     */             }
/*     */             else {
/*     */               
/* 662 */               state.setMapType(MapType.from((MapType.Name)this.miniMapProperties.preferredMapType.get(), player));
/* 663 */               wasInCaves = true;
/*     */             } 
/*     */           } 
/*     */           
/* 667 */           MapType currentMapType = state.getMapType();
/* 668 */           if (playerUnderground && currentMapType.isUnderground() && currentMapType.vSlice
/* 669 */             .intValue() != player.chunkCoordY)
/*     */           {
/* 671 */             state.setMapType(MapType.underground(player));
/*     */           }
/*     */         } 
/*     */ 
/*     */         
/* 676 */         if (this.miniMapProperties.showDayNight.get().booleanValue() && (wasInCaves || state.getMapType()
/* 677 */           .isDayOrNight())) {
/*     */           
/* 679 */           long NIGHT = 13800L;
/* 680 */           long worldTime = this.mc.level.getDayTime() % 24000L;
/* 681 */           boolean neverChecked = (this.lastAutoDayNightTime == -1L);
/* 682 */           if (worldTime >= 13800L && (neverChecked || this.lastAutoDayNightTime < 13800L))
/*     */           {
/* 684 */             this.lastAutoDayNightTime = worldTime;
/* 685 */             state.setMapType(MapType.night(this.mc.level.dimension()));
/*     */           }
/* 687 */           else if (worldTime < 13800L && (neverChecked || this.lastAutoDayNightTime >= 13800L))
/*     */           {
/* 689 */             this.lastAutoDayNightTime = worldTime;
/* 690 */             state.setMapType(MapType.day(this.mc.level.dimension()));
/*     */           }
/*     */         
/*     */         } 
/* 694 */       } else if (forceCave && FeatureManager.getInstance().isAllowed(Feature.MapCaves)) {
/*     */         
/* 696 */         state.setMapType(MapType.from(MapType.Name.underground, Integer.valueOf(forceSlice), player.dimension));
/*     */       }
/* 698 */       else if (Level.NETHER != player.dimension) {
/*     */         
/* 700 */         state.setMapType(MapType.from(
/* 701 */               MapTypeProvider.from((getCurrentMinimapProperties()).minimapLockedMapType.get()), player));
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void resetState() {
/* 710 */     if ((DataCache.getPlayer()).dimension == Level.NETHER) {
/*     */       
/* 712 */       state.setMapType(MapType.underground(DataCache.getPlayer()));
/*     */     }
/*     */     else {
/*     */       
/* 716 */       state.setMapType(MapType.day(this.mc.level.dimension()));
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void reset() {
/* 726 */     this.initTime = System.currentTimeMillis();
/* 727 */     this.lastAutoDayNightTime = -1L;
/* 728 */     initGridRenderer();
/* 729 */     updateDisplayVars((Shape)this.miniMapProperties.shape.get(), this.miniMapProperties.positionX.get().floatValue(), this.miniMapProperties.positionY
/* 730 */         .get().floatValue(), (Position)this.miniMapProperties.position.get(), true, true);
/* 731 */     CoreProperties coreProperties = JourneymapClient.getInstance().getCoreProperties();
/* 732 */     this.playerArrowColor = coreProperties.getColor(coreProperties.colorSelf);
/* 733 */     this.playerArrowBg = TextureCache.getTexture(TextureCache.PlayerArrowBG);
/* 734 */     this.playerArrowFg = TextureCache.getTexture(TextureCache.PlayerArrow);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void updateDisplayVars(boolean force) {
/* 745 */     updateDisplayVars(force, true);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void updateDisplayVars(boolean force, boolean save) {
/* 755 */     if (this.dv != null)
/*     */     {
/* 757 */       updateDisplayVars(this.dv.shape, this.dv.positionX, this.dv.positionY, this.dv.position, force, save);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void updateDisplayVars(Shape shape, float posX, float posY, Position position, boolean force, boolean save) {
/* 770 */     if (this.dv != null && !force && this.mc
/*     */       
/* 772 */       .getWindow().getScreenHeight() == this.dv.displayHeight && this.mc
/* 773 */       .getWindow().getScreenWidth() == this.dv.displayWidth && this.dv.shape == shape && this.dv.positionX == posX && this.dv.positionY == posY && this.dv.position == position && this.dv.fontScale == this.miniMapProperties.fontScale
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 778 */       .get().floatValue() && this.dv.infoSlotFontScale == this.miniMapProperties.infoSlotFontScale
/* 779 */       .get().floatValue()) {
/*     */       return;
/*     */     }
/*     */ 
/*     */     
/* 784 */     if (save);
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 789 */     if (force) {
/*     */       
/* 791 */       shape = (Shape)this.miniMapProperties.shape.get();
/* 792 */       posX = this.miniMapProperties.positionX.get().floatValue();
/* 793 */       posY = this.miniMapProperties.positionY.get().floatValue();
/* 794 */       position = (Position)this.miniMapProperties.position.get();
/* 795 */       state.setForceRefreshState(true);
/*     */     } 
/*     */     
/* 798 */     this.miniMapProperties.shape.set(shape);
/* 799 */     this.miniMapProperties.positionX.set(Float.valueOf(posX));
/* 800 */     this.miniMapProperties.position.set(position);
/* 801 */     this.miniMapProperties.positionY.set(Float.valueOf(posY));
/*     */ 
/*     */     
/* 804 */     this.miniMapProperties.save();
/*     */     
/* 806 */     DisplayVars oldDv = this.dv;
/* 807 */     this.dv = new DisplayVars(this.mc, this.miniMapProperties);
/*     */     
/* 809 */     if (oldDv == null || oldDv.shape != this.dv.shape) {
/*     */       
/* 811 */       String timerName = String.format("MiniMap%s.%s", new Object[] { Integer.valueOf(this.miniMapProperties.getId()), shape.name() });
/* 812 */       this.drawTimer = StatTimer.get(timerName, 100);
/* 813 */       this.drawTimer.reset();
/* 814 */       this.refreshStateTimer = StatTimer.get(timerName + "+refreshState", 5);
/* 815 */       this.refreshStateTimer.reset();
/*     */     } 
/*     */ 
/*     */     
/* 819 */     double xpad = 0.0D;
/* 820 */     double ypad = 0.0D;
/* 821 */     Rectangle2D.Double viewPortBounds = new Rectangle2D.Double(this.dv.textureX + xpad, this.dv.textureY + ypad, this.dv.minimapWidth - 2.0D * xpad, this.dv.minimapHeight - 2.0D * ypad);
/*     */ 
/*     */     
/* 824 */     mapRenderer.setViewPortBounds(viewPortBounds);
/*     */ 
/*     */     
/* 827 */     updateUIState(true);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String getLocation() {
/* 833 */     int playerX = Mth.floor(this.mc.player.getX());
/* 834 */     int playerZ = Mth.floor(this.mc.player.getZ());
/* 835 */     int playerY = Mth.floor((this.mc.player.getBoundingBox()).minY);
/* 836 */     return this.dv.locationFormatKeys.format(this.dv.locationFormatVerbose, playerX, playerZ, playerY, this.mc.player
/* 837 */         .getBlockY() >> 4);
/*     */   }
/*     */ 
/*     */   
/*     */   public String getBiome() {
/* 842 */     return state.getPlayerBiome();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean mouseClicked(double pMouseX, double pMouseY, int pButton) {
/* 848 */     if (withinBounds(pMouseX, pMouseY) && !this.minimapDragging && this.drawingInPreviewMode) {
/*     */       
/* 850 */       this.minimapDragging = true;
/*     */       
/* 852 */       double scale = JmUI.calculateScaleFactor();
/* 853 */       double posX = pMouseX * scale;
/* 854 */       double posY = pMouseY * scale;
/* 855 */       this.mouseDragOffsetX = (int)(posX - (getDisplayVars()).textureX);
/* 856 */       this.mouseDragOffsetY = (int)(posY - (getDisplayVars()).textureY);
/* 857 */       return true;
/*     */     } 
/*     */     
/* 860 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean mouseDragged(double pMouseX, double pMouseY, int pButton, double pDragX, double pDragY) {
/* 866 */     if (this.minimapDragging) {
/*     */ 
/*     */       
/* 869 */       if (!Position.Custom.equals(this.miniMapProperties.position.get())) {
/*     */         
/* 871 */         this.miniMapProperties.position.set(Position.Custom);
/* 872 */         this.miniMapProperties.position.save();
/*     */       } 
/* 874 */       int screenHeight = Minecraft.getInstance().getWindow().getScreenHeight();
/* 875 */       int screenWidth = Minecraft.getInstance().getWindow().getScreenWidth();
/*     */       
/* 877 */       Vec2 vec2 = validateScreenBounds(pMouseX, pMouseY);
/*     */       
/* 879 */       this.miniMapProperties.positionX.set(Float.valueOf(vec2.x / screenWidth));
/* 880 */       this.miniMapProperties.positionY.set(Float.valueOf(vec2.y / screenHeight));
/*     */       
/* 882 */       updateDisplayVars(true, false);
/*     */       
/* 884 */       return true;
/*     */     } 
/* 886 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean mouseReleased(double mouseX, double mouseY, int mouseButton) {
/* 891 */     if (this.minimapDragging) {
/*     */       
/* 893 */       this.mouseDragOffsetX = 0;
/* 894 */       this.mouseDragOffsetY = 0;
/* 895 */       this.minimapDragging = false;
/* 896 */       updateDisplayVars(true);
/* 897 */       return true;
/*     */     } 
/* 899 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isMinimapDragging() {
/* 904 */     return this.minimapDragging;
/*     */   }
/*     */ 
/*     */   
/*     */   public void tick() {
/* 909 */     long windowId = Minecraft.getInstance().getWindow().getWindow();
/* 910 */     float speed = 
/* 911 */       (JourneymapClient.getInstance().getActiveMiniMapProperties()).minimapKeyMovementSpeed.get().floatValue();
/*     */     
/* 913 */     if (InputConstants.isKeyDown(windowId, 265)) {
/*     */       
/* 915 */       moveMiniMapOnKey(0.0F, -speed);
/*     */     }
/* 917 */     else if (InputConstants.isKeyDown(windowId, 264)) {
/*     */       
/* 919 */       moveMiniMapOnKey(0.0F, speed);
/*     */     }
/* 921 */     else if (InputConstants.isKeyDown(windowId, 263)) {
/*     */       
/* 923 */       moveMiniMapOnKey(-speed, 0.0F);
/*     */     }
/* 925 */     else if (InputConstants.isKeyDown(windowId, 262)) {
/*     */       
/* 927 */       moveMiniMapOnKey(speed, 0.0F);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   private void moveMiniMapOnKey(float incX, float incY) {
/* 933 */     float pX = this.miniMapProperties.positionX.get().floatValue();
/* 934 */     float pY = this.miniMapProperties.positionY.get().floatValue();
/* 935 */     int screenHeight = Minecraft.getInstance().getWindow().getHeight();
/* 936 */     int screenWidth = Minecraft.getInstance().getWindow().getWidth();
/*     */     
/* 938 */     float texX = screenWidth * (pX + incX);
/* 939 */     float texY = screenHeight * (pY + incY);
/*     */     
/* 941 */     DisplayVars vars = UIManager.INSTANCE.getMiniMap().getDisplayVars();
/* 942 */     float x = (texX < 0.0F) ? 0.0F : ((texX + vars.minimapWidth > screenWidth) ? pX : (pX + incX));
/* 943 */     float y = (texY < 0.0F) ? 0.0F : ((texY + vars.minimapHeight > screenHeight) ? pY : (pY + incY));
/*     */     
/* 945 */     this.miniMapProperties.positionX.set(Float.valueOf(x));
/* 946 */     this.miniMapProperties.positionY.set(Float.valueOf(y));
/* 947 */     updateDisplayVars(true);
/*     */   }
/*     */ 
/*     */   
/*     */   public void renderBorder(GuiGraphics graphics, int color) {
/* 952 */     graphics.pose().pushPose();
/* 953 */     double scale = JmUI.calculateScaleFactor();
/* 954 */     int startX = (int)((getDisplayVars()).textureX / scale);
/* 955 */     int startY = (int)((getDisplayVars()).textureY / scale);
/* 956 */     int width = (int)((getDisplayVars()).minimapWidth / scale);
/* 957 */     int height = (int)((getDisplayVars()).minimapHeight / scale);
/* 958 */     int endX = startX + width;
/* 959 */     int endY = startY + height;
/* 960 */     graphics.fill(startX, startY - 1, endX + 1, startY + 1, color);
/* 961 */     graphics.fill(startX - 1, startY - 1, startX + 1, endY + 2, color);
/* 962 */     graphics.fill(startX, endY, endX + 1, endY + 2, color);
/* 963 */     graphics.fill(endX, startY - 1, endX + 2, endY + 2, color);
/* 964 */     graphics.pose().popPose();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isDragging() {
/* 970 */     return this.minimapDragging;
/*     */   }
/*     */ 
/*     */   
/*     */   public Vec2 validateScreenBounds(double pMouseX, double pMouseY) {
/* 975 */     int screenHeight = Minecraft.getInstance().getWindow().getHeight();
/* 976 */     int screenWidth = Minecraft.getInstance().getWindow().getWidth();
/* 977 */     double scale = JmUI.calculateScaleFactor();
/* 978 */     float posX = (float)(pMouseX * scale - this.mouseDragOffsetX);
/* 979 */     float posY = (float)(pMouseY * scale - this.mouseDragOffsetY);
/* 980 */     DisplayVars vars = UIManager.INSTANCE.getMiniMap().getDisplayVars();
/*     */     
/* 982 */     float x = (posX < 0.0F) ? 0.0F : ((posX + vars.minimapWidth > screenWidth) ? (screenWidth - vars.minimapWidth) : posX);
/*     */     
/* 984 */     float y = (posY < 0.0F) ? 0.0F : ((posY + vars.minimapHeight > screenHeight) ? (screenHeight - vars.minimapHeight) : posY);
/* 985 */     return new Vec2(x, y);
/*     */   }
/*     */ 
/*     */   
/*     */   public void setDrawingInPreviewMode(boolean drawingInPreviewMode) {
/* 990 */     this.drawingInPreviewMode = drawingInPreviewMode;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isDrawingInPreviewMode() {
/* 995 */     return this.drawingInPreviewMode;
/*     */   }
/*     */ }


/* Location:              C:\Users\Administrator\Downloads\journeymap-neoforge-1.21-6.0.0-beta.18.jar!\journeymap\clien\\ui\minimap\MiniMap.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */