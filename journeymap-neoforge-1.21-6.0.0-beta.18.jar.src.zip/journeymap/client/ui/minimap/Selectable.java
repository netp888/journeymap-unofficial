package journeymap.client.ui.minimap;

import net.minecraft.client.gui.GuiGraphics;

public interface Selectable {
  public static final int SELECTED_COLOR = -16711936;
  
  public static final int UNSELECTED_COLOR = -65536;
  
  boolean mouseClicked(double paramDouble1, double paramDouble2, int paramInt);
  
  boolean mouseDragged(double paramDouble1, double paramDouble2, int paramInt, double paramDouble3, double paramDouble4);
  
  boolean mouseReleased(double paramDouble1, double paramDouble2, int paramInt);
  
  void tick();
  
  void renderBorder(GuiGraphics paramGuiGraphics, int paramInt);
  
  boolean isDragging();
}


/* Location:              C:\Users\Administrator\Downloads\journeymap-neoforge-1.21-6.0.0-beta.18.jar!\journeymap\clien\\ui\minimap\Selectable.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */