/*    */ package journeymap.client.ui.minimap;
/*    */ 
/*    */ import journeymap.client.JourneymapClient;
/*    */ import journeymap.client.render.RenderWrapper;
/*    */ import journeymap.client.render.draw.DrawUtil;
/*    */ import journeymap.client.ui.theme.Theme;
/*    */ import net.minecraft.client.gui.GuiGraphics;
/*    */ import net.minecraft.client.renderer.MultiBufferSource;
/*    */ import net.minecraft.network.chat.Component;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class LabelVars
/*    */ {
/*    */   final double x;
/*    */   final double y;
/*    */   final double fontScale;
/*    */   final DrawUtil.HAlign hAlign;
/*    */   final DrawUtil.VAlign vAlign;
/*    */   final DisplayVars displayVars;
/*    */   final Theme.LabelSpec labelSpec;
/*    */   
/*    */   LabelVars(DisplayVars displayVars, double x, double y, DrawUtil.HAlign hAlign, DrawUtil.VAlign vAlign, double fontScale, Theme.LabelSpec labelSpec) {
/* 66 */     this.displayVars = displayVars;
/* 67 */     this.x = x;
/* 68 */     this.y = y;
/* 69 */     this.hAlign = hAlign;
/* 70 */     this.vAlign = vAlign;
/* 71 */     this.fontScale = fontScale;
/* 72 */     this.labelSpec = labelSpec;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   void draw(GuiGraphics graphics, MultiBufferSource buffers, String text) {
/* 82 */     RenderWrapper.enableBlend();
/*    */     
/* 84 */     float backgroundAlpha = (JourneymapClient.getInstance().getActiveMiniMapProperties()).infoSlotAlpha.get().floatValue();
/* 85 */     DrawUtil.drawBatchLabel(graphics, 
/* 86 */         (Component)Component.literal(text), (int)this.x, (int)this.y, this.hAlign, this.vAlign, 
/*    */ 
/*    */ 
/*    */ 
/*    */         
/* 91 */         Integer.valueOf(this.labelSpec.background.getColor()), backgroundAlpha, this.labelSpec.foreground
/*    */         
/* 93 */         .getColor(), this.labelSpec.foreground.alpha, this.fontScale, (backgroundAlpha < 0.05F || this.labelSpec.shadow), 0.0D);
/*    */ 
/*    */ 
/*    */ 
/*    */     
/* 98 */     RenderWrapper.disableBlend();
/*    */   }
/*    */ }


/* Location:              C:\Users\Administrator\Downloads\journeymap-neoforge-1.21-6.0.0-beta.18.jar!\journeymap\clien\\ui\minimap\LabelVars.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */