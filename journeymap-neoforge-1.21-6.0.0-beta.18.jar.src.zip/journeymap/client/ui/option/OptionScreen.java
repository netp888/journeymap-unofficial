/*     */ package journeymap.client.ui.option;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.List;
/*     */ import journeymap.api.client.impl.OptionsDisplayFactory;
/*     */ import journeymap.client.Constants;
/*     */ import journeymap.client.InternalStateHandler;
/*     */ import journeymap.client.JourneymapClient;
/*     */ import journeymap.client.render.draw.DrawUtil;
/*     */ import journeymap.client.ui.UIManager;
/*     */ import journeymap.client.ui.component.ButtonList;
/*     */ import journeymap.client.ui.component.buttons.Button;
/*     */ import journeymap.client.ui.component.screens.JmUILegacy;
/*     */ import net.minecraft.ChatFormatting;
/*     */ import net.minecraft.client.gui.GuiGraphics;
/*     */ import net.minecraft.client.gui.components.Button;
/*     */ import net.minecraft.client.gui.components.events.GuiEventListener;
/*     */ import net.minecraft.client.gui.screens.Screen;
/*     */ import net.minecraft.client.server.IntegratedServer;
/*     */ import net.minecraft.network.chat.Component;
/*     */ import net.minecraft.network.chat.MutableComponent;
/*     */ 
/*     */ public abstract class OptionScreen
/*     */   extends JmUILegacy {
/*  26 */   protected final int panelTop = 70;
/*  27 */   protected final int panelBottomMargin = 30;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected Button buttonClose;
/*     */ 
/*     */ 
/*     */   
/*     */   protected Button buttonAbout;
/*     */ 
/*     */ 
/*     */   
/*     */   protected Button buttonServer;
/*     */ 
/*     */ 
/*     */   
/*     */   protected Button buttonMultiplayer;
/*     */ 
/*     */ 
/*     */   
/*     */   protected Button buttonAddons;
/*     */ 
/*     */ 
/*     */   
/*  52 */   protected List<Button> specialBottomButtons = new ArrayList<>();
/*     */ 
/*     */ 
/*     */   
/*     */   protected Button clientOptions;
/*     */ 
/*     */   
/*     */   protected Screen returnDisplay;
/*     */ 
/*     */   
/*     */   protected boolean clientOnly = false;
/*     */ 
/*     */ 
/*     */   
/*     */   public OptionScreen(String title, Screen returnDisplay, boolean clientOnly) {
/*  67 */     super(title, returnDisplay);
/*  68 */     if (returnDisplay == null)
/*     */     {
/*  70 */       returnDisplayStack.pop();
/*     */     }
/*  72 */     this.clientOnly = clientOnly;
/*     */   }
/*     */ 
/*     */   
/*     */   public OptionScreen(String title) {
/*  77 */     super(title);
/*  78 */     returnDisplayStack.pop();
/*     */   }
/*     */ 
/*     */   
/*     */   public void init() {
/*     */     ButtonList bottomRow;
/*  84 */     setRenderBottomBar(true);
/*  85 */     getRenderables().clear();
/*     */     
/*  87 */     this.buttonClose = (Button)addRenderableWidget((GuiEventListener)new Button(Constants.getString("jm.common.close"), button -> closeAndReturn()));
/*  88 */     this.buttonClose.setDefaultStyle(false);
/*  89 */     this.buttonAbout = (Button)addRenderableWidget((GuiEventListener)new Button(Constants.getString("jm.common.splash_about"), button -> UIManager.INSTANCE.openSplash((Screen)this)));
/*  90 */     this.buttonAbout.setDefaultStyle(false);
/*     */     
/*  92 */     this.buttonServer = new Button(Constants.getString("jm.server.edit.label.admin.edit"), button -> UIManager.INSTANCE.openServerEditor(null));
/*  93 */     setUpTopButton(this.buttonServer);
/*     */     
/*  95 */     this.buttonMultiplayer = new Button(Constants.getString("jm.options.multiplayer.button_label"), button -> UIManager.INSTANCE.openMultiplayerEditor(null));
/*  96 */     setUpTopButton(this.buttonMultiplayer);
/*     */     
/*  98 */     this.buttonAddons = new Button(Constants.getString("jm.common.addon_options"), button -> UIManager.INSTANCE.openAddonOptionsEditor(null, this.clientOnly));
/*  99 */     setUpTopButton(this.buttonAddons);
/*     */ 
/*     */ 
/*     */     
/* 103 */     if (OptionsDisplayFactory.PROPERTIES_REGISTRY.isEmpty()) {
/*     */       
/* 105 */       this.buttonAddons.setTooltip(new String[] { Constants.getString("jm.common.addon_options_invalid") });
/* 106 */       disableButton(this.buttonAddons);
/*     */     } 
/*     */     
/* 109 */     this.clientOptions = new Button(Constants.getString("jm.common.client_options"), button -> UIManager.INSTANCE.openOptionsManager(null, this.clientOnly));
/* 110 */     setUpTopButton(this.clientOptions);
/*     */ 
/*     */     
/* 113 */     InternalStateHandler stateHandler = JourneymapClient.getInstance().getStateHandler();
/*     */     
/* 115 */     if ((!stateHandler.canServerAdmin() && !stateHandler.isReadOnlyServerAdmin()) || this.clientOnly) {
/*     */       
/* 117 */       boolean isAdmin = stateHandler.isServerAdmin();
/* 118 */       boolean hasServer = stateHandler.isJourneyMapServerConnection();
/*     */       
/* 120 */       if (!isAdmin && hasServer && !stateHandler.isReadOnlyServerAdmin()) {
/*     */         
/* 122 */         this.buttonServer.setTooltip(new String[] { Constants.getString("jm.server.button.no_permission.tooltip") });
/*     */       }
/* 124 */       else if (!hasServer) {
/*     */         
/* 126 */         this.buttonServer.setTooltip(new String[] { Constants.getString("jm.server.button.no_server.tooltip") });
/*     */       } 
/* 128 */       disableButton(this.buttonServer);
/*     */     } 
/* 130 */     IntegratedServer server = this.minecraft.getSingleplayerServer();
/* 131 */     boolean isSinglePlayer = (server != null && !server.isPublished());
/* 132 */     if (!stateHandler.isMultiplayerOptionsAllowed() || isSinglePlayer || !stateHandler.isJourneyMapServerConnection()) {
/*     */       
/* 134 */       boolean hasServer = stateHandler.isJourneyMapServerConnection();
/* 135 */       if (isSinglePlayer) {
/*     */         
/* 137 */         this.buttonMultiplayer.setTooltip(new String[] { Constants.getString("menu.singleplayer") });
/*     */       }
/* 139 */       else if (hasServer) {
/*     */         
/* 141 */         this.buttonMultiplayer.setTooltip(new String[] { Constants.getString("jm.server.button.no_permission.tooltip") });
/*     */       }
/*     */       else {
/*     */         
/* 145 */         this.buttonMultiplayer.setTooltip(new String[] { Constants.getString("jm.server.button.no_server.tooltip") });
/*     */       } 
/* 147 */       disableButton(this.buttonMultiplayer);
/*     */     } 
/*     */ 
/*     */     
/* 151 */     if (this.specialBottomButtons.isEmpty()) {
/*     */       
/* 153 */       bottomRow = new ButtonList(new Button[] { this.buttonAbout, this.buttonClose });
/*     */     }
/*     */     else {
/*     */       
/* 157 */       bottomRow = new ButtonList();
/* 158 */       bottomRow.add(this.buttonAbout);
/* 159 */       bottomRow.addAll(this.specialBottomButtons);
/* 160 */       bottomRow.add(this.buttonClose);
/*     */     } 
/*     */     
/* 163 */     bottomRow.equalizeWidths(getFontRenderer());
/* 164 */     bottomRow.setWidths(Math.max(100, this.buttonAbout.getWidth()));
/* 165 */     bottomRow.layoutCenteredHorizontal(this.width / 2, this.height - 25, true, 4);
/*     */     
/* 167 */     ButtonList topRow = new ButtonList(new Button[] { this.clientOptions, this.buttonAddons, this.buttonServer, this.buttonMultiplayer });
/* 168 */     topRow.equalizeWidths(getFontRenderer());
/* 169 */     topRow.setWidths(Math.max(100, this.clientOptions.getWidth()));
/* 170 */     topRow.layoutCenteredHorizontal(this.width / 2, 46, true, 1);
/* 171 */     getRenderables().addAll((Collection)bottomRow);
/* 172 */     getRenderables().addAll((Collection)topRow);
/*     */     
/* 174 */     if (this.clientOnly)
/*     */     {
/* 176 */       disableButton(this.buttonAbout);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   private void setUpTopButton(Button button) {
/* 182 */     addRenderableWidget((GuiEventListener)button);
/* 183 */     button.setEnabled(true);
/* 184 */     button.setDefaultStyle(false);
/* 185 */     button.setDrawBackground(false);
/* 186 */     button.setDrawBackgroundOnDisable(false);
/*     */   }
/*     */ 
/*     */   
/*     */   private void disableButton(Button button) {
/* 191 */     button.setEnabled(false);
/* 192 */     button.setDefaultStyle(false);
/* 193 */     button.setDrawBackground(true);
/* 194 */     button.setDrawBackgroundOnDisable(true);
/* 195 */     MutableComponent component = Component.literal(String.valueOf(ChatFormatting.STRIKETHROUGH) + String.valueOf(ChatFormatting.STRIKETHROUGH));
/* 196 */     button.setMessage((Component)component);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected void renderBottomBar(GuiGraphics graphics) {
/* 202 */     DrawUtil.drawRectangle(graphics, 0.0D, (this.height - 30), this.width, this.height, 0, 0.8F);
/*     */   }
/*     */ }


/* Location:              C:\Users\Administrator\Downloads\journeymap-neoforge-1.21-6.0.0-beta.18.jar!\journeymap\clien\\ui\option\OptionScreen.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */