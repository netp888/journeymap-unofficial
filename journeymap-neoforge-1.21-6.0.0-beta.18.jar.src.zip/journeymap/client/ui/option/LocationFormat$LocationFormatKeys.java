/*    */ package journeymap.client.ui.option;
/*    */ 
/*    */ import journeymap.client.Constants;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class LocationFormatKeys
/*    */ {
/*    */   final String id;
/*    */   final String label_key;
/*    */   final String verbose_key;
/*    */   final String plain_key;
/*    */   
/*    */   LocationFormatKeys(String id) {
/* 83 */     this.id = id;
/* 84 */     this.label_key = String.format("jm.common.location_%s_label", new Object[] { id });
/* 85 */     this.verbose_key = String.format("jm.common.location_%s_verbose", new Object[] { id });
/* 86 */     this.plain_key = String.format("jm.common.location_%s_plain", new Object[] { id });
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public String format(boolean verbose, int x, int z, int y, int vslice) {
/* 92 */     if (verbose)
/*    */     {
/* 94 */       return Constants.getString(this.verbose_key, new Object[] { Integer.valueOf(x), Integer.valueOf(z), Integer.valueOf(y), Integer.valueOf(vslice) });
/*    */     }
/*    */ 
/*    */     
/* 98 */     return Constants.getString(this.plain_key, new Object[] { Integer.valueOf(x), Integer.valueOf(z), Integer.valueOf(y), Integer.valueOf(vslice) });
/*    */   }
/*    */ }


/* Location:              C:\Users\Administrator\Downloads\journeymap-neoforge-1.21-6.0.0-beta.18.jar!\journeymap\clien\\ui\option\LocationFormat$LocationFormatKeys.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */