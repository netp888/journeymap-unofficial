/*     */ package journeymap.client.ui.option;
/*     */ 
/*     */ import com.google.common.collect.Lists;
/*     */ import com.google.common.collect.Maps;
/*     */ import java.util.Arrays;
/*     */ import java.util.HashMap;
/*     */ import java.util.HashSet;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Objects;
/*     */ import java.util.Set;
/*     */ import java.util.stream.Collectors;
/*     */ import journeymap.client.Constants;
/*     */ import journeymap.client.properties.ClientCategory;
/*     */ import journeymap.client.properties.MiniMapProperties;
/*     */ import journeymap.client.ui.UIManager;
/*     */ import journeymap.client.ui.component.DraggableListPane;
/*     */ import journeymap.client.ui.component.ScrollListPane;
/*     */ import journeymap.client.ui.component.buttons.Button;
/*     */ import journeymap.client.ui.component.buttons.ResetButton;
/*     */ import journeymap.client.ui.component.screens.JmUILegacy;
/*     */ import journeymap.client.ui.minimap.Effect;
/*     */ import journeymap.client.ui.minimap.MiniMap;
/*     */ import journeymap.client.ui.minimap.Position;
/*     */ import journeymap.client.ui.minimap.Selectable;
/*     */ import journeymap.common.properties.PropertiesBase;
/*     */ import journeymap.common.properties.catagory.Category;
/*     */ import net.minecraft.client.Minecraft;
/*     */ import net.minecraft.client.gui.GuiGraphics;
/*     */ import net.minecraft.client.gui.components.Button;
/*     */ import net.minecraft.client.gui.components.events.GuiEventListener;
/*     */ import net.minecraft.client.gui.screens.Screen;
/*     */ import net.minecraft.core.Holder;
/*     */ import net.minecraft.util.FormattedCharSequence;
/*     */ import net.minecraft.world.effect.MobEffect;
/*     */ import net.minecraft.world.effect.MobEffectInstance;
/*     */ import net.minecraft.world.effect.MobEffects;
/*     */ 
/*     */ 
/*     */ public class MinimapOptions
/*     */   extends JmUILegacy
/*     */ {
/*     */   protected Button buttonClose;
/*     */   protected Map<Category, List<SlotMetadata>> toolbars;
/*     */   protected DraggableListPane<CategorySlot> minimapPositionPane;
/*     */   private final MiniMapProperties miniMapProperties;
/*     */   private final MiniMap minimap;
/*     */   private final Effect effect;
/*     */   private Selectable selected;
/*     */   boolean dragging = false;
/*     */   private Selectable notSelected;
/*     */   private Map<Holder<MobEffect>, MobEffectInstance> activeEffects;
/*  54 */   private Map<Category, PropertiesBase> slotMap = Maps.newHashMap();
/*     */   
/*     */   private static final Map<Holder<MobEffect>, MobEffectInstance> FAKE_EFFECT_MAP;
/*     */ 
/*     */   
/*     */   static {
/*  60 */     List<MobEffectInstance> fakeEffect = Lists.newArrayList((Object[])new MobEffectInstance[] { new MobEffectInstance(MobEffects.CONFUSION), new MobEffectInstance(MobEffects.BLINDNESS), new MobEffectInstance(MobEffects.POISON), new MobEffectInstance(MobEffects.REGENERATION), new MobEffectInstance(MobEffects.DAMAGE_RESISTANCE), new MobEffectInstance(MobEffects.WATER_BREATHING), new MobEffectInstance(MobEffects.INVISIBILITY) });
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  71 */     FAKE_EFFECT_MAP = (Map<Holder<MobEffect>, MobEffectInstance>)fakeEffect.stream().collect(
/*  72 */         Collectors.toMap(MobEffectInstance::getEffect, e -> e));
/*     */   }
/*     */ 
/*     */   
/*     */   public MinimapOptions(Screen returnDisplay, MiniMapProperties miniMapProperties) {
/*  77 */     super(Constants.getString("jm.common.minimap_options.title"), returnDisplay);
/*  78 */     this.miniMapProperties = miniMapProperties;
/*  79 */     UIManager.INSTANCE.switchMiniMapPreset(miniMapProperties.getId());
/*  80 */     this.minimap = UIManager.INSTANCE.getMiniMap();
/*  81 */     UIManager.INSTANCE.getMiniMap().setDrawingInPreviewMode(true);
/*  82 */     this.effect = Effect.getInstance();
/*  83 */     this.slotMap.put(ClientCategory.MinimapPosition, miniMapProperties);
/*     */     
/*  85 */     this.activeEffects = Maps.newHashMap((Minecraft.getInstance()).player.getActiveEffectsMap());
/*     */     
/*  87 */     (Minecraft.getInstance()).player.getActiveEffectsMap().clear();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void init(Minecraft minecraft, int width, int height) {
/*  93 */     setRenderBottomBar(true);
/*  94 */     super.init(minecraft, width, height);
/*  95 */     Objects.requireNonNull(this); drawOptionsPane(20, 36);
/*  96 */     this.buttonClose = (Button)addRenderableWidget((GuiEventListener)new Button(Constants.getString("jm.common.close"), button -> closeAndReturn()));
/*  97 */     this.buttonClose.fitWidth(minecraft.font);
/*  98 */     this.buttonClose.setX(minecraft.getWindow().getGuiScaledWidth() / 2 - this.buttonClose.getWidth() / 2);
/*  99 */     this.buttonClose.setY(minecraft.getWindow().getGuiScaledHeight() - 25);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected void drawOptionsPane(int x, int y) {
/* 105 */     Objects.requireNonNull(this); this.minimapPositionPane = new DraggableListPane(this.minecraft, 0, 36, x, y);
/* 106 */     List<CategorySlot> slotList = OptionSlotFactory.getOptionSlots(getToolbars((ScrollListPane<CategorySlot>)this.minimapPositionPane), this.slotMap, false, true);
/* 107 */     this.minimapPositionPane.setAlignTop(false);
/* 108 */     this.minimapPositionPane.setSlots(slotList);
/* 109 */     this.minimapPositionPane.updateSlots();
/*     */   }
/*     */ 
/*     */   
/*     */   protected Map<Category, List<SlotMetadata>> getToolbars(ScrollListPane<CategorySlot> pane) {
/* 114 */     if (this.toolbars == null) {
/*     */       
/* 116 */       this.toolbars = new HashMap<>();
/* 117 */       for (Iterator<Category> iterator = ClientCategory.values.iterator(); iterator.hasNext(); ) { Category category = iterator.next();
/*     */         
/* 119 */         String name = Constants.getString("jm.config.reset");
/* 120 */         String tooltip = Constants.getString("jm.config.reset.tooltip");
/* 121 */         SlotMetadata toolbarSlotMetadata = new SlotMetadata((Button)new ResetButton(category, button -> refreshOptions(category, pane, true)), name, tooltip);
/* 122 */         this.toolbars.put(category, Arrays.asList(new SlotMetadata[] { toolbarSlotMetadata })); }
/*     */     
/*     */     } 
/* 125 */     return this.toolbars;
/*     */   }
/*     */ 
/*     */   
/*     */   protected void refreshOptions(Category category, ScrollListPane<CategorySlot> pane, boolean reset) {
/* 130 */     Set<PropertiesBase> updatedProperties = new HashSet<>();
/* 131 */     for (CategorySlot categorySlot : pane.getRootSlots()) {
/*     */       
/* 133 */       if (category.equals(categorySlot.getCategory())) {
/*     */         
/* 135 */         for (SlotMetadata slotMetadata : categorySlot.getAllChildMetadata()) {
/*     */           
/* 137 */           if (reset)
/*     */           {
/* 139 */             slotMetadata.resetToDefaultValue();
/*     */           }
/* 141 */           if (slotMetadata.hasConfigField()) {
/*     */             
/* 143 */             PropertiesBase properties = slotMetadata.getProperties();
/* 144 */             if (reset) {
/*     */               
/* 146 */               if (properties instanceof MiniMapProperties) {
/*     */                 
/* 148 */                 this.miniMapProperties.effectTranslateX.setToDefault();
/* 149 */                 this.miniMapProperties.effectTranslateY.setToDefault();
/* 150 */                 this.miniMapProperties.positionX.set(Float.valueOf(0.82F));
/* 151 */                 this.miniMapProperties.positionY.set(Float.valueOf(0.05F));
/*     */               } 
/*     */               
/* 154 */               this.miniMapProperties.effectTranslateX.set(Integer.valueOf(0));
/*     */             } 
/* 156 */             if (properties != null)
/*     */             {
/* 158 */               updatedProperties.add(properties);
/*     */             }
/* 160 */             slotMetadata.getButton().refresh();
/*     */           } 
/*     */         } 
/*     */         
/*     */         break;
/*     */       } 
/*     */     } 
/* 167 */     for (PropertiesBase properties : updatedProperties)
/*     */     {
/* 169 */       properties.save();
/*     */     }
/* 171 */     this.minimapPositionPane.updateSlots();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void render(GuiGraphics graphics, int x, int y, float partialTicks) {
/* 178 */     this.effect.renderBorder(graphics, (this.effect == this.selected) ? -16711936 : -65536);
/* 179 */     this.minimap.drawMap(graphics, true);
/* 180 */     this.minimap.renderBorder(graphics, (this.minimap == this.selected) ? -16711936 : -65536);
/*     */     
/* 182 */     if (!this.dragging)
/*     */     {
/* 184 */       super.render(graphics, x, y, partialTicks);
/*     */     }
/*     */ 
/*     */     
/* 188 */     if (this.minimapPositionPane != null) {
/*     */       
/* 190 */       List<FormattedCharSequence> lastTooltip = this.minimapPositionPane.lastTooltip;
/* 191 */       long lastTooltipTime = this.minimapPositionPane.lastTooltipTime;
/* 192 */       this.minimapPositionPane.lastTooltip = null;
/* 193 */       this.minimapPositionPane.render(graphics, x, y, partialTicks);
/* 194 */       this.minimap.updateDisplayVars(true);
/* 195 */       renderTooltip(graphics, x, lastTooltipTime, lastTooltip);
/*     */     } 
/*     */     
/* 198 */     this.minecraft.player.getActiveEffectsMap().putAll(FAKE_EFFECT_MAP);
/*     */   }
/*     */ 
/*     */   
/*     */   private void renderTooltip(GuiGraphics graphics, int x, long lastTooltipTime, List<FormattedCharSequence> lastTooltip) {
/* 203 */     if (this.minimapPositionPane.lastTooltip != null)
/*     */     {
/* 205 */       if (!this.minimapPositionPane.lastTooltip.equals(lastTooltip)) {
/*     */         
/* 207 */         this.minimapPositionPane.lastTooltipTime = lastTooltipTime;
/* 208 */         if (System.currentTimeMillis() - this.minimapPositionPane.lastTooltipTime > this.minimapPositionPane.hoverDelay) {
/*     */           
/* 210 */           Button button = this.minimapPositionPane.lastTooltipMetadata.getButton();
/* 211 */           graphics.renderTooltip(this.font, this.minimapPositionPane.lastTooltip, x, button.getBottomY() + 15);
/*     */         } 
/*     */       } 
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected void closeAndReturn() {
/* 220 */     cleanup();
/* 221 */     super.closeAndReturn();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void close() {
/* 227 */     cleanup();
/* 228 */     super.close();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void onClose() {
/* 234 */     cleanup();
/* 235 */     super.onClose();
/*     */   }
/*     */ 
/*     */   
/*     */   private void cleanup() {
/* 240 */     UIManager.INSTANCE.getMiniMap().setDrawingInPreviewMode(false);
/* 241 */     removeTempEffects();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private void removeTempEffects() {
/* 247 */     this.minecraft.player.getActiveEffectsMap().clear();
/*     */ 
/*     */     
/* 250 */     this.minecraft.player.getActiveEffectsMap().putAll(this.activeEffects);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void layoutButtons(GuiGraphics graphics) {
/* 257 */     if (getRenderables().isEmpty())
/*     */     {
/* 259 */       init();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void renderBackground(GuiGraphics graphics, int i, int j, float f) {}
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean mouseClicked(double pMouseX, double pMouseY, int pButton) {
/* 272 */     if (this.minimapPositionPane.mouseClicked(pMouseX, pMouseY, pButton)) {
/*     */       
/* 274 */       this.minimap.updateDisplayVars(true);
/*     */     } else {
/* 276 */       if (this.minimap.mouseClicked(pMouseX, pMouseY, pButton)) {
/*     */         
/* 278 */         if (!Position.Custom.equals(this.miniMapProperties.position.get())) {
/*     */           
/* 280 */           int oldX = this.minimapPositionPane.getX();
/* 281 */           int oldY = this.minimapPositionPane.getY();
/* 282 */           this.miniMapProperties.position.set((Enum)Position.Custom);
/* 283 */           this.miniMapProperties.position.save();
/* 284 */           this.minimapPositionPane = null;
/* 285 */           drawOptionsPane(oldX, oldY);
/* 286 */           ((CategorySlot)this.minimapPositionPane.getRootSlots().get(0)).setSelected(true);
/* 287 */           this.minimapPositionPane.updateSlots();
/* 288 */           this.minimapPositionPane.setClicked(true);
/*     */         } 
/*     */         
/* 291 */         this.selected = (Selectable)this.minimap;
/* 292 */         this.notSelected = (Selectable)this.effect;
/* 293 */         return true;
/*     */       } 
/* 295 */       if (this.effect.mouseClicked(pMouseX, pMouseY, pButton)) {
/*     */         
/* 297 */         this.selected = (Selectable)this.effect;
/* 298 */         this.notSelected = (Selectable)this.minimap;
/* 299 */         return true;
/*     */       } 
/*     */     } 
/* 302 */     return super.mouseClicked(pMouseX, pMouseY, pButton);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean mouseScrolled(double x, double y, double f, double scroll) {
/* 308 */     this.minimapPositionPane.mouseScrolled(x, y, f, scroll);
/* 309 */     return super.mouseScrolled(x, y, f, scroll);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean mouseDragged(double pMouseX, double pMouseY, int pButton, double pDragX, double pDragY) {
/* 315 */     if (!this.minimapPositionPane.mouseDragged(pMouseX, pMouseY, pButton, pDragX, pDragY))
/*     */     {
/*     */ 
/*     */       
/* 319 */       if (this.selected != null && this.selected.mouseDragged(pMouseX, pMouseY, pButton, pDragX, pDragY)) {
/*     */         
/* 321 */         this.dragging = true;
/* 322 */         return true;
/*     */       }  } 
/* 324 */     return super.mouseDragged(pMouseX, pMouseY, pButton, pDragX, pDragY);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean mouseReleased(double mouseX, double mouseY, int mouseButton) {
/* 330 */     this.dragging = false;
/* 331 */     this.minimapPositionPane.mouseReleased(mouseX, mouseY, mouseButton);
/* 332 */     this.minimap.mouseReleased(mouseX, mouseY, mouseButton);
/* 333 */     this.effect.mouseReleased(mouseX, mouseY, mouseButton);
/* 334 */     return super.mouseReleased(mouseX, mouseY, mouseButton);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void tick() {
/* 340 */     if (this.selected != null)
/*     */     {
/* 342 */       this.selected.tick();
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\Administrator\Downloads\journeymap-neoforge-1.21-6.0.0-beta.18.jar!\journeymap\clien\\ui\option\MinimapOptions.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */