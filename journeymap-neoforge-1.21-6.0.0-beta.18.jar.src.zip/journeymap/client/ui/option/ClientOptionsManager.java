/*      */ package journeymap.client.ui.option;
/*      */ 
/*      */ import com.google.common.collect.Maps;
/*      */ import java.util.ArrayList;
/*      */ import java.util.HashMap;
/*      */ import java.util.HashSet;
/*      */ import java.util.List;
/*      */ import java.util.Map;
/*      */ import java.util.Objects;
/*      */ import java.util.Set;
/*      */ import journeymap.client.Constants;
/*      */ import journeymap.client.JourneymapClient;
/*      */ import journeymap.client.data.DataCache;
/*      */ import journeymap.client.io.ThemeLoader;
/*      */ import journeymap.client.log.ChatLog;
/*      */ import journeymap.client.log.JMLogger;
/*      */ import journeymap.client.mod.ModBlockDelegate;
/*      */ import journeymap.client.model.BlockMD;
/*      */ import journeymap.client.model.MapType;
/*      */ import journeymap.client.properties.ClientCategory;
/*      */ import journeymap.client.properties.CoreProperties;
/*      */ import journeymap.client.properties.MiniMapProperties;
/*      */ import journeymap.client.render.draw.DrawUtil;
/*      */ import journeymap.client.task.main.SoftResetTask;
/*      */ import journeymap.client.task.multi.MapPlayerTask;
/*      */ import journeymap.client.task.multi.RenderSpec;
/*      */ import journeymap.client.ui.UIManager;
/*      */ import journeymap.client.ui.component.ButtonList;
/*      */ import journeymap.client.ui.component.IConfigFieldHolder;
/*      */ import journeymap.client.ui.component.Slot;
/*      */ import journeymap.client.ui.component.buttons.Button;
/*      */ import journeymap.client.ui.component.buttons.CheckBox;
/*      */ import journeymap.client.ui.component.buttons.CopyConfigButton;
/*      */ import journeymap.client.ui.component.buttons.IntSliderButton;
/*      */ import journeymap.client.ui.component.buttons.ResetButton;
/*      */ import journeymap.client.ui.component.buttons.TextFieldButton;
/*      */ import journeymap.client.ui.fullscreen.Fullscreen;
/*      */ import journeymap.client.ui.minimap.MiniMap;
/*      */ import journeymap.client.waypoint.WaypointHandler;
/*      */ import journeymap.common.Journeymap;
/*      */ import journeymap.common.properties.PropertiesBase;
/*      */ import journeymap.common.properties.catagory.Category;
/*      */ import net.minecraft.client.Minecraft;
/*      */ import net.minecraft.client.gui.Font;
/*      */ import net.minecraft.client.gui.GuiGraphics;
/*      */ import net.minecraft.client.gui.components.AbstractSelectionList;
/*      */ import net.minecraft.client.gui.screens.Screen;
/*      */ import net.minecraft.network.chat.Component;
/*      */ import net.minecraft.util.FormattedCharSequence;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class ClientOptionsManager
/*      */   extends OptionScreen
/*      */ {
/*   72 */   protected static Set<Category> openCategories = new HashSet<>();
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected final int inGameMinimapId;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected Category[] initialCategories;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected CheckBox minimapPreviewButton;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected CheckBox minimap1PreviewButton;
/*      */ 
/*      */ 
/*      */   
/*      */   protected CheckBox minimap2PreviewButton;
/*      */ 
/*      */ 
/*      */   
/*      */   protected Button renderStatsButton;
/*      */ 
/*      */ 
/*      */   
/*      */   protected Button editGridMinimap1Button;
/*      */ 
/*      */ 
/*      */   
/*      */   protected Button editGridMinimap2Button;
/*      */ 
/*      */ 
/*      */   
/*      */   protected Button editMinimap1LocationsButton;
/*      */ 
/*      */ 
/*      */   
/*      */   protected Button editMinimap2LocationsButton;
/*      */ 
/*      */ 
/*      */   
/*      */   protected Button editGridFullscreenButton;
/*      */ 
/*      */ 
/*      */   
/*      */   protected SlotMetadata renderStatsSlotMetadata;
/*      */ 
/*      */ 
/*      */   
/*      */   protected CategorySlot cartographyCategorySlot;
/*      */ 
/*      */ 
/*      */   
/*      */   protected OptionsScrollListPane<CategorySlot> optionsListPane;
/*      */ 
/*      */ 
/*      */   
/*      */   protected Map<Category, List<SlotMetadata>> toolbars;
/*      */ 
/*      */ 
/*      */   
/*  140 */   protected Set<Category> changedCategories = new HashSet<>();
/*      */ 
/*      */ 
/*      */   
/*      */   protected boolean forceMinimapUpdate;
/*      */ 
/*      */ 
/*      */   
/*  148 */   protected ButtonList editGridButtons = new ButtonList();
/*      */ 
/*      */   
/*      */   private MiniMapProperties currentMiniMapProp;
/*      */ 
/*      */   
/*      */   private MiniMap currentMiniMap;
/*      */ 
/*      */   
/*      */   public ClientOptionsManager() {
/*  158 */     this((Screen)null, false);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ClientOptionsManager(Screen returnDisplay, boolean clientOnly) {
/*  168 */     this(returnDisplay, clientOnly, openCategories.<Category>toArray(new Category[0]));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ClientOptionsManager(Screen returnDisplay, boolean clientOnly, Category... initialCategories) {
/*  179 */     super(String.format("JourneyMap %s %s", new Object[] { Journeymap.JM_VERSION, Constants.getString("jm.common.options") }), returnDisplay, clientOnly);
/*  180 */     this.initialCategories = initialCategories;
/*  181 */     this.inGameMinimapId = JourneymapClient.getInstance().getActiveMinimapId();
/*      */   }
/*      */ 
/*      */   
/*      */   public ClientOptionsManager(String title, Screen returnDisplay, boolean clientOnly) {
/*  186 */     super(title, returnDisplay, clientOnly);
/*  187 */     this.inGameMinimapId = JourneymapClient.getInstance().getActiveMinimapId();
/*      */   }
/*      */ 
/*      */   
/*      */   protected Map<Category, PropertiesBase> getSlots() {
/*  192 */     Map<Category, PropertiesBase> slotMap = Maps.newHashMap();
/*  193 */     slotMap.put(ClientCategory.MiniMap1, JourneymapClient.getInstance().getMiniMapProperties1());
/*  194 */     slotMap.put(ClientCategory.MiniMap2, JourneymapClient.getInstance().getMiniMapProperties2());
/*  195 */     slotMap.put(ClientCategory.FullMap, JourneymapClient.getInstance().getFullMapProperties());
/*  196 */     slotMap.put(ClientCategory.WebMap, JourneymapClient.getInstance().getWebMapProperties());
/*  197 */     slotMap.put(ClientCategory.Waypoint, JourneymapClient.getInstance().getWaypointProperties());
/*  198 */     slotMap.put(ClientCategory.Advanced, JourneymapClient.getInstance().getCoreProperties());
/*  199 */     slotMap.put(ClientCategory.AdvancedMapRendering, JourneymapClient.getInstance().getRenderingProperties());
/*  200 */     return slotMap;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void init() {
/*      */     try {
/*  208 */       super.init();
/*  209 */       this.clientOptions.setEnabled(false);
/*  210 */       if (this.editGridMinimap1Button == null) {
/*      */         
/*  212 */         String name = Constants.getString("jm.common.grid_edit");
/*  213 */         String tooltip = Constants.getString("jm.common.grid_edit.tooltip");
/*  214 */         this.editGridMinimap1Button = new Button(name);
/*  215 */         this.editGridMinimap1Button.setTooltip(new String[] { tooltip });
/*  216 */         this.editGridMinimap1Button.setDrawBackground(false);
/*  217 */         this.editGridMinimap2Button = new Button(name);
/*  218 */         this.editGridMinimap2Button.setTooltip(new String[] { tooltip });
/*  219 */         this.editGridMinimap2Button.setDrawBackground(false);
/*  220 */         this.editGridFullscreenButton = new Button(name);
/*  221 */         this.editGridFullscreenButton.setTooltip(new String[] { tooltip });
/*  222 */         this.editGridFullscreenButton.setDrawBackground(false);
/*  223 */         this.editGridButtons = new ButtonList(new Button[] { this.editGridMinimap1Button, this.editGridMinimap2Button, this.editGridFullscreenButton });
/*      */       } 
/*      */       
/*  226 */       if (this.editMinimap1LocationsButton == null) {
/*      */         
/*  228 */         String name = Constants.getString("jm.common.minimap_position.button");
/*  229 */         String tooltip = Constants.getString("jm.common.minimap_position.button.tooltip");
/*  230 */         this.editMinimap1LocationsButton = new Button(name);
/*  231 */         this.editMinimap1LocationsButton.setTooltip(new String[] { tooltip });
/*  232 */         this.editMinimap1LocationsButton.setDrawBackground(false);
/*  233 */         this.editMinimap2LocationsButton = new Button(name);
/*  234 */         this.editMinimap2LocationsButton.setTooltip(new String[] { tooltip });
/*  235 */         this.editMinimap2LocationsButton.setDrawBackground(false);
/*      */       } 
/*  237 */       if (this.minimapPreviewButton == null) {
/*      */         
/*  239 */         String name = Constants.getString("jm.minimap.preview");
/*  240 */         String tooltip = Constants.getString("jm.minimap.preview.tooltip", new Object[] { (JourneymapClient.getInstance().getKeyEvents().getHandler()).kbMinimapPreset.getTranslatedName() });
/*  241 */         this.minimapPreviewButton = new CheckBox(name, false);
/*  242 */         this.minimapPreviewButton.setTooltip(new String[] { tooltip });
/*  243 */         if ((Minecraft.getInstance()).level == null)
/*      */         {
/*  245 */           this.minimapPreviewButton.setEnabled(false);
/*      */         }
/*      */       } 
/*      */       
/*  249 */       if (this.minimap1PreviewButton == null) {
/*      */         
/*  251 */         String name = String.format("%s %s", new Object[] { Constants.getString("jm.minimap.preview"), "1" });
/*  252 */         String tooltip = Constants.getString("jm.minimap.preview.tooltip", new Object[] { (JourneymapClient.getInstance().getKeyEvents().getHandler()).kbMinimapPreset.getTranslatedName() });
/*  253 */         this.minimap1PreviewButton = new CheckBox(name, false);
/*  254 */         this.minimap1PreviewButton.setTooltip(new String[] { tooltip });
/*  255 */         if ((Minecraft.getInstance()).level == null)
/*      */         {
/*  257 */           this.minimap1PreviewButton.setEnabled(false);
/*      */         }
/*      */       } 
/*      */       
/*  261 */       if (this.minimap2PreviewButton == null) {
/*      */         
/*  263 */         String name = String.format("%s %s", new Object[] { Constants.getString("jm.minimap.preview"), "2" });
/*  264 */         String tooltip = Constants.getString("jm.minimap.preview.tooltip", new Object[] { (JourneymapClient.getInstance().getKeyEvents().getHandler()).kbMinimapPreset.getTranslatedName() });
/*  265 */         this.minimap2PreviewButton = new CheckBox(name, false);
/*  266 */         this.minimap2PreviewButton.setTooltip(new String[] { tooltip });
/*  267 */         if ((Minecraft.getInstance()).level == null)
/*      */         {
/*  269 */           this.minimap2PreviewButton.setEnabled(false);
/*      */         }
/*      */       } 
/*      */       
/*  273 */       if (this.renderStatsButton == null) {
/*      */         
/*  275 */         this.renderStatsButton = new LabelButton(150, "jm.common.renderstats", new Object[] { Integer.valueOf(0), Integer.valueOf(0), Integer.valueOf(0) });
/*  276 */         this.renderStatsButton.setEnabled(false);
/*      */       } 
/*      */       
/*  279 */       if (this.optionsListPane == null)
/*      */       {
/*  281 */         List<Slot> categorySlots = new ArrayList<>();
/*  282 */         Objects.requireNonNull(this); Objects.requireNonNull(this); Objects.requireNonNull(this); this.optionsListPane = new OptionsScrollListPane<>(this.minecraft, 0, 70, this.width, this.height - 70 - 30, 20);
/*  283 */         this.optionsListPane.setAlignTop(true);
/*  284 */         this.optionsListPane.setSlots(OptionSlotFactory.getOptionSlots(getToolbars(), getSlots()));
/*  285 */         if (this.initialCategories != null)
/*      */         {
/*  287 */           for (Category initialCategory : this.initialCategories) {
/*      */             
/*  289 */             for (CategorySlot categorySlot : this.optionsListPane.getRootSlots()) {
/*      */               
/*  291 */               if (categorySlot.getCategory() == initialCategory) {
/*      */                 
/*  293 */                 categorySlot.setSelected(true);
/*  294 */                 categorySlots.add(categorySlot);
/*      */               } 
/*      */             } 
/*      */           } 
/*      */         }
/*      */ 
/*      */         
/*  301 */         for (Slot rootSlot : this.optionsListPane.getRootSlots()) {
/*      */           
/*  303 */           if (rootSlot instanceof CategorySlot) {
/*      */             
/*  305 */             CategorySlot categorySlot = (CategorySlot)rootSlot;
/*  306 */             Category category = categorySlot.getCategory();
/*      */ 
/*      */ 
/*      */ 
/*      */             
/*  311 */             if (category == ClientCategory.AdvancedMapRendering)
/*      */             {
/*  313 */               if ((Minecraft.getInstance()).level != null)
/*      */               {
/*  315 */                 categorySlot.getAllChildMetadata().add(new SlotMetadata((Button)this.minimapPreviewButton, 6));
/*      */               }
/*      */             }
/*  318 */             if (category == ClientCategory.MiniMap1) {
/*      */               
/*  320 */               if ((Minecraft.getInstance()).level != null)
/*      */               {
/*  322 */                 categorySlot.getAllChildMetadata().add(new SlotMetadata((Button)this.minimap1PreviewButton, 6));
/*      */               }
/*  324 */               categorySlot.getAllChildMetadata().add(new SlotMetadata(this.editGridMinimap1Button, 5));
/*  325 */               categorySlot.getAllChildMetadata().add(new SlotMetadata(this.editMinimap1LocationsButton, 4)); continue;
/*      */             } 
/*  327 */             if (category == ClientCategory.MiniMap2) {
/*      */               
/*  329 */               if ((Minecraft.getInstance()).level != null)
/*      */               {
/*  331 */                 categorySlot.getAllChildMetadata().add(new SlotMetadata((Button)this.minimap2PreviewButton, 6));
/*      */               }
/*  333 */               categorySlot.getAllChildMetadata().add(new SlotMetadata(this.editGridMinimap2Button, 5));
/*  334 */               categorySlot.getAllChildMetadata().add(new SlotMetadata(this.editMinimap2LocationsButton, 4)); continue;
/*      */             } 
/*  336 */             if (category == ClientCategory.FullMap) {
/*      */               
/*  338 */               categorySlot.getAllChildMetadata().add(new SlotMetadata(this.editGridMinimap2Button, 4)); continue;
/*      */             } 
/*  340 */             if (category == ClientCategory.Cartography) {
/*      */               
/*  342 */               this.cartographyCategorySlot = categorySlot;
/*  343 */               this
/*      */                 
/*  345 */                 .renderStatsSlotMetadata = new SlotMetadata(this.renderStatsButton, Constants.getString("jm.common.renderstats.title"), Constants.getString("jm.common.renderstats.tooltip"), 2);
/*      */             } 
/*      */           } 
/*      */         } 
/*      */ 
/*      */         
/*  351 */         this.optionsListPane.updateSlots();
/*      */         
/*  353 */         if (!categorySlots.isEmpty())
/*      */         {
/*      */           
/*  356 */           this.optionsListPane.scrollTo(categorySlots.get(0));
/*      */         }
/*      */       }
/*      */       else
/*      */       {
/*  361 */         Objects.requireNonNull(this); Objects.requireNonNull(this); Objects.requireNonNull(this); this.optionsListPane.updateSize(this.width, this.height - 70 - 30, 0, 70);
/*  362 */         this.optionsListPane.updateSlots();
/*      */       }
/*      */     
/*      */     }
/*  366 */     catch (Throwable t) {
/*      */       
/*  368 */       JMLogger.throwLogOnce("Error in OptionsManager.init(): " + String.valueOf(t), t);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   protected void layoutButtons(GuiGraphics graphics) {
/*  375 */     if (getRenderables().isEmpty())
/*      */     {
/*  377 */       init();
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void render(GuiGraphics graphics, int mouseX, int mouseY, float par3) {
/*  384 */     Objects.requireNonNull(this); Objects.requireNonNull(this); graphics.fillGradient(0, 36, this.width, 70, -1072689136, -804253680);
/*      */     
/*      */     try {
/*  387 */       if (this.forceMinimapUpdate)
/*      */       {
/*      */         
/*  390 */         if (this.minimap1PreviewButton.isActive()) {
/*      */           
/*  392 */           UIManager.INSTANCE.switchMiniMapPreset(1);
/*      */         }
/*  394 */         else if (this.minimap2PreviewButton.isActive()) {
/*      */           
/*  396 */           UIManager.INSTANCE.switchMiniMapPreset(2);
/*      */         } 
/*      */       }
/*      */ 
/*      */       
/*  401 */       if (this.minecraft.level != null)
/*      */       {
/*  403 */         updateRenderStats();
/*      */       }
/*  405 */       List<FormattedCharSequence> lastTooltip = this.optionsListPane.lastTooltip;
/*  406 */       long lastTooltipTime = this.optionsListPane.lastTooltipTime;
/*      */       
/*  408 */       this.optionsListPane.lastTooltip = null;
/*  409 */       this.optionsListPane.render(graphics, mouseX, mouseY, par3);
/*  410 */       super.render(graphics, mouseX, mouseY, par3);
/*      */       
/*  412 */       if (previewMiniMap() && !this.clientOnly) {
/*      */         
/*  414 */         UIManager.INSTANCE.getMiniMap().setDrawingInPreviewMode(true);
/*  415 */         UIManager.INSTANCE.getMiniMap().drawMap(graphics, !this.minimapPreviewButton.getToggled().booleanValue());
/*  416 */         UIManager.INSTANCE.getMiniMap().updateDisplayVars(true, false);
/*      */       }
/*      */       else {
/*      */         
/*  420 */         UIManager.INSTANCE.getMiniMap().setDrawingInPreviewMode(false);
/*      */       } 
/*      */       
/*  423 */       if (this.optionsListPane.lastTooltip != null && (!previewMiniMap() || !UIManager.INSTANCE.getMiniMap().withinBounds(mouseX, mouseY)))
/*      */       {
/*  425 */         if (!this.optionsListPane.lastTooltip.equals(lastTooltip)) {
/*      */           
/*  427 */           this.optionsListPane.lastTooltipTime = lastTooltipTime;
/*  428 */           if (System.currentTimeMillis() - this.optionsListPane.lastTooltipTime > this.optionsListPane.hoverDelay)
/*      */           {
/*  430 */             Button button = this.optionsListPane.lastTooltipMetadata.getButton();
/*  431 */             graphics.renderTooltip(this.font, this.optionsListPane.lastTooltip, mouseX, button.getBottomY() + 15);
/*      */           }
/*      */         
/*      */         } 
/*      */       }
/*  436 */     } catch (Throwable t) {
/*      */       
/*  438 */       JMLogger.throwLogOnce("Error in OptionsManager.render(): " + String.valueOf(t), t);
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   private void updateRenderStats() {
/*  444 */     RenderSpec.getSurfaceSpec();
/*  445 */     RenderSpec.getTopoSpec();
/*  446 */     RenderSpec.getUndergroundSpec();
/*      */ 
/*      */ 
/*      */     
/*  450 */     for (Slot rootSlot : this.optionsListPane.getRootSlots()) {
/*      */       
/*  452 */       if (rootSlot instanceof CategorySlot) {
/*      */         
/*  454 */         CategorySlot categorySlot = (CategorySlot)rootSlot;
/*  455 */         if (categorySlot.getCategory() == ClientCategory.Cartography) {
/*      */           
/*  457 */           CoreProperties coreProperties = JourneymapClient.getInstance().getCoreProperties();
/*  458 */           for (SlotMetadata slotMetadata : categorySlot.getAllChildMetadata()) {
/*      */             
/*  460 */             if (slotMetadata.getButton() instanceof IConfigFieldHolder) {
/*      */               
/*  462 */               Object property = ((IConfigFieldHolder)slotMetadata.getButton()).getConfigField();
/*  463 */               boolean limitButtonRange = false;
/*  464 */               if (property == coreProperties.renderDistanceCaveMax) {
/*      */                 
/*  466 */                 limitButtonRange = true;
/*      */                 
/*  468 */                 slotMetadata.getButton().resetLabelColors();
/*      */ 
/*      */               
/*      */               }
/*  472 */               else if (property == coreProperties.renderDistanceSurfaceMax) {
/*      */                 
/*  474 */                 limitButtonRange = true;
/*  475 */                 slotMetadata.getButton().resetLabelColors();
/*      */               } 
/*      */ 
/*      */               
/*  479 */               if (limitButtonRange) {
/*      */                 
/*  481 */                 IntSliderButton button = (IntSliderButton)slotMetadata.getButton();
/*  482 */                 int renderDistance = JourneymapClient.getInstance().getRenderDistance();
/*  483 */                 button.maxValue = renderDistance;
/*  484 */                 if (button.getValue() > renderDistance)
/*      */                 {
/*  486 */                   button.setValue(renderDistance);
/*      */                 }
/*      */               } 
/*      */             } 
/*      */           } 
/*      */         } 
/*      */       } 
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/*  497 */     String messageString = (JourneymapClient.getInstance().getCoreProperties()).mappingEnabled.get().booleanValue() ? MapPlayerTask.getSimpleStats() : Constants.getString("jm.common.enable_mapping_false_text");
/*  498 */     this.renderStatsButton.setMessage((Component)Constants.getStringTextComponent(messageString));
/*      */     
/*  500 */     if (this.cartographyCategorySlot != null)
/*      */     {
/*  502 */       this.renderStatsButton.setWidth(this.cartographyCategorySlot.getCurrentColumnWidth());
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void renderBackground(GuiGraphics graphics, int i, int j, float f) {}
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean mouseClicked(double mouseX, double mouseY, int mouseButton) {
/*  520 */     if (previewMiniMap() && UIManager.INSTANCE.getMiniMap().withinBounds(mouseX, mouseY))
/*      */     {
/*  522 */       return false;
/*      */     }
/*      */     
/*      */     try {
/*  526 */       boolean pressed = this.optionsListPane.mouseClicked(mouseX, mouseY, mouseButton);
/*  527 */       if (pressed)
/*      */       {
/*  529 */         checkPressedButton();
/*      */       }
/*  531 */       return super.mouseClicked(mouseX, mouseY, mouseButton);
/*      */     }
/*  533 */     catch (Throwable t) {
/*      */       
/*  535 */       Journeymap.getLogger().error(t.getMessage(), t);
/*  536 */       return false;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean mouseReleased(double mouseX, double mouseY, int mouseButton) {
/*  543 */     this.optionsListPane.mouseReleased(mouseX, mouseY, mouseButton);
/*  544 */     return super.mouseReleased(mouseX, mouseY, mouseButton);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean mouseDragged(double mouseX, double mouseY, int button, double mouseDX, double mouseDY) {
/*  551 */     if (this.optionsListPane.mouseDragged(mouseX, mouseY, button, mouseDX, mouseDY))
/*      */     {
/*  553 */       checkPressedButton();
/*      */     }
/*  555 */     return super.mouseDragged(mouseX, mouseY, button, mouseDX, mouseDY);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean mouseScrolled(double x, double y, double f, double scroll) {
/*  561 */     this.optionsListPane.mouseScrolled(x, y, f, scroll);
/*  562 */     return super.mouseScrolled(x, y, f, scroll);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void checkPressedButton() {
/*  570 */     SlotMetadata slotMetadata = this.optionsListPane.getLastPressed();
/*  571 */     if (slotMetadata != null) {
/*      */ 
/*      */       
/*  574 */       if (slotMetadata.getButton() instanceof ResetButton)
/*      */       {
/*  576 */         resetOptions(((ResetButton)slotMetadata.getButton()).category);
/*      */       }
/*      */ 
/*      */       
/*  580 */       if (slotMetadata.getName().equals(Constants.getString("jm.common.ui_theme"))) {
/*      */         
/*  582 */         ThemeLoader.getCurrentTheme(true);
/*  583 */         if (previewMiniMap())
/*      */         {
/*  585 */           UIManager.INSTANCE.getMiniMap().updateDisplayVars(true);
/*      */         }
/*      */       } 
/*      */ 
/*      */       
/*  590 */       if (this.editGridButtons.contains(slotMetadata.getButton())) {
/*      */         
/*  592 */         UIManager.INSTANCE.openGridEditor((Screen)this);
/*      */         
/*      */         return;
/*      */       } 
/*  596 */       if (slotMetadata.getButton() == this.editMinimap1LocationsButton) {
/*      */         
/*  598 */         UIManager.INSTANCE.openMinimapPosition((Screen)this, JourneymapClient.getInstance().getMiniMapProperties(1));
/*      */         
/*      */         return;
/*      */       } 
/*  602 */       if (slotMetadata.getButton() == this.editMinimap2LocationsButton) {
/*      */         
/*  604 */         UIManager.INSTANCE.openMinimapPosition((Screen)this, JourneymapClient.getInstance().getMiniMapProperties(2));
/*      */         
/*      */         return;
/*      */       } 
/*  608 */       if (slotMetadata.getButton() == this.minimapPreviewButton) {
/*      */         
/*  610 */         this.minimap2PreviewButton.setToggled(Boolean.valueOf(false));
/*  611 */         this.minimap1PreviewButton.setToggled(Boolean.valueOf(false));
/*  612 */         UIManager.INSTANCE.getMiniMap().resetInitTime();
/*  613 */         this.currentMiniMap = UIManager.INSTANCE.getMiniMap();
/*  614 */         this.currentMiniMapProp = this.currentMiniMap.getCurrentMinimapProperties();
/*      */       } 
/*      */       
/*  617 */       if (slotMetadata.getButton() == this.minimap1PreviewButton) {
/*      */         
/*  619 */         this.minimap2PreviewButton.setToggled(Boolean.valueOf(false));
/*  620 */         this.minimapPreviewButton.setToggled(Boolean.valueOf(false));
/*  621 */         UIManager.INSTANCE.switchMiniMapPreset(1);
/*  622 */         UIManager.INSTANCE.getMiniMap().resetInitTime();
/*  623 */         this.currentMiniMap = UIManager.INSTANCE.getMiniMap();
/*  624 */         this.currentMiniMapProp = this.currentMiniMap.getCurrentMinimapProperties();
/*      */       } 
/*      */       
/*  627 */       if (slotMetadata.getButton() == this.minimap2PreviewButton) {
/*      */         
/*  629 */         this.minimap1PreviewButton.setToggled(Boolean.valueOf(false));
/*  630 */         this.minimapPreviewButton.setToggled(Boolean.valueOf(false));
/*  631 */         UIManager.INSTANCE.switchMiniMapPreset(2);
/*  632 */         UIManager.INSTANCE.getMiniMap().resetInitTime();
/*  633 */         this.currentMiniMap = UIManager.INSTANCE.getMiniMap();
/*  634 */         this.currentMiniMapProp = this.currentMiniMap.getCurrentMinimapProperties();
/*      */       } 
/*      */     } 
/*      */     
/*  638 */     CategorySlot categorySlot = (CategorySlot)this.optionsListPane.getLastPressedParentSlot();
/*  639 */     if (categorySlot != null) {
/*      */ 
/*      */       
/*  642 */       Category category = categorySlot.getCategory();
/*  643 */       this.changedCategories.add(category);
/*      */ 
/*      */       
/*  646 */       if (category == ClientCategory.MiniMap1 || category == ClientCategory.MiniMap2) {
/*      */         
/*  648 */         refreshMinimapOptions();
/*  649 */         DataCache.INSTANCE.resetRadarCaches();
/*  650 */         UIManager.INSTANCE.getMiniMap().updateDisplayVars(true);
/*      */       } 
/*      */ 
/*      */       
/*  654 */       if (category == ClientCategory.Cartography) {
/*      */         
/*  656 */         JourneymapClient.getInstance().getCoreProperties().save();
/*  657 */         RenderSpec.resetRenderSpecs();
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean charTyped(char typedChar, int keyCode) {
/*  665 */     switch (keyCode) {
/*      */ 
/*      */       
/*      */       case 256:
/*  669 */         if (previewMiniMap()) {
/*      */           
/*  671 */           this.minimap1PreviewButton.setToggled(Boolean.valueOf(false));
/*  672 */           this.minimap2PreviewButton.setToggled(Boolean.valueOf(false));
/*  673 */           this.minimapPreviewButton.setToggled(Boolean.valueOf(false));
/*      */           
/*      */           break;
/*      */         } 
/*  677 */         closeAndReturn();
/*      */         break;
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/*  683 */     boolean optionUpdated = this.optionsListPane.charTyped(typedChar, keyCode);
/*  684 */     if (optionUpdated && previewMiniMap())
/*      */     {
/*  686 */       UIManager.INSTANCE.getMiniMap().updateDisplayVars(true);
/*      */     }
/*  688 */     return true;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean keyPressed(int key, int value, int modifier) {
/*  695 */     switch (key) {
/*      */ 
/*      */       
/*      */       case 256:
/*  699 */         if (previewMiniMap()) {
/*      */           
/*  701 */           this.minimap1PreviewButton.setToggled(Boolean.valueOf(false));
/*  702 */           this.minimap2PreviewButton.setToggled(Boolean.valueOf(false));
/*  703 */           this.minimapPreviewButton.setToggled(Boolean.valueOf(false));
/*      */           
/*      */           break;
/*      */         } 
/*      */         
/*  708 */         closeAndReturn();
/*      */         break;
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/*  714 */     boolean optionUpdated = this.optionsListPane.keyPressed(key, value, modifier);
/*  715 */     if (optionUpdated && previewMiniMap())
/*      */     {
/*  717 */       UIManager.INSTANCE.getMiniMap().updateDisplayVars(true);
/*      */     }
/*  719 */     return optionUpdated;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void resetOptions(Category category) {
/*  729 */     Set<PropertiesBase> updatedProperties = new HashSet<>();
/*  730 */     for (CategorySlot categorySlot : this.optionsListPane.getRootSlots()) {
/*      */       
/*  732 */       if (category.equals(categorySlot.getCategory())) {
/*      */         
/*  734 */         for (SlotMetadata slotMetadata : categorySlot.getAllChildMetadata()) {
/*      */           
/*  736 */           slotMetadata.resetToDefaultValue();
/*  737 */           if ((ClientCategory.MiniMap1.equals(category) || ClientCategory.MiniMap2.equals(category)) && !this.clientOnly)
/*      */           {
/*  739 */             UIManager.INSTANCE.getMiniMap().resetState();
/*      */           }
/*  741 */           if (ClientCategory.FullMap.equals(category) && !this.clientOnly)
/*      */           {
/*  743 */             Fullscreen.state().setMapType(MapType.Name.day);
/*      */           }
/*  745 */           if (slotMetadata.hasConfigField()) {
/*      */             
/*  747 */             PropertiesBase properties = slotMetadata.getProperties();
/*  748 */             if (properties != null)
/*      */             {
/*  750 */               updatedProperties.add(properties);
/*      */             }
/*      */           } 
/*      */         } 
/*      */         
/*      */         break;
/*      */       } 
/*      */     } 
/*  758 */     for (PropertiesBase properties : updatedProperties)
/*      */     {
/*  760 */       properties.save();
/*      */     }
/*      */ 
/*      */     
/*  764 */     if (!this.clientOnly)
/*      */     {
/*  766 */       RenderSpec.resetRenderSpecs();
/*      */     }
/*      */   }
/*      */ 
/*      */   
/*      */   protected void updateOnCopy(Category category) {
/*  772 */     Set<PropertiesBase> updatedProperties = new HashSet<>();
/*  773 */     for (CategorySlot categorySlot : this.optionsListPane.getRootSlots()) {
/*      */       
/*  775 */       if (category.equals(categorySlot.getCategory())) {
/*      */         
/*  777 */         for (SlotMetadata slotMetadata : categorySlot.getAllChildMetadata()) {
/*      */ 
/*      */           
/*  780 */           if (slotMetadata.hasConfigField()) {
/*      */             
/*  782 */             PropertiesBase properties = slotMetadata.getProperties();
/*  783 */             if (properties != null)
/*      */             {
/*  785 */               updatedProperties.add(properties);
/*      */             }
/*  787 */             slotMetadata.getButton().refresh();
/*      */           } 
/*      */         } 
/*      */         
/*      */         break;
/*      */       } 
/*      */     } 
/*  794 */     for (PropertiesBase properties : updatedProperties)
/*      */     {
/*  796 */       properties.save();
/*      */     }
/*  798 */     this.optionsListPane.updateSlots();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean previewMiniMap() {
/*  809 */     return (this.minimap1PreviewButton.getToggled().booleanValue() || this.minimap2PreviewButton.getToggled().booleanValue() || this.minimapPreviewButton.getToggled().booleanValue());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void refreshMinimapOptions() {
/*  818 */     Set<Category> cats = new HashSet<>();
/*  819 */     cats.add(ClientCategory.MiniMap1);
/*  820 */     cats.add(ClientCategory.MiniMap2);
/*  821 */     for (CategorySlot categorySlot : this.optionsListPane.getRootSlots()) {
/*      */       
/*  823 */       if (cats.contains(categorySlot.getCategory()))
/*      */       {
/*  825 */         for (SlotMetadata slotMetadata : categorySlot.getAllChildMetadata())
/*      */         {
/*  827 */           slotMetadata.getButton().refresh();
/*      */         }
/*      */       }
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void closeWithKeyBind() {
/*  836 */     AbstractSelectionList.Entry entry = this.optionsListPane.getSelected(); if (entry instanceof ButtonListSlot) { ButtonListSlot buttonListSlot = (ButtonListSlot)entry;
/*  837 */       Button button = buttonListSlot.getLastPressed().getButton(); if (button instanceof TextFieldButton) { TextFieldButton textFieldButton = (TextFieldButton)button; if (textFieldButton
/*  838 */           .isFocused())
/*      */           return;  }
/*      */        }
/*      */     
/*  842 */     closeAndReturn();
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   protected void closeAndReturn() {
/*  848 */     (JourneymapClient.getInstance().getCoreProperties()).optionsManagerViewed.set(Journeymap.JM_VERSION.toString()).save();
/*      */ 
/*      */     
/*  851 */     JourneymapClient.getInstance().saveConfigProperties();
/*      */ 
/*      */     
/*  854 */     if (this.minecraft.level != null) {
/*      */ 
/*      */       
/*  857 */       UIManager.INSTANCE.getMiniMap().setMiniMapProperties(JourneymapClient.getInstance().getMiniMapProperties(this.inGameMinimapId));
/*      */       
/*  859 */       for (Category category : this.changedCategories) {
/*      */         
/*  861 */         if (category == ClientCategory.MiniMap1) {
/*      */           
/*  863 */           DataCache.INSTANCE.resetRadarCaches();
/*  864 */           UIManager.INSTANCE.getMiniMap().reset();
/*      */           continue;
/*      */         } 
/*  867 */         if (category == ClientCategory.MiniMap2) {
/*      */           
/*  869 */           DataCache.INSTANCE.resetRadarCaches();
/*      */           continue;
/*      */         } 
/*  872 */         if (category == ClientCategory.FullMap) {
/*      */           
/*  874 */           DataCache.INSTANCE.resetRadarCaches();
/*  875 */           ThemeLoader.getCurrentTheme(true);
/*      */           continue;
/*      */         } 
/*  878 */         if (category == ClientCategory.WebMap) {
/*      */           
/*  880 */           if (JourneymapClient.getInstance().getWebMap() != null) {
/*      */             
/*  882 */             DataCache.INSTANCE.resetRadarCaches();
/*      */             
/*  884 */             if ((JourneymapClient.getInstance().getWebMapProperties()).enabled.get().booleanValue()) {
/*      */               
/*  886 */               JourneymapClient.getInstance().getWebMap().start();
/*      */             }
/*      */             else {
/*      */               
/*  890 */               JourneymapClient.getInstance().getWebMap().stop();
/*      */             } 
/*      */             
/*  893 */             ChatLog.announceMod(true);
/*      */           } 
/*      */           continue;
/*      */         } 
/*  897 */         if (category == ClientCategory.Waypoint) {
/*      */           
/*  899 */           WaypointHandler.getInstance().reset();
/*      */           continue;
/*      */         } 
/*  902 */         if (category == ClientCategory.WaypointBeacon) {
/*      */           continue;
/*      */         }
/*      */         
/*  906 */         if (category == ClientCategory.Cartography) {
/*      */ 
/*      */           
/*  909 */           ModBlockDelegate.INSTANCE.reset();
/*  910 */           BlockMD.reset();
/*  911 */           RenderSpec.resetRenderSpecs();
/*  912 */           MiniMap.state().requireRefresh();
/*  913 */           Fullscreen.state().requireRefresh();
/*  914 */           MapPlayerTask.forceNearbyRemap();
/*      */           continue;
/*      */         } 
/*  917 */         if (category == ClientCategory.Advanced) {
/*      */           
/*  919 */           SoftResetTask.queue();
/*      */ 
/*      */           
/*      */           try {
/*  923 */             if ((JourneymapClient.getInstance().getWebMapProperties()).enabled.get().booleanValue())
/*      */             {
/*  925 */               JourneymapClient.getInstance().startWebMap();
/*      */             }
/*      */             else
/*      */             {
/*  929 */               JourneymapClient.getInstance().stopWebMap();
/*      */             }
/*      */           
/*  932 */           } catch (Exception exception) {}
/*      */ 
/*      */ 
/*      */           
/*  936 */           ChatLog.announceMod(false);
/*      */         } 
/*      */       } 
/*      */ 
/*      */       
/*  941 */       UIManager.INSTANCE.getMiniMap().reset();
/*  942 */       UIManager.INSTANCE.getMiniMap().updateDisplayVars(true);
/*      */     } 
/*      */     
/*  945 */     if (returnDisplayStack != null && !returnDisplayStack.isEmpty() && returnDisplayStack.peek() instanceof Fullscreen)
/*      */     {
/*  947 */       ((Fullscreen)returnDisplayStack.peek()).reset();
/*      */     }
/*      */     
/*  950 */     openCategories.clear();
/*  951 */     for (CategorySlot categorySlot : this.optionsListPane.getRootSlots()) {
/*      */       
/*  953 */       if (categorySlot.isSelected())
/*      */       {
/*  955 */         openCategories.add(categorySlot.getCategory());
/*      */       }
/*      */     } 
/*      */     
/*  959 */     super.closeAndReturn();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected Map<Category, List<SlotMetadata>> getToolbars() {
/*  969 */     if (this.toolbars == null) {
/*      */       
/*  971 */       this.toolbars = new HashMap<>();
/*  972 */       for (Category category : ClientCategory.values) {
/*      */         
/*  974 */         List<SlotMetadata> toolbarButtons = new ArrayList<>();
/*      */ 
/*      */ 
/*      */         
/*  978 */         if (ClientCategory.MiniMap1.equals(category))
/*      */         {
/*  980 */           addToolbarCopyButton(toolbarButtons, ClientCategory.MiniMap1, new Category[] { ClientCategory.MiniMap2, ClientCategory.FullMap });
/*      */         }
/*  982 */         if (ClientCategory.MiniMap2.equals(category))
/*      */         {
/*  984 */           addToolbarCopyButton(toolbarButtons, ClientCategory.MiniMap2, new Category[] { ClientCategory.MiniMap1, ClientCategory.FullMap });
/*      */         }
/*  986 */         if (ClientCategory.FullMap.equals(category))
/*      */         {
/*  988 */           addToolbarCopyButton(toolbarButtons, ClientCategory.FullMap, new Category[] { ClientCategory.MiniMap1, ClientCategory.MiniMap2 });
/*      */         }
/*      */ 
/*      */ 
/*      */         
/*  993 */         toolbarButtons.add(new SlotMetadata((Button)new ResetButton(category), Constants.getString("jm.config.reset"), Constants.getString("jm.config.reset.tooltip"), 0));
/*  994 */         this.toolbars.put(category, toolbarButtons);
/*      */       } 
/*      */     } 
/*  997 */     return this.toolbars;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void addToolbarCopyButton(List<SlotMetadata> buttons, Category from, Category... to) {
/* 1005 */     CopyConfigButton button = new CopyConfigButton(Constants.getString("jm.common.options.copy_to"), from, to, this::updateOnCopy);
/* 1006 */     button.setTooltip(new String[] { "Copy" });
/* 1007 */     button.setDrawBackground(false);
/* 1008 */     buttons.add(new SlotMetadata((Button)button, Constants.getString("jm.common.options.copy_to"), Constants.getString("jm.common.options.copy_to.tooltip"), 1));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean isPauseScreen() {
/* 1015 */     return !this.minimapPreviewButton.getToggled().booleanValue();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static class LabelButton
/*      */     extends Button
/*      */   {
/* 1026 */     DrawUtil.HAlign hAlign = DrawUtil.HAlign.Left;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public LabelButton(int width, String key, Object... labelArgs) {
/* 1037 */       super(Constants.getString(key, labelArgs));
/* 1038 */       setTooltip(new String[] { Constants.getString(key + ".tooltip") });
/* 1039 */       setDrawBackground(false);
/* 1040 */       setDrawFrame(false);
/* 1041 */       setEnabled(false);
/* 1042 */       setLabelColors(Integer.valueOf(12632256), Integer.valueOf(12632256), Integer.valueOf(12632256));
/* 1043 */       setWidth(width);
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*      */     public int getFitWidth(Font fr) {
/* 1049 */       return this.width;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public void fitWidth(Font fr) {}
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public void setHAlign(DrawUtil.HAlign hAlign) {
/* 1064 */       this.hAlign = hAlign;
/*      */     }
/*      */     
/*      */     public void renderWidget(GuiGraphics graphics, int mouseX, int mouseY, float ticks) {
/*      */       // Byte code:
/*      */       //   0: getstatic journeymap/client/ui/option/ClientOptionsManager$1.$SwitchMap$journeymap$client$render$draw$DrawUtil$HAlign : [I
/*      */       //   3: aload_0
/*      */       //   4: getfield hAlign : Ljourneymap/client/render/draw/DrawUtil$HAlign;
/*      */       //   7: invokevirtual ordinal : ()I
/*      */       //   10: iaload
/*      */       //   11: lookupswitch default -> 54, 1 -> 36, 2 -> 45
/*      */       //   36: aload_0
/*      */       //   37: invokevirtual getRightX : ()I
/*      */       //   40: istore #5
/*      */       //   42: goto -> 60
/*      */       //   45: aload_0
/*      */       //   46: invokevirtual getX : ()I
/*      */       //   49: istore #5
/*      */       //   51: goto -> 60
/*      */       //   54: aload_0
/*      */       //   55: invokevirtual getCenterX : ()I
/*      */       //   58: istore #5
/*      */       //   60: aload_1
/*      */       //   61: aload_0
/*      */       //   62: invokevirtual getMessage : ()Lnet/minecraft/network/chat/Component;
/*      */       //   65: invokeinterface getString : ()Ljava/lang/String;
/*      */       //   70: iload #5
/*      */       //   72: i2d
/*      */       //   73: aload_0
/*      */       //   74: invokevirtual getMiddleY : ()I
/*      */       //   77: i2d
/*      */       //   78: aload_0
/*      */       //   79: getfield hAlign : Ljourneymap/client/render/draw/DrawUtil$HAlign;
/*      */       //   82: getstatic journeymap/client/render/draw/DrawUtil$VAlign.Middle : Ljourneymap/client/render/draw/DrawUtil$VAlign;
/*      */       //   85: aconst_null
/*      */       //   86: fconst_0
/*      */       //   87: aload_0
/*      */       //   88: getfield labelColor : Ljava/lang/Integer;
/*      */       //   91: invokevirtual intValue : ()I
/*      */       //   94: fconst_1
/*      */       //   95: dconst_1
/*      */       //   96: aload_0
/*      */       //   97: getfield drawLabelShadow : Z
/*      */       //   100: invokestatic drawLabel : (Lnet/minecraft/client/gui/GuiGraphics;Ljava/lang/String;DDLjourneymap/client/render/draw/DrawUtil$HAlign;Ljourneymap/client/render/draw/DrawUtil$VAlign;Ljava/lang/Integer;FIFDZ)V
/*      */       //   103: return
/*      */       // Line number table:
/*      */       //   Java source line number -> byte code offset
/*      */       //   #1071	-> 0
/*      */       //   #1075	-> 36
/*      */       //   #1076	-> 42
/*      */       //   #1080	-> 45
/*      */       //   #1081	-> 51
/*      */       //   #1085	-> 54
/*      */       //   #1089	-> 60
/*      */       //   #1090	-> 103
/*      */       // Local variable table:
/*      */       //   start	length	slot	name	descriptor
/*      */       //   42	3	5	labelX	I
/*      */       //   51	3	5	labelX	I
/*      */       //   0	104	0	this	Ljourneymap/client/ui/option/ClientOptionsManager$LabelButton;
/*      */       //   0	104	1	graphics	Lnet/minecraft/client/gui/GuiGraphics;
/*      */       //   0	104	2	mouseX	I
/*      */       //   0	104	3	mouseY	I
/*      */       //   0	104	4	ticks	F
/*      */       //   60	44	5	labelX	I
/*      */     }
/*      */   }
/*      */ }


/* Location:              C:\Users\Administrator\Downloads\journeymap-neoforge-1.21-6.0.0-beta.18.jar!\journeymap\clien\\ui\option\ClientOptionsManager.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */