/*    */ package journeymap.client.ui.option;
/*    */ 
/*    */ import com.google.common.collect.Maps;
/*    */ import java.util.Map;
/*    */ import journeymap.api.client.impl.OptionsDisplayFactory;
/*    */ import journeymap.client.Constants;
/*    */ import journeymap.client.properties.AddonProperties;
/*    */ import journeymap.common.properties.PropertiesBase;
/*    */ import journeymap.common.properties.catagory.Category;
/*    */ import net.minecraft.client.gui.screens.Screen;
/*    */ 
/*    */ public class AddonOptionsManager
/*    */   extends ClientOptionsManager
/*    */ {
/*    */   public AddonOptionsManager(Screen returnDisplay, boolean clientOnly) {
/* 16 */     super(Constants.getString("jm.common.addon_options"), returnDisplay, clientOnly);
/*    */   }
/*    */ 
/*    */   
/*    */   protected Map<Category, PropertiesBase> getSlots() {
/* 21 */     Map<Category, PropertiesBase> slotMap = Maps.newHashMap();
/* 22 */     OptionsDisplayFactory.PROPERTIES_REGISTRY.forEach((modId, prop) -> slotMap.put(prop.getParentCategory(), prop));
/* 23 */     return slotMap;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public void init() {
/* 29 */     super.init();
/* 30 */     this.buttonAddons.setEnabled(false);
/* 31 */     this.clientOptions.setEnabled(true);
/*    */   }
/*    */ }


/* Location:              C:\Users\Administrator\Downloads\journeymap-neoforge-1.21-6.0.0-beta.18.jar!\journeymap\clien\\ui\option\AddonOptionsManager.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */