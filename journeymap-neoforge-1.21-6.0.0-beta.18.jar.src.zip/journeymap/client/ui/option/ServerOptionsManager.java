/*     */ package journeymap.client.ui.option;
/*     */ 
/*     */ import com.google.common.collect.Maps;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Objects;
/*     */ import journeymap.client.Constants;
/*     */ import journeymap.client.JourneymapClient;
/*     */ import journeymap.client.data.WorldData;
/*     */ import journeymap.client.log.JMLogger;
/*     */ import journeymap.client.ui.component.buttons.Button;
/*     */ import journeymap.client.ui.component.buttons.ResetButton;
/*     */ import journeymap.common.Journeymap;
/*     */ import journeymap.common.helper.DimensionHelper;
/*     */ import journeymap.common.network.model.ServerPropertyType;
/*     */ import journeymap.common.properties.DefaultDimensionProperties;
/*     */ import journeymap.common.properties.DimensionProperties;
/*     */ import journeymap.common.properties.GlobalProperties;
/*     */ import journeymap.common.properties.PropertiesBase;
/*     */ import journeymap.common.properties.ServerCategory;
/*     */ import journeymap.common.properties.catagory.Category;
/*     */ import net.minecraft.client.Minecraft;
/*     */ import net.minecraft.client.gui.GuiGraphics;
/*     */ import net.minecraft.client.gui.components.Button;
/*     */ import net.minecraft.client.gui.components.events.GuiEventListener;
/*     */ import net.minecraft.client.gui.screens.Screen;
/*     */ import net.minecraft.resources.ResourceKey;
/*     */ import net.minecraft.util.FormattedCharSequence;
/*     */ import net.minecraft.world.level.Level;
/*     */ import org.jetbrains.annotations.NotNull;
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ServerOptionsManager
/*     */   extends OptionScreen
/*     */ {
/*     */   protected OptionsScrollListPane<CategorySlot> optionsListPane;
/*  41 */   protected final Map<Category, PropertiesBase> slotMap = Maps.newHashMap();
/*     */   private GlobalProperties globalProperties;
/*     */   private DefaultDimensionProperties defaultDimensionProperties;
/*  44 */   private final Map<ResourceKey<Level>, DimensionProperties> dimensionPropertyMap = Maps.newHashMap();
/*     */   
/*     */   protected Map<Category, List<SlotMetadata>> toolbars;
/*     */   protected final List<Category> categoryList;
/*     */   private boolean initialized = false;
/*     */   private Button buttonSave;
/*     */   
/*     */   public ServerOptionsManager(Screen returnDisplay) {
/*  52 */     super(JourneymapClient.getInstance().getStateHandler().canServerAdmin() ? 
/*  53 */         Constants.getString("jm.server.edit.label.admin.edit") : 
/*  54 */         Constants.getString("jm.server.edit.label.admin.read_only"), returnDisplay, false);
/*  55 */     this.categoryList = new ArrayList<>(ServerCategory.values);
/*  56 */     requestInitData();
/*     */   }
/*     */ 
/*     */   
/*     */   public ServerOptionsManager(Screen returnDisplay, String title, List<Category> categoryList) {
/*  61 */     super(title, returnDisplay, false);
/*  62 */     this.categoryList = categoryList;
/*  63 */     requestInitData();
/*     */   }
/*     */ 
/*     */   
/*     */   public void render(GuiGraphics graphics, int x, int y, float par3) {
/*  68 */     Objects.requireNonNull(this); Objects.requireNonNull(this); graphics.fillGradient(0, 36, this.width, 70, -1072689136, -804253680);
/*     */ 
/*     */     
/*     */     try {
/*  72 */       if (this.optionsListPane != null) {
/*     */         
/*  74 */         List<FormattedCharSequence> lastTooltip = this.optionsListPane.lastTooltip;
/*  75 */         long lastTooltipTime = this.optionsListPane.lastTooltipTime;
/*     */         
/*  77 */         this.optionsListPane.lastTooltip = null;
/*  78 */         this.optionsListPane.render(graphics, x, y, par3);
/*     */         
/*  80 */         super.render(graphics, x, y, par3);
/*     */         
/*  82 */         if (this.optionsListPane.lastTooltip != null)
/*     */         {
/*  84 */           if (!this.optionsListPane.lastTooltip.equals(lastTooltip)) {
/*     */             
/*  86 */             this.optionsListPane.lastTooltipTime = lastTooltipTime;
/*  87 */             if (System.currentTimeMillis() - this.optionsListPane.lastTooltipTime > this.optionsListPane.hoverDelay)
/*     */             {
/*  89 */               Button button = this.optionsListPane.lastTooltipMetadata.getButton();
/*  90 */               graphics.renderTooltip(this.font, this.optionsListPane.lastTooltip, x, button.getBottomY() + 15);
/*     */             }
/*     */           
/*     */           } 
/*     */         }
/*     */       } 
/*  96 */     } catch (Throwable t) {
/*     */       
/*  98 */       JMLogger.throwLogOnce("Error in OptionsManager.render(): " + String.valueOf(t), t);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void renderBackground(GuiGraphics graphics, int i, int j, float f) {}
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void layoutButtons(GuiGraphics graphics) {
/* 112 */     if (getRenderables().isEmpty())
/*     */     {
/* 114 */       init();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void init() {
/* 121 */     if (!this.initialized) {
/*     */       
/* 123 */       getRenderables().clear();
/* 124 */       this.specialBottomButtons.clear();
/* 125 */       this.initialized = true;
/* 126 */       this.buttonSave = new Button(Constants.getString("jm.waypoint.save"), b -> {
/*     */             save();
/*     */             this.buttonSave.setEnabled(false);
/*     */           });
/* 130 */       this.buttonSave.setEnabled(false);
/* 131 */       boolean canServerAdmin = JourneymapClient.getInstance().getStateHandler().canServerAdmin();
/* 132 */       if (!canServerAdmin)
/*     */       {
/* 134 */         this.buttonSave.setTooltip(new String[] { Constants.getString("jm.server.button.save.read_only") });
/*     */       }
/* 136 */       this.buttonSave.setDefaultStyle(false);
/* 137 */       this.specialBottomButtons.add(this.buttonSave);
/* 138 */       addRenderableWidget((GuiEventListener)this.buttonSave);
/*     */     } 
/* 140 */     super.init();
/* 141 */     this.buttonServer.setEnabled(false);
/* 142 */     if (this.optionsListPane == null || this.slotMap.size() <= WorldData.getDimensionProviders().size() + 2) {
/*     */       
/* 144 */       Objects.requireNonNull(this); Objects.requireNonNull(this); Objects.requireNonNull(this); this.optionsListPane = new OptionsScrollListPane<>(this.minecraft, 0, 70, this.width, this.height - 70 - 30, 20);
/* 145 */       this.optionsListPane.setAlignTop(true);
/* 146 */       List<CategorySlot> categorySlotList = getCategorySlotList();
/* 147 */       this.optionsListPane.setSlots(categorySlotList);
/*     */     
/*     */     }
/*     */     else {
/*     */       
/* 152 */       Objects.requireNonNull(this); Objects.requireNonNull(this); Objects.requireNonNull(this); this.optionsListPane.updateSize(this.width, this.height - 70 - 30, 0, 70);
/*     */     } 
/* 154 */     this.optionsListPane.updateSlots();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected List<CategorySlot> getCategorySlotList() {
/* 160 */     return OptionSlotFactory.getOptionSlots(
/* 161 */         getToolbars(), this.slotMap, 
/*     */         
/* 163 */         !JourneymapClient.getInstance().getStateHandler().canServerAdmin(), false);
/*     */   }
/*     */ 
/*     */   
/*     */   protected Map<Category, List<SlotMetadata>> getToolbars() {
/* 168 */     this.toolbars = new HashMap<>();
/* 169 */     for (Category category : this.categoryList) {
/*     */       
/* 171 */       String name = Constants.getString("jm.config.reset");
/* 172 */       String tooltip = Constants.getString("jm.config.reset.tooltip");
/* 173 */       SlotMetadata<?> toolbarSlotMetadata = new SlotMetadata((Button)new ResetButton(category), name, tooltip);
/* 174 */       this.toolbars.put(category, Collections.singletonList(toolbarSlotMetadata));
/*     */     } 
/* 176 */     return this.toolbars;
/*     */   }
/*     */ 
/*     */   
/*     */   private void onReset(Category category) {
/* 181 */     for (CategorySlot categorySlot : this.optionsListPane.getRootSlots()) {
/*     */       
/* 183 */       if (category.equals(categorySlot.getCategory())) {
/*     */         
/* 185 */         for (SlotMetadata<?> slotMetadata : categorySlot.getAllChildMetadata())
/*     */         {
/* 187 */           slotMetadata.resetToDefaultValue();
/*     */         }
/*     */         break;
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected void requestInitData() {
/* 197 */     requestData(ServerPropertyType.GLOBAL.getId(), "");
/* 198 */     requestData(ServerPropertyType.DEFAULT.getId(), "");
/*     */     
/* 200 */     WorldData.getDimensionProviders().forEach(dimensionProvider -> requestData(ServerPropertyType.DIMENSION.getId(), dimensionProvider.getDimensionId()));
/*     */   }
/*     */ 
/*     */   
/*     */   protected void requestData(int id, String dim) {
/* 205 */     JourneymapClient.getInstance().getDispatcher().sendServerAdminScreenRequest(id, dim);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void setData(ServerPropertyType requestType, String payload, String dim) {
/*     */     try {
/* 212 */       if (ServerPropertyType.GLOBAL.equals(requestType)) {
/*     */         
/* 214 */         this.globalProperties = (GlobalProperties)(new GlobalProperties()).loadForClient(payload, false);
/* 215 */         this.slotMap.put(ServerCategory.Global, this.globalProperties);
/*     */       } 
/* 217 */       if (ServerPropertyType.DEFAULT.equals(requestType)) {
/*     */         
/* 219 */         this.defaultDimensionProperties = (DefaultDimensionProperties)(new DefaultDimensionProperties()).loadForClient(payload, false);
/* 220 */         this.slotMap.put(ServerCategory.Default, this.defaultDimensionProperties);
/*     */       } 
/*     */       
/* 223 */       if (ServerPropertyType.DIMENSION.equals(requestType)) {
/*     */         
/* 225 */         DimensionProperties dimensionProperties = (DimensionProperties)(new DimensionProperties(dim)).loadForClient(payload, false);
/* 226 */         this.dimensionPropertyMap.put(dimensionProperties.getDimension(), dimensionProperties);
/* 227 */         Category category = ServerCategory.create(dim, Constants.getString("jm.server.edit.label.selection.dimension", new Object[] { dim
/* 228 */               }), Constants.getString("jm.server.edit.label.selection.dimension.tooltip"));
/* 229 */         this.categoryList.add(category);
/* 230 */         this.slotMap.put(category, dimensionProperties);
/*     */       } 
/* 232 */       init();
/*     */     }
/* 234 */     catch (Exception e) {
/*     */       
/* 236 */       Journeymap.getLogger().error("Error getting data", e);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   protected void save() {
/* 242 */     sendSavePacket(ServerPropertyType.GLOBAL.getId(), this.globalProperties.toJsonString(false), "");
/* 243 */     sendSavePacket(ServerPropertyType.DEFAULT.getId(), this.defaultDimensionProperties.toJsonString(false), "");
/* 244 */     this.dimensionPropertyMap.values()
/* 245 */       .forEach(dim -> sendSavePacket(ServerPropertyType.DIMENSION.getId(), dim.toJsonString(false), DimensionHelper.getDimKeyName(dim.getDimension())));
/*     */   }
/*     */ 
/*     */   
/*     */   private void sendSavePacket(int id, String payload, String dim) {
/* 250 */     JourneymapClient.getInstance().getDispatcher().sendSaveAdminDataPacket(id, payload, dim);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean mouseClicked(double mouseX, double mouseY, int mouseButton) {
/*     */     try {
/* 258 */       boolean pressed = this.optionsListPane.mouseClicked(mouseX, mouseY, mouseButton);
/* 259 */       if (pressed) {
/*     */         
/* 261 */         SlotMetadata slotMetadata = this.optionsListPane.getLastPressed();
/* 262 */         if (slotMetadata != null) {
/*     */ 
/*     */           
/* 265 */           if (slotMetadata.getButton() instanceof ResetButton)
/*     */           {
/* 267 */             onReset(((ResetButton)slotMetadata.getButton()).category);
/*     */           }
/* 269 */           if (!slotMetadata.isToolbar() || slotMetadata.getButton() instanceof ResetButton)
/*     */           {
/* 271 */             this.buttonSave.setEnabled(true);
/*     */           }
/*     */         } 
/*     */       } 
/*     */       
/* 276 */       return super.mouseClicked(mouseX, mouseY, mouseButton);
/*     */     }
/* 278 */     catch (Throwable t) {
/*     */       
/* 280 */       Journeymap.getLogger().error(t.getMessage(), t);
/* 281 */       return false;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void resize(@NotNull Minecraft minecraft, int width, int height) {
/* 288 */     this.initialized = false;
/* 289 */     super.resize(minecraft, width, height);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean mouseReleased(double mouseX, double mouseY, int mouseButton) {
/* 295 */     this.optionsListPane.mouseReleased(mouseX, mouseY, mouseButton);
/* 296 */     return super.mouseReleased(mouseX, mouseY, mouseButton);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean mouseDragged(double mouseX, double mouseY, int button, double mouseDX, double mouseDY) {
/* 303 */     this.optionsListPane.mouseDragged(mouseX, mouseY, button, mouseDX, mouseDY);
/*     */     
/* 305 */     return super.mouseDragged(mouseX, mouseY, button, mouseDX, mouseDY);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean mouseScrolled(double x, double y, double f, double scroll) {
/* 311 */     this.optionsListPane.mouseScrolled(x, y, f, scroll);
/* 312 */     return super.mouseScrolled(x, y, f, scroll);
/*     */   }
/*     */ }


/* Location:              C:\Users\Administrator\Downloads\journeymap-neoforge-1.21-6.0.0-beta.18.jar!\journeymap\clien\\ui\option\ServerOptionsManager.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */