/*    */ package journeymap.client.ui.option;
/*    */ 
/*    */ import java.util.Arrays;
/*    */ import java.util.List;
/*    */ import journeymap.client.Constants;
/*    */ import journeymap.client.ui.component.buttons.PropertyDropdownButton;
/*    */ import journeymap.common.properties.config.ConfigField;
/*    */ import journeymap.common.properties.config.StringField;
/*    */ 
/*    */ public class DateFormat
/*    */ {
/* 12 */   private static String[] timeFormatValues = new String[] { "MM-dd-yyyy", "MM-dd-yy", "dd-MM-yyyy", "dd-MM-yy", "yyyy-MM-dd", "yy-MM-dd" };
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static class Provider
/*    */     implements StringField.ValuesProvider
/*    */   {
/*    */     public List<String> getStrings() {
/* 24 */       return Arrays.asList(DateFormat.timeFormatValues);
/*    */     }
/*    */ 
/*    */ 
/*    */     
/*    */     public String getDefaultString() {
/* 30 */       return DateFormat.timeFormatValues[0];
/*    */     }
/*    */   }
/*    */   
/*    */   public static class Button
/*    */     extends PropertyDropdownButton<String>
/*    */   {
/*    */     DateFormat timeFormat;
/*    */     
/*    */     public Button(StringField valueHolder) {
/* 40 */       super(Arrays.asList(DateFormat.timeFormatValues), Constants.getString("jm.common.date_format"), (ConfigField)valueHolder);
/* 41 */       if (this.timeFormat == null)
/*    */       {
/* 43 */         this.timeFormat = new DateFormat();
/*    */       }
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Users\Administrator\Downloads\journeymap-neoforge-1.21-6.0.0-beta.18.jar!\journeymap\clien\\ui\option\DateFormat.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */