/*    */ package journeymap.client.ui.option;
/*    */ 
/*    */ import java.util.Arrays;
/*    */ import journeymap.client.Constants;
/*    */ import journeymap.client.ui.component.buttons.PropertyDropdownButton;
/*    */ import journeymap.common.properties.config.ConfigField;
/*    */ import journeymap.common.properties.config.StringField;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Button
/*    */   extends PropertyDropdownButton<String>
/*    */ {
/*    */   DateFormat timeFormat;
/*    */   
/*    */   public Button(StringField valueHolder) {
/* 40 */     super(Arrays.asList(DateFormat.timeFormatValues), Constants.getString("jm.common.date_format"), (ConfigField)valueHolder);
/* 41 */     if (this.timeFormat == null)
/*    */     {
/* 43 */       this.timeFormat = new DateFormat();
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Users\Administrator\Downloads\journeymap-neoforge-1.21-6.0.0-beta.18.jar!\journeymap\clien\\ui\option\DateFormat$Button.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */