/*    */ package journeymap.client.ui.option;
/*    */ 
/*    */ import java.util.Arrays;
/*    */ import java.util.List;
/*    */ import journeymap.common.properties.config.StringField;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class IdProvider
/*    */   implements StringField.ValuesProvider
/*    */ {
/*    */   public List<String> getStrings() {
/* 64 */     return Arrays.asList(LocationFormat.locationFormatIds);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public String getDefaultString() {
/* 70 */     return LocationFormat.locationFormatIds[0];
/*    */   }
/*    */ }


/* Location:              C:\Users\Administrator\Downloads\journeymap-neoforge-1.21-6.0.0-beta.18.jar!\journeymap\clien\\ui\option\LocationFormat$IdProvider.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */