/*    */ package journeymap.client.ui.option;
/*    */ 
/*    */ import java.util.Arrays;
/*    */ import java.util.List;
/*    */ import journeymap.common.properties.config.StringField;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Provider
/*    */   implements StringField.ValuesProvider
/*    */ {
/*    */   public List<String> getStrings() {
/* 24 */     return Arrays.asList(DateFormat.timeFormatValues);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public String getDefaultString() {
/* 30 */     return DateFormat.timeFormatValues[0];
/*    */   }
/*    */ }


/* Location:              C:\Users\Administrator\Downloads\journeymap-neoforge-1.21-6.0.0-beta.18.jar!\journeymap\clien\\ui\option\DateFormat$Provider.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */