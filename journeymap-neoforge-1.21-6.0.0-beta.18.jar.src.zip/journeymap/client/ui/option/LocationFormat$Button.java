/*     */ package journeymap.client.ui.option;
/*     */ 
/*     */ import com.google.common.collect.Lists;
/*     */ import java.util.Arrays;
/*     */ import java.util.Collection;
/*     */ import java.util.List;
/*     */ import journeymap.client.Constants;
/*     */ import journeymap.client.ui.component.DropDownItem;
/*     */ import journeymap.client.ui.component.buttons.DropDownButton;
/*     */ import journeymap.client.ui.component.buttons.PropertyDropdownButton;
/*     */ import journeymap.common.properties.config.ConfigField;
/*     */ import journeymap.common.properties.config.StringField;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Button
/*     */   extends PropertyDropdownButton<String>
/*     */ {
/*     */   LocationFormat locationFormat;
/*     */   
/*     */   public Button(StringField valueHolder) {
/* 109 */     super(Arrays.asList(LocationFormat.locationFormatIds), Constants.getString("jm.common.location_format"), (ConfigField)valueHolder);
/* 110 */     this.buttonBuffer = 50;
/* 111 */     if (this.locationFormat == null)
/*     */     {
/* 113 */       this.locationFormat = new LocationFormat();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String getFormattedLabel(String id) {
/* 120 */     if (this.locationFormat == null)
/*     */     {
/* 122 */       this.locationFormat = new LocationFormat();
/*     */     }
/* 124 */     return String.format("%1$s : %2$s %3$s %2$s", new Object[] { this.baseLabel, "⇕", this.locationFormat.getLabel(id) });
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected String getLabel(DropDownItem item) {
/* 130 */     return getFormattedLabel(item.getLabel());
/*     */   }
/*     */ 
/*     */   
/*     */   public String getLabel(String id) {
/* 135 */     return this.locationFormat.getLabel(id);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected List<DropDownItem> setItems(Collection<String> values) {
/* 141 */     List<DropDownItem> items = Lists.newArrayList();
/* 142 */     values.forEach(value -> items.add(new LocationFormat.LocationDropDownItem((DropDownButton)this, value, getLabel(value))));
/* 143 */     return items;
/*     */   }
/*     */ }


/* Location:              C:\Users\Administrator\Downloads\journeymap-neoforge-1.21-6.0.0-beta.18.jar!\journeymap\clien\\ui\option\LocationFormat$Button.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */