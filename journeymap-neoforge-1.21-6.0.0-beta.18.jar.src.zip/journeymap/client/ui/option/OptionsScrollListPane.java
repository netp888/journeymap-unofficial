/*    */ package journeymap.client.ui.option;
/*    */ 
/*    */ import java.util.Objects;
/*    */ import journeymap.client.ui.component.ScrollListPane;
/*    */ import journeymap.client.ui.component.Slot;
/*    */ import net.minecraft.client.Minecraft;
/*    */ import net.minecraft.client.gui.GuiGraphics;
/*    */ import net.minecraft.client.gui.components.AbstractSelectionList;
/*    */ 
/*    */ 
/*    */ public class OptionsScrollListPane<T extends Slot>
/*    */   extends ScrollListPane<T>
/*    */ {
/*    */   public OptionsScrollListPane(Minecraft mc, int x, int y, int width, int height, int slotHeight) {
/* 15 */     super(mc, x, y, width, height, slotHeight);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public void renderListItems(GuiGraphics graphics, int mouseX, int mouseY, float partialTicks) {
/* 21 */     int count = getItemCount();
/* 22 */     for (int slotIndex = 0; slotIndex < count; slotIndex++) {
/*    */       
/* 24 */       int y = getRowTop(slotIndex);
/* 25 */       int l = getRowTop(slotIndex) + this.itemHeight;
/* 26 */       if (l >= getY() && y <= getBottom()) {
/*    */         
/* 28 */         int slightHeight = this.itemHeight - 4;
/* 29 */         AbstractSelectionList.Entry entry = getEntry(slotIndex);
/* 30 */         int listWidth = getRowWidth();
/* 31 */         int x = getRowLeft();
/* 32 */         if (y >= getY() && y + this.itemHeight <= getBottom())
/*    */         {
/* 34 */           entry.render(graphics, slotIndex, y, x, listWidth, slightHeight, mouseX, mouseY, Objects.equals(getHovered(), entry), partialTicks);
/*    */         }
/*    */       } 
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Users\Administrator\Downloads\journeymap-neoforge-1.21-6.0.0-beta.18.jar!\journeymap\clien\\ui\option\OptionsScrollListPane.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */