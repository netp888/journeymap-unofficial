/*    */ package journeymap.client.ui.theme;
/*    */ 
/*    */ import journeymap.api.v2.client.fullscreen.IThemeToolBar;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public interface IThemeToolbarInternal
/*    */   extends IThemeToolBar
/*    */ {
/*    */   @Deprecated
/*    */   default int getHeight() {
/* 15 */     return getToolbarHeight();
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   int getToolbarHeight();
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   @Deprecated
/*    */   default int getWidth() {
/* 28 */     return getToolbarWidth();
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   int getToolbarWidth();
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   @Deprecated
/*    */   default int getX() {
/* 41 */     return getToolbarX();
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   int getToolbarX();
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   @Deprecated
/*    */   default int getY() {
/* 54 */     return getToolbarY();
/*    */   }
/*    */ 
/*    */   
/*    */   int getToolbarY();
/*    */ 
/*    */   
/*    */   @Deprecated
/*    */   default void setPosition(int x, int y) {
/* 63 */     setToolbarPosition(x, y);
/*    */   }
/*    */   
/*    */   void setToolbarPosition(int paramInt1, int paramInt2);
/*    */ }


/* Location:              C:\Users\Administrator\Downloads\journeymap-neoforge-1.21-6.0.0-beta.18.jar!\journeymap\clien\\ui\theme\IThemeToolbarInternal.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */