/*     */ package journeymap.client.ui.theme;
/*     */ 
/*     */ import com.google.common.base.Strings;
/*     */ import com.google.gson.annotations.Since;
/*     */ import java.awt.Color;
/*     */ import journeymap.common.Journeymap;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Theme
/*     */ {
/*     */   public static final double VERSION = 2.0D;
/*     */   @Since(2.0D)
/*     */   public int schema;
/*     */   @Since(1.0D)
/*     */   public String author;
/*     */   @Since(1.0D)
/*     */   public String name;
/*     */   @Since(1.0D)
/*     */   public String directory;
/*     */   @Since(1.0D)
/*  53 */   public Container container = new Container();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Since(1.0D)
/*  60 */   public Control control = new Control();
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Since(1.0D)
/*  66 */   public Fullscreen fullscreen = new Fullscreen();
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Since(1.0D)
/*  72 */   public ImageSpec icon = new ImageSpec();
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Since(1.0D)
/*  78 */   public Minimap minimap = new Minimap();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String toHexColor(Color color) {
/*  89 */     return String.format("#%02x%02x%02x", new Object[] { Integer.valueOf(color.getRed()), Integer.valueOf(color.getGreen()), Integer.valueOf(color.getBlue()) });
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String toHexColor(int rgb) {
/* 100 */     return toHexColor(new Color(rgb));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static int getColor(String hexColor) {
/* 111 */     if (!Strings.isNullOrEmpty(hexColor)) {
/*     */       
/*     */       try {
/*     */         
/* 115 */         int color = Integer.parseInt(hexColor.replaceFirst("#", ""), 16);
/* 116 */         return color;
/*     */       }
/* 118 */       catch (Exception e) {
/*     */         
/* 120 */         Journeymap.getLogger().warn("Journeymap theme has an invalid color string: " + hexColor);
/*     */       } 
/*     */     }
/* 123 */     return 16777215;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 129 */     if (Strings.isNullOrEmpty(this.name))
/*     */     {
/* 131 */       return "???";
/*     */     }
/*     */ 
/*     */     
/* 135 */     return this.name;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean equals(Object o) {
/* 142 */     if (this == o)
/*     */     {
/* 144 */       return true;
/*     */     }
/* 146 */     if (o == null || getClass() != o.getClass())
/*     */     {
/* 148 */       return false;
/*     */     }
/*     */     
/* 151 */     Theme theme = (Theme)o;
/*     */     
/* 153 */     if ((this.directory != null) ? !this.directory.equals(theme.directory) : (theme.directory != null))
/*     */     {
/* 155 */       return false;
/*     */     }
/* 157 */     if ((this.name != null) ? !this.name.equals(theme.name) : (theme.name != null))
/*     */     {
/* 159 */       return false;
/*     */     }
/*     */     
/* 162 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 168 */     int result = (this.name != null) ? this.name.hashCode() : 0;
/* 169 */     result = 31 * result + ((this.directory != null) ? this.directory.hashCode() : 0);
/* 170 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static class Container
/*     */   {
/*     */     @Since(1.0D)
/* 181 */     public Toolbar toolbar = new Toolbar();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public static class Toolbar
/*     */     {
/*     */       @Since(1.0D)
/* 192 */       public ToolbarSpec horizontal = new ToolbarSpec();
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       @Since(1.0D)
/* 198 */       public ToolbarSpec vertical = new ToolbarSpec();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       public static class ToolbarSpec
/*     */       {
/*     */         @Since(1.0D)
/*     */         public boolean useThemeImages;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/*     */         @Since(1.0D)
/* 219 */         public String prefix = ""; @Since(1.0D) public int margin; @Since(1.0D) public int padding; @Since(1.0D) public Theme.ImageSpec begin; @Since(1.0D) public Theme.ImageSpec inner; @Since(1.0D) public Theme.ImageSpec end; } } } public static class Toolbar { @Since(1.0D) public ToolbarSpec horizontal = new ToolbarSpec(); @Since(1.0D) public ToolbarSpec vertical = new ToolbarSpec(); public static class ToolbarSpec { @Since(1.0D) public boolean useThemeImages; @Since(1.0D) public String prefix = ""; @Since(1.0D) public int margin; @Since(1.0D) public int padding; @Since(1.0D) public Theme.ImageSpec begin; @Since(1.0D) public Theme.ImageSpec inner; @Since(1.0D) public Theme.ImageSpec end; } } public static class ToolbarSpec { @Since(1.0D) public boolean useThemeImages; @Since(1.0D) public String prefix = "";
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @Since(1.0D)
/*     */     public int margin;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @Since(1.0D)
/*     */     public int padding;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @Since(1.0D)
/*     */     public Theme.ImageSpec begin;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @Since(1.0D)
/*     */     public Theme.ImageSpec inner;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @Since(1.0D)
/*     */     public Theme.ImageSpec end; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static class Control
/*     */   {
/*     */     @Since(1.0D)
/* 263 */     public ButtonSpec button = new ButtonSpec();
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @Since(1.0D)
/* 269 */     public ButtonSpec toggle = new ButtonSpec();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public static class ButtonSpec
/*     */     {
/*     */       @Since(1.0D)
/*     */       public boolean useThemeImages;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       @Since(1.0D)
/*     */       public int width;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       @Since(1.0D)
/*     */       public int height;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       @Since(1.0D)
/* 300 */       public String prefix = "";
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       @Since(1.0D)
/* 306 */       public String tooltipOnStyle = "";
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       @Since(1.0D)
/* 312 */       public String tooltipOffStyle = "";
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       @Since(1.0D)
/* 318 */       public String tooltipDisabledStyle = "";
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       @Since(2.0D)
/* 324 */       public Theme.ColorSpec iconOn = new Theme.ColorSpec();
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       @Since(2.0D)
/* 330 */       public Theme.ColorSpec iconOff = new Theme.ColorSpec();
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       @Since(2.0D)
/* 336 */       public Theme.ColorSpec iconHoverOn = new Theme.ColorSpec();
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       @Since(2.0D)
/* 342 */       public Theme.ColorSpec iconHoverOff = new Theme.ColorSpec();
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       @Since(2.0D)
/* 348 */       public Theme.ColorSpec iconDisabled = new Theme.ColorSpec();
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       @Since(2.0D)
/* 354 */       public Theme.ColorSpec buttonOn = new Theme.ColorSpec();
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       @Since(2.0D)
/* 360 */       public Theme.ColorSpec buttonOff = new Theme.ColorSpec();
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       @Since(2.0D)
/* 366 */       public Theme.ColorSpec buttonHoverOn = new Theme.ColorSpec();
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       @Since(2.0D)
/* 372 */       public Theme.ColorSpec buttonHoverOff = new Theme.ColorSpec();
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       @Since(2.0D)
/* 378 */       public Theme.ColorSpec buttonDisabled = new Theme.ColorSpec(); } } public static class ButtonSpec { @Since(1.0D) public boolean useThemeImages; @Since(1.0D) public int width; @Since(1.0D) public int height; @Since(1.0D) public String prefix = ""; @Since(1.0D) public String tooltipOnStyle = ""; @Since(1.0D) public String tooltipOffStyle = ""; @Since(1.0D) public String tooltipDisabledStyle = ""; @Since(2.0D) public Theme.ColorSpec iconOn = new Theme.ColorSpec(); @Since(2.0D) public Theme.ColorSpec iconOff = new Theme.ColorSpec(); @Since(2.0D) public Theme.ColorSpec iconHoverOn = new Theme.ColorSpec(); @Since(2.0D) public Theme.ColorSpec iconHoverOff = new Theme.ColorSpec(); @Since(2.0D) public Theme.ColorSpec iconDisabled = new Theme.ColorSpec(); @Since(2.0D) public Theme.ColorSpec buttonOn = new Theme.ColorSpec(); @Since(2.0D) public Theme.ColorSpec buttonOff = new Theme.ColorSpec(); @Since(2.0D) public Theme.ColorSpec buttonHoverOn = new Theme.ColorSpec(); @Since(2.0D) public Theme.ColorSpec buttonHoverOff = new Theme.ColorSpec(); @Since(2.0D) public Theme.ColorSpec buttonDisabled = new Theme.ColorSpec(); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static class Fullscreen
/*     */   {
/*     */     @Since(2.0D)
/* 391 */     public Theme.ColorSpec background = new Theme.ColorSpec();
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @Since(1.0D)
/* 397 */     public Theme.LabelSpec statusLabel = new Theme.LabelSpec();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static class ColorSpec
/*     */     implements Cloneable
/*     */   {
/*     */     public ColorSpec(String color, float alpha) {
/* 418 */       this.color = color;
/* 419 */       this.alpha = alpha;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @Since(2.0D)
/* 426 */     public String color = "#ffffff";
/*     */ 
/*     */ 
/*     */     
/*     */     private transient Integer _color;
/*     */ 
/*     */     
/*     */     @Since(2.0D)
/* 434 */     public float alpha = 1.0F;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public int getColor() {
/* 444 */       if (this._color == null)
/*     */       {
/* 446 */         this._color = Integer.valueOf(Theme.getColor(this.color));
/*     */       }
/* 448 */       return this._color.intValue();
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public ColorSpec clone() {
/* 454 */       ColorSpec clone = new ColorSpec();
/* 455 */       clone.color = this.color;
/* 456 */       clone.alpha = this.alpha;
/* 457 */       return clone;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public ColorSpec() {}
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static class ImageSpec
/*     */     extends ColorSpec
/*     */   {
/*     */     @Since(1.0D)
/*     */     public int width;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @Since(1.0D)
/*     */     public int height;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public ImageSpec() {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public ImageSpec(int width, int height) {
/* 494 */       this.width = width;
/* 495 */       this.height = height;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static class Minimap
/*     */   {
/*     */     @Since(1.0D)
/* 507 */     public MinimapCircle circle = new MinimapCircle();
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @Since(1.0D)
/* 513 */     public MinimapSquare square = new MinimapSquare();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public static abstract class MinimapSpec
/*     */     {
/*     */       @Since(1.0D)
/*     */       public int margin;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       @Since(2.0D)
/* 530 */       public Theme.LabelSpec labelTop = new Theme.LabelSpec();
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       @Since(2.0D)
/*     */       public boolean labelTopInside = false;
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       @Since(2.0D)
/* 542 */       public Theme.LabelSpec labelBottom = new Theme.LabelSpec();
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       @Since(2.0D)
/*     */       public boolean labelBottomInside = false;
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       @Since(1.0D)
/* 554 */       public Theme.LabelSpec compassLabel = new Theme.LabelSpec();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       @Since(1.0D)
/* 561 */       public Theme.ImageSpec compassPoint = new Theme.ImageSpec();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       @Since(1.0D)
/*     */       public int compassPointLabelPad;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       @Since(1.0D)
/*     */       public double compassPointOffset;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       @Since(1.0D)
/*     */       public boolean compassShowNorth = true;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       @Since(1.0D)
/*     */       public boolean compassShowSouth = true;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       @Since(1.0D)
/*     */       public boolean compassShowEast = true;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       @Since(1.0D)
/*     */       public boolean compassShowWest = true;
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       @Since(1.0D)
/*     */       public double waypointOffset;
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       @Since(2.0D)
/* 615 */       public Theme.ColorSpec reticle = new Theme.ColorSpec();
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       @Since(2.0D)
/* 621 */       public Theme.ColorSpec reticleHeading = new Theme.ColorSpec();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       @Since(1.0D)
/* 628 */       public double reticleThickness = 2.25D;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       @Since(1.0D)
/* 635 */       public double reticleHeadingThickness = 2.5D;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       @Since(2.0D)
/* 642 */       public int reticleOffsetOuter = 16;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       @Since(2.0D)
/* 649 */       public int reticleOffsetInner = 16;
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       @Since(2.0D)
/* 655 */       public Theme.ColorSpec frame = new Theme.ColorSpec();
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       @Since(1.0D)
/* 661 */       public String prefix = "";
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public static class MinimapCircle
/*     */       extends MinimapSpec
/*     */     {
/*     */       @Since(1.0D)
/* 682 */       public Theme.ImageSpec rim256 = new Theme.ImageSpec(256, 256);
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       @Since(1.0D)
/* 688 */       public Theme.ImageSpec mask256 = new Theme.ImageSpec(256, 256);
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       @Since(1.0D)
/* 694 */       public Theme.ImageSpec rim512 = new Theme.ImageSpec(512, 512);
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       @Since(1.0D)
/* 700 */       public Theme.ImageSpec mask512 = new Theme.ImageSpec(512, 512);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       @Since(2.0D)
/*     */       public boolean rotates = false;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public static class MinimapSquare
/*     */       extends MinimapSpec
/*     */     {
/*     */       @Since(1.0D)
/* 725 */       public Theme.ImageSpec topLeft = new Theme.ImageSpec();
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       @Since(1.0D)
/* 731 */       public Theme.ImageSpec top = new Theme.ImageSpec();
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       @Since(1.0D)
/* 737 */       public Theme.ImageSpec topRight = new Theme.ImageSpec();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       @Since(1.0D)
/* 744 */       public Theme.ImageSpec right = new Theme.ImageSpec();
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       @Since(1.0D)
/* 750 */       public Theme.ImageSpec bottomRight = new Theme.ImageSpec();
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       @Since(1.0D)
/* 756 */       public Theme.ImageSpec bottom = new Theme.ImageSpec();
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       @Since(1.0D)
/* 762 */       public Theme.ImageSpec bottomLeft = new Theme.ImageSpec();
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       @Since(1.0D)
/* 768 */       public Theme.ImageSpec left = new Theme.ImageSpec(); } } public static abstract class MinimapSpec { @Since(1.0D) public int margin; @Since(2.0D) public Theme.LabelSpec labelTop; @Since(2.0D) public boolean labelTopInside; @Since(2.0D) public Theme.LabelSpec labelBottom; @Since(2.0D) public boolean labelBottomInside; @Since(1.0D) public Theme.LabelSpec compassLabel; @Since(1.0D) public Theme.ImageSpec compassPoint; @Since(1.0D) public int compassPointLabelPad; @Since(1.0D) public double compassPointOffset; @Since(1.0D) public boolean compassShowNorth; @Since(1.0D) public boolean compassShowSouth; @Since(1.0D) public boolean compassShowEast; @Since(1.0D) public boolean compassShowWest; @Since(1.0D) public double waypointOffset; @Since(2.0D) public Theme.ColorSpec reticle; @Since(2.0D) public Theme.ColorSpec reticleHeading; @Since(1.0D) public double reticleThickness; @Since(1.0D) public double reticleHeadingThickness; @Since(2.0D) public int reticleOffsetOuter; @Since(2.0D) public int reticleOffsetInner; @Since(2.0D) public Theme.ColorSpec frame; @Since(1.0D) public String prefix; public MinimapSpec() { this.labelTop = new Theme.LabelSpec(); this.labelTopInside = false; this.labelBottom = new Theme.LabelSpec(); this.labelBottomInside = false; this.compassLabel = new Theme.LabelSpec(); this.compassPoint = new Theme.ImageSpec(); this.compassShowNorth = true; this.compassShowSouth = true; this.compassShowEast = true; this.compassShowWest = true; this.reticle = new Theme.ColorSpec(); this.reticleHeading = new Theme.ColorSpec(); this.reticleThickness = 2.25D; this.reticleHeadingThickness = 2.5D; this.reticleOffsetOuter = 16; this.reticleOffsetInner = 16; this.frame = new Theme.ColorSpec(); this.prefix = ""; } } public static class MinimapCircle extends Minimap.MinimapSpec { @Since(1.0D) public Theme.ImageSpec rim256; @Since(1.0D) public Theme.ImageSpec mask256; @Since(1.0D) public Theme.ImageSpec rim512; @Since(1.0D) public Theme.ImageSpec mask512; @Since(2.0D) public boolean rotates; public MinimapCircle() { this.rim256 = new Theme.ImageSpec(256, 256); this.mask256 = new Theme.ImageSpec(256, 256); this.rim512 = new Theme.ImageSpec(512, 512); this.mask512 = new Theme.ImageSpec(512, 512); this.rotates = false; } } public static class MinimapSquare extends Minimap.MinimapSpec { @Since(1.0D) public Theme.ImageSpec topLeft; @Since(1.0D) public Theme.ImageSpec top; public MinimapSquare() { this.topLeft = new Theme.ImageSpec(); this.top = new Theme.ImageSpec(); this.topRight = new Theme.ImageSpec(); this.right = new Theme.ImageSpec(); this.bottomRight = new Theme.ImageSpec(); this.bottom = new Theme.ImageSpec(); this.bottomLeft = new Theme.ImageSpec(); this.left = new Theme.ImageSpec(); }
/*     */     
/*     */     @Since(1.0D)
/*     */     public Theme.ImageSpec topRight; @Since(1.0D)
/*     */     public Theme.ImageSpec right; @Since(1.0D)
/*     */     public Theme.ImageSpec bottomRight; @Since(1.0D)
/*     */     public Theme.ImageSpec bottom;
/*     */     @Since(1.0D)
/*     */     public Theme.ImageSpec bottomLeft;
/*     */     @Since(1.0D)
/*     */     public Theme.ImageSpec left; }
/*     */   
/*     */   public static class LabelSpec implements Cloneable { @Since(2.0D)
/* 781 */     public int margin = 2;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @Since(2.0D)
/* 788 */     public Theme.ColorSpec background = new Theme.ColorSpec("#000000", 0.0F);
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @Since(2.0D)
/* 794 */     public Theme.ColorSpec foreground = new Theme.ColorSpec();
/*     */ 
/*     */     
/*     */     @Since(2.0D)
/* 798 */     public Theme.ColorSpec highlight = new Theme.ColorSpec();
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @Since(1.0D)
/*     */     public boolean shadow = false;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public LabelSpec clone() {
/* 810 */       LabelSpec clone = new LabelSpec();
/* 811 */       clone.margin = this.margin;
/* 812 */       clone.background = this.background.clone();
/* 813 */       clone.foreground = this.foreground.clone();
/* 814 */       clone.highlight = this.highlight.clone();
/* 815 */       return clone;
/*     */     } }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static class DefaultPointer
/*     */   {
/*     */     @Since(1.0D)
/*     */     public String directory;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @Since(1.0D)
/*     */     public String filename;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @Since(1.0D)
/*     */     public String name;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     protected DefaultPointer() {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public DefaultPointer(Theme theme) {
/* 857 */       this.name = theme.name;
/* 858 */       this.filename = theme.name;
/* 859 */       this.directory = theme.directory;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\Administrator\Downloads\journeymap-neoforge-1.21-6.0.0-beta.18.jar!\journeymap\clien\\ui\theme\Theme.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */