/*     */ package journeymap.client.ui.theme;
/*     */ 
/*     */ import com.google.gson.annotations.Since;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Control
/*     */ {
/*     */   @Since(1.0D)
/* 263 */   public ButtonSpec button = new ButtonSpec();
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Since(1.0D)
/* 269 */   public ButtonSpec toggle = new ButtonSpec();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static class ButtonSpec
/*     */   {
/*     */     @Since(1.0D)
/*     */     public boolean useThemeImages;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @Since(1.0D)
/*     */     public int width;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @Since(1.0D)
/*     */     public int height;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @Since(1.0D)
/* 300 */     public String prefix = "";
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @Since(1.0D)
/* 306 */     public String tooltipOnStyle = "";
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @Since(1.0D)
/* 312 */     public String tooltipOffStyle = "";
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @Since(1.0D)
/* 318 */     public String tooltipDisabledStyle = "";
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @Since(2.0D)
/* 324 */     public Theme.ColorSpec iconOn = new Theme.ColorSpec();
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @Since(2.0D)
/* 330 */     public Theme.ColorSpec iconOff = new Theme.ColorSpec();
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @Since(2.0D)
/* 336 */     public Theme.ColorSpec iconHoverOn = new Theme.ColorSpec();
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @Since(2.0D)
/* 342 */     public Theme.ColorSpec iconHoverOff = new Theme.ColorSpec();
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @Since(2.0D)
/* 348 */     public Theme.ColorSpec iconDisabled = new Theme.ColorSpec();
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @Since(2.0D)
/* 354 */     public Theme.ColorSpec buttonOn = new Theme.ColorSpec();
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @Since(2.0D)
/* 360 */     public Theme.ColorSpec buttonOff = new Theme.ColorSpec();
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @Since(2.0D)
/* 366 */     public Theme.ColorSpec buttonHoverOn = new Theme.ColorSpec();
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @Since(2.0D)
/* 372 */     public Theme.ColorSpec buttonHoverOff = new Theme.ColorSpec();
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @Since(2.0D)
/* 378 */     public Theme.ColorSpec buttonDisabled = new Theme.ColorSpec();
/*     */   }
/*     */ }


/* Location:              C:\Users\Administrator\Downloads\journeymap-neoforge-1.21-6.0.0-beta.18.jar!\journeymap\clien\\ui\theme\Theme$Control.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */