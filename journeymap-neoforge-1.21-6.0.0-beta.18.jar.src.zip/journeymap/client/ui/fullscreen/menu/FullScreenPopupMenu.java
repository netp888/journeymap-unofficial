/*    */ package journeymap.client.ui.fullscreen.menu;
/*    */ 
/*    */ import java.util.ArrayList;
/*    */ import java.util.List;
/*    */ import journeymap.api.client.impl.ModPopupMenuImpl;
/*    */ import journeymap.api.v2.client.fullscreen.ModPopupMenu;
/*    */ import journeymap.client.event.dispatchers.CustomEventDispatcher;
/*    */ import journeymap.client.ui.component.DropDownItem;
/*    */ import journeymap.client.ui.component.SelectableParent;
/*    */ import journeymap.client.ui.component.buttons.Button;
/*    */ import journeymap.client.ui.component.popupscreenbutton.PopupMenu;
/*    */ import journeymap.client.ui.fullscreen.Fullscreen;
/*    */ import journeymap.client.waypoint.ClientWaypointImpl;
/*    */ import net.minecraft.client.gui.components.Button;
/*    */ import net.minecraft.client.gui.screens.Screen;
/*    */ import net.minecraft.core.BlockPos;
/*    */ 
/*    */ 
/*    */ public class FullScreenPopupMenu
/*    */   extends PopupMenu
/*    */ {
/*    */   public FullScreenPopupMenu(PopupMenu parent) {
/* 23 */     super(parent);
/*    */   }
/*    */ 
/*    */   
/*    */   public FullScreenPopupMenu(Screen parent) {
/* 28 */     super(parent);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void displayBasicOptions(BlockPos blockPos) {
/* 38 */     ModPopupMenuImpl modPopupMenuImpl = new ModPopupMenuImpl(((Fullscreen)this.parent).popupMenu);
/* 39 */     if (CustomEventDispatcher.getInstance().popupMenuEvent((Fullscreen)this.parent, (ModPopupMenu)modPopupMenuImpl))
/*    */     {
/* 41 */       displayOptions(blockPos, (ModPopupMenu)modPopupMenuImpl);
/*    */     }
/*    */   }
/*    */ 
/*    */   
/*    */   public void displayWaypointOptions(BlockPos blockPos, ClientWaypointImpl wp) {
/* 47 */     ModPopupMenuImpl modPopupMenuImpl = new ModPopupMenuImpl(((Fullscreen)this.parent).popupMenu);
/*    */     
/* 49 */     if (CustomEventDispatcher.getInstance().popupWaypointMenuEvent((Fullscreen)this.parent, (ModPopupMenu)modPopupMenuImpl, wp))
/*    */     {
/* 51 */       displayOptions(blockPos, (ModPopupMenu)modPopupMenuImpl);
/*    */     }
/*    */   }
/*    */ 
/*    */   
/*    */   public void displayOptions(BlockPos blockPos, ModPopupMenu popupMenu) {
/* 57 */     ModPopupMenuImpl menu = (ModPopupMenuImpl)popupMenu;
/* 58 */     if (menu.getMenuItemList() != null && !menu.getMenuItemList().isEmpty()) {
/*    */       
/* 60 */       List<DropDownItem> items = new ArrayList<>();
/* 61 */       menu.getMenuItemList().forEach(menuItem -> items.add(dropDownItemBuilder(menuItem, menu, blockPos)));
/* 62 */       display(items);
/*    */     } 
/*    */   }
/*    */ 
/*    */   
/*    */   private DropDownItem dropDownItemBuilder(ModPopupMenuImpl.MenuItem menuItem, ModPopupMenuImpl menu, BlockPos blockPos) {
/*    */     DropDownItem dropDownItem;
/* 69 */     if (menuItem.isAutoCloseable()) {
/*    */       
/* 71 */       dropDownItem = new DropDownItem((SelectableParent)this, menuItem, menuItem.isAutoCloseable(), menuItem.getLabel(), b -> {
/*    */             if (menu.isSub()) {
/*    */               closeStack();
/*    */             }
/*    */ 
/*    */ 
/*    */             
/*    */             menuItem.getAction().doAction(blockPos);
/*    */           });
/*    */     } else {
/* 81 */       dropDownItem = new DropDownItem((SelectableParent)this, menuItem, menuItem.isAutoCloseable(), menuItem.getLabel(), b -> menuItem.getSubMenuAction().doAction(blockPos, (Button)b));
/* 82 */       dropDownItem.setOnHover((button, isHovered) -> menuItem.getSubMenuAction().onHoverState(blockPos, button, isHovered));
/*    */     } 
/*    */     
/* 85 */     return dropDownItem;
/*    */   }
/*    */ }


/* Location:              C:\Users\Administrator\Downloads\journeymap-neoforge-1.21-6.0.0-beta.18.jar!\journeymap\clien\\ui\fullscreen\menu\FullScreenPopupMenu.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */