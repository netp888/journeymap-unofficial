/*     */ package journeymap.client.ui.fullscreen;
/*     */ 
/*     */ import net.minecraft.client.Minecraft;
/*     */ import net.minecraft.client.gui.GuiGraphics;
/*     */ import net.minecraft.client.gui.screens.ChatScreen;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MapChat
/*     */   extends ChatScreen
/*     */ {
/*     */   protected boolean hidden = false;
/*     */   protected int cursorCounter;
/*     */   
/*     */   public MapChat(String defaultText, boolean hidden) {
/*  38 */     super(defaultText);
/*  39 */     this.hidden = hidden;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void removed() {
/*  45 */     super.removed();
/*  46 */     this.hidden = true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void close() {
/*  54 */     removed();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void tick() {
/*  63 */     if (this.hidden) {
/*     */       return;
/*     */     }
/*     */     
/*  67 */     super.tick();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean charTyped(char typedChar, int keyCode) {
/*  76 */     if (this.hidden)
/*     */     {
/*  78 */       return false;
/*     */     }
/*  80 */     if (keyCode == 256) {
/*     */       
/*  82 */       close();
/*  83 */       return true;
/*     */     } 
/*  85 */     if (keyCode != 257 && keyCode != 335)
/*     */     {
/*  87 */       return super.charTyped(typedChar, keyCode);
/*     */     }
/*     */ 
/*     */     
/*  91 */     String s = this.input.getValue().trim();
/*     */     
/*  93 */     if (!s.isEmpty())
/*     */     {
/*  95 */       handleChatInput(s, true);
/*     */     }
/*     */     
/*  98 */     this.input.setValue("");
/*  99 */     (Minecraft.getInstance()).gui.getChat().resetChatScroll();
/* 100 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean keyPressed(int key, int value, int modifier) {
/* 108 */     if (key == 257 || key == 335) {
/*     */       
/* 110 */       String s = this.input.getValue().trim();
/*     */       
/* 112 */       if (!s.isEmpty())
/*     */       {
/* 114 */         handleChatInput(s, true);
/*     */       }
/*     */       
/* 117 */       this.input.setValue("");
/* 118 */       (Minecraft.getInstance()).gui.getChat().resetChatScroll();
/* 119 */       close();
/* 120 */       return true;
/*     */     } 
/* 122 */     return super.keyPressed(key, value, modifier);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean mouseClicked(double mouseX, double mouseY, int mouseButton) {
/* 131 */     if (this.hidden)
/*     */     {
/* 133 */       return false;
/*     */     }
/* 135 */     return super.mouseClicked(mouseX, mouseY, mouseButton);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void render(GuiGraphics graphics, int mouseX, int mouseY, float partialTicks) {
/* 145 */     graphics.pose().pushPose();
/* 146 */     graphics.pose().translate(0.0F, this.height - 47.5F, 0.0F);
/* 147 */     if (this.minecraft != null)
/*     */     {
/* 149 */       if (this.minecraft.gui != null)
/*     */       {
/* 151 */         this.minecraft.gui.getChat().render(graphics, mouseX, mouseY, this.hidden ? this.minecraft.gui.getGuiTicks() : this.cursorCounter++, true);
/*     */       }
/*     */     }
/* 154 */     graphics.pose().popPose();
/*     */     
/* 156 */     if (this.hidden) {
/*     */       return;
/*     */     }
/*     */ 
/*     */     
/* 161 */     super.render(graphics, mouseX, mouseY, partialTicks);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isHidden() {
/* 171 */     return this.hidden;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setHidden(boolean hidden) {
/* 181 */     this.hidden = hidden;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setText(String defaultText) {
/* 191 */     this.input.setValue(defaultText);
/*     */   }
/*     */ }


/* Location:              C:\Users\Administrator\Downloads\journeymap-neoforge-1.21-6.0.0-beta.18.jar!\journeymap\clien\\ui\fullscreen\MapChat.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */