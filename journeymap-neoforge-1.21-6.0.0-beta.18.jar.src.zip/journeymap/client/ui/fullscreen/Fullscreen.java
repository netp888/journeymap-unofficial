/*      */ package journeymap.client.ui.fullscreen;
/*      */ 
/*      */ import com.mojang.blaze3d.platform.InputConstants;
/*      */ import com.mojang.blaze3d.vertex.VertexConsumer;
/*      */ import java.awt.geom.Point2D;
/*      */ import java.awt.geom.Rectangle2D;
/*      */ import java.util.ArrayList;
/*      */ import java.util.List;
/*      */ import java.util.Locale;
/*      */ import java.util.Objects;
/*      */ import java.util.stream.Collectors;
/*      */ import javax.annotation.Nullable;
/*      */ import journeymap.api.client.impl.ClientAPI;
/*      */ import journeymap.api.common.waypoint.WaypointFactoryImpl;
/*      */ import journeymap.api.v2.client.display.Context;
/*      */ import journeymap.api.v2.client.display.Displayable;
/*      */ import journeymap.api.v2.client.display.Overlay;
/*      */ import journeymap.api.v2.client.display.PolygonOverlay;
/*      */ import journeymap.api.v2.client.fullscreen.IFullscreen;
/*      */ import journeymap.api.v2.client.model.MapPolygon;
/*      */ import journeymap.api.v2.client.model.ShapeProperties;
/*      */ import journeymap.api.v2.client.util.UIState;
/*      */ import journeymap.client.Constants;
/*      */ import journeymap.client.JourneymapClient;
/*      */ import journeymap.client.data.DataCache;
/*      */ import journeymap.client.data.WaypointsData;
/*      */ import journeymap.client.event.dispatchers.CustomEventDispatcher;
/*      */ import journeymap.client.event.dispatchers.FullscreenEventDispatcher;
/*      */ import journeymap.client.feature.Feature;
/*      */ import journeymap.client.feature.FeatureManager;
/*      */ import journeymap.client.io.MapSaver;
/*      */ import journeymap.client.io.ThemeLoader;
/*      */ import journeymap.client.log.ChatLog;
/*      */ import journeymap.client.log.StatTimer;
/*      */ import journeymap.client.model.BlockMD;
/*      */ import journeymap.client.model.EntityDTO;
/*      */ import journeymap.client.model.MapState;
/*      */ import journeymap.client.model.MapType;
/*      */ import journeymap.client.properties.CoreProperties;
/*      */ import journeymap.client.properties.FullMapProperties;
/*      */ import journeymap.client.properties.InGameMapProperties;
/*      */ import journeymap.client.properties.MapProperties;
/*      */ import journeymap.client.properties.MiniMapProperties;
/*      */ import journeymap.client.render.JMRenderTypes;
/*      */ import journeymap.client.render.draw.DrawUtil;
/*      */ import journeymap.client.render.draw.RadarDrawStepFactory;
/*      */ import journeymap.client.render.draw.WaypointDrawStepFactory;
/*      */ import journeymap.client.render.map.MapRenderer;
/*      */ import journeymap.client.render.map.RegionRenderer;
/*      */ import journeymap.client.render.map.Renderer;
/*      */ import journeymap.client.task.multi.MapRegionTask;
/*      */ import journeymap.client.task.multi.SaveMapTask;
/*      */ import journeymap.client.texture.Texture;
/*      */ import journeymap.client.texture.TextureCache;
/*      */ import journeymap.client.ui.UIManager;
/*      */ import journeymap.client.ui.component.ButtonList;
/*      */ import journeymap.client.ui.component.SearchTextBox;
/*      */ import journeymap.client.ui.component.buttons.Button;
/*      */ import journeymap.client.ui.component.buttons.FullscreenThemeDropdownButton;
/*      */ import journeymap.client.ui.component.buttons.IntSliderButton;
/*      */ import journeymap.client.ui.component.screens.JmUILegacy;
/*      */ import journeymap.client.ui.dialog.AutoMapConfirmation;
/*      */ import journeymap.client.ui.dialog.DeleteMapConfirmation;
/*      */ import journeymap.client.ui.dialog.FullscreenActions;
/*      */ import journeymap.client.ui.fullscreen.layer.LayerDelegate;
/*      */ import journeymap.client.ui.fullscreen.menu.FullScreenPopupMenu;
/*      */ import journeymap.client.ui.minimap.Shape;
/*      */ import journeymap.client.ui.option.LocationFormat;
/*      */ import journeymap.client.ui.theme.Theme;
/*      */ import journeymap.client.ui.theme.ThemeButton;
/*      */ import journeymap.client.ui.theme.ThemeToggle;
/*      */ import journeymap.client.ui.theme.ThemeToolbar;
/*      */ import journeymap.client.waypoint.ClientWaypointImpl;
/*      */ import journeymap.common.Journeymap;
/*      */ import journeymap.common.log.LogFormatter;
/*      */ import journeymap.common.properties.config.StringField;
/*      */ import journeymap.common.version.VersionCheck;
/*      */ import net.minecraft.Util;
/*      */ import net.minecraft.client.Minecraft;
/*      */ import net.minecraft.client.gui.Font;
/*      */ import net.minecraft.client.gui.GuiGraphics;
/*      */ import net.minecraft.client.gui.components.Button;
/*      */ import net.minecraft.client.gui.components.Renderable;
/*      */ import net.minecraft.client.gui.components.events.GuiEventListener;
/*      */ import net.minecraft.client.gui.screens.Screen;
/*      */ import net.minecraft.client.player.LocalPlayer;
/*      */ import net.minecraft.client.renderer.MultiBufferSource;
/*      */ import net.minecraft.client.renderer.RenderType;
/*      */ import net.minecraft.core.BlockPos;
/*      */ import net.minecraft.network.chat.Component;
/*      */ import net.minecraft.network.chat.FormattedText;
/*      */ import net.minecraft.resources.ResourceKey;
/*      */ import net.minecraft.util.FormattedCharSequence;
/*      */ import net.minecraft.util.Mth;
/*      */ import net.minecraft.world.entity.player.Player;
/*      */ import net.minecraft.world.level.Level;
/*      */ import net.minecraft.world.phys.Vec3;
/*      */ import org.apache.logging.log4j.Level;
/*      */ import org.apache.logging.log4j.Logger;
/*      */ 
/*      */ 
/*      */ 
/*      */ public class Fullscreen
/*      */   extends JmUILegacy
/*      */   implements IFullscreen
/*      */ {
/*  107 */   private long lastGridUpdate = 0L;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  112 */   private static final MapState state = new MapState();
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  117 */   private static final MapRenderer mapRenderer = new MapRenderer(Context.UI.Fullscreen);
/*      */ 
/*      */ 
/*      */   
/*  121 */   private final WaypointDrawStepFactory waypointRenderer = new WaypointDrawStepFactory();
/*      */ 
/*      */ 
/*      */   
/*  125 */   private final RadarDrawStepFactory radarRenderer = new RadarDrawStepFactory();
/*      */ 
/*      */ 
/*      */   
/*      */   private final LayerDelegate layerDelegate;
/*      */ 
/*      */ 
/*      */   
/*  133 */   private FullMapProperties fullMapProperties = JourneymapClient.getInstance().getFullMapProperties();
/*      */ 
/*      */ 
/*      */   
/*  137 */   private CoreProperties coreProperties = JourneymapClient.getInstance().getCoreProperties();
/*      */ 
/*      */ 
/*      */   
/*      */   private boolean firstLayoutPass = true;
/*      */ 
/*      */ 
/*      */   
/*      */   private static boolean buttonsVisible = true;
/*      */ 
/*      */   
/*  148 */   private Boolean isDragging = Boolean.valueOf(false);
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private int mouseDragX;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private int mouseDragY;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private int mx;
/*      */ 
/*      */ 
/*      */   
/*      */   private int my;
/*      */ 
/*      */ 
/*      */   
/*  171 */   private Logger logger = Journeymap.getLogger();
/*      */ 
/*      */ 
/*      */   
/*      */   private MapChat chat;
/*      */ 
/*      */ 
/*      */   
/*      */   private ThemeButton buttonFollow;
/*      */ 
/*      */ 
/*      */   
/*      */   private ThemeButton buttonZoomIn;
/*      */ 
/*      */ 
/*      */   
/*      */   private ThemeButton buttonZoomOut;
/*      */ 
/*      */ 
/*      */   
/*      */   private ThemeButton buttonSearch;
/*      */ 
/*      */ 
/*      */   
/*      */   private SearchTextBox searchTextX;
/*      */ 
/*      */ 
/*      */   
/*      */   private SearchTextBox searchTextZ;
/*      */ 
/*      */ 
/*      */   
/*      */   private ThemeButton buttonExecuteSearch;
/*      */ 
/*      */ 
/*      */   
/*      */   private ThemeToolbar searchToolBar;
/*      */ 
/*      */ 
/*      */   
/*      */   private ThemeButton buttonDay;
/*      */ 
/*      */   
/*      */   private ThemeButton buttonNight;
/*      */ 
/*      */   
/*      */   private ThemeButton buttonTopo;
/*      */ 
/*      */   
/*      */   private ThemeButton buttonBiome;
/*      */ 
/*      */   
/*      */   private ThemeButton buttonLayers;
/*      */ 
/*      */   
/*      */   private ThemeButton buttonCaves;
/*      */ 
/*      */   
/*      */   private ThemeButton buttonAlert;
/*      */ 
/*      */   
/*      */   private ThemeButton buttonOptions;
/*      */ 
/*      */   
/*      */   private ThemeButton buttonClose;
/*      */ 
/*      */   
/*      */   private FullscreenThemeDropdownButton buttonTheme;
/*      */ 
/*      */   
/*      */   private boolean buttonThemeNeedReopen = false;
/*      */ 
/*      */   
/*      */   private ThemeButton buttonWaypointManager;
/*      */ 
/*      */   
/*      */   private ThemeButton buttonMobs;
/*      */ 
/*      */   
/*      */   private ThemeButton buttonAnimals;
/*      */ 
/*      */   
/*      */   private ThemeButton buttonPets;
/*      */ 
/*      */   
/*      */   private ThemeButton buttonVillagers;
/*      */ 
/*      */   
/*      */   private ThemeButton buttonPlayers;
/*      */ 
/*      */   
/*      */   private ThemeButton buttonGrid;
/*      */ 
/*      */   
/*      */   private ThemeButton buttonKeys;
/*      */ 
/*      */   
/*      */   private ThemeButton buttonAutomap;
/*      */ 
/*      */   
/*      */   private ThemeButton buttonSavemap;
/*      */ 
/*      */   
/*      */   private ThemeButton buttonDeletemap;
/*      */ 
/*      */   
/*      */   private ThemeButton buttonDisable;
/*      */ 
/*      */   
/*      */   private ThemeButton buttonColorPalette;
/*      */ 
/*      */   
/*      */   private ThemeButton buttonBrowser;
/*      */ 
/*      */   
/*      */   private ThemeButton buttonAbout;
/*      */ 
/*      */   
/*      */   ThemeButton overlayRenderButton;
/*      */ 
/*      */   
/*      */   private ThemeToolbar mapTypeToolbar;
/*      */ 
/*      */   
/*      */   private ThemeToolbar optionsToolbar;
/*      */ 
/*      */   
/*      */   private ThemeToolbar menuToolbar;
/*      */ 
/*      */   
/*      */   private ThemeToolbar zoomToolbar;
/*      */ 
/*      */   
/*      */   private ThemeToolbar addonToolbar;
/*      */ 
/*      */   
/*      */   private List<ThemeToolbar> customToolbars;
/*      */ 
/*      */   
/*      */   private BlockPos zoomBlock;
/*      */ 
/*      */   
/*  313 */   private int bgColor = 2236962;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private Theme.LabelSpec statusLabelSpec;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  323 */   private final StatTimer renderTimer = StatTimer.get("Fullscreen.render");
/*      */ 
/*      */ 
/*      */   
/*  327 */   private final StatTimer drawMapTimer = StatTimer.get("Fullscreen.render.drawMap", 50);
/*      */ 
/*      */ 
/*      */   
/*  331 */   private final StatTimer drawMapTimerWithRefresh = StatTimer.get("Fullscreen.drawMap+refreshState", 5);
/*      */ 
/*      */ 
/*      */   
/*  335 */   private final LocationFormat locationFormat = new LocationFormat();
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  340 */   private final List<Overlay> tempOverlays = new ArrayList<>();
/*      */   
/*      */   private IntSliderButton sliderCaveLayer;
/*      */   
/*      */   private List<FormattedCharSequence> autoMapOnTooltip;
/*      */   private List<FormattedCharSequence> autoMapOffTooltip;
/*      */   private Rectangle2D.Double mapTypeToolbarBounds;
/*      */   private Rectangle2D.Double optionsToolbarBounds;
/*      */   private Rectangle2D.Double menuToolbarBounds;
/*      */   private final Minecraft minecraft;
/*      */   public boolean chatOpenedFromEvent = false;
/*      */   public final FullScreenPopupMenu popupMenu;
/*      */   private List<FormattedCharSequence> entityTooltip;
/*  353 */   int zoom = 512;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Fullscreen() {
/*  360 */     super("Fullscreen Map");
/*  361 */     this.popupMenu = new FullScreenPopupMenu((Screen)this);
/*  362 */     this.minecraft = Minecraft.getInstance();
/*  363 */     mapRenderer.clear();
/*  364 */     mapRenderer.setZoom((JourneymapClient.getInstance().getFullMapProperties()).zoomLevel.get().intValue());
/*  365 */     this.layerDelegate = new LayerDelegate(this);
/*  366 */     if ((JourneymapClient.getInstance().getFullMapProperties()).showCaves.get().booleanValue() && 
/*  367 */       (DataCache.getPlayer()).underground.booleanValue() && state.follow.get() && 
/*  368 */       FeatureManager.getInstance().isAllowed(Feature.MapCaves))
/*      */     {
/*  370 */       state.setMapType(MapType.underground(DataCache.getPlayer()));
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static synchronized MapState state() {
/*  381 */     return state;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static synchronized UIState uiState() {
/*  391 */     return mapRenderer.getUIState();
/*      */   }
/*      */ 
/*      */   
/*      */   public UIState getUiState() {
/*  396 */     return mapRenderer.getUIState();
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public Screen getScreen() {
/*  402 */     return (Screen)this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void reset() {
/*  410 */     this.isDragging = Boolean.valueOf(false);
/*  411 */     state.requireRefresh();
/*  412 */     mapRenderer.clear();
/*  413 */     clearWidgets();
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void init() {
/*  419 */     this.fullMapProperties = JourneymapClient.getInstance().getFullMapProperties();
/*  420 */     state.requireRefresh();
/*  421 */     state.refresh(this.minecraft, (Player)(Minecraft.getInstance()).player, (InGameMapProperties)this.fullMapProperties);
/*  422 */     MapType mapType = state.getMapType();
/*      */ 
/*      */     
/*  425 */     if (!mapType.dimension.equals(this.minecraft.player.getCommandSenderWorld().dimension()))
/*      */     {
/*  427 */       mapRenderer.clear();
/*      */     }
/*      */     
/*  430 */     initButtons();
/*      */     
/*  432 */     String thisVersion = Journeymap.JM_VERSION.toString();
/*  433 */     String splashViewed = (JourneymapClient.getInstance().getCoreProperties()).splashViewed.get();
/*      */     
/*  435 */     if (splashViewed == null || !thisVersion.equals(splashViewed))
/*      */     {
/*  437 */       UIManager.INSTANCE.openSplash((Screen)this);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void render(GuiGraphics graphics, int mouseX, int mouseY, float partialTicks) {
/*      */     try {
/*  446 */       MultiBufferSource.BufferSource buffers = graphics.bufferSource();
/*  447 */       renderBackground(graphics, mouseX, mouseY, partialTicks);
/*  448 */       drawMap(graphics, buffers, mouseX, mouseY);
/*  449 */       if (buttonsVisible)
/*      */       {
/*  451 */         drawLogo(graphics);
/*      */       }
/*  453 */       this.renderTimer.start();
/*      */       
/*  455 */       layoutButtons(graphics);
/*      */       
/*  457 */       List<FormattedCharSequence> tooltip = null;
/*      */       
/*  459 */       if (this.firstLayoutPass) {
/*      */         
/*  461 */         layoutButtons(graphics);
/*  462 */         updateMapType(state.getMapType());
/*  463 */         this.firstLayoutPass = false;
/*      */ 
/*      */       
/*      */       }
/*  467 */       else if (buttonsVisible) {
/*      */         
/*  469 */         for (int k = 0; k < getRenderables().size(); k++) {
/*      */           
/*  471 */           Button guibutton = getRenderables().get(k);
/*  472 */           guibutton.render(graphics, mouseX, mouseY, partialTicks);
/*  473 */           if (tooltip == null)
/*      */           {
/*  475 */             if (guibutton instanceof Button) {
/*      */               
/*  477 */               Button button = (Button)guibutton;
/*  478 */               if (button.mouseOver(this.mx, this.my))
/*      */               {
/*  480 */                 tooltip = button.getWrappedTooltip();
/*      */               }
/*      */             } 
/*      */           }
/*      */         } 
/*      */       } 
/*      */ 
/*      */       
/*  488 */       if (this.chat != null)
/*      */       {
/*  490 */         this.chat.render(graphics, mouseX, mouseY, partialTicks);
/*      */       }
/*      */       
/*  493 */       if (tooltip == null || tooltip.isEmpty())
/*      */       {
/*  495 */         tooltip = this.entityTooltip;
/*      */       }
/*      */       
/*  498 */       if (tooltip != null && !tooltip.isEmpty())
/*      */       {
/*  500 */         renderWrappedToolTip(graphics, tooltip, this.mx, this.my, getFontRenderer());
/*  501 */         this.entityTooltip = null;
/*      */       }
/*      */     
/*  504 */     } catch (Exception e) {
/*      */       
/*  506 */       this.logger.log(Level.ERROR, "Unexpected exception in jm.fullscreen.render(): " + LogFormatter.toString(e));
/*  507 */       UIManager.INSTANCE.closeAll();
/*      */     }
/*      */     finally {
/*      */       
/*  511 */       this.renderTimer.stop();
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   public void queueToolTip(List<Component> tooltips) {
/*  517 */     this.entityTooltip = (List<FormattedCharSequence>)tooltips.stream().map(Component::getVisualOrderText).collect(Collectors.toList());
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void resize(Minecraft minecraft, int width, int height) {
/*  523 */     super.resize(minecraft, width, height);
/*  524 */     mapRenderer.clear();
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void init(Minecraft minecraft, int width, int height) {
/*  530 */     super.init(minecraft, width, height);
/*  531 */     state.requireRefresh();
/*      */     
/*  533 */     if (this.chat == null)
/*      */     {
/*  535 */       this.chat = new MapChat("", true);
/*      */     }
/*  537 */     if (this.chat != null)
/*      */     {
/*      */       
/*  540 */       this.chat.init(minecraft, width, height);
/*      */     }
/*      */     
/*  543 */     init();
/*  544 */     refreshState();
/*  545 */     mouseMoved(0.0D, 0.0D);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void initButtons() {
/*  553 */     if (getRenderables().isEmpty()) {
/*      */       
/*      */       try {
/*      */         
/*  557 */         this.firstLayoutPass = true;
/*  558 */         Theme theme = ThemeLoader.getCurrentTheme();
/*  559 */         MapType mapType = state.getMapType();
/*      */ 
/*      */         
/*  562 */         this.bgColor = theme.fullscreen.background.getColor();
/*  563 */         this.statusLabelSpec = theme.fullscreen.statusLabel;
/*      */ 
/*      */         
/*  566 */         this.buttonDay = (ThemeButton)addRenderableWidget((GuiEventListener)new ThemeToggle(theme, "jm.fullscreen.map_day", "day", button -> {
/*      */                 if (this.buttonDay.isEnabled()) {
/*      */                   updateMapType(MapType.day(state.getDimension()));
/*      */                 }
/*      */               }));
/*      */ 
/*      */         
/*  573 */         this.buttonDay.setToggled(Boolean.valueOf(mapType.isDay()), false);
/*  574 */         this.buttonDay.setStaysOn(true);
/*      */         
/*  576 */         this.buttonNight = (ThemeButton)addRenderableWidget((GuiEventListener)new ThemeToggle(theme, "jm.fullscreen.map_night", "night", button -> {
/*      */                 if (this.buttonNight.isEnabled()) {
/*      */                   updateMapType(MapType.night(state.getDimension()));
/*      */                 }
/*      */               }));
/*      */ 
/*      */         
/*  583 */         this.buttonNight.setToggled(Boolean.valueOf(mapType.isNight()), false);
/*  584 */         this.buttonNight.setStaysOn(true);
/*      */         
/*  586 */         this.buttonTopo = (ThemeButton)addRenderableWidget((GuiEventListener)new ThemeToggle(theme, "jm.fullscreen.map_topo", "topo", button -> {
/*      */                 if (this.buttonTopo.isEnabled()) {
/*      */                   updateMapType(MapType.topo(state.getDimension()));
/*      */                 }
/*      */               }));
/*      */ 
/*      */         
/*  593 */         this.buttonTopo.setDrawButton(this.coreProperties.mapTopography.get().booleanValue());
/*  594 */         this.buttonTopo.setToggled(Boolean.valueOf(mapType.isTopo()), false);
/*  595 */         this.buttonTopo.setStaysOn(true);
/*      */ 
/*      */         
/*  598 */         this.buttonBiome = (ThemeButton)addRenderableWidget((GuiEventListener)new ThemeToggle(theme, "jm.fullscreen.map_biome", "biome", button -> {
/*      */                 if (this.buttonBiome.isEnabled()) {
/*      */                   updateMapType(MapType.biome(state.getDimension()));
/*      */                 }
/*      */               }));
/*      */ 
/*      */         
/*  605 */         this.buttonBiome.setDrawButton(this.coreProperties.mapBiome.get().booleanValue());
/*  606 */         this.buttonBiome.setToggled(Boolean.valueOf(mapType.isBiome()), false);
/*  607 */         this.buttonBiome.setStaysOn(true);
/*      */         
/*  609 */         this.buttonLayers = (ThemeButton)addRenderableWidget((GuiEventListener)new ThemeToggle(theme, "jm.fullscreen.map_cave_layers", "layers", button -> {
/*      */                 EntityDTO player = DataCache.getPlayer();
/*      */                 
/*      */                 this.buttonLayers.toggle();
/*      */                 
/*      */                 this.sliderCaveLayer.setDrawButton(this.buttonLayers.getToggled().booleanValue());
/*      */               }));
/*  616 */         this.buttonLayers.setEnabled(state.isCaveMappingAllowed());
/*  617 */         this.buttonLayers.setDrawButton(state.isCaveMappingAllowed());
/*      */         
/*  619 */         Font fontRenderer = getFontRenderer();
/*      */ 
/*      */         
/*  622 */         this.sliderCaveLayer = (IntSliderButton)addRenderableOnly((Renderable)new IntSliderButton(state.getLastSlice(), Constants.getString("jm.fullscreen.map_cave_layers.button") + " ", ""));
/*  623 */         this.sliderCaveLayer.setWidth(this.sliderCaveLayer.getFitWidth(fontRenderer) + fontRenderer.width("0"));
/*  624 */         this.sliderCaveLayer.setDefaultStyle(false);
/*  625 */         this.sliderCaveLayer.setDrawBackground(true);
/*  626 */         Theme.Control.ButtonSpec buttonSpec = this.buttonLayers.getButtonSpec();
/*  627 */         this.sliderCaveLayer.setBackgroundColors(Integer.valueOf(buttonSpec.buttonDisabled.getColor()), Integer.valueOf(buttonSpec.buttonOff.getColor()), Integer.valueOf(buttonSpec.buttonOff.getColor()));
/*  628 */         this.sliderCaveLayer.setLabelColors(Integer.valueOf(buttonSpec.iconHoverOff.getColor()), Integer.valueOf(buttonSpec.iconHoverOn.getColor()), Integer.valueOf(buttonSpec.iconDisabled.getColor()));
/*  629 */         this.sliderCaveLayer.setDrawButton(false);
/*  630 */         this.sliderCaveLayer.addClickListener(button -> {
/*      */               state.setMapType(MapType.underground(Integer.valueOf(this.sliderCaveLayer.getValue()), state.getDimension()));
/*      */               state.setForceRefreshState(true);
/*      */               return Boolean.valueOf(true);
/*      */             });
/*  635 */         getRenderables().add(this.sliderCaveLayer);
/*      */ 
/*      */         
/*  638 */         this.buttonSearch = (ThemeButton)addRenderableWidget((GuiEventListener)new ThemeButton(theme, "jm.fullscreen.search", "search", button -> {
/*      */                 this.buttonSearch.toggle();
/*      */                 
/*      */                 toggleSearchBar(this.buttonSearch.getToggled().booleanValue());
/*      */               }));
/*      */         
/*  644 */         this.searchTextX = (SearchTextBox)addRenderableWidget((GuiEventListener)new SearchTextBox("x:", fontRenderer, 40, 20));
/*  645 */         this.searchTextZ = (SearchTextBox)addRenderableWidget((GuiEventListener)new SearchTextBox("z:", fontRenderer, 40, 20));
/*      */         
/*  647 */         this.buttonExecuteSearch = (ThemeButton)addRenderableWidget((GuiEventListener)new ThemeButton(theme, "jm.fullscreen.search_execute", "follow", button -> executeSearch()));
/*      */         
/*  649 */         this.searchTextX.setVisible(false);
/*  650 */         this.searchTextZ.setVisible(false);
/*  651 */         this.buttonExecuteSearch.setVisible(false);
/*      */ 
/*      */         
/*  654 */         this.buttonFollow = (ThemeButton)addRenderableWidget((GuiEventListener)new ThemeButton(theme, "jm.fullscreen.follow", "follow", button -> toggleFollow()));
/*      */ 
/*      */ 
/*      */         
/*  658 */         this.buttonZoomIn = (ThemeButton)addRenderableWidget((GuiEventListener)new ThemeButton(theme, "jm.fullscreen.zoom_in", "zoomin", button -> zoomIn()));
/*  659 */         Objects.requireNonNull(state); this.buttonZoomIn.setEnabled((this.fullMapProperties.zoomLevel.get().intValue() < 16384));
/*  660 */         this.buttonZoomIn.setDisplayClickToggle(false);
/*      */ 
/*      */         
/*  663 */         this.buttonZoomOut = (ThemeButton)addRenderableWidget((GuiEventListener)new ThemeButton(theme, "jm.fullscreen.zoom_out", "zoomout", button -> zoomOut()));
/*  664 */         this.buttonZoomOut.setEnabled((this.fullMapProperties.zoomLevel.get().intValue() > state.minZoom));
/*  665 */         this.buttonZoomOut.setDisplayClickToggle(false);
/*      */ 
/*      */         
/*  668 */         this.buttonWaypointManager = (ThemeButton)addRenderableWidget((GuiEventListener)new ThemeButton(theme, "jm.waypoint.waypoints_button", "waypoints", button -> UIManager.INSTANCE.openWaypointManager(null, (Screen)this)));
/*      */ 
/*      */         
/*  671 */         this.buttonWaypointManager.setEnabled(WaypointsData.isManagerEnabled());
/*  672 */         this.buttonWaypointManager.setDrawButton(WaypointsData.isManagerEnabled());
/*      */ 
/*      */         
/*  675 */         this.buttonOptions = (ThemeButton)addRenderableWidget((GuiEventListener)new ThemeButton(theme, "jm.common.options_button", "options", button -> {
/*      */                 try {
/*      */                   UIManager.INSTANCE.openOptionsManager((Screen)this, new journeymap.common.properties.catagory.Category[0]);
/*      */ 
/*      */ 
/*      */                   
/*      */                   clearWidgets();
/*  682 */                 } catch (Exception e) {
/*      */                   e.printStackTrace();
/*      */                 } 
/*      */               }));
/*      */ 
/*      */ 
/*      */         
/*  689 */         String versionAvailable = Constants.getString("jm.common.new_version_available", new Object[] { VersionCheck.getVersionAvailable() });
/*  690 */         this.buttonAlert = (ThemeButton)addRenderableWidget((GuiEventListener)new ThemeButton(theme, versionAvailable, versionAvailable, false, "alert", button -> {
/*      */                 FullscreenActions.launchDownloadWebsite();
/*      */                 
/*      */                 this.buttonAlert.setDrawButton(false);
/*      */               }));
/*  695 */         this.buttonAlert.setDrawButton((VersionCheck.getVersionIsChecked().booleanValue() && !VersionCheck.getVersionIsCurrent().booleanValue()));
/*  696 */         this.buttonAlert.setToggled(Boolean.valueOf(true));
/*      */ 
/*      */ 
/*      */         
/*  700 */         this.buttonClose = (ThemeButton)addRenderableWidget((GuiEventListener)new ThemeButton(theme, "jm.common.close", "close", button -> UIManager.INSTANCE.closeAll()));
/*      */ 
/*      */         
/*  703 */         StringField themeField = (JourneymapClient.getInstance().getCoreProperties()).themeName;
/*  704 */         this.buttonTheme = (FullscreenThemeDropdownButton)addRenderableWidget((GuiEventListener)new FullscreenThemeDropdownButton(fontRenderer, themeField, this.buttonThemeNeedReopen, button -> {
/*      */                 UIManager.INSTANCE.getMiniMap().reset();
/*      */                 clearWidgets();
/*      */                 this.buttonThemeNeedReopen = true;
/*      */               }));
/*  709 */         this.buttonThemeNeedReopen = false;
/*      */ 
/*      */         
/*  712 */         this.buttonCaves = (ThemeButton)addRenderableWidget((GuiEventListener)new ThemeToggle(theme, "jm.common.show_caves", "caves", this.fullMapProperties.showCaves, button -> {
/*      */                 EntityDTO player = DataCache.getPlayer();
/*      */ 
/*      */                 
/*      */                 this.buttonCaves.setToggled(Boolean.valueOf(!this.buttonCaves.getToggled().booleanValue()));
/*      */                 
/*      */                 if (this.buttonCaves.getToggled().booleanValue()) {
/*      */                   updateMapType(MapType.underground(player));
/*      */                 } else {
/*      */                   updateMapType(MapType.day(player));
/*      */                 } 
/*      */               }));
/*      */         
/*  725 */         this.buttonCaves.setTooltip(new String[] { Constants.getString("jm.common.show_caves.tooltip") });
/*  726 */         this.buttonCaves.setDrawButton(state.isCaveMappingAllowed());
/*      */         
/*  728 */         this.buttonMobs = (ThemeButton)addRenderableWidget((GuiEventListener)new ThemeToggle(theme, "jm.common.show_mobs", "monsters", this.fullMapProperties.showMobs, button -> this.buttonMobs.toggle()));
/*  729 */         this.buttonMobs.setTooltip(new String[] { Constants.getString("jm.common.show_mobs.tooltip") });
/*  730 */         this.buttonMobs.setDrawButton(FeatureManager.getInstance().isAllowed(Feature.RadarMobs));
/*      */         
/*  732 */         this.buttonAnimals = (ThemeButton)addRenderableWidget((GuiEventListener)new ThemeToggle(theme, "jm.common.show_animals", "animals", this.fullMapProperties.showAnimals, button -> this.buttonAnimals.toggle()));
/*  733 */         this.buttonAnimals.setTooltip(new String[] { Constants.getString("jm.common.show_animals.tooltip") });
/*  734 */         this.buttonAnimals.setDrawButton(FeatureManager.getInstance().isAllowed(Feature.RadarAnimals));
/*      */         
/*  736 */         this.buttonPets = (ThemeButton)addRenderableWidget((GuiEventListener)new ThemeToggle(theme, "jm.common.show_pets", "pets", this.fullMapProperties.showPets, button -> this.buttonPets.toggle()));
/*  737 */         this.buttonPets.setTooltip(new String[] { Constants.getString("jm.common.show_pets.tooltip") });
/*  738 */         this.buttonPets.setDrawButton(FeatureManager.getInstance().isAllowed(Feature.RadarAnimals));
/*      */         
/*  740 */         this.buttonVillagers = (ThemeButton)addRenderableWidget((GuiEventListener)new ThemeToggle(theme, "jm.common.show_villagers", "villagers", this.fullMapProperties.showVillagers, button -> this.buttonVillagers.toggle()));
/*  741 */         this.buttonVillagers.setTooltip(new String[] { Constants.getString("jm.common.show_villagers.tooltip") });
/*  742 */         this.buttonVillagers.setDrawButton(FeatureManager.getInstance().isAllowed(Feature.RadarVillagers));
/*      */         
/*  744 */         this.buttonPlayers = (ThemeButton)addRenderableWidget((GuiEventListener)new ThemeToggle(theme, "jm.common.show_players", "players", this.fullMapProperties.showPlayers, button -> this.buttonPlayers.toggle()));
/*  745 */         this.buttonPlayers.setTooltip(new String[] { Constants.getString("jm.common.show_players.tooltip") });
/*  746 */         this.buttonPlayers.setDrawButton((!this.minecraft.hasSingleplayerServer() && FeatureManager.getInstance().isAllowed(Feature.RadarPlayers)));
/*      */         
/*  748 */         this.buttonGrid = (ThemeButton)addRenderableWidget((GuiEventListener)new ThemeToggle(theme, "jm.common.show_grid", "grid", this.fullMapProperties.showGrid, button -> {
/*      */                 this.buttonGrid.toggle();
/*  750 */                 boolean shiftDown = (InputConstants.isKeyDown(Minecraft.getInstance().getWindow().getWindow(), 340) || InputConstants.isKeyDown(Minecraft.getInstance().getWindow().getWindow(), 344));
/*      */ 
/*      */                 
/*      */                 if (shiftDown) {
/*      */                   UIManager.INSTANCE.openGridEditor((Screen)this);
/*      */                   
/*      */                   this.buttonGrid.setValue(Boolean.valueOf(true));
/*      */                 } 
/*      */               }));
/*      */         
/*  760 */         this.buttonGrid.setTooltip(new String[] { Constants.getString("jm.common.show_grid_shift.tooltip") });
/*  761 */         this.buttonKeys = (ThemeButton)addRenderableWidget((GuiEventListener)new ThemeToggle(theme, "jm.common.show_keys", "keys", this.fullMapProperties.showKeys, button -> this.buttonKeys.toggle()));
/*  762 */         this.buttonKeys.setTooltip(new String[] { Constants.getString("jm.common.show_keys.tooltip") });
/*      */ 
/*      */         
/*  765 */         this.buttonAbout = (ThemeButton)addRenderableWidget((GuiEventListener)new ThemeButton(theme, "jm.common.splash_about", "about", button -> UIManager.INSTANCE.openSplash((Screen)this)));
/*      */         
/*  767 */         this.overlayRenderButton = new ThemeButton(theme, "region display on", " region display off", false, "server", button -> RegionRenderer.render(!RegionRenderer.TOGGLED));
/*      */ 
/*      */         
/*  770 */         addRenderableWidget((GuiEventListener)this.overlayRenderButton);
/*      */         
/*  772 */         this.buttonSavemap = (ThemeButton)addRenderableWidget((GuiEventListener)new ThemeButton(theme, "jm.common.save_map", "savemap", button -> {
/*      */                 this.buttonSavemap.setEnabled(false);
/*      */                 
/*      */                 try {
/*      */                   MapSaver mapSaver = new MapSaver(state.getWorldDir(), state.getMapType());
/*      */                   
/*      */                   if (mapSaver.isValid()) {
/*      */                     JourneymapClient.getInstance().toggleTask(SaveMapTask.Manager.class, true, mapSaver);
/*      */                     
/*      */                     ChatLog.announceI18N("jm.common.save_filename", new Object[] { mapSaver.getSaveFileName() });
/*      */                   } 
/*      */                 } finally {
/*      */                   this.buttonSavemap.setToggled(Boolean.valueOf(false));
/*      */                   
/*      */                   this.buttonSavemap.setEnabled(true);
/*      */                 } 
/*      */               }));
/*      */         
/*  790 */         this.buttonBrowser = (ThemeButton)addRenderableWidget((GuiEventListener)new ThemeButton(theme, "jm.common.use_browser", "browser", button -> FullscreenActions.launchLocalhost()));
/*      */         
/*  792 */         boolean webMapEnabled = (JourneymapClient.getInstance().getWebMap() != null && (JourneymapClient.getInstance().getWebMapProperties()).enabled.get().booleanValue());
/*  793 */         this.buttonBrowser.setEnabled(webMapEnabled);
/*  794 */         this.buttonBrowser.setDrawButton(webMapEnabled);
/*      */ 
/*      */         
/*  797 */         boolean automapRunning = JourneymapClient.getInstance().isTaskManagerEnabled(MapRegionTask.Manager.class);
/*  798 */         String autoMapOn = Constants.getString("jm.common.automap_stop_title");
/*  799 */         String autoMapOff = Constants.getString("jm.common.automap_title");
/*  800 */         this.autoMapOnTooltip = fontRenderer.split((FormattedText)Constants.getTranslatedTextComponent("jm.common.automap_stop_text"), 200);
/*  801 */         this.autoMapOffTooltip = fontRenderer.split((FormattedText)Constants.getTranslatedTextComponent("jm.common.automap_text"), 200);
/*  802 */         this.buttonAutomap = (ThemeButton)addRenderableWidget((GuiEventListener)new ThemeToggle(theme, autoMapOn, autoMapOff, "automap", button -> {
/*      */                 if (!this.buttonAutomap.getToggled().booleanValue()) {
/*      */                   UIManager.INSTANCE.open(AutoMapConfirmation.class, (Screen)this);
/*      */                 } else {
/*      */                   JourneymapClient.getInstance().toggleTask(MapRegionTask.Manager.class, false, null);
/*      */                   
/*      */                   this.buttonAutomap.setToggled(Boolean.valueOf(false), false);
/*      */                   
/*      */                   clearWidgets();
/*      */                 } 
/*      */               }));
/*      */         
/*  814 */         this.buttonAutomap.setEnabled((Minecraft.getInstance().hasSingleplayerServer() && (JourneymapClient.getInstance().getCoreProperties()).mappingEnabled.get().booleanValue()));
/*  815 */         this.buttonAutomap.setToggled(Boolean.valueOf(automapRunning), false);
/*      */ 
/*      */         
/*  818 */         this.buttonDeletemap = (ThemeButton)addRenderableWidget((GuiEventListener)new ThemeButton(theme, "jm.common.deletemap_title", "delete", button -> UIManager.INSTANCE.open(DeleteMapConfirmation.class, (Screen)this)));
/*  819 */         this.buttonDeletemap.setAdditionalTooltips(fontRenderer.split((FormattedText)Constants.getTranslatedTextComponent("jm.common.deletemap_text"), 200));
/*      */         
/*  821 */         this.buttonDisable = (ThemeButton)addRenderableWidget((GuiEventListener)new ThemeToggle(theme, "jm.common.enable_mapping_false", "disable", button -> {
/*      */                 this.buttonDisable.toggle();
/*      */                 
/*      */                 (JourneymapClient.getInstance().getCoreProperties()).mappingEnabled.set(Boolean.valueOf(!this.buttonDisable.getToggled().booleanValue()));
/*      */                 
/*      */                 if ((JourneymapClient.getInstance().getCoreProperties()).mappingEnabled.get().booleanValue()) {
/*      */                   DataCache.INSTANCE.invalidateChunkMDCache();
/*      */                   
/*      */                   ChatLog.announceI18N("jm.common.enable_mapping_true_text", new Object[0]);
/*      */                 } else {
/*      */                   JourneymapClient.getInstance().stopMapping();
/*      */                   
/*      */                   BlockMD.reset();
/*      */                   ChatLog.announceI18N("jm.common.enable_mapping_false_text", new Object[0]);
/*      */                 } 
/*      */               }));
/*  837 */         this.buttonColorPalette = (ThemeButton)addRenderableWidget((GuiEventListener)new ThemeButton(theme, "jm.colorpalette.colorpalette_button", "colorpalette", button -> UIManager.INSTANCE.openColorPalette((Screen)this)));
/*      */ 
/*      */         
/*  840 */         this.mapTypeToolbar = CustomEventDispatcher.getInstance().getMapTypeToolbar(this, theme, new Button[] { (Button)this.buttonLayers, (Button)this.buttonTopo, (Button)this.buttonBiome, (Button)this.buttonNight, (Button)this.buttonDay });
/*  841 */         this.mapTypeToolbar.addAllButtons(this);
/*      */         
/*  843 */         this.optionsToolbar = new ThemeToolbar(theme, new ThemeButton[] { this.buttonCaves, this.buttonMobs, this.buttonAnimals, this.buttonPets, this.buttonVillagers, this.buttonPlayers, this.buttonGrid, this.buttonKeys });
/*  844 */         this.optionsToolbar.addAllButtons(this);
/*  845 */         this.optionsToolbar.visible = false;
/*      */         
/*  847 */         this.menuToolbar = new ThemeToolbar(theme, new ThemeButton[] { this.buttonWaypointManager, this.buttonOptions, this.buttonAbout, this.buttonBrowser, this.buttonColorPalette, this.buttonDeletemap, this.buttonSavemap, this.buttonAutomap, this.buttonDisable, this.overlayRenderButton });
/*  848 */         this.menuToolbar.addAllButtons(this);
/*  849 */         this.menuToolbar.visible = false;
/*      */         
/*  851 */         this.zoomToolbar = new ThemeToolbar(theme, new ThemeButton[] { this.buttonSearch, this.buttonFollow, this.buttonZoomIn, this.buttonZoomOut });
/*  852 */         this.zoomToolbar.setLayout(ButtonList.Layout.Vertical, ButtonList.Direction.LeftToRight);
/*  853 */         this.zoomToolbar.addAllButtons(this);
/*      */         
/*  855 */         this.searchToolBar = new ThemeToolbar(theme, new Button[] { (Button)this.searchTextX, (Button)this.searchTextZ, (Button)this.buttonExecuteSearch });
/*  856 */         this.searchToolBar.setLayout(ButtonList.Layout.CenteredHorizontal, ButtonList.Direction.LeftToRight);
/*  857 */         this.searchToolBar.addAllButtons(this);
/*      */         
/*  859 */         this.addonToolbar = CustomEventDispatcher.getInstance().getAddonToolbar(this, theme);
/*  860 */         if (this.addonToolbar != null) {
/*      */           
/*  862 */           this.addonToolbar.setLayout(ButtonList.Layout.CenteredVertical, ButtonList.Direction.LeftToRight);
/*  863 */           this.addonToolbar.addAllButtons(this);
/*      */         } 
/*      */         
/*  866 */         this.customToolbars = CustomEventDispatcher.getInstance().getCustomToolBars(this, theme);
/*      */         
/*  868 */         getRenderables().add(this.buttonAlert);
/*  869 */         getRenderables().add(this.buttonClose);
/*  870 */         getRenderables().add(this.buttonTheme);
/*      */       }
/*  872 */       catch (Throwable t) {
/*      */         
/*  874 */         Journeymap.getLogger().error("Failure to build Fullscreen Map buttons.", t);
/*      */       } 
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void layoutButtons(GuiGraphics graphics) {
/*  886 */     this.mx = (int)(this.minecraft.mouseHandler.xpos() * this.width / this.minecraft.getWindow().getScreenWidth());
/*  887 */     this.my = (int)(this.minecraft.mouseHandler.ypos() * this.height / this.minecraft.getWindow().getScreenHeight() - 1.0D);
/*      */ 
/*      */     
/*  890 */     if (this.buttonDay != null && !this.buttonDay.hasValidTextures())
/*      */     {
/*  892 */       clearWidgets();
/*      */     }
/*      */     
/*  895 */     if (getRenderables().isEmpty())
/*      */     {
/*  897 */       initButtons();
/*      */     }
/*      */     
/*  900 */     this.menuToolbar.setDrawToolbar(!isChatOpen());
/*      */ 
/*      */     
/*  903 */     MapType mapType = state.getMapType();
/*      */     
/*  905 */     this.buttonDay.setEnabled(state.isSurfaceMappingAllowed());
/*  906 */     this.buttonDay.setToggled(Boolean.valueOf((this.buttonDay.isEnabled() && mapType.isDay())));
/*      */     
/*  908 */     this.buttonNight.setEnabled(state.isSurfaceMappingAllowed());
/*  909 */     this.buttonNight.setToggled(Boolean.valueOf((this.buttonNight.isEnabled() && mapType.isNight())));
/*      */     
/*  911 */     this.buttonTopo.setEnabled(state.isTopoMappingAllowed());
/*  912 */     this.buttonTopo.setToggled(Boolean.valueOf((this.buttonTopo.isEnabled() && mapType.isTopo())));
/*      */     
/*  914 */     this.buttonBiome.setEnabled(state.isBiomeMappingAllowed());
/*  915 */     this.buttonBiome.setToggled(Boolean.valueOf((this.buttonBiome.isEnabled() && mapType.isBiome())));
/*      */     
/*  917 */     this.buttonCaves.setEnabled(state.isCaveMappingAllowed());
/*  918 */     this.buttonCaves.setToggled(Boolean.valueOf((this.buttonCaves.isEnabled() && mapType.isUnderground())));
/*      */     
/*  920 */     this.buttonFollow.setEnabled(!state.follow.get());
/*      */     
/*  922 */     boolean automapRunning = JourneymapClient.getInstance().isTaskManagerEnabled(MapRegionTask.Manager.class);
/*  923 */     boolean mappingEnabled = (JourneymapClient.getInstance().getCoreProperties()).mappingEnabled.get().booleanValue();
/*  924 */     this.buttonDisable.setToggled(Boolean.valueOf(!mappingEnabled), false);
/*      */     
/*  926 */     this.buttonAutomap.setToggled(Boolean.valueOf(automapRunning), false);
/*  927 */     this.buttonAutomap.setEnabled(mappingEnabled);
/*      */     
/*  929 */     this.buttonAutomap.setAdditionalTooltips(automapRunning ? this.autoMapOnTooltip : this.autoMapOffTooltip);
/*      */     
/*  931 */     this.buttonWaypointManager.setEnabled(WaypointsData.isManagerEnabled());
/*  932 */     this.buttonWaypointManager.setDrawButton((WaypointsData.isManagerEnabled() && !isChatOpen()));
/*      */     
/*  934 */     boolean webMapEnabled = (JourneymapClient.getInstance().getWebMap() != null && (JourneymapClient.getInstance().getWebMapProperties()).enabled.get().booleanValue());
/*  935 */     this.buttonBrowser.setEnabled((webMapEnabled && mappingEnabled));
/*  936 */     this.buttonBrowser.setDrawButton((webMapEnabled && !isChatOpen()));
/*  937 */     this.buttonTheme.setDrawButton(!isChatOpen());
/*  938 */     this.buttonTheme.setEnabled(!isChatOpen());
/*  939 */     boolean mainThreadActive = JourneymapClient.getInstance().isMainThreadTaskActive();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  946 */     this.overlayRenderButton.setVisible((System.getProperty("journeymap.map_testing") != null));
/*      */ 
/*      */     
/*  949 */     int padding = (this.mapTypeToolbar.getToolbarSpec()).padding;
/*  950 */     this.zoomToolbar.layoutCenteredVertical(this.zoomToolbar.getHMargin(), this.height / 2, true, padding);
/*      */     
/*  952 */     this.searchToolBar.layoutHorizontal(this.zoomToolbar.getRightX() + 2, this.zoomToolbar.getY() + 1, true, 7, true);
/*  953 */     this.searchTextX.setX(this.searchTextX.getX() + 3);
/*  954 */     this.searchTextZ.setX(this.searchTextZ.getX() + 2);
/*  955 */     this.buttonExecuteSearch.setDisplayClickToggle(false);
/*      */     
/*  957 */     if (this.addonToolbar != null)
/*      */     {
/*  959 */       this.addonToolbar.layoutCenteredVertical(this.width - this.addonToolbar.getWidth() - this.zoomToolbar.getHMargin(), this.height / 2, true, padding);
/*      */     }
/*      */     
/*  962 */     int topY = this.mapTypeToolbar.getVMargin();
/*      */     
/*  964 */     int margin = this.mapTypeToolbar.getHMargin();
/*      */     
/*  966 */     this.buttonClose.leftOf(this.width - this.zoomToolbar.getHMargin()).below(this.mapTypeToolbar.getVMargin());
/*  967 */     this.buttonAlert.leftOf(this.width - this.zoomToolbar.getHMargin()).below((Button)this.buttonClose, padding);
/*      */     
/*  969 */     this.buttonTheme.rightOf(6).above(this.height - 6);
/*      */     
/*  971 */     int toolbarsWidth = this.mapTypeToolbar.getWidth() + this.optionsToolbar.getWidth() + margin + padding;
/*  972 */     int startX = (this.width - toolbarsWidth) / 2;
/*      */     
/*  974 */     Rectangle2D.Double oldBounds = this.mapTypeToolbar.getBounds();
/*  975 */     this.mapTypeToolbar.layoutHorizontal(startX + this.mapTypeToolbar.getWidth(), topY, false, padding);
/*  976 */     if (!this.mapTypeToolbar.getBounds().equals(oldBounds))
/*      */     {
/*  978 */       this.mapTypeToolbarBounds = null;
/*      */     }
/*      */     
/*  981 */     oldBounds = this.optionsToolbar.getBounds();
/*  982 */     this.optionsToolbar.layoutHorizontal(this.mapTypeToolbar.getRightX() + margin, topY, true, padding);
/*  983 */     this.optionsToolbar.visible = true;
/*  984 */     if (!this.optionsToolbar.getBounds().equals(oldBounds))
/*      */     {
/*  986 */       this.optionsToolbarBounds = null;
/*      */     }
/*      */     
/*  989 */     oldBounds = this.menuToolbar.getBounds();
/*  990 */     this.menuToolbar.layoutCenteredHorizontal(this.width / 2, this.height - this.menuToolbar.getHeight() - this.menuToolbar.getVMargin(), true, padding);
/*  991 */     if (!this.menuToolbar.getBounds().equals(oldBounds))
/*      */     {
/*  993 */       this.menuToolbarBounds = null;
/*      */     }
/*      */     
/*  996 */     if (this.sliderCaveLayer.isVisible()) {
/*      */       
/*  998 */       this.sliderCaveLayer.below((Button)this.buttonLayers, 1).centerHorizontalOn(this.buttonLayers.getCenterX());
/*  999 */       int slice = this.sliderCaveLayer.getValue();
/* 1000 */       int minY = slice << 4;
/* 1001 */       int maxY = (slice + 1 << 4) - 1;
/* 1002 */       this.sliderCaveLayer.setTooltip(new String[] { Constants.getString("jm.fullscreen.map_cave_layers.button.tooltip", new Object[] { Integer.valueOf(minY), Integer.valueOf(maxY) }) });
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   @Nullable
/*      */   public Rectangle2D.Double getOptionsToolbarBounds() {
/* 1009 */     if (this.optionsToolbar != null && this.optionsToolbar.isVisible()) {
/*      */       
/* 1011 */       Rectangle2D.Double unscaled = this.optionsToolbar.getBounds();
/* 1012 */       this.optionsToolbarBounds = new Rectangle2D.Double(unscaled.x * this.scaleFactor, unscaled.y * this.scaleFactor, unscaled.width * this.scaleFactor, unscaled.height * this.scaleFactor);
/*      */     } 
/* 1014 */     return this.optionsToolbarBounds;
/*      */   }
/*      */ 
/*      */   
/*      */   @Nullable
/*      */   public Rectangle2D.Double getMenuToolbarBounds() {
/* 1020 */     if (this.menuToolbar != null && this.menuToolbar.isVisible()) {
/*      */       
/* 1022 */       Rectangle2D.Double unscaled = this.menuToolbar.getBounds();
/* 1023 */       this.menuToolbarBounds = new Rectangle2D.Double(unscaled.x * this.scaleFactor, unscaled.y * this.scaleFactor, unscaled.width * this.scaleFactor, unscaled.height * this.scaleFactor);
/*      */     } 
/* 1025 */     return this.menuToolbarBounds;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean mouseScrolled(double mouseX, double mouseY, double f, double wheel) {
/*      */     try {
/* 1034 */       if (wheel > 0.0D) {
/*      */         
/* 1036 */         zoomIn();
/*      */       }
/* 1038 */       else if (wheel < 0.0D) {
/*      */         
/* 1040 */         zoomOut();
/*      */       } 
/* 1042 */       if (!state.follow.get())
/*      */       {
/* 1044 */         BlockPos newBlockLoc = getBlockAtMouse();
/* 1045 */         moveCanvas((this.zoomBlock.getX() - newBlockLoc.getX()), (this.zoomBlock.getZ() - newBlockLoc.getZ()));
/*      */       }
/*      */     
/* 1048 */     } catch (Throwable t) {
/*      */       
/* 1050 */       Journeymap.getLogger().error(LogFormatter.toPartialString(t));
/* 1051 */       return false;
/*      */     } 
/* 1053 */     return true;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean mouseClicked(double mouseX, double mouseY, int mouseButton) {
/*      */     try {
/* 1062 */       if (this.chat != null && !this.chat.isHidden())
/*      */       {
/* 1064 */         this.chat.mouseClicked(mouseX, mouseY, mouseButton);
/*      */       }
/*      */ 
/*      */       
/* 1068 */       Point2D.Double mousePosition = new Point2D.Double(this.minecraft.mouseHandler.xpos(), this.minecraft.mouseHandler.ypos());
/*      */       
/* 1070 */       this.mx = (int)(this.minecraft.mouseHandler.xpos() * this.width / this.minecraft.getWindow().getScreenWidth());
/* 1071 */       this.my = (int)(this.minecraft.mouseHandler.ypos() * this.height / this.minecraft.getWindow().getScreenHeight() - 1.0D);
/*      */       
/* 1073 */       if (!isMouseOverButton(mouseX, mouseY)) {
/*      */         
/* 1075 */         if (FullscreenEventDispatcher.clickEventPre(getBlockAtMouse(), (Minecraft.getInstance()).level.dimension(), new Point2D.Double(mouseX, mouseY), mouseButton))
/*      */         {
/* 1077 */           return false;
/*      */         }
/* 1079 */         this.popupMenu.setClickLoc((int)mouseX, (int)mouseY);
/* 1080 */         this.layerDelegate.onMouseClicked(this.minecraft, (Renderer)mapRenderer, mousePosition, mouseButton, getMapFontScale());
/* 1081 */         FullscreenEventDispatcher.clickEventPost(getBlockAtMouse(), (Minecraft.getInstance()).level.dimension(), new Point2D.Double(mouseX, mouseY), mouseButton);
/*      */       } 
/* 1083 */       this.sliderCaveLayer.mouseClicked(mouseX, mouseY, mouseButton);
/*      */     
/*      */     }
/* 1086 */     catch (Throwable t) {
/*      */       
/* 1088 */       Journeymap.getLogger().error(LogFormatter.toPartialString(t));
/*      */     } 
/* 1090 */     this.popupMenu.resetPass();
/*      */ 
/*      */     
/* 1093 */     if (this.searchTextX.mouseOver(mouseX, mouseY) || this.searchTextZ.mouseOver(mouseX, mouseY)) {
/*      */       
/* 1095 */       boolean zClicked = this.searchTextZ.mouseClicked(mouseX, mouseY, mouseButton);
/* 1096 */       boolean xClicked = this.searchTextX.mouseClicked(mouseX, mouseY, mouseButton);
/* 1097 */       setFocused(zClicked ? (GuiEventListener)this.searchTextZ : (GuiEventListener)this.searchTextX);
/* 1098 */       return true;
/*      */     } 
/*      */ 
/*      */     
/* 1102 */     return super.mouseClicked(mouseX, mouseY, mouseButton);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void mouseMoved(double mouseX, double mouseY) {
/* 1109 */     this.zoomBlock = getBlockAtMouse();
/* 1110 */     Point2D.Double mousePosition = new Point2D.Double(this.minecraft.mouseHandler.xpos(), this.minecraft.mouseHandler.ypos());
/* 1111 */     this.layerDelegate.onMouseMove(this.minecraft, (Renderer)mapRenderer, mousePosition, getMapFontScale(), this.isDragging.booleanValue());
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean mouseDragged(double mouseX, double mouseY, int button, double mouseDX, double mouseDY) {
/* 1117 */     this.sliderCaveLayer.mouseDragged(mouseX, mouseY, button, mouseDX, mouseDY);
/* 1118 */     if (this.sliderCaveLayer.dragging || !(this.minecraft.screen instanceof Fullscreen))
/*      */     {
/* 1120 */       this.isDragging = Boolean.valueOf(false);
/*      */     }
/*      */     
/* 1123 */     long sysTime = Util.getMillis();
/* 1124 */     boolean updateGrid = (sysTime - this.lastGridUpdate > 200L);
/* 1125 */     if (button == 0 && this.isDragging.booleanValue() && updateGrid) {
/*      */       
/* 1127 */       this.lastGridUpdate = sysTime;
/* 1128 */       updateGrid();
/*      */     } 
/*      */     
/* 1131 */     if (button == 0 && !this.isDragging.booleanValue() && !isMouseOverButton(mouseX, mouseY)) {
/*      */       
/* 1133 */       Point2D.Double mousePosition = new Point2D.Double(this.minecraft.mouseHandler.xpos(), this.minecraft.mouseHandler.ypos());
/* 1134 */       if (FullscreenEventDispatcher.dragEventPre(getBlockAtMouse(), (Minecraft.getInstance()).level.dimension(), new Point2D.Double(mouseX, mouseY), button))
/*      */       {
/* 1136 */         return false;
/*      */       }
/*      */       
/* 1139 */       this.isDragging = Boolean.valueOf(!this.sliderCaveLayer.dragging);
/* 1140 */       this.mouseDragX = this.mx;
/* 1141 */       this.mouseDragY = this.my;
/* 1142 */       this.minecraft.mouseHandler.setIgnoreFirstMove();
/* 1143 */       this.layerDelegate.onMouseMove(this.minecraft, (Renderer)mapRenderer, mousePosition, getMapFontScale(), this.isDragging.booleanValue());
/*      */     } 
/*      */     
/* 1146 */     return super.mouseDragged(mouseX, mouseY, button, mouseDX, mouseDY);
/*      */   }
/*      */ 
/*      */   
/*      */   private void updateGrid() {
/* 1151 */     Point2D.Double drag = getMouseDrag();
/* 1152 */     updateGrid(-drag.getX(), -drag.getY());
/*      */   }
/*      */ 
/*      */   
/*      */   private void updateGrid(double x, double z) {
/* 1157 */     this.mouseDragX = this.mx;
/* 1158 */     this.mouseDragY = this.my;
/*      */ 
/*      */     
/*      */     try {
/* 1162 */       mapRenderer.move(x, z);
/* 1163 */       mapRenderer.updateTiles(state.getMapType(), this.fullMapProperties.zoomLevel.get().intValue(), false);
/* 1164 */       mapRenderer.setZoom(this.fullMapProperties.zoomLevel.get().intValue());
/*      */     }
/* 1166 */     catch (Exception e) {
/*      */       
/* 1168 */       this.logger.error("Error moving grid: " + String.valueOf(e));
/*      */     } 
/*      */     
/* 1171 */     setFollow(Boolean.valueOf(false));
/* 1172 */     refreshState();
/*      */   }
/*      */ 
/*      */   
/*      */   private Point2D.Double getMouseDrag() {
/* 1177 */     double blockSize = (uiState()).blockSize;
/* 1178 */     int dragScale = this.fullMapProperties.dragScale.get().intValue();
/* 1179 */     double mouseDragX = (this.mx - this.mouseDragX) * this.scaleFactor / blockSize / dragScale;
/* 1180 */     double mouseDragY = (this.my - this.mouseDragY) * this.scaleFactor / blockSize / dragScale;
/* 1181 */     return new Point2D.Double(mouseDragX, mouseDragY);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean mouseReleased(double mouseX, double mouseY, int button) {
/*      */     try {
/* 1189 */       Point2D.Double mousePosition = new Point2D.Double(this.minecraft.mouseHandler.xpos(), this.minecraft.mouseHandler.ypos());
/* 1190 */       super.mouseReleased(mouseX, mouseY, button);
/* 1191 */       if (this.sliderCaveLayer.isVisible() && this.sliderCaveLayer.dragging) {
/*      */         
/* 1193 */         this.sliderCaveLayer.mouseReleased(mouseX, mouseY, button);
/* 1194 */         this.isDragging = Boolean.valueOf(false);
/* 1195 */         return true;
/*      */       } 
/*      */       
/* 1198 */       if (this.isDragging.booleanValue()) {
/*      */         
/* 1200 */         this.isDragging = Boolean.valueOf(false);
/* 1201 */         updateGrid();
/*      */         
/* 1203 */         FullscreenEventDispatcher.dragEventPost(getBlockAtMouse(), (Minecraft.getInstance()).level.dimension(), new Point2D.Double(mouseX, mouseY), button);
/*      */       } 
/*      */       
/* 1206 */       this.layerDelegate.onMouseMove(this.minecraft, (Renderer)mapRenderer, mousePosition, getMapFontScale(), this.isDragging.booleanValue());
/* 1207 */       return true;
/*      */     }
/* 1209 */     catch (Throwable t) {
/*      */       
/* 1211 */       Journeymap.getLogger().error(LogFormatter.toPartialString(t));
/* 1212 */       return false;
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   public void toggleMapType() {
/* 1218 */     updateMapType(state.toggleMapType());
/*      */   }
/*      */ 
/*      */   
/*      */   public void updateMapType(Context.MapType mapType, Integer vSlice, ResourceKey<Level> dimension) {
/* 1223 */     updateMapType(MapType.fromApiContextMapType(mapType, vSlice, dimension));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void updateMapType(MapType newType) {
/* 1233 */     if (!newType.isAllowed())
/*      */     {
/* 1235 */       newType = state.getMapType();
/*      */     }
/*      */     
/* 1238 */     state.setMapType(newType);
/* 1239 */     this.buttonDay.setToggled(Boolean.valueOf(newType.isDay()), false);
/* 1240 */     this.buttonNight.setToggled(Boolean.valueOf(newType.isNight()), false);
/* 1241 */     this.buttonBiome.setToggled(Boolean.valueOf(newType.isBiome()), false);
/* 1242 */     this.buttonTopo.setToggled(Boolean.valueOf(newType.isTopo()), false);
/* 1243 */     if (newType.isUnderground())
/*      */     {
/* 1245 */       this.sliderCaveLayer.setValue(newType.vSlice.intValue());
/*      */     }
/* 1247 */     mapRenderer.clear();
/* 1248 */     state.requireRefresh();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void zoomIn() {
/* 1256 */     Objects.requireNonNull(state); if (this.fullMapProperties.zoomLevel.get().intValue() < 16384) {
/*      */       
/* 1258 */       Integer currentZoom = this.fullMapProperties.zoomLevel.get();
/*      */       
/* 1260 */       setZoom(currentZoom.intValue() * 2);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void zoomOut() {
/* 1269 */     if (this.fullMapProperties.zoomLevel.get().intValue() > state.minZoom) {
/*      */       
/* 1271 */       Integer currentZoom = this.fullMapProperties.zoomLevel.get();
/*      */       
/* 1273 */       setZoom(currentZoom.intValue() / 2);
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   private void setZoom(int zoom) {
/* 1279 */     if (state.setZoom(zoom)) {
/*      */       
/* 1281 */       mapRenderer.setZoom(zoom);
/* 1282 */       this.buttonZoomOut.setEnabled((this.fullMapProperties.zoomLevel.get().intValue() > state.minZoom));
/* 1283 */       Objects.requireNonNull(state); this.buttonZoomIn.setEnabled((this.fullMapProperties.zoomLevel.get().intValue() < 16384));
/* 1284 */       refreshState();
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void toggleSearchBar(boolean toggled) {
/* 1293 */     this.searchToolBar.setEnabled(toggled);
/* 1294 */     this.searchToolBar.setVisible(toggled);
/* 1295 */     this.buttonSearch.setToggled(Boolean.valueOf(toggled));
/* 1296 */     this.searchTextZ.setVisible(toggled);
/* 1297 */     this.searchTextX.setVisible(toggled);
/* 1298 */     this.buttonExecuteSearch.setVisible(toggled);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   void executeSearch() {
/* 1304 */     this.buttonExecuteSearch.setToggled(Boolean.valueOf(true), false);
/*      */ 
/*      */     
/*      */     try {
/* 1308 */       int x = Integer.parseInt(this.searchTextX.getText().toLowerCase(Locale.ROOT).replace("x:", ""));
/* 1309 */       int z = Integer.parseInt(this.searchTextZ.getText().toLowerCase(Locale.ROOT).replace("z:", ""));
/* 1310 */       centerOn(x, z);
/*      */     }
/* 1312 */     catch (Exception exception) {}
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void toggleFollow() {
/* 1323 */     boolean isFollow = !state.follow.get();
/* 1324 */     setFollow(Boolean.valueOf(isFollow));
/* 1325 */     if (isFollow)
/*      */     {
/* 1327 */       if (this.minecraft.player != null) {
/*      */         
/* 1329 */         this.sliderCaveLayer.setValue(this.minecraft.player.getBlockY() >> 4);
/* 1330 */         if (state.getMapType().isUnderground())
/*      */         {
/* 1332 */           this.sliderCaveLayer.checkClickListeners();
/*      */         }
/*      */       } 
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setFollow(Boolean follow) {
/* 1345 */     state.follow.set(follow.booleanValue());
/* 1346 */     if (follow.booleanValue()) {
/*      */       
/* 1348 */       state.resetMapType();
/* 1349 */       refreshState();
/*      */     } 
/* 1351 */     ClientAPI.INSTANCE.flagOverlaysForRerender();
/*      */   }
/*      */ 
/*      */   
/*      */   public BlockPos getBlockAtMouse() {
/* 1356 */     Point2D.Double mousePosition = new Point2D.Double(this.minecraft.mouseHandler.xpos(), this.minecraft.mouseHandler.ypos());
/* 1357 */     return this.layerDelegate.getBlockPos(this.minecraft, (Renderer)mapRenderer, mousePosition);
/*      */   }
/*      */ 
/*      */   
/*      */   public void createWaypointAtMouse() {
/* 1362 */     ClientWaypointImpl holder = WaypointFactoryImpl.at(getBlockAtMouse(), false, this.minecraft.player.getCommandSenderWorld().dimension().location().toString());
/* 1363 */     UIManager.INSTANCE.openWaypointEditor(holder, true, true, (Screen)this);
/*      */   }
/*      */ 
/*      */   
/*      */   public void chatPositionAtMouse() {
/* 1368 */     ClientWaypointImpl holder = WaypointFactoryImpl.at(getBlockAtMouse(), false, state.getDimension().location().toString());
/* 1369 */     this.chatOpenedFromEvent = true;
/* 1370 */     openChat(holder.toChatString());
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean isChatOpen() {
/* 1375 */     return (this.chat != null && !this.chat.isHidden());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean keyPressed(int key, int value, int modifier) {
/* 1382 */     switch (key) {
/*      */ 
/*      */       
/*      */       case 256:
/* 1386 */         if (isChatOpen()) {
/*      */           
/* 1388 */           this.chat.close();
/*      */         }
/*      */         else {
/*      */           
/* 1392 */           UIManager.INSTANCE.closeAll();
/*      */         } 
/*      */         
/* 1395 */         return true;
/*      */     } 
/*      */     
/* 1398 */     long windowId = Minecraft.getInstance().getWindow().getWindow();
/* 1399 */     if (this.minecraft.options.keyChat.matches(key, value) && !isChatOpen() && !InputConstants.isKeyDown(windowId, 292)) {
/*      */       
/* 1401 */       this.chatOpenedFromEvent = true;
/* 1402 */       openChat("");
/* 1403 */       return true;
/*      */     } 
/* 1405 */     if (this.minecraft.options.keyCommand.matches(key, value) && !isChatOpen() && !InputConstants.isKeyDown(windowId, 292)) {
/*      */       
/* 1407 */       this.chatOpenedFromEvent = true;
/* 1408 */       openChat("/");
/* 1409 */       return true;
/*      */     } 
/* 1411 */     if (isChatOpen())
/*      */     {
/* 1413 */       this.chat.keyPressed(key, value, modifier);
/*      */     }
/* 1415 */     return super.keyPressed(key, value, modifier);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean charTyped(char typedChar, int keyCode) {
/* 1429 */     if (isChatOpen() && this.chatOpenedFromEvent) {
/*      */       
/* 1431 */       this.chatOpenedFromEvent = false;
/* 1432 */       return false;
/*      */     } 
/*      */     
/* 1435 */     if (this.searchTextX != null && this.searchTextZ != null) {
/*      */       
/* 1437 */       if (this.searchTextX.isHoveredOrFocused() && !isChatOpen())
/*      */       {
/* 1439 */         return this.searchTextX.charTyped(typedChar, keyCode);
/*      */       }
/* 1441 */       if (this.searchTextZ.isHoveredOrFocused() && !isChatOpen())
/*      */       {
/* 1443 */         return this.searchTextZ.charTyped(typedChar, keyCode);
/*      */       }
/* 1445 */       return this.chat.charTyped(typedChar, keyCode);
/*      */     } 
/* 1447 */     return super.charTyped(typedChar, keyCode);
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean isSearchFocused() {
/* 1452 */     return (this.searchTextX.isHoveredOrFocused() || this.searchTextZ.isHoveredOrFocused());
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void tick() {
/* 1458 */     super.tick();
/* 1459 */     if (this.chat != null)
/*      */     {
/* 1461 */       this.chat.tick();
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void renderBackground(GuiGraphics graphics, int i, int j, float f) {
/* 1468 */     DrawUtil.drawRectangle(graphics, 0.0D, 0.0D, this.width, this.height, this.bgColor, 1.0F);
/* 1469 */     DrawUtil.drawRectangle(graphics, 0.0D, 0.0D, this.width, this.height, 2236962, 0.8F);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void drawMap(GuiGraphics graphics, MultiBufferSource.BufferSource buffers, int mouseX, int mouseY) {
/* 1477 */     boolean refreshReady = isRefreshReady();
/* 1478 */     StatTimer timer = refreshReady ? this.drawMapTimerWithRefresh : this.drawMapTimer;
/* 1479 */     MapType mapType = state.getMapType();
/* 1480 */     timer.start();
/*      */ 
/*      */     
/*      */     try {
/* 1484 */       sizeDisplay(false);
/*      */       
/* 1486 */       double xOffset = 0.0D;
/* 1487 */       double yOffset = 0.0D;
/*      */       
/* 1489 */       if (this.isDragging.booleanValue()) {
/*      */         
/* 1491 */         Point2D.Double drag = getMouseDrag();
/* 1492 */         double blockSize = (uiState()).blockSize;
/*      */         
/* 1494 */         double mouseDragX = drag.getX();
/* 1495 */         double mouseDragY = drag.getY();
/*      */         
/* 1497 */         xOffset = mouseDragX * blockSize;
/* 1498 */         yOffset = mouseDragY * blockSize;
/*      */ 
/*      */ 
/*      */       
/*      */       }
/* 1503 */       else if (refreshReady) {
/*      */         
/* 1505 */         refreshState();
/*      */       }
/*      */       else {
/*      */         
/* 1509 */         mapRenderer.setContext(state);
/*      */       } 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1515 */       mapRenderer.clearGlErrors(false);
/* 1516 */       mapRenderer.updateRotation(graphics, 0.0D);
/* 1517 */       Vec3 playerCamera = this.minecraft.gameRenderer.getMainCamera().getPosition();
/* 1518 */       if (state.follow.get()) {
/*      */         
/* 1520 */         mapRenderer.center(state.getWorldDir(), mapType, playerCamera.x(), playerCamera.z(), this.fullMapProperties.zoomLevel.get().intValue());
/* 1521 */         ClientAPI.INSTANCE.flagOverlaysForRerender();
/*      */       } 
/* 1523 */       mapRenderer.updateTiles(state.getMapType(), this.fullMapProperties.zoomLevel.get().intValue(), false);
/* 1524 */       mapRenderer.render(graphics, buffers, xOffset, yOffset, 0.8F, this.fullMapProperties.showGrid.get().booleanValue());
/* 1525 */       mapRenderer.draw(graphics, buffers, state.getDrawSteps(), this, (int)(mouseX + xOffset), (int)(mouseY + yOffset), xOffset, yOffset, getMapFontScale(), 0.0D);
/* 1526 */       mapRenderer.draw(graphics, buffers, state.getDrawWaypointSteps(), xOffset, yOffset, getMapFontScale(), 0.0D);
/*      */       
/* 1528 */       if (this.fullMapProperties.showSelf.get().booleanValue()) {
/*      */         
/* 1530 */         Point2D playerPixel = mapRenderer.getPixel(playerCamera.x(), playerCamera.z());
/*      */         
/* 1532 */         if (playerPixel != null) {
/*      */           
/* 1534 */           float scale = this.fullMapProperties.selfDisplayScale.get().floatValue();
/*      */           
/* 1536 */           graphics.pose().translate(0.0F, 0.0F, 1000.0F);
/*      */           
/* 1538 */           Texture bgTex = TextureCache.getTexture(TextureCache.PlayerArrowBG);
/* 1539 */           RenderType renderType = JMRenderTypes.getIcon(bgTex);
/* 1540 */           VertexConsumer vertexBuilder = buffers.getBuffer(renderType);
/* 1541 */           DrawUtil.drawColoredEntity(graphics.pose(), vertexBuilder, bgTex, 16777215, 1.0F, playerPixel.getX() + xOffset, playerPixel.getY() + yOffset, scale / 5.0F, -this.minecraft.gameRenderer.getMainCamera().getYRot());
/*      */ 
/*      */           
/* 1544 */           int playerColor = this.coreProperties.getColor(this.coreProperties.colorSelf);
/* 1545 */           Texture fgTex = TextureCache.getTexture(TextureCache.PlayerArrow);
/* 1546 */           RenderType renderType1 = JMRenderTypes.getIcon(fgTex);
/* 1547 */           VertexConsumer vertexConsumer1 = buffers.getBuffer(renderType1);
/* 1548 */           DrawUtil.drawColoredEntity(graphics.pose(), vertexConsumer1, fgTex, playerColor, 1.0F, playerPixel.getX() + xOffset, playerPixel.getY() + yOffset, scale / 5.0F, -this.minecraft.gameRenderer.getMainCamera().getYRot());
/*      */ 
/*      */           
/* 1551 */           graphics.pose().translate(0.0F, 0.0F, -1000.0F);
/*      */         } 
/*      */       } 
/*      */       
/* 1555 */       mapRenderer.draw(graphics, buffers, this.layerDelegate.getDrawSteps(), xOffset, yOffset, getMapFontScale(), 0.0D);
/* 1556 */       sizeDisplay(true);
/*      */     }
/* 1558 */     catch (Throwable t) {
/*      */       
/* 1560 */       t.printStackTrace();
/* 1561 */       Journeymap.getLogger().error("Error drawing something on the fullscreen map.", t);
/*      */     }
/*      */     finally {
/*      */       
/* 1565 */       timer.stop();
/*      */ 
/*      */       
/* 1568 */       mapRenderer.clearGlErrors(true);
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   private float getMapFontScale() {
/* 1574 */     return this.fullMapProperties.fontScale.get().floatValue();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void centerOn(ClientWaypointImpl holder) {
/* 1584 */     if (holder.isInPlayerDimension()) {
/*      */       
/* 1586 */       if (!holder.isPersistent())
/*      */       {
/* 1588 */         addTempMarker(holder);
/*      */       }
/* 1590 */       centerOn(holder.getX(), holder.getZ());
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void centerOn(double x, double z) {
/* 1602 */     state.follow.set(false);
/* 1603 */     state.requireRefresh();
/* 1604 */     mapRenderer.center(state.getWorldDir(), state.getMapType(), x, z, this.fullMapProperties.zoomLevel.get().intValue());
/* 1605 */     refreshState();
/* 1606 */     tick();
/* 1607 */     ClientAPI.INSTANCE.flagOverlaysForRerender();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void addTempMarker(ClientWaypointImpl waypoint) {
/*      */     try {
/* 1619 */       BlockPos pos = waypoint.getBlockPos();
/*      */ 
/*      */ 
/*      */       
/* 1623 */       PolygonOverlay polygonOverlay = new PolygonOverlay("journeymap", this.minecraft.player.getCommandSenderWorld().dimension(), (new ShapeProperties()).setStrokeColor(255).setStrokeOpacity(1.0F).setStrokeWidth(1.5F), new MapPolygon(new BlockPos[] { pos.offset(-1, 0, 2), pos.offset(2, 0, 2), pos.offset(2, 0, -1), pos.offset(-1, 0, -1) }));
/*      */       
/* 1625 */       polygonOverlay.setActiveMapTypes(Context.MapType.all());
/* 1626 */       polygonOverlay.setActiveUIs(new Context.UI[] { Context.UI.Fullscreen });
/* 1627 */       polygonOverlay.setLabel(waypoint.getName());
/* 1628 */       this.tempOverlays.add(polygonOverlay);
/* 1629 */       ClientAPI.INSTANCE.show((Displayable)polygonOverlay);
/*      */     }
/* 1631 */     catch (Throwable t) {
/*      */       
/* 1633 */       Journeymap.getLogger().error("Error showing temp location marker: " + LogFormatter.toPartialString(t));
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void refreshState() {
/* 1643 */     LocalPlayer localPlayer = this.minecraft.player;
/* 1644 */     if (localPlayer == null) {
/*      */       
/* 1646 */       this.logger.warn("Could not get player");
/*      */       
/*      */       return;
/*      */     } 
/* 1650 */     StatTimer timer = StatTimer.get("Fullscreen.refreshState");
/* 1651 */     timer.start();
/*      */ 
/*      */ 
/*      */     
/*      */     try {
/* 1656 */       this.menuToolbarBounds = null;
/* 1657 */       this.optionsToolbarBounds = null;
/*      */ 
/*      */       
/* 1660 */       this.fullMapProperties = JourneymapClient.getInstance().getFullMapProperties();
/* 1661 */       state.refresh(this.minecraft, (Player)localPlayer, (InGameMapProperties)this.fullMapProperties);
/* 1662 */       MapType mapType = state.getMapType();
/*      */       
/* 1664 */       mapRenderer.setContext(state);
/*      */       
/* 1666 */       if (state.follow.get()) {
/*      */         
/* 1668 */         mapRenderer.center(state.getWorldDir(), mapType, this.minecraft.player.getX(), this.minecraft.player.getZ(), this.fullMapProperties.zoomLevel.get().intValue());
/*      */       }
/*      */       else {
/*      */         
/* 1672 */         mapRenderer.setZoom(this.fullMapProperties.zoomLevel.get().intValue());
/*      */       } 
/*      */ 
/*      */       
/* 1676 */       mapRenderer.updateTiles(state.getMapType(), this.fullMapProperties.zoomLevel.get().intValue(), true);
/* 1677 */       mapRenderer.updateUIState(true);
/*      */       
/* 1679 */       state.generateDrawSteps(this.minecraft, (Renderer)mapRenderer, this.waypointRenderer, this.radarRenderer, (InGameMapProperties)this.fullMapProperties, false);
/*      */ 
/*      */       
/* 1682 */       LocationFormat.LocationFormatKeys locationFormatKeys = this.locationFormat.getFormatKeys(this.fullMapProperties.locationFormat.get());
/* 1683 */       state
/*      */ 
/*      */ 
/*      */         
/* 1687 */         .playerLastPos = locationFormatKeys.format(this.fullMapProperties.locationFormatVerbose.get().booleanValue(), Mth.floor(this.minecraft.player.getX()), Mth.floor(this.minecraft.player.getZ()), Mth.floor((this.minecraft.player.getBoundingBox()).minY), this.minecraft.player.getBlockY() >> 4) + " " + locationFormatKeys.format(this.fullMapProperties.locationFormatVerbose.get().booleanValue(), Mth.floor(this.minecraft.player.getX()), Mth.floor(this.minecraft.player.getZ()), Mth.floor((this.minecraft.player.getBoundingBox()).minY), this.minecraft.player.getBlockY() >> 4);
/*      */ 
/*      */       
/* 1690 */       state.updateLastRefresh();
/*      */     }
/*      */     finally {
/*      */       
/* 1694 */       timer.stop();
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void openChat(String defaultText) {
/* 1705 */     if (this.chat != null) {
/*      */       
/* 1707 */       this.chat.setText(defaultText);
/* 1708 */       this.chat.setHidden(false);
/*      */     }
/*      */     else {
/*      */       
/* 1712 */       this.chat = new MapChat(defaultText, false);
/* 1713 */       this.chat.resize(this.minecraft, this.width, this.height);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void close() {
/* 1720 */     for (Overlay temp : this.tempOverlays)
/*      */     {
/* 1722 */       ClientAPI.INSTANCE.remove((Displayable)temp);
/*      */     }
/* 1724 */     mapRenderer.updateUIState(false);
/* 1725 */     if (this.chat != null)
/*      */     {
/* 1727 */       this.chat.close();
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void removed() {}
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   boolean isRefreshReady() {
/* 1744 */     if (this.isDragging.booleanValue())
/*      */     {
/* 1746 */       return false;
/*      */     }
/*      */ 
/*      */     
/* 1750 */     return (state.shouldRefresh(getMinecraft(), (MapProperties)this.fullMapProperties) || mapRenderer.hasUnloadedTile());
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public double getScreenScaleFactor() {
/* 1756 */     return this.scaleFactor;
/*      */   }
/*      */ 
/*      */   
/*      */   public int getZoom() {
/* 1761 */     return mapRenderer.getZoom();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void moveCanvas(double deltaBlockX, double deltaBlockZ) {
/* 1772 */     refreshState();
/* 1773 */     mapRenderer.move(deltaBlockX, deltaBlockZ);
/* 1774 */     mapRenderer.updateTiles(state.getMapType(), this.fullMapProperties.zoomLevel.get().intValue(), true);
/* 1775 */     ClientAPI.INSTANCE.flagOverlaysForRerender();
/*      */     
/* 1777 */     setFollow(Boolean.valueOf(false));
/*      */   }
/*      */ 
/*      */   
/*      */   public void showCaveLayers() {
/* 1782 */     if (!state.isUnderground())
/*      */     {
/* 1784 */       updateMapType(MapType.underground(Integer.valueOf(3), state.getDimension()));
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   protected void drawLogo(GuiGraphics graphics) {
/* 1791 */     if (!this.logo.hasImage())
/*      */     {
/* 1793 */       this.logo = TextureCache.getTexture(TextureCache.Logo);
/*      */     }
/* 1795 */     DrawUtil.sizeDisplay(this.minecraft.getWindow().getScreenWidth(), this.minecraft.getWindow().getScreenHeight());
/* 1796 */     Theme.Container.Toolbar toolbar = (ThemeLoader.getCurrentTheme()).container.toolbar;
/* 1797 */     double scale = this.scaleFactor * 2.0D;
/*      */     
/* 1799 */     DrawUtil.sizeDisplay(this.width, this.height);
/* 1800 */     DrawUtil.drawImage(graphics.pose(), this.logo, toolbar.horizontal.margin, toolbar.vertical.margin, false, (float)(1.0D / scale), 0.0D);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public final boolean isPauseScreen() {
/* 1806 */     return false;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setTheme(String name) {
/*      */     try {
/* 1819 */       MiniMapProperties mmp = JourneymapClient.getInstance().getMiniMapProperties(JourneymapClient.getInstance().getActiveMinimapId());
/* 1820 */       mmp.shape.set((Enum)Shape.Rectangle);
/* 1821 */       mmp.sizePercent.set(Integer.valueOf(20));
/* 1822 */       mmp.save();
/* 1823 */       Theme theme = ThemeLoader.getThemeByName(name);
/* 1824 */       ThemeLoader.setCurrentTheme(theme);
/* 1825 */       UIManager.INSTANCE.getMiniMap().reset();
/* 1826 */       ChatLog.announceI18N("jm.common.ui_theme_applied", new Object[0]);
/* 1827 */       UIManager.INSTANCE.closeAll();
/*      */     }
/* 1829 */     catch (Exception e) {
/*      */       
/* 1831 */       Journeymap.getLogger().error("Could not load Theme: " + LogFormatter.toString(e));
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   public void addButtonWidget(Button button) {
/* 1837 */     addRenderableWidget((GuiEventListener)button);
/*      */   }
/*      */ 
/*      */   
/*      */   public MapType getMapType() {
/* 1842 */     return mapRenderer.getMapType();
/*      */   }
/*      */ 
/*      */   
/*      */   public void hideButtons() {
/* 1847 */     buttonsVisible = !buttonsVisible;
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean isButtonsVisable() {
/* 1852 */     return buttonsVisible;
/*      */   }
/*      */ 
/*      */   
/*      */   public void toggleEntityNames() {
/* 1857 */     this.fullMapProperties.showEntityNames.toggle();
/*      */   }
/*      */ }


/* Location:              C:\Users\Administrator\Downloads\journeymap-neoforge-1.21-6.0.0-beta.18.jar!\journeymap\clien\\ui\fullscreen\Fullscreen.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */