/*    */ package journeymap.client.ui.component.popupscreenbutton;
/*    */ 
/*    */ import java.util.function.Supplier;
/*    */ import journeymap.client.ui.component.buttons.Button;
/*    */ import net.minecraft.client.gui.components.Button;
/*    */ 
/*    */ public class PopupButton<T>
/*    */   extends Button
/*    */ {
/*    */   public PopupButton(int width, int height, String title, Supplier<PopupButtonScreen<T>> screen, PopupButtonScreen.OnClose<T> onClose) {
/* 11 */     super(width, height, title, b -> {
/*    */           PopupButtonScreen<T> s = screen.get();
/*    */           s.display();
/*    */           s.setOnClosed(onClose);
/*    */         });
/*    */   }
/*    */ }


/* Location:              C:\Users\Administrator\Downloads\journeymap-neoforge-1.21-6.0.0-beta.18.jar!\journeymap\clien\\ui\component\popupscreenbutton\PopupButton.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */