/*    */ package journeymap.client.ui.component.popupscreenbutton.simple;
/*    */ import journeymap.client.ui.component.buttons.Button;
/*    */ import net.minecraft.client.gui.GuiGraphics;
/*    */ import net.minecraft.client.gui.components.AbstractWidget;
/*    */ import net.minecraft.client.gui.components.Button;
/*    */ import net.minecraft.client.gui.components.events.GuiEventListener;
/*    */ import net.minecraft.client.gui.layouts.FrameLayout;
/*    */ import net.minecraft.client.gui.layouts.LayoutElement;
/*    */ import net.minecraft.client.gui.layouts.LinearLayout;
/*    */ import net.minecraft.network.chat.Component;
/*    */ import net.minecraft.network.chat.FormattedText;
/*    */ import net.minecraft.resources.ResourceLocation;
/*    */ 
/*    */ public class ConfirmationPopup extends PopupButtonScreen<Boolean> {
/* 15 */   private static final ResourceLocation BACKGROUND_SPRITE = ResourceLocation.parse("popup/background");
/*    */   
/* 17 */   private final LinearLayout layout = LinearLayout.vertical();
/*    */   
/*    */   private final Component confirm;
/*    */   private final Component cancel;
/*    */   
/*    */   public ConfirmationPopup(String messageKey, String confirmKey, String cancelKey) {
/* 23 */     super((Component)Component.translatable(messageKey));
/* 24 */     this.confirm = (Component)Component.translatable(confirmKey);
/* 25 */     this.cancel = (Component)Component.translatable(cancelKey);
/* 26 */     this.response = Boolean.valueOf(false);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public void init() {
/* 32 */     this.layout.spacing(12).defaultCellSetting().alignHorizontallyCenter();
/* 33 */     this.layout.addChild((LayoutElement)(new MultiLineTextWidget((Component)this.title.copy().withStyle(ChatFormatting.BOLD), this.font)).setMaxWidth(150).setCentered(true));
/*    */     
/* 35 */     LinearLayout bottomButtons = LinearLayout.horizontal();
/* 36 */     bottomButtons.spacing(12);
/* 37 */     bottomButtons.addChild((LayoutElement)Button.builder(this.confirm, b -> setResponseAndClose(Boolean.valueOf(true))).width(this.font.width((FormattedText)this.confirm) + 10).build());
/* 38 */     bottomButtons.addChild((LayoutElement)Button.builder(this.cancel, b -> setResponseAndClose(Boolean.valueOf(false))).width(this.font.width((FormattedText)this.cancel) + 10).build());
/* 39 */     this.layout.addChild((LayoutElement)bottomButtons);
/*    */     
/* 41 */     this.layout.visitWidgets(x$0 -> (AbstractWidget)rec$.addRenderableWidget(x$0));
/* 42 */     repositionElements();
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public void renderPopupScreenBackground(GuiGraphics graphics, int mouseX, int mouseY, float partialTick) {
/* 48 */     renderTransparentBackground(graphics);
/* 49 */     graphics.blitSprite(BACKGROUND_SPRITE, this.layout.getX() - 18, this.layout.getY() - 18, this.layout.getWidth() + 36, this.layout.getHeight() + 36);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   protected void repositionElements() {
/* 55 */     this.layout.arrangeElements();
/* 56 */     FrameLayout.centerInRectangle((LayoutElement)this.layout, getRectangle());
/*    */   }
/*    */ }


/* Location:              C:\Users\Administrator\Downloads\journeymap-neoforge-1.21-6.0.0-beta.18.jar!\journeymap\clien\\ui\component\popupscreenbutton\simple\ConfirmationPopup.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */