/*    */ package journeymap.client.ui.component.popupscreenbutton.colorpicker;
/*    */ 
/*    */ import java.util.function.BooleanSupplier;
/*    */ import java.util.function.IntSupplier;
/*    */ import journeymap.client.Constants;
/*    */ import journeymap.client.render.draw.DrawUtil;
/*    */ import journeymap.client.texture.Texture;
/*    */ import journeymap.client.texture.TextureCache;
/*    */ import journeymap.client.ui.component.popupscreenbutton.PopupButton;
/*    */ import journeymap.client.ui.component.popupscreenbutton.PopupButtonScreen;
/*    */ import net.minecraft.client.gui.GuiGraphics;
/*    */ import net.minecraft.network.chat.Component;
/*    */ 
/*    */ public class ColorPickerButton
/*    */   extends PopupButton<ColorPickerScreen.ColorPickerResponse> {
/* 16 */   final Texture colorWheel = TextureCache.getTexture(TextureCache.ColorWheel);
/*    */ 
/*    */   
/*    */   public ColorPickerButton(int width, int height, IntSupplier color, PopupButtonScreen.OnClose<ColorPickerScreen.ColorPickerResponse> onClose) {
/* 20 */     this(width, height, color, () -> false, onClose);
/*    */   }
/*    */ 
/*    */   
/*    */   public ColorPickerButton(int width, int height, IntSupplier color, BooleanSupplier withAlpha, PopupButtonScreen.OnClose<ColorPickerScreen.ColorPickerResponse> onClose) {
/* 25 */     super(width, height, "", () -> new ColorPickerScreen((Component)Constants.getTranslatedTextComponent(""), Integer.valueOf(color.getAsInt()), withAlpha.getAsBoolean()), onClose);
/* 26 */     init();
/*    */   }
/*    */ 
/*    */   
/*    */   void init() {
/* 31 */     setTooltip(new String[] { Constants.getString("jm.common.button.colorwheel.tooltip") });
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public void renderWidget(GuiGraphics graphics, int mouseX, int mouseY, float partialTicks) {
/* 37 */     super.renderWidget(graphics, mouseX, mouseY, partialTicks);
/* 38 */     DrawUtil.drawQuad(graphics.pose(), this.colorWheel, (getX() + 1), (getY() + 1), (getWidth() - 2), (getHeight() - 2), false, 0.0D);
/*    */   }
/*    */ }


/* Location:              C:\Users\Administrator\Downloads\journeymap-neoforge-1.21-6.0.0-beta.18.jar!\journeymap\clien\\ui\component\popupscreenbutton\colorpicker\ColorPickerButton.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */