package journeymap.client.ui.component.popupscreenbutton;

@FunctionalInterface
public interface OnClose<T> {
  void closed(T paramT);
}


/* Location:              C:\Users\Administrator\Downloads\journeymap-neoforge-1.21-6.0.0-beta.18.jar!\journeymap\clien\\ui\component\popupscreenbutton\PopupButtonScreen$OnClose.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */