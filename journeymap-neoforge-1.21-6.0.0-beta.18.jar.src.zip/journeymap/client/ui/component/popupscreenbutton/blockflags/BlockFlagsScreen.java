/*     */ package journeymap.client.ui.component.popupscreenbutton.blockflags;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.EnumSet;
/*     */ import java.util.List;
/*     */ import journeymap.client.Constants;
/*     */ import journeymap.client.model.BlockFlag;
/*     */ import journeymap.client.ui.component.buttons.Button;
/*     */ import journeymap.client.ui.component.buttons.CheckBox;
/*     */ import journeymap.client.ui.component.popupscreenbutton.PopupButtonScreen;
/*     */ import net.minecraft.client.gui.GuiGraphics;
/*     */ import net.minecraft.client.gui.components.AbstractWidget;
/*     */ import net.minecraft.client.gui.components.Button;
/*     */ import net.minecraft.client.gui.components.events.GuiEventListener;
/*     */ import net.minecraft.client.gui.layouts.FrameLayout;
/*     */ import net.minecraft.client.gui.layouts.LayoutElement;
/*     */ import net.minecraft.client.gui.layouts.LinearLayout;
/*     */ import net.minecraft.network.chat.Component;
/*     */ import net.minecraft.network.chat.FormattedText;
/*     */ import net.minecraft.resources.ResourceLocation;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class BlockFlagsScreen
/*     */   extends PopupButtonScreen<BlockFlagsScreen.BlockFlagsResponse>
/*     */ {
/*  33 */   private static final ResourceLocation BACKGROUND_SPRITE = ResourceLocation.parse("popup/background");
/*     */   
/*  35 */   private final LinearLayout layout = LinearLayout.vertical();
/*     */   
/*  37 */   private final List<BlockFlag> validFlags = List.of(new BlockFlag[] { BlockFlag.Ignore, BlockFlag.Foliage, BlockFlag.Grass, BlockFlag.Water, BlockFlag.Fluid, BlockFlag.OpenToSky, BlockFlag.NoShadow, BlockFlag.Transparency, BlockFlag.Plant, BlockFlag.Crop, BlockFlag.NoTopo, BlockFlag.Force });
/*  38 */   private final Component labelSubmit = (Component)Component.translatable("jm.common.submit");
/*  39 */   private final Component labelReset = (Component)Component.translatable("jm.common.reset");
/*  40 */   private final Component labelCancel = (Component)Component.translatable("jm.common.cancel");
/*     */   
/*  42 */   private final List<CheckBox> checkFlags = new ArrayList<>();
/*     */   
/*     */   private final EnumSet<BlockFlag> originalFlags;
/*     */   
/*     */   private EnumSet<BlockFlag> currentFlags;
/*     */ 
/*     */   
/*     */   protected BlockFlagsScreen(EnumSet<BlockFlag> flags) {
/*  50 */     super((Component)Component.empty());
/*  51 */     this.response = new BlockFlagsResponse(flags, true);
/*     */     
/*  53 */     this.originalFlags = flags.clone();
/*  54 */     this.currentFlags = flags.clone();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void init() {
/*  60 */     this.layout.spacing(12).defaultCellSetting().alignHorizontallyCenter();
/*     */     
/*  62 */     LinearLayout columnsLayout = LinearLayout.horizontal();
/*  63 */     columnsLayout.spacing(24).defaultCellSetting().alignVerticallyTop();
/*  64 */     LinearLayout leftColumnLayout = LinearLayout.vertical();
/*  65 */     leftColumnLayout.spacing(12).defaultCellSetting().alignHorizontallyLeft();
/*  66 */     LinearLayout rightColumnLayout = LinearLayout.vertical();
/*  67 */     rightColumnLayout.spacing(12).defaultCellSetting().alignHorizontallyLeft();
/*     */     
/*  69 */     int count = 0;
/*  70 */     for (BlockFlag flag : this.validFlags) {
/*     */       
/*  72 */       CheckBox check = new CheckBox(Constants.getTranslatedTextComponent(flag.getKey()).getString(), this.currentFlags.contains(flag), this::checkToggled);
/*  73 */       this.checkFlags.add(check);
/*  74 */       if (count < this.validFlags.size() / 2) {
/*     */         
/*  76 */         leftColumnLayout.addChild((LayoutElement)check);
/*     */       }
/*     */       else {
/*     */         
/*  80 */         rightColumnLayout.addChild((LayoutElement)check);
/*     */       } 
/*  82 */       count++;
/*     */     } 
/*     */     
/*  85 */     columnsLayout.addChild((LayoutElement)leftColumnLayout);
/*  86 */     columnsLayout.addChild((LayoutElement)rightColumnLayout);
/*  87 */     this.layout.addChild((LayoutElement)columnsLayout);
/*     */     
/*  89 */     LinearLayout bottomButtons = LinearLayout.horizontal();
/*  90 */     bottomButtons.spacing(12);
/*  91 */     bottomButtons.addChild((LayoutElement)Button.builder(this.labelSubmit, b -> setResponseAndClose(new BlockFlagsResponse(this.currentFlags, false))).width(this.font.width((FormattedText)this.labelSubmit) + 10).build());
/*  92 */     bottomButtons.addChild((LayoutElement)Button.builder(this.labelReset, b -> reset()).width(this.font.width((FormattedText)this.labelReset) + 10).build());
/*  93 */     bottomButtons.addChild((LayoutElement)Button.builder(this.labelCancel, b -> setResponseAndClose(new BlockFlagsResponse(this.originalFlags, true))).width(this.font.width((FormattedText)this.labelCancel) + 10).build());
/*  94 */     this.layout.addChild((LayoutElement)bottomButtons);
/*     */     
/*  96 */     this.layout.visitWidgets(x$0 -> (AbstractWidget)rec$.addRenderableWidget(x$0));
/*  97 */     repositionElements();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void renderPopupScreenBackground(GuiGraphics graphics, int mouseX, int mouseY, float partialTick) {
/* 103 */     renderTransparentBackground(graphics);
/* 104 */     graphics.blitSprite(BACKGROUND_SPRITE, this.layout.getX() - 18, this.layout.getY() - 18, this.layout.getWidth() + 36, this.layout.getHeight() + 36);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected void repositionElements() {
/* 110 */     this.layout.arrangeElements();
/* 111 */     FrameLayout.centerInRectangle((LayoutElement)this.layout, getRectangle());
/*     */   }
/*     */ 
/*     */   
/*     */   private void checkToggled(Button button) {
/* 116 */     CheckBox check = (CheckBox)button;
/* 117 */     int index = this.checkFlags.indexOf(check);
/* 118 */     BlockFlag flag = this.validFlags.get(index);
/* 119 */     if (check.getToggled().booleanValue()) {
/*     */       
/* 121 */       this.currentFlags.add(flag);
/*     */     }
/*     */     else {
/*     */       
/* 125 */       this.currentFlags.remove(flag);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   private void reset() {
/* 131 */     this.currentFlags = this.originalFlags.clone();
/* 132 */     for (int i = 0; i < this.validFlags.size(); i++)
/*     */     {
/* 134 */       ((CheckBox)this.checkFlags.get(i)).setToggled(Boolean.valueOf(this.currentFlags.contains(this.validFlags.get(i)))); } 
/*     */   }
/*     */   public static final class BlockFlagsResponse extends Record { private final EnumSet<BlockFlag> flags;
/*     */     private final boolean canceled;
/*     */     
/* 139 */     public BlockFlagsResponse(EnumSet<BlockFlag> flags, boolean canceled) { this.flags = flags; this.canceled = canceled; } public final String toString() { // Byte code:
/*     */       //   0: aload_0
/*     */       //   1: <illegal opcode> toString : (Ljourneymap/client/ui/component/popupscreenbutton/blockflags/BlockFlagsScreen$BlockFlagsResponse;)Ljava/lang/String;
/*     */       //   6: areturn
/*     */       // Line number table:
/*     */       //   Java source line number -> byte code offset
/*     */       //   #139	-> 0
/*     */       // Local variable table:
/*     */       //   start	length	slot	name	descriptor
/* 139 */       //   0	7	0	this	Ljourneymap/client/ui/component/popupscreenbutton/blockflags/BlockFlagsScreen$BlockFlagsResponse; } public EnumSet<BlockFlag> flags() { return this.flags; } public final int hashCode() { // Byte code:
/*     */       //   0: aload_0
/*     */       //   1: <illegal opcode> hashCode : (Ljourneymap/client/ui/component/popupscreenbutton/blockflags/BlockFlagsScreen$BlockFlagsResponse;)I
/*     */       //   6: ireturn
/*     */       // Line number table:
/*     */       //   Java source line number -> byte code offset
/*     */       //   #139	-> 0
/*     */       // Local variable table:
/*     */       //   start	length	slot	name	descriptor
/*     */       //   0	7	0	this	Ljourneymap/client/ui/component/popupscreenbutton/blockflags/BlockFlagsScreen$BlockFlagsResponse; } public final boolean equals(Object o) { // Byte code:
/*     */       //   0: aload_0
/*     */       //   1: aload_1
/*     */       //   2: <illegal opcode> equals : (Ljourneymap/client/ui/component/popupscreenbutton/blockflags/BlockFlagsScreen$BlockFlagsResponse;Ljava/lang/Object;)Z
/*     */       //   7: ireturn
/*     */       // Line number table:
/*     */       //   Java source line number -> byte code offset
/*     */       //   #139	-> 0
/*     */       // Local variable table:
/*     */       //   start	length	slot	name	descriptor
/*     */       //   0	8	0	this	Ljourneymap/client/ui/component/popupscreenbutton/blockflags/BlockFlagsScreen$BlockFlagsResponse;
/* 139 */       //   0	8	1	o	Ljava/lang/Object; } public boolean canceled() { return this.canceled; }
/*     */      }
/*     */ 
/*     */ }


/* Location:              C:\Users\Administrator\Downloads\journeymap-neoforge-1.21-6.0.0-beta.18.jar!\journeymap\clien\\ui\component\popupscreenbutton\blockflags\BlockFlagsScreen.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */