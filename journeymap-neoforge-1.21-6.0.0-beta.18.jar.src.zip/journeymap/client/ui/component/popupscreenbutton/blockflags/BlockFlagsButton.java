/*    */ package journeymap.client.ui.component.popupscreenbutton.blockflags;
/*    */ 
/*    */ import java.util.EnumSet;
/*    */ import java.util.function.Supplier;
/*    */ import journeymap.client.Constants;
/*    */ import journeymap.client.model.BlockFlag;
/*    */ import journeymap.client.render.draw.DrawUtil;
/*    */ import journeymap.client.texture.Texture;
/*    */ import journeymap.client.texture.TextureCache;
/*    */ import journeymap.client.ui.component.popupscreenbutton.PopupButton;
/*    */ import journeymap.client.ui.component.popupscreenbutton.PopupButtonScreen;
/*    */ import net.minecraft.client.gui.GuiGraphics;
/*    */ 
/*    */ public class BlockFlagsButton
/*    */   extends PopupButton<BlockFlagsScreen.BlockFlagsResponse>
/*    */ {
/* 17 */   final Texture colorWheel = TextureCache.getTexture(TextureCache.Flag);
/*    */ 
/*    */   
/*    */   public BlockFlagsButton(int width, int height, Supplier<EnumSet<BlockFlag>> flags, PopupButtonScreen.OnClose<BlockFlagsScreen.BlockFlagsResponse> onClose) {
/* 21 */     super(width, height, "", () -> new BlockFlagsScreen(flags.get()), onClose);
/* 22 */     init();
/*    */   }
/*    */ 
/*    */   
/*    */   void init() {
/* 27 */     setTooltip(new String[] { Constants.getString("jm.common.button.flags.tooltip") });
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public void renderWidget(GuiGraphics graphics, int mouseX, int mouseY, float partialTicks) {
/* 33 */     super.renderWidget(graphics, mouseX, mouseY, partialTicks);
/* 34 */     DrawUtil.drawQuad(graphics.pose(), this.colorWheel, (getX() + 1), (getY() + 1), (getWidth() - 2), (getHeight() - 2), false, 0.0D);
/*    */   }
/*    */ }


/* Location:              C:\Users\Administrator\Downloads\journeymap-neoforge-1.21-6.0.0-beta.18.jar!\journeymap\clien\\ui\component\popupscreenbutton\blockflags\BlockFlagsButton.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */