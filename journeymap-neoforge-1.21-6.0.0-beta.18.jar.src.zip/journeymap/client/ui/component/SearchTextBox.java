/*    */ package journeymap.client.ui.component;
/*    */ 
/*    */ import journeymap.client.ui.component.buttons.TextBoxButton;
/*    */ import net.minecraft.client.gui.Font;
/*    */ 
/*    */ public class SearchTextBox
/*    */   extends TextBoxButton
/*    */ {
/*    */   private final String initialValue;
/*    */   
/*    */   public SearchTextBox(String value, Font fontRenderer, int width, int height) {
/* 12 */     this(value, fontRenderer, width, height, true, true);
/*    */   }
/*    */ 
/*    */   
/*    */   public SearchTextBox(String value, Font fontRenderer, int width, int height, boolean isNumeric, boolean negative) {
/* 17 */     super(value, fontRenderer, width, height, isNumeric, negative);
/* 18 */     this.text = value;
/* 19 */     this.initialValue = value;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public boolean mouseClicked(double mouseX, double mouseY, int mouseButton) {
/* 25 */     boolean clicked = super.mouseClicked(mouseX, mouseY, mouseButton);
/*    */     
/* 27 */     if (clicked && this.initialValue.contains(this.textBox.getValue()))
/*    */     {
/* 29 */       this.textBox.selectAll();
/*    */     }
/* 31 */     return clicked;
/*    */   }
/*    */ }


/* Location:              C:\Users\Administrator\Downloads\journeymap-neoforge-1.21-6.0.0-beta.18.jar!\journeymap\clien\\ui\component\SearchTextBox.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */