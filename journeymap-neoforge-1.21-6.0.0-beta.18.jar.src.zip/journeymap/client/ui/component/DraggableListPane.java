/*     */ package journeymap.client.ui.component;
/*     */ 
/*     */ import java.awt.Color;
/*     */ import java.util.List;
/*     */ import journeymap.client.render.draw.DrawUtil;
/*     */ import journeymap.client.ui.option.CategorySlot;
/*     */ import journeymap.client.ui.option.SlotMetadata;
/*     */ import net.minecraft.client.Minecraft;
/*     */ import net.minecraft.client.gui.GuiGraphics;
/*     */ 
/*     */ public class DraggableListPane<T extends Slot>
/*     */   extends ScrollListPane<T>
/*     */ {
/*     */   private boolean clicked = false;
/*  15 */   private Integer frameColor = Integer.valueOf((new Color(-6250336)).getRGB());
/*     */   private boolean dragging = false;
/*     */   private boolean didDrag = false;
/*  18 */   private int mouseDragOffsetX = 0;
/*  19 */   private int mouseDragOffsetY = 0;
/*     */ 
/*     */   
/*     */   public DraggableListPane(Minecraft mc, int width, int height, int x, int y) {
/*  23 */     super(mc, x, y, width, height, 20);
/*  24 */     setX(x);
/*  25 */     setY(y);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void setSlots(List<T> slots) {
/*  31 */     int newWidth = this.width;
/*  32 */     int newHeight = this.height;
/*  33 */     super.setSlots(slots);
/*  34 */     for (Slot slot : getRootSlots()) {
/*     */       
/*  36 */       if (slot instanceof CategorySlot) {
/*     */         
/*  38 */         newHeight = ((CategorySlot)slot).getAllChildMetadata().size() * 25;
/*  39 */         for (SlotMetadata child : ((CategorySlot)slot).getAllChildMetadata()) {
/*     */           
/*  41 */           String name = child.getName();
/*  42 */           int sWidth = (Minecraft.getInstance()).font.width(name) * 2;
/*  43 */           newWidth = Math.max(sWidth, newWidth);
/*     */         } 
/*     */       } 
/*     */     } 
/*  47 */     updateSize(newWidth, newHeight, 0, getY());
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void updateSize(int width, int height, int x, int y) {
/*  53 */     setRectangle(width, height, x, y);
/*     */     
/*  55 */     this.listWidth = this.width - this.hpad * 4;
/*  56 */     this.scrollbarX = this.width - this.hpad + getX();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected void renderBackground(GuiGraphics graphics, int x, int y, float partialTicks) {
/*  62 */     if (this.clicked) {
/*     */       
/*  64 */       graphics.fillGradient(getX(), getY(), getRight(), getBottom(), -1072689136, -804253680);
/*     */       
/*  66 */       float alpha = 1.0F;
/*  67 */       DrawUtil.drawRectangle(graphics, (getX() - 1), (getY() - 1), (this.width + 2), 1.0D, this.frameColor.intValue(), alpha);
/*  68 */       DrawUtil.drawRectangle(graphics, (getX() - 1), (getY() + this.height), (this.width + 2), 1.0D, this.frameColor.intValue(), alpha);
/*     */       
/*  70 */       DrawUtil.drawRectangle(graphics, (getX() - 1), (getY() - 1), 1.0D, (this.height + 1), this.frameColor.intValue(), alpha);
/*  71 */       DrawUtil.drawRectangle(graphics, (this.width + getX()), (getY() - 1), 1.0D, (this.height + 2), this.frameColor.intValue(), alpha);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean mouseClicked(double pMouseX, double pMouseY, int pButton) {
/*  78 */     boolean paneClicked = false;
/*  79 */     if (isMouseOver(pMouseX, pMouseY) && !(getEntryAtPosition(pMouseX, pMouseY) instanceof CategorySlot)) {
/*     */       
/*  81 */       paneClicked = super.mouseClicked(pMouseX, pMouseY, pButton);
/*     */     }
/*  83 */     else if (isMouseOver(pMouseX, pMouseY) && getEntryAtPosition(pMouseX, pMouseY) instanceof CategorySlot) {
/*     */       
/*  85 */       this.mouseDragOffsetX = (int)(pMouseX - getX());
/*  86 */       this.mouseDragOffsetY = (int)(pMouseY - getY());
/*  87 */       this.dragging = true;
/*     */     } 
/*     */     
/*  90 */     return paneClicked;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean mouseDragged(double pMouseX, double pMouseY, int pButton, double pDragX, double pDragY) {
/*  96 */     if (this.dragging) {
/*     */       
/*  98 */       this.didDrag = true;
/*  99 */       int posX = (int)(pMouseX - this.mouseDragOffsetX);
/* 100 */       int posY = (int)(pMouseY - this.mouseDragOffsetY);
/* 101 */       updatePosition(posX, posY);
/*     */     } 
/*     */     
/* 104 */     return super.mouseDragged(pMouseX, pMouseY, pButton, pDragX, pDragY);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected void renderSelection(GuiGraphics graphics, int top, int width, int height, int outerColor, int innerColor) {
/* 110 */     int i = getX() + (this.width - width) / 2;
/* 111 */     int j = getX() + (this.width + width + 8) / 2;
/* 112 */     graphics.fill(i, top - 2, j, top + height + 2, outerColor);
/* 113 */     graphics.fill(i + 1, top - 1, j - 1, top + height + 1, innerColor);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean mouseReleased(double mouseX, double mouseY, int mouseButton) {
/* 119 */     if (this.dragging && this.didDrag) {
/*     */       
/* 121 */       this.didDrag = false;
/* 122 */       this.dragging = false;
/*     */     }
/* 124 */     else if (isMouseOver(mouseX, mouseY) && getEntryAtPosition(mouseX, mouseY) instanceof CategorySlot) {
/*     */       
/* 126 */       this.didDrag = false;
/* 127 */       this.dragging = false;
/* 128 */       super.mouseClicked(mouseX, mouseY, mouseButton);
/* 129 */       CategorySlot slot = (CategorySlot)getEntryAtPosition(mouseX, mouseY);
/* 130 */       this.clicked = slot.isSelected();
/*     */     } 
/* 132 */     return super.mouseReleased(mouseX, mouseY, mouseButton);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void updatePosition(int x, int y) {
/* 138 */     setPosition(x, y);
/* 139 */     this.scrollbarX = this.width - this.hpad + getX();
/* 140 */     this.listWidth = this.width - this.hpad * 4;
/*     */   }
/*     */ 
/*     */   
/*     */   public int getHeight() {
/* 145 */     return this.height;
/*     */   }
/*     */ 
/*     */   
/*     */   public int getWidth() {
/* 150 */     return this.width;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isClicked() {
/* 155 */     return this.clicked;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setClicked(boolean clicked) {
/* 160 */     this.clicked = clicked;
/*     */   }
/*     */ }


/* Location:              C:\Users\Administrator\Downloads\journeymap-neoforge-1.21-6.0.0-beta.18.jar!\journeymap\clien\\ui\component\DraggableListPane.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */