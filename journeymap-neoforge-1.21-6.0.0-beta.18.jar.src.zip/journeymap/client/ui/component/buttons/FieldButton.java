/*    */ package journeymap.client.ui.component.buttons;
/*    */ 
/*    */ import journeymap.common.properties.config.ConfigField;
/*    */ import net.minecraft.client.gui.GuiGraphics;
/*    */ import net.minecraft.client.gui.components.Button;
/*    */ 
/*    */ public abstract class FieldButton
/*    */   extends Button
/*    */ {
/*    */   private final ConfigField<?> field;
/*    */   
/*    */   public FieldButton(ConfigField<?> field, String label) {
/* 13 */     super(label);
/* 14 */     this.field = field;
/*    */   }
/*    */ 
/*    */   
/*    */   public FieldButton(ConfigField<?> field, String label, Button.OnPress onPress) {
/* 19 */     super(label, onPress);
/* 20 */     this.field = field;
/*    */   }
/*    */ 
/*    */   
/*    */   public FieldButton(ConfigField<?> field, int width, int height, String label, Button.OnPress onPress) {
/* 25 */     super(width, height, label, onPress);
/* 26 */     this.field = field;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public void renderWidget(GuiGraphics graphics, int mouseX, int mouseY, float partialTicks) {
/* 32 */     if (this.field.hasEnabledAttribute())
/*    */     {
/* 34 */       setEnabled(this.field.isEnabled());
/*    */     }
/* 36 */     super.renderWidget(graphics, mouseX, mouseY, partialTicks);
/*    */   }
/*    */ 
/*    */   
/*    */   public String getCustomFieldTooltip() {
/* 41 */     return this.field.getCustomToolTip();
/*    */   }
/*    */ }


/* Location:              C:\Users\Administrator\Downloads\journeymap-neoforge-1.21-6.0.0-beta.18.jar!\journeymap\clien\\ui\component\buttons\FieldButton.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */