/*      */ package journeymap.client.ui.component.buttons;
/*      */ 
/*      */ import java.awt.Color;
/*      */ import java.awt.geom.Rectangle2D;
/*      */ import java.util.ArrayList;
/*      */ import java.util.List;
/*      */ import java.util.Objects;
/*      */ import java.util.StringJoiner;
/*      */ import java.util.function.Function;
/*      */ import journeymap.client.Constants;
/*      */ import journeymap.client.render.draw.DrawUtil;
/*      */ import journeymap.client.ui.UIManager;
/*      */ import journeymap.client.ui.component.ButtonList;
/*      */ import journeymap.client.ui.option.ClientOptionsManager;
/*      */ import journeymap.common.Journeymap;
/*      */ import journeymap.common.log.LogFormatter;
/*      */ import net.minecraft.client.Minecraft;
/*      */ import net.minecraft.client.gui.Font;
/*      */ import net.minecraft.client.gui.GuiGraphics;
/*      */ import net.minecraft.client.gui.components.Button;
/*      */ import net.minecraft.client.gui.components.WidgetSprites;
/*      */ import net.minecraft.client.sounds.SoundManager;
/*      */ import net.minecraft.network.chat.Component;
/*      */ import net.minecraft.network.chat.FormattedText;
/*      */ import net.minecraft.network.chat.Style;
/*      */ import net.minecraft.resources.ResourceLocation;
/*      */ import net.minecraft.util.FormattedCharSequence;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class Button
/*      */   extends Button
/*      */ {
/*   37 */   public static final ResourceLocation buttonActiveResource = ResourceLocation.parse("widget/button");
/*   38 */   public static final ResourceLocation buttonDisabledResource = ResourceLocation.parse("widget/button_disabled");
/*   39 */   public static final ResourceLocation buttonHighlightedResource = ResourceLocation.parse("widget/button_highlighted");
/*      */ 
/*      */   
/*   42 */   public static final WidgetSprites SPRITES = new WidgetSprites(buttonActiveResource, buttonDisabledResource, buttonHighlightedResource);
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*   47 */   protected Integer customFrameColorLight = Integer.valueOf((new Color(160, 160, 160)).getRGB());
/*      */ 
/*      */ 
/*      */   
/*   51 */   protected Integer customFrameColorDark = Integer.valueOf((new Color(120, 120, 120)).getRGB());
/*      */ 
/*      */ 
/*      */   
/*   55 */   protected Integer customBgColor = Integer.valueOf((new Color(100, 100, 100)).getRGB());
/*      */ 
/*      */ 
/*      */   
/*   59 */   protected Integer customBgHoverColor = Integer.valueOf((new Color(125, 135, 190)).getRGB());
/*      */ 
/*      */ 
/*      */   
/*   63 */   protected Integer customBgHoverColor2 = Integer.valueOf((new Color(100, 100, 100)).getRGB());
/*      */ 
/*      */   
/*      */   protected Integer labelColor;
/*      */ 
/*      */   
/*      */   protected Integer varLabelColor;
/*      */ 
/*      */   
/*      */   protected Integer hoverLabelColor;
/*      */ 
/*      */   
/*      */   protected Integer disabledLabelColor;
/*      */ 
/*      */   
/*      */   public static final int UNSET_ACTIVE_COLOR = -1;
/*      */ 
/*      */   
/*   81 */   protected int packedActiveColor = -1;
/*      */ 
/*      */ 
/*      */   
/*   85 */   protected Integer disabledBgColor = Integer.valueOf((new Color(45, 45, 45)).getRGB());
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected boolean drawFrame;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected boolean drawBackground;
/*      */ 
/*      */ 
/*      */   
/*      */   protected boolean drawBackgroundOnDisable = true;
/*      */ 
/*      */ 
/*      */   
/*      */   protected boolean drawLabelShadow = true;
/*      */ 
/*      */ 
/*      */   
/*      */   protected boolean showDisabledHoverText;
/*      */ 
/*      */ 
/*      */   
/*      */   protected boolean defaultStyle = true;
/*      */ 
/*      */ 
/*      */   
/*  115 */   protected int WIDTH_PAD = 12;
/*      */ 
/*      */ 
/*      */   
/*      */   protected String[] tooltip;
/*      */ 
/*      */   
/*      */   protected String label;
/*      */ 
/*      */   
/*  125 */   protected Font fontRenderer = (Minecraft.getInstance()).font;
/*      */   
/*      */   protected Rectangle2D.Double bounds;
/*      */   
/*  129 */   protected ArrayList<Function<Button, Boolean>> clickListeners = new ArrayList<>(0);
/*  130 */   private int tooltipSize = 200;
/*      */   
/*  132 */   private DrawUtil.HAlign horizontalAlignment = DrawUtil.HAlign.Center;
/*      */ 
/*      */   
/*      */   private boolean drawHovered = true;
/*      */ 
/*      */   
/*      */   private HoverState onHoverState;
/*      */ 
/*      */   
/*      */   private boolean wasHovered = false;
/*      */ 
/*      */   
/*      */   private boolean drawUnderline = false;
/*      */ 
/*      */   
/*      */   public Button(String label) {
/*  148 */     this(0, 0, label, emptyPressable());
/*  149 */     resetLabelColors();
/*      */   }
/*      */ 
/*      */   
/*      */   public Button(String label, Button.OnPress onPress) {
/*  154 */     this(0, 0, label, onPress);
/*  155 */     resetLabelColors();
/*      */   }
/*      */ 
/*      */   
/*      */   public Button(int width, int height, String label) {
/*  160 */     this(width, height, label, emptyPressable());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Button(int width, int height, String label, Button.OnPress onPress) {
/*  172 */     super(0, 0, width, height, (Component)Constants.getStringTextComponent(label), onPress, DEFAULT_NARRATION);
/*  173 */     this.label = label;
/*  174 */     resetLabelColors();
/*  175 */     finishInit();
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public static Button.OnPress emptyPressable() {
/*  181 */     return button -> {
/*      */       
/*      */       };
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void resetLabelColors() {
/*  192 */     this.labelColor = Integer.valueOf((new Color(14737632)).getRGB());
/*  193 */     this.hoverLabelColor = Integer.valueOf((new Color(16777120)).getRGB());
/*  194 */     this.disabledLabelColor = Integer.valueOf(Color.gray.getRGB());
/*      */   }
/*      */ 
/*      */   
/*      */   public int getActiveColor() {
/*  199 */     if (this.packedActiveColor != -1)
/*      */     {
/*  201 */       return this.packedActiveColor;
/*      */     }
/*  203 */     return this.active ? 16777215 : 10526880;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void finishInit() {
/*  212 */     setEnabled(true);
/*  213 */     setDrawButton(true);
/*  214 */     setDrawFrame(true);
/*  215 */     setDrawBackground(true);
/*  216 */     if (this.height == 0)
/*      */     {
/*  218 */       setHeight(20);
/*      */     }
/*  220 */     if (this.width == 0)
/*      */     {
/*  222 */       setWidth(200);
/*      */     }
/*  224 */     updateBounds();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void updateLabel() {}
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean isActive() {
/*  241 */     return isEnabled();
/*      */   }
/*      */ 
/*      */   
/*      */   public int getFitWidth(Font fr) {
/*  246 */     int max = fr.width(getMessage().getString());
/*  247 */     return max + this.WIDTH_PAD + (fr.isBidirectional() ? (int)Math.ceil(max * 0.25D) : 0);
/*      */   }
/*      */ 
/*      */   
/*      */   public String getLabel() {
/*  252 */     return this.label;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void fitWidth(Font fr) {
/*  262 */     setWidth(getFitWidth(fr));
/*      */   }
/*      */ 
/*      */   
/*      */   public void drawPartialScrollable(GuiGraphics graphics, Minecraft minecraft, int x, int y, int width, int height) {
/*  267 */     graphics.blitSprite(SPRITES.disabled(), x, y, width, height);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void showDisabledOnHover(boolean show) {
/*  277 */     this.showDisabledHoverText = show;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean isMouseOver(double x, double y) {
/*  283 */     Minecraft mc = Minecraft.getInstance();
/*  284 */     if (mc.screen instanceof ClientOptionsManager && ((ClientOptionsManager)mc.screen)
/*  285 */       .previewMiniMap() && UIManager.INSTANCE
/*  286 */       .getMiniMap().withinBounds(x, y))
/*      */     {
/*  288 */       return false;
/*      */     }
/*      */     
/*  291 */     return super.isMouseOver(x, y);
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean isMouseOver() {
/*  296 */     return super.isMouseOver(getX(), getY());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setMouseOver(boolean hover) {
/*  306 */     setHovered(hover);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void playDownSound(SoundManager soundHandler) {
/*  312 */     if (isEnabled())
/*      */     {
/*  314 */       super.playDownSound(soundHandler);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void renderWidget(GuiGraphics graphics, int mouseX, int mouseY, float partialTicks) {
/*  321 */     if (!isVisible()) {
/*      */       return;
/*      */     }
/*      */ 
/*      */     
/*  326 */     if (this.defaultStyle) {
/*      */       
/*  328 */       super.renderWidget(graphics, mouseX, mouseY, partialTicks);
/*      */     } else {
/*      */       int textX;
/*      */       
/*  332 */       Minecraft minecraft = Minecraft.getInstance();
/*      */       
/*  334 */       if (minecraft.screen instanceof ClientOptionsManager && ((ClientOptionsManager)minecraft.screen)
/*  335 */         .previewMiniMap() && UIManager.INSTANCE
/*  336 */         .getMiniMap().withinBounds(mouseX, mouseY)) {
/*      */         
/*  338 */         setHovered(false);
/*      */       }
/*      */       else {
/*      */         
/*  342 */         setHovered((mouseX >= getX() && mouseY >= getY() && mouseX < getX() + this.width && mouseY < getY() + this.height));
/*      */       } 
/*      */ 
/*      */       
/*  346 */       if (isDrawBackground() || (!this.drawBackgroundOnDisable && isEnabled())) {
/*      */         
/*  348 */         DrawUtil.drawRectangle(graphics, getX(), getY(), this.width, this.height, ((isHovered() && this.drawHovered) ? this.customBgHoverColor : this.customBgColor).intValue(), 1.0F);
/*      */       }
/*  350 */       else if (isEnabled() && isHoveredOrFocused() && this.drawHovered) {
/*      */         
/*  352 */         DrawUtil.drawRectangle(graphics, getX(), getY(), this.width, this.height, this.customBgHoverColor2.intValue(), 0.5F);
/*      */       } 
/*      */       
/*  355 */       if (isDrawFrame()) {
/*      */         
/*  357 */         DrawUtil.drawRectangle(graphics, getX(), getY(), this.width, 1.0D, this.customFrameColorLight.intValue(), 1.0F);
/*  358 */         DrawUtil.drawRectangle(graphics, getX(), getY(), 1.0D, this.height, this.customFrameColorLight.intValue(), 1.0F);
/*      */         
/*  360 */         DrawUtil.drawRectangle(graphics, getX(), (getY() + this.height - 1), (this.width - 1), 1.0D, this.customFrameColorDark.intValue(), 1.0F);
/*  361 */         DrawUtil.drawRectangle(graphics, (getX() + this.width - 1), (getY() + 1), 1.0D, (this.height - 1), this.customFrameColorDark.intValue(), 1.0F);
/*      */       } 
/*      */       
/*  364 */       renderBg(graphics, minecraft, mouseX, mouseY);
/*  365 */       this.varLabelColor = this.labelColor;
/*      */       
/*  367 */       if (!isEnabled()) {
/*      */         
/*  369 */         this.varLabelColor = this.disabledLabelColor;
/*      */         
/*  371 */         if (this.drawBackground)
/*      */         {
/*  373 */           float alpha = 0.7F;
/*  374 */           int widthOffset = this.width - ((this.height >= 20) ? 3 : 2);
/*  375 */           DrawUtil.drawRectangle(graphics, (getX() + 1), (getY() + 1), widthOffset, (this.height - 2), this.disabledBgColor.intValue(), alpha);
/*      */         
/*      */         }
/*      */       
/*      */       }
/*  380 */       else if (isHoveredOrFocused() && this.drawHovered) {
/*      */         
/*  382 */         this.varLabelColor = this.hoverLabelColor;
/*      */       }
/*  384 */       else if (this.labelColor != null) {
/*      */         
/*  386 */         this.varLabelColor = this.labelColor;
/*      */       }
/*  388 */       else if (getActiveColor() != 0) {
/*      */         
/*  390 */         this.varLabelColor = Integer.valueOf(getActiveColor());
/*      */       } 
/*      */ 
/*      */ 
/*      */       
/*  395 */       switch (this.horizontalAlignment) {
/*      */         
/*      */         case Above:
/*  398 */           textX = getRightX() - this.WIDTH_PAD / 2;
/*      */           break;
/*      */         case Below:
/*  401 */           textX = getX() + this.WIDTH_PAD / 2;
/*      */           break;
/*      */         
/*      */         default:
/*  405 */           textX = getCenterX();
/*      */           break;
/*      */       } 
/*  408 */       DrawUtil.drawLabel(graphics, getMessage().getString(), textX, getMiddleY(), this.horizontalAlignment, DrawUtil.VAlign.Middle, null, 0.0F, this.varLabelColor, 1.0F, 1.0D, this.drawLabelShadow, 0.0D);
/*      */       
/*  410 */       if (this.drawUnderline)
/*      */       {
/*  412 */         drawUnderline(graphics);
/*      */       }
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   protected void renderBg(GuiGraphics graphics, Minecraft $$1, int $$2, int $$3) {}
/*      */ 
/*      */ 
/*      */   
/*      */   public void renderSpecialDecoration(GuiGraphics graphics, int mouseX, int mouseY, int x, int y, int width, int height) {}
/*      */ 
/*      */   
/*      */   public void setHorizontalAlignment(DrawUtil.HAlign horizontalAlignment) {
/*  427 */     this.horizontalAlignment = horizontalAlignment;
/*      */   }
/*      */ 
/*      */   
/*      */   public void drawHovered(boolean drawHovered) {
/*  432 */     this.drawHovered = drawHovered;
/*      */   }
/*      */ 
/*      */   
/*      */   public void drawUnderline(boolean drawUnderline) {
/*  437 */     this.drawUnderline = drawUnderline;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void drawUnderline(GuiGraphics graphics) {
/*  445 */     if (isVisible())
/*      */     {
/*  447 */       DrawUtil.drawRectangle(graphics, getX(), (getY() + this.height), this.width, 1.0D, this.customFrameColorDark.intValue(), 1.0F);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void secondaryDrawButton() {}
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void onPress() {
/*  461 */     if (this.clickListeners == null || this.clickListeners.size() == 0) {
/*      */       
/*  463 */       super.onPress();
/*      */     }
/*      */     else {
/*      */       
/*  467 */       checkClickListeners();
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void mouseMoved(double mouseX, double mouseY) {
/*  474 */     if (this.onHoverState != null)
/*      */     {
/*  476 */       if (isHovered() && !this.wasHovered) {
/*      */         
/*  478 */         this.wasHovered = true;
/*  479 */         this.onHoverState.onHoverState(this, this.wasHovered);
/*      */       }
/*  481 */       else if (this.wasHovered && !isHovered()) {
/*      */         
/*  483 */         this.wasHovered = false;
/*  484 */         this.onHoverState.onHoverState(this, this.wasHovered);
/*      */       } 
/*      */     }
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean checkClickListeners() {
/*  491 */     boolean clicked = true;
/*  492 */     if (!this.clickListeners.isEmpty()) {
/*      */       
/*      */       try {
/*      */         
/*  496 */         for (Function<Button, Boolean> listener : this.clickListeners)
/*      */         {
/*  498 */           if (!((Boolean)listener.apply(this)).booleanValue()) {
/*      */             break;
/*      */           }
/*      */         }
/*      */       
/*      */       }
/*  504 */       catch (Throwable t) {
/*      */         
/*  506 */         Journeymap.getLogger().error("Error trying to toggle button '" + String.valueOf(getMessage()) + "': " + LogFormatter.toString(t));
/*  507 */         clicked = false;
/*      */       } 
/*      */     }
/*  510 */     return clicked;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String getUnformattedTooltip() {
/*  520 */     if (this.tooltip != null && this.tooltip.length > 0)
/*      */     {
/*  522 */       return this.tooltip[0];
/*      */     }
/*  524 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public List<FormattedCharSequence> getWrappedTooltip() {
/*  540 */     ArrayList<FormattedCharSequence> list = new ArrayList<>();
/*  541 */     if (this.tooltip != null) {
/*      */       
/*  543 */       for (String line : this.tooltip)
/*      */       {
/*  545 */         list.addAll(this.fontRenderer.split((FormattedText)Constants.getTranslatedTextComponent(line), this.tooltipSize));
/*      */       }
/*  547 */       return list;
/*      */     } 
/*      */     
/*  550 */     if (!isEnabled() && this.showDisabledHoverText)
/*      */     {
/*  552 */       list.add(FormattedCharSequence.forward(Constants.getString("jm.common.disabled_feature"), Style.EMPTY.withItalic(Boolean.valueOf(true))));
/*      */     }
/*  554 */     return list;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setTooltip(String... tooltip) {
/*  564 */     this.tooltip = tooltip;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setTooltip(int size, String... tooltip) {
/*  574 */     this.tooltipSize = size;
/*  575 */     this.tooltip = tooltip;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean mouseOver(double mouseX, double mouseY) {
/*  587 */     return (isVisible() && getBounds().contains(mouseX, mouseY));
/*      */   }
/*      */ 
/*      */   
/*      */   protected Rectangle2D.Double updateBounds() {
/*  592 */     this.bounds = new Rectangle2D.Double(getX(), getY(), getWidth(), getHeight());
/*  593 */     return this.bounds;
/*      */   }
/*      */ 
/*      */   
/*      */   public Rectangle2D.Double getBounds() {
/*  598 */     if (this.bounds == null)
/*      */     {
/*  600 */       return updateBounds();
/*      */     }
/*  602 */     return this.bounds;
/*      */   }
/*      */ 
/*      */   
/*      */   public int getScrollableWidth() {
/*  607 */     return this.width;
/*      */   }
/*      */ 
/*      */   
/*      */   public void setWidth(int width) {
/*  612 */     if (this.width != width) {
/*      */       
/*  614 */       this.width = width;
/*  615 */       this.bounds = null;
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   public void setScrollableWidth(int width) {
/*  621 */     setWidth(width);
/*      */   }
/*      */ 
/*      */   
/*      */   public int getButtonHeight() {
/*  626 */     return getHeight();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setHeight(int height) {
/*  636 */     if (this.height != height) {
/*      */       
/*  638 */       this.height = height;
/*  639 */       this.bounds = null;
/*  640 */       if (height != 20)
/*      */       {
/*  642 */         this.defaultStyle = false;
/*      */       }
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setTextOnly(Font fr) {
/*  654 */     Objects.requireNonNull(fr); setHeight(9 + 1);
/*  655 */     fitWidth(fr);
/*  656 */     setDrawBackground(false);
/*  657 */     setDrawFrame(false);
/*      */   }
/*      */ 
/*      */   
/*      */   public void drawScrollable(GuiGraphics graphics, Minecraft mc, int mouseX, int mouseY) {
/*  662 */     render(graphics, mouseX, mouseY, 0.0F);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void clickScrollable(Minecraft mc, int mouseX, int mouseY) {}
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setX(int x) {
/*  677 */     if (getX() != x) {
/*      */       
/*  679 */       super.setX(x);
/*  680 */       this.bounds = null;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setY(int y) {
/*  691 */     if (getY() != y) {
/*      */       
/*  693 */       super.setY(y);
/*  694 */       this.bounds = null;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int getCenterX() {
/*  706 */     return getX() + this.width / 2;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int getMiddleY() {
/*  716 */     return getY() + this.height / 2;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int getBottomY() {
/*  726 */     return getY() + this.height;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int getRightX() {
/*  736 */     return getX() + this.width;
/*      */   }
/*      */ 
/*      */   
/*      */   public void setScrollablePosition(int x, int y) {
/*  741 */     setX(x);
/*  742 */     setY(y);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Button leftOf(int x) {
/*  753 */     setX(x - getWidth());
/*  754 */     return this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Button rightOf(int x) {
/*  765 */     setX(x);
/*  766 */     return this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Button centerHorizontalOn(int x) {
/*  777 */     setX(x - this.width / 2);
/*  778 */     return this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Button centerVerticalOn(int y) {
/*  789 */     setY(y - this.height / 2);
/*  790 */     return this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Button leftOf(Button other, int margin) {
/*  802 */     setX(other.getX() - getWidth() - margin);
/*  803 */     return this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Button rightOf(Button other, int margin) {
/*  815 */     setX(other.getX() + other.getWidth() + margin);
/*  816 */     return this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Button above(Button other, int margin) {
/*  828 */     setY(other.getY() - getHeight() - margin);
/*  829 */     return this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Button above(int y) {
/*  840 */     setY(y - getHeight());
/*  841 */     return this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Button below(Button other, int margin) {
/*  853 */     setY(other.getY() + other.getHeight() + margin);
/*  854 */     return this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Button below(ButtonList list, int margin) {
/*  866 */     setY(list.getBottomY() + margin);
/*  867 */     return this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Button below(int y) {
/*  878 */     setY(y);
/*  879 */     return this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Button alignTo(Button other, DrawUtil.HAlign hAlign, int hgap, DrawUtil.VAlign vAlign, int vgap) {
/*  894 */     int x = getX();
/*  895 */     int y = getY();
/*      */     
/*  897 */     switch (hAlign) {
/*      */ 
/*      */       
/*      */       case Below:
/*  901 */         x = other.getRightX() + hgap;
/*      */         break;
/*      */ 
/*      */       
/*      */       case Above:
/*  906 */         x = other.getX() - hgap;
/*      */         break;
/*      */ 
/*      */       
/*      */       case Middle:
/*  911 */         x = other.getCenterX();
/*      */         break;
/*      */     } 
/*      */ 
/*      */     
/*  916 */     switch (vAlign) {
/*      */ 
/*      */       
/*      */       case Above:
/*  920 */         y = other.getY() - vgap - getHeight();
/*      */         break;
/*      */ 
/*      */       
/*      */       case Below:
/*  925 */         y = other.getBottomY() + vgap;
/*      */         break;
/*      */ 
/*      */       
/*      */       case Middle:
/*  930 */         y = other.getMiddleY() - getHeight() / 2;
/*      */         break;
/*      */     } 
/*      */ 
/*      */     
/*  935 */     setX(x);
/*  936 */     setY(y);
/*  937 */     return this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean isEnabled() {
/*  947 */     return this.active;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setEnabled(boolean enabled) {
/*  957 */     this.active = enabled;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean isVisible() {
/*  967 */     return this.visible;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setVisible(boolean visible) {
/*  977 */     this.visible = visible;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setDrawButton(boolean drawButton) {
/*  987 */     if (drawButton != this.visible)
/*      */     {
/*  989 */       this.visible = drawButton;
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean isDrawFrame() {
/* 1000 */     return this.drawFrame;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setDrawFrame(boolean drawFrame) {
/* 1010 */     this.drawFrame = drawFrame;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean isDrawBackground() {
/* 1020 */     return this.drawBackground;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setDrawBackground(boolean drawBackground) {
/* 1030 */     this.drawBackground = drawBackground;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean isDefaultStyle() {
/* 1040 */     return this.defaultStyle;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setDefaultStyle(boolean defaultStyle) {
/* 1050 */     this.defaultStyle = defaultStyle;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setBackgroundColors(Integer customBgColor, Integer customBgHoverColor, Integer customBgHoverColor2) {
/* 1062 */     this.customBgColor = customBgColor;
/* 1063 */     this.customBgHoverColor = customBgHoverColor;
/* 1064 */     this.customBgHoverColor2 = customBgHoverColor2;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setDrawLabelShadow(boolean draw) {
/* 1074 */     this.drawLabelShadow = draw;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setLabelColors(Integer labelColor, Integer hoverLabelColor, Integer disabledLabelColor) {
/* 1086 */     this.labelColor = labelColor;
/* 1087 */     this.packedActiveColor = labelColor.intValue();
/* 1088 */     if (hoverLabelColor != null)
/*      */     {
/* 1090 */       this.hoverLabelColor = hoverLabelColor;
/*      */     }
/* 1092 */     if (disabledLabelColor != null)
/*      */     {
/* 1094 */       this.disabledLabelColor = disabledLabelColor;
/*      */     }
/*      */   }
/*      */ 
/*      */   
/*      */   public String getDisplayString() {
/* 1100 */     return getMessage().getString();
/*      */   }
/*      */ 
/*      */   
/*      */   public void setOnHover(HoverState hoverState) {
/* 1105 */     this.onHoverState = hoverState;
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean isDrawBackgroundOnDisable() {
/* 1110 */     return this.drawBackgroundOnDisable;
/*      */   }
/*      */ 
/*      */   
/*      */   public void setDrawBackgroundOnDisable(boolean drawBackgroundOnDisable) {
/* 1115 */     this.drawBackgroundOnDisable = drawBackgroundOnDisable;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void refresh() {}
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Integer getLabelColor() {
/* 1132 */     return this.labelColor;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean isHovered() {
/* 1142 */     return super.isHovered();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setHovered(boolean hovered) {
/* 1152 */     this.isHovered = hovered;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void addClickListener(Function<Button, Boolean> listener) {
/* 1162 */     this.clickListeners.add(listener);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public String toString() {
/* 1168 */     return (new StringJoiner(", ", Button.class.getSimpleName() + "[", "]"))
/* 1169 */       .add("label='" + this.label + "'")
/* 1170 */       .toString();
/*      */   }
/*      */   
/*      */   public static interface HoverState {
/*      */     void onHoverState(Button param1Button, boolean param1Boolean);
/*      */   }
/*      */ }


/* Location:              C:\Users\Administrator\Downloads\journeymap-neoforge-1.21-6.0.0-beta.18.jar!\journeymap\clien\\ui\component\buttons\Button.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */