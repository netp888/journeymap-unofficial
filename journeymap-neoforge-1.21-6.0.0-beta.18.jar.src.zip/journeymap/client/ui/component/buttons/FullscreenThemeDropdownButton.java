/*    */ package journeymap.client.ui.component.buttons;
/*    */ import journeymap.client.render.draw.DrawUtil;
/*    */ import journeymap.client.ui.component.DropDownItem;
/*    */ import journeymap.common.properties.config.ConfigField;
/*    */ import journeymap.common.properties.config.StringField;
/*    */ import net.minecraft.client.gui.Font;
/*    */ import net.minecraft.client.gui.GuiGraphics;
/*    */ import net.minecraft.client.gui.components.Button;
/*    */ 
/*    */ public class FullscreenThemeDropdownButton extends PropertyDropdownButton<String> {
/* 11 */   private String editSymbol = " ✎";
/*    */   
/*    */   private boolean needReopen;
/*    */   
/*    */   public FullscreenThemeDropdownButton(Font fr, StringField field, boolean needReopen, Button.OnPress pressable) {
/* 16 */     super(field.getValidValues(), Constants.getString(field.getKey()), (ConfigField<String>)field, pressable);
/* 17 */     setTextOnly(fr);
/* 18 */     this.paneWidth -= this.buttonBuffer;
/* 19 */     this.paneScreen.setPaneWidth(this.paneWidth);
/* 20 */     this.width -= this.buttonBuffer;
/* 21 */     this.buttonBuffer = 0;
/* 22 */     this.needReopen = needReopen;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public String getFormattedLabel(String value) {
/* 28 */     return value;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public void setTextOnly(Font fr) {
/* 34 */     Objects.requireNonNull(fr); setHeight(9 * 2 + 2);
/* 35 */     fitWidth(fr);
/* 36 */     setDrawBackground(false);
/* 37 */     setDrawFrame(false);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   protected int getPaneHeight() {
/* 43 */     return this.items.size() * (((DropDownItem)this.items.get(0)).getHeight() + 3);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public void renderWidget(GuiGraphics graphics, int mouseX, int mouseY, float partialTicks) {
/* 49 */     if (this.needReopen) {
/*    */       
/* 51 */       this.needReopen = false;
/* 52 */       openDropDown();
/*    */     } 
/*    */     
/* 55 */     if (isEnabled() && isHovered())
/*    */     {
/* 57 */       DrawUtil.drawRectangle(graphics, (getX() + 1), (getY() - 2), (this.width - 2), (this.height + 3), this.customBgHoverColor2.intValue(), 0.5F);
/*    */     }
/*    */     
/* 60 */     this.varLabelColor = this.labelColor;
/*    */     
/* 62 */     if (!isEnabled()) {
/*    */       
/* 64 */       this.varLabelColor = this.disabledLabelColor;
/*    */ 
/*    */     
/*    */     }
/* 68 */     else if (isHovered()) {
/*    */       
/* 70 */       this.varLabelColor = this.hoverLabelColor;
/*    */     }
/* 72 */     else if (this.labelColor != null) {
/*    */       
/* 74 */       this.varLabelColor = this.labelColor;
/*    */     }
/* 76 */     else if (getActiveColor() != 0) {
/*    */       
/* 78 */       this.varLabelColor = Integer.valueOf(getActiveColor());
/*    */     } 
/*    */ 
/*    */     
/* 82 */     int textX = getCenterX();
/*    */     
/* 84 */     DrawUtil.drawLabel(graphics, this.baseLabel + this.baseLabel, textX, (getMiddleY() - 5), DrawUtil.HAlign.Center, DrawUtil.VAlign.Middle, null, 0.0F, this.varLabelColor, 1.0F, 1.0D, this.drawLabelShadow, 0.0D);
/* 85 */     DrawUtil.drawLabel(graphics, getMessage().getString(), textX, (getMiddleY() + 5), DrawUtil.HAlign.Center, DrawUtil.VAlign.Middle, null, 0.0F, this.varLabelColor, 1.0F, 1.0D, this.drawLabelShadow, 0.0D);
/*    */   }
/*    */ }


/* Location:              C:\Users\Administrator\Downloads\journeymap-neoforge-1.21-6.0.0-beta.18.jar!\journeymap\clien\\ui\component\buttons\FullscreenThemeDropdownButton.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */