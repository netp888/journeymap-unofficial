/*     */ package journeymap.client.ui.component.buttons;
/*     */ 
/*     */ import java.util.function.Consumer;
/*     */ import journeymap.client.ui.component.TextBox;
/*     */ import net.minecraft.client.gui.Font;
/*     */ import net.minecraft.client.gui.GuiGraphics;
/*     */ 
/*     */ 
/*     */ public class TextBoxButton
/*     */   extends Button
/*     */ {
/*     */   protected TextBox textBox;
/*     */   protected Object text;
/*     */   private boolean isNumeric;
/*     */   private boolean negative;
/*     */   
/*     */   public TextBoxButton(String text) {
/*  18 */     super(text);
/*     */   }
/*     */ 
/*     */   
/*     */   public TextBoxButton(Object text, Font fontRenderer, int width, int height) {
/*  23 */     this(text, fontRenderer, width, height, false, false);
/*     */   }
/*     */ 
/*     */   
/*     */   public TextBoxButton(Object text, Font fontRenderer, int width, int height, boolean isNumeric, boolean negative) {
/*  28 */     super(width, height, text.toString());
/*     */     
/*  30 */     this.text = text;
/*  31 */     this.fontRenderer = fontRenderer;
/*  32 */     this.width = width;
/*  33 */     this.height = height;
/*  34 */     this.isNumeric = isNumeric;
/*  35 */     this.negative = negative;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected TextBox getTextBox() {
/*  42 */     if (this.textBox == null) {
/*     */       
/*  44 */       this.textBox = new TextBox((this.text == null) ? this.label : this.text, this.fontRenderer, this.width, this.height - 4, this.isNumeric, this.negative);
/*  45 */       this.textBox.setMinLength(1);
/*     */     } 
/*  47 */     return this.textBox;
/*     */   }
/*     */ 
/*     */   
/*     */   public String getText() {
/*  52 */     return getTextBox().getValue();
/*     */   }
/*     */ 
/*     */   
/*     */   public String getSelectedText() {
/*  57 */     return getTextBox().getHighlighted();
/*     */   }
/*     */ 
/*     */   
/*     */   public void setResponder(Consumer<String> responder) {
/*  62 */     getTextBox().setResponder(responder);
/*     */   }
/*     */ 
/*     */   
/*     */   public void setMinLength(int minLength) {
/*  67 */     getTextBox().setMinLength(minLength);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void renderWidget(GuiGraphics graphics, int mouseX, int mouseY, float partialTicks) {
/*  73 */     getTextBox().setX(getX());
/*  74 */     getTextBox().setY(getY());
/*  75 */     getTextBox().render(graphics, mouseX, mouseY, partialTicks);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean mouseReleased(double mouseX, double mouseY, int mouseButton) {
/*  82 */     getTextBox().mouseReleased(mouseX, mouseY, mouseButton);
/*  83 */     return super.mouseReleased(mouseX, mouseY, mouseButton);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean mouseDragged(double mouseX, double mouseY, int button, double mouseDX, double mouseDY) {
/*  90 */     getTextBox().mouseDragged(mouseX, mouseY, button, mouseDX, mouseDY);
/*  91 */     return super.mouseDragged(mouseX, mouseY, button, mouseDX, mouseDY);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean mouseClicked(double mouseX, double mouseY, int mouseButton) {
/*  97 */     return getTextBox().mouseClicked(mouseX, mouseY, 0);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean charTyped(char typedChar, int keyCode) {
/* 103 */     return getTextBox().charTyped(typedChar, keyCode);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean keyPressed(int key, int value, int modifier) {
/* 109 */     return getTextBox().keyPressed(key, value, modifier);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isFocused() {
/* 115 */     return getTextBox().isFocused();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isActive() {
/* 121 */     return getTextBox().isActive();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void setFocused(boolean focused) {
/* 127 */     getTextBox().setFocused(focused);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isHoveredOrFocused() {
/* 133 */     if (this.textBox != null)
/*     */     {
/* 135 */       return (getTextBox().isHovered() || getTextBox().isFocused());
/*     */     }
/* 137 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void setVisible(boolean visible) {
/* 143 */     getTextBox().setVisible(visible);
/* 144 */     super.setVisible(visible);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public int getCenterX() {
/* 150 */     return getTextBox().getCenterX();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public int getRightX() {
/* 156 */     return getTextBox().getRightX();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public int getBottomY() {
/* 162 */     return getTextBox().getBottomY();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public int getMiddleY() {
/* 168 */     return getTextBox().getMiddleY();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public int getWidth() {
/* 174 */     if (this.textBox != null)
/*     */     {
/* 176 */       return getTextBox().getWidth();
/*     */     }
/* 178 */     return this.width;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void setWidth(int width) {
/* 184 */     if (this.textBox != null)
/*     */     {
/* 186 */       getTextBox().setWidth(width);
/*     */     }
/* 188 */     this.width = width;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public int getHeight() {
/* 194 */     if (this.textBox != null)
/*     */     {
/* 196 */       return getTextBox().getHeight();
/*     */     }
/* 198 */     return this.height;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setText(String text) {
/* 203 */     getTextBox().setValue(text);
/*     */   }
/*     */ }


/* Location:              C:\Users\Administrator\Downloads\journeymap-neoforge-1.21-6.0.0-beta.18.jar!\journeymap\clien\\ui\component\buttons\TextBoxButton.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */