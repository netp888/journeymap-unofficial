/*     */ package journeymap.client.ui.component.buttons;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import journeymap.client.Constants;
/*     */ import journeymap.common.Journeymap;
/*     */ import journeymap.common.log.LogFormatter;
/*     */ import net.minecraft.client.gui.Font;
/*     */ import net.minecraft.client.gui.components.Button;
/*     */ import net.minecraft.network.chat.Component;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class OnOffButton
/*     */   extends Button
/*     */ {
/*  20 */   protected Boolean toggled = Boolean.valueOf(true);
/*     */   protected String labelOn;
/*     */   protected String labelOff;
/*  23 */   protected ArrayList<ToggleListener> toggleListeners = new ArrayList<>(0);
/*     */ 
/*     */   
/*     */   public OnOffButton(String labelOn, String labelOff, boolean toggled, Button.OnPress onPress) {
/*  27 */     super(toggled ? labelOn : labelOff, onPress);
/*  28 */     this.labelOn = labelOn;
/*  29 */     this.labelOff = labelOff;
/*  30 */     setToggled(Boolean.valueOf(toggled));
/*  31 */     finishInit();
/*     */   }
/*     */ 
/*     */   
/*     */   public void setLabels(String labelOn, String labelOff) {
/*  36 */     this.labelOn = labelOn;
/*  37 */     this.labelOff = labelOff;
/*  38 */     updateLabel();
/*     */   }
/*     */ 
/*     */   
/*     */   protected void updateLabel() {
/*  43 */     if (this.labelOn != null && this.labelOff != null)
/*     */     {
/*  45 */       setMessage((Component)Constants.getStringTextComponent(getToggled().booleanValue() ? this.labelOn : this.labelOff));
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public void toggle() {
/*  51 */     setToggled(Boolean.valueOf(!getToggled().booleanValue()));
/*     */   }
/*     */ 
/*     */   
/*     */   public int getFitWidth(Font fr) {
/*  56 */     int max = fr.width(getMessage().getString());
/*  57 */     if (this.labelOn != null)
/*     */     {
/*  59 */       max = Math.max(max, fr.width(this.labelOn));
/*     */     }
/*  61 */     if (this.labelOff != null)
/*     */     {
/*  63 */       max = Math.max(max, fr.width(this.labelOff));
/*     */     }
/*  65 */     return max + this.WIDTH_PAD;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isActive() {
/*  71 */     return (isEnabled() && this.toggled.booleanValue());
/*     */   }
/*     */ 
/*     */   
/*     */   public Boolean getToggled() {
/*  76 */     return this.toggled;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setToggled(Boolean toggled) {
/*  81 */     setToggled(toggled, true);
/*     */   }
/*     */ 
/*     */   
/*     */   public void setToggled(Boolean toggled, boolean notifyToggleListener) {
/*  86 */     if (this.toggled == toggled || !isEnabled() || !this.visible) {
/*     */       return;
/*     */     }
/*     */ 
/*     */     
/*  91 */     boolean allowChange = true;
/*     */     
/*     */     try {
/*  94 */       if (notifyToggleListener && !this.toggleListeners.isEmpty())
/*     */       {
/*  96 */         for (ToggleListener listener : this.toggleListeners)
/*     */         {
/*  98 */           allowChange = listener.onToggle(this, toggled.booleanValue());
/*  99 */           if (!allowChange) {
/*     */             break;
/*     */           }
/*     */         }
/*     */       
/*     */       }
/*     */     }
/* 106 */     catch (Throwable t) {
/*     */       
/* 108 */       Journeymap.getLogger().error("Error trying to toggle button '" + String.valueOf(getMessage()) + "': " + LogFormatter.toString(t));
/* 109 */       allowChange = false;
/*     */     } 
/*     */     
/* 112 */     if (allowChange) {
/*     */       
/* 114 */       this.toggled = toggled;
/* 115 */       updateLabel();
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void addToggleListener(ToggleListener toggleListener) {
/* 121 */     this.toggleListeners.add(toggleListener);
/*     */   }
/*     */   
/*     */   public static interface ToggleListener {
/*     */     boolean onToggle(OnOffButton param1OnOffButton, boolean param1Boolean);
/*     */   }
/*     */ }


/* Location:              C:\Users\Administrator\Downloads\journeymap-neoforge-1.21-6.0.0-beta.18.jar!\journeymap\clien\\ui\component\buttons\OnOffButton.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */