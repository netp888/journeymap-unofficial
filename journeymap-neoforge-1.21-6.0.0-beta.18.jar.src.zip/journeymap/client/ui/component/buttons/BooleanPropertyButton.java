/*    */ package journeymap.client.ui.component.buttons;
/*    */ 
/*    */ import journeymap.client.ui.component.IConfigFieldHolder;
/*    */ import journeymap.common.properties.config.BooleanField;
/*    */ import journeymap.common.properties.config.ConfigField;
/*    */ import net.minecraft.client.gui.components.Button;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class BooleanPropertyButton
/*    */   extends OnOffButton
/*    */   implements IConfigFieldHolder<BooleanField>
/*    */ {
/*    */   final BooleanField booleanField;
/*    */   
/*    */   public BooleanPropertyButton(String labelOn, String labelOff, BooleanField field, Button.OnPress onPress) {
/* 20 */     super(labelOn, labelOff, (field != null && field.get().booleanValue()), onPress);
/* 21 */     this.booleanField = field;
/*    */   }
/*    */ 
/*    */   
/*    */   public BooleanField getField() {
/* 26 */     return this.booleanField;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public void toggle() {
/* 32 */     if (isEnabled())
/*    */     {
/* 34 */       if (this.booleanField != null) {
/*    */         
/* 36 */         setToggled(Boolean.valueOf(this.booleanField.toggleAndSave()));
/*    */       }
/*    */       else {
/*    */         
/* 40 */         setToggled(Boolean.valueOf(!this.toggled.booleanValue()));
/*    */       } 
/*    */     }
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public void refresh() {
/* 48 */     if (this.booleanField != null)
/*    */     {
/* 50 */       setToggled(this.booleanField.get());
/*    */     }
/*    */   }
/*    */ 
/*    */   
/*    */   public void setValue(Boolean value) {
/* 56 */     if (this.booleanField == null) {
/*    */       
/* 58 */       this.toggled = value;
/*    */     }
/*    */     else {
/*    */       
/* 62 */       this.booleanField.set(value);
/* 63 */       this.booleanField.save();
/*    */     } 
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public BooleanField getConfigField() {
/* 70 */     return this.booleanField;
/*    */   }
/*    */ }


/* Location:              C:\Users\Administrator\Downloads\journeymap-neoforge-1.21-6.0.0-beta.18.jar!\journeymap\clien\\ui\component\buttons\BooleanPropertyButton.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */