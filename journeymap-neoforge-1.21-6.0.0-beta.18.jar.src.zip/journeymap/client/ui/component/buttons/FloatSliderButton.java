/*     */ package journeymap.client.ui.component.buttons;
/*     */ 
/*     */ import java.math.BigDecimal;
/*     */ import journeymap.client.Constants;
/*     */ import journeymap.client.ui.component.IConfigFieldHolder;
/*     */ import journeymap.common.properties.config.ConfigField;
/*     */ import journeymap.common.properties.config.FloatField;
/*     */ import net.minecraft.client.gui.Font;
/*     */ import net.minecraft.network.chat.Component;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class FloatSliderButton
/*     */   extends AbstractSliderButton
/*     */   implements IConfigFieldHolder<FloatField>, SliderButton
/*     */ {
/*  25 */   public String prefix = "";
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean dragging = false;
/*     */ 
/*     */ 
/*     */   
/*  33 */   public float minValue = 0.0F;
/*     */ 
/*     */ 
/*     */   
/*  37 */   public float maxValue = 0.0F;
/*     */ 
/*     */ 
/*     */   
/*  41 */   public String suffix = "";
/*     */ 
/*     */   
/*     */   public boolean drawString = true;
/*     */ 
/*     */   
/*  47 */   private float incrementValue = 0.1F;
/*  48 */   private int precision = 2;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   FloatField field;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public FloatSliderButton(FloatField field, String prefix, String suf) {
/*  63 */     this(field, prefix, suf, field.getMinValue(), field.getMaxValue());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public FloatSliderButton(FloatField field, String prefix, String suf, float minVal, float maxVal) {
/*  77 */     this(field, prefix, suf, minVal, maxVal, field.getIncrementValue(), field.getPrecision());
/*     */   }
/*     */ 
/*     */   
/*     */   public FloatSliderButton(FloatField field, String prefix, String suf, float minVal, float maxVal, float incrementValue, int precision) {
/*  82 */     super((ConfigField<?>)field, prefix);
/*  83 */     this.minValue = minVal;
/*  84 */     this.maxValue = maxVal;
/*  85 */     this.prefix = prefix;
/*  86 */     this.suffix = suf;
/*  87 */     this.field = field;
/*  88 */     setValue(field.get().floatValue());
/*  89 */     this.disabledLabelColor = Integer.valueOf(4210752);
/*  90 */     this.incrementValue = incrementValue;
/*  91 */     this.precision = precision;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean mouseDragged(double mouseX, double mouseY, int button, double mouseDX, double mouseDY) {
/*  97 */     if (this.visible && isEnabled() && isMouseOver(mouseX, mouseY) && this.dragging) {
/*     */       
/*  99 */       setValueFromMouse(mouseX);
/* 100 */       if (this.clickListeners != null)
/*     */       {
/* 102 */         checkClickListeners();
/*     */       }
/* 104 */       return true;
/*     */     } 
/* 106 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   private void setValueFromMouse(double mouseX) {
/* 111 */     setSliderValue((mouseX - (getX() + 4)) / (this.width - 8));
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean mouseClicked(double mouseX, double mouseY, int button) {
/* 117 */     if (mouseOver(mouseX, mouseY)) {
/*     */       
/* 119 */       this.dragging = true;
/* 120 */       setValueFromMouse(mouseX);
/* 121 */       checkClickListeners();
/* 122 */       return true;
/*     */     } 
/* 124 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public double getSliderValue() {
/* 135 */     return ((this.field.get().floatValue() - this.minValue) / (this.maxValue - this.minValue));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setSliderValue(double sliderValue) {
/* 145 */     float val = (float)sliderValue * (this.maxValue - this.minValue) + this.minValue;
/* 146 */     setValue(val);
/*     */   }
/*     */ 
/*     */   
/*     */   public void updateLabel() {
/* 151 */     if (this.drawString)
/*     */     {
/* 153 */       setMessage((Component)Constants.getStringTextComponent(this.prefix + this.prefix + this.field.get()));
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean mouseReleased(double mouseX, double mouseY, int mouseButton) {
/* 163 */     if (this.dragging) {
/*     */       
/* 165 */       this.dragging = false;
/* 166 */       this.field.save();
/* 167 */       checkClickListeners();
/*     */     } 
/* 169 */     return super.mouseReleased(mouseX, mouseY, mouseButton);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public int getFitWidth(Font fr) {
/* 175 */     int max = fr.width(this.prefix + this.prefix + this.minValue);
/* 176 */     max = Math.max(max, fr.width(this.prefix + this.prefix + this.maxValue));
/* 177 */     return max + this.WIDTH_PAD;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean keyPressed(int key, int value, int modifier) {
/* 183 */     if (isEnabled()) {
/*     */       
/* 185 */       if (key == 263 || key == 45) {
/*     */         
/* 187 */         setValue(Math.max(this.minValue, getValue() - this.incrementValue));
/* 188 */         if (this.clickListeners != null)
/*     */         {
/* 190 */           checkClickListeners();
/*     */         }
/* 192 */         return true;
/*     */       } 
/*     */       
/* 195 */       if (key == 262 || key == 61) {
/*     */         
/* 197 */         setValue(Math.min(this.maxValue, getValue() + this.incrementValue));
/* 198 */         if (this.clickListeners != null)
/*     */         {
/* 200 */           checkClickListeners();
/*     */         }
/* 202 */         return true;
/*     */       } 
/*     */     } 
/* 205 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public float getValue() {
/* 215 */     return this.field.get().floatValue();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setValue(float value) {
/* 225 */     float roundedValue = (new BigDecimal(value)).setScale(this.precision, 4).floatValue();
/* 226 */     roundedValue = Math.min(roundedValue, this.maxValue);
/* 227 */     roundedValue = Math.max(roundedValue, this.minValue);
/* 228 */     if (this.field.get().floatValue() != roundedValue) {
/*     */       
/* 230 */       this.field.set(Float.valueOf(roundedValue));
/* 231 */       if (!this.dragging)
/*     */       {
/* 233 */         this.field.save();
/*     */       }
/*     */     } 
/* 236 */     updateLabel();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void refresh() {
/* 242 */     setValue(this.field.get().floatValue());
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public FloatField getConfigField() {
/* 248 */     return this.field;
/*     */   }
/*     */ }


/* Location:              C:\Users\Administrator\Downloads\journeymap-neoforge-1.21-6.0.0-beta.18.jar!\journeymap\clien\\ui\component\buttons\FloatSliderButton.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */