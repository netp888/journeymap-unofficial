/*    */ package journeymap.client.ui.component.buttons;
/*    */ 
/*    */ import journeymap.common.properties.config.ConfigField;
/*    */ import net.minecraft.client.Minecraft;
/*    */ import net.minecraft.client.gui.GuiGraphics;
/*    */ import net.minecraft.client.gui.components.Button;
/*    */ import net.minecraft.resources.ResourceLocation;
/*    */ 
/*    */ public abstract class AbstractSliderButton
/*    */   extends FieldButton {
/* 11 */   private static final ResourceLocation SLIDER_HANDLE_SPRITE = ResourceLocation.withDefaultNamespace("widget/slider_handle");
/* 12 */   private static final ResourceLocation SLIDER_HANDLE_HIGHLIGHTED_SPRITE = ResourceLocation.withDefaultNamespace("widget/slider_handle_highlighted");
/*    */ 
/*    */   
/*    */   public AbstractSliderButton(ConfigField<?> field, String label) {
/* 16 */     super(field, label);
/*    */   }
/*    */ 
/*    */   
/*    */   public AbstractSliderButton(ConfigField<?> field, String label, Button.OnPress onPress) {
/* 21 */     super(field, label, onPress);
/*    */   }
/*    */ 
/*    */   
/*    */   public AbstractSliderButton(ConfigField<?> field, int width, int height, String label, Button.OnPress onPress) {
/* 26 */     super(field, width, height, label, onPress);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   private ResourceLocation getHandleSprite() {
/* 32 */     return !this.isHovered ? SLIDER_HANDLE_SPRITE : SLIDER_HANDLE_HIGHLIGHTED_SPRITE;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   protected void renderBg(GuiGraphics graphics, Minecraft mc, int mouseX, int mouseY) {
/* 38 */     double sliderValue = getSliderValue();
/*    */     
/* 40 */     graphics.blitSprite(getHandleSprite(), 
/* 41 */         getX() + 1 + (int)(sliderValue * (this.width - 10)), 
/* 42 */         getY() + 1, 8, this.height - 2);
/*    */   }
/*    */   
/*    */   public abstract double getSliderValue();
/*    */ }


/* Location:              C:\Users\Administrator\Downloads\journeymap-neoforge-1.21-6.0.0-beta.18.jar!\journeymap\clien\\ui\component\buttons\AbstractSliderButton.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */