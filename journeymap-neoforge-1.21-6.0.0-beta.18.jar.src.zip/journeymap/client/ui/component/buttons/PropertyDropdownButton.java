/*     */ package journeymap.client.ui.component.buttons;
/*     */ 
/*     */ import com.google.common.collect.Lists;
/*     */ import java.util.Collection;
/*     */ import java.util.List;
/*     */ import journeymap.api.v2.client.option.KeyedEnum;
/*     */ import journeymap.client.Constants;
/*     */ import journeymap.client.ui.component.DropDownItem;
/*     */ import journeymap.client.ui.component.IConfigFieldHolder;
/*     */ import journeymap.common.Journeymap;
/*     */ import journeymap.common.log.LogFormatter;
/*     */ import journeymap.common.properties.config.ConfigField;
/*     */ import journeymap.common.properties.config.StringField;
/*     */ import net.minecraft.client.gui.Font;
/*     */ import net.minecraft.client.gui.components.Button;
/*     */ import net.minecraft.network.chat.Component;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class PropertyDropdownButton<T>
/*     */   extends DropDownButton
/*     */   implements IConfigFieldHolder<ConfigField<T>>
/*     */ {
/*     */   protected final ConfigField<T> field;
/*     */   protected final String baseLabel;
/*  31 */   protected final String glyph = "⇕";
/*  32 */   protected final String labelPattern = "%1$s : %2$s %3$s %2$s";
/*     */   
/*     */   private final Collection<T> values;
/*     */   protected Button.OnPress pressable;
/*     */   
/*     */   public PropertyDropdownButton(Collection<T> values, String label, ConfigField<T> field, Button.OnPress pressable) {
/*  38 */     super("", pressable);
/*  39 */     this.pressable = pressable;
/*  40 */     this.field = field;
/*  41 */     this.baseLabel = label;
/*  42 */     this.values = values;
/*  43 */     setValue((T)field.get());
/*  44 */     this.disabledLabelColor = Integer.valueOf(4210752);
/*  45 */     List<DropDownItem> items = setItems(values);
/*  46 */     setItems(items);
/*  47 */     setRenderDecorations(true);
/*  48 */     setRenderSolidBackground(true);
/*     */   }
/*     */ 
/*     */   
/*     */   public PropertyDropdownButton(Collection<T> values, String label, ConfigField<T> field) {
/*  53 */     this(values, label, field, emptyPressable());
/*     */   }
/*     */ 
/*     */   
/*     */   protected List<DropDownItem> setItems(Collection<T> values) {
/*  58 */     List<DropDownItem> items = Lists.newArrayList();
/*  59 */     values.forEach(value -> {
/*     */           String label;
/*     */           
/*     */           String tooltip = null;
/*     */           
/*     */           if (value instanceof KeyedEnum) {
/*     */             String key = ((KeyedEnum)value).getKey();
/*     */             
/*     */             label = Constants.getString(key);
/*     */             
/*     */             String tooltipKey = key + ".tooltip";
/*     */             
/*     */             tooltip = Constants.getString(tooltipKey);
/*     */             
/*     */             if (tooltipKey.equals(tooltip)) {
/*     */               tooltip = null;
/*     */             }
/*     */           } else if (value instanceof String) {
/*     */             label = Constants.getString((String)value);
/*     */             
/*     */             Class<? extends StringField.ValuesProvider> valueProviderClass = ((StringField)this.field).getValuesProviderClass();
/*     */             
/*     */             try {
/*     */               StringField.ValuesProvider valueProvider = valueProviderClass.newInstance();
/*     */               tooltip = valueProvider.getTooltip((String)value);
/*  84 */             } catch (Throwable t) {
/*     */               Journeymap.getLogger().error(String.format("Couldn't use ValuesProvider %s: %s", new Object[] { valueProviderClass, LogFormatter.toString(t) }));
/*     */             } 
/*     */           } else {
/*     */             label = Constants.getString(value.toString());
/*     */           } 
/*     */ 
/*     */ 
/*     */ 
/*     */           
/*     */           if (tooltip == null) {
/*     */             items.add(new DropDownItem(this, value, label));
/*     */           } else {
/*     */             items.add(new DropDownItem(this, value, label, new String[] { tooltip }));
/*     */           } 
/*     */         });
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 104 */     return items;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void setSelected(DropDownItem selected) {
/* 110 */     this.selected = selected;
/* 111 */     setValue((T)selected.getId());
/* 112 */     this.onPress.onPress((Button)selected);
/*     */   }
/*     */   
/*     */   public void setValue(T value) {
/*     */     String label;
/* 117 */     if (!this.field.get().equals(value)) {
/*     */       
/* 119 */       this.field.set(value);
/* 120 */       this.field.save();
/*     */     } 
/*     */     
/* 123 */     if (value instanceof KeyedEnum) {
/*     */       
/* 125 */       label = Constants.getString(((KeyedEnum)value).getKey());
/*     */     }
/*     */     else {
/*     */       
/* 129 */       label = Constants.getString(value.toString());
/*     */     } 
/*     */     
/* 132 */     setMessage((Component)Constants.getStringTextComponent(getFormattedLabel(label)));
/*     */   }
/*     */ 
/*     */   
/*     */   public ConfigField<T> getField() {
/* 137 */     return this.field;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public int getFitWidth(Font fr) {
/* 143 */     int max = fr.width(getMessage().getString());
/* 144 */     for (DropDownItem item : this.items)
/*     */     {
/* 146 */       max = Math.max(max, fr.width(getFormattedLabel(item.getLabel())));
/*     */     }
/* 148 */     return max + this.buttonBuffer;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public int getWidth() {
/* 154 */     return this.width;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void setWidth(int width) {
/* 160 */     if (this.paneScreen != null)
/*     */     {
/* 162 */       this.paneScreen.setPaneWidth(width);
/*     */     }
/* 164 */     super.setWidth(width);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected String getLabel(DropDownItem item) {
/* 170 */     return getFormattedLabel(item.getLabel());
/*     */   }
/*     */ 
/*     */   
/*     */   protected String getFormattedLabel(String value) {
/* 175 */     return String.format("%1$s : %2$s %3$s %2$s", new Object[] { this.baseLabel, "⇕", value });
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void refresh() {
/* 181 */     setValue((T)this.field.get());
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public ConfigField<T> getConfigField() {
/* 187 */     return this.field;
/*     */   }
/*     */ }


/* Location:              C:\Users\Administrator\Downloads\journeymap-neoforge-1.21-6.0.0-beta.18.jar!\journeymap\clien\\ui\component\buttons\PropertyDropdownButton.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */