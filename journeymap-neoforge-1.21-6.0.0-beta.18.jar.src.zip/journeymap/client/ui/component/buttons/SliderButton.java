package journeymap.client.ui.component.buttons;

public interface SliderButton {
  boolean mouseDragged(double paramDouble1, double paramDouble2, int paramInt, double paramDouble3, double paramDouble4);
}


/* Location:              C:\Users\Administrator\Downloads\journeymap-neoforge-1.21-6.0.0-beta.18.jar!\journeymap\clien\\ui\component\buttons\SliderButton.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */