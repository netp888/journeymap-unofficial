/*    */ package journeymap.client.ui.component.buttons;
/*    */ 
/*    */ import journeymap.client.ui.component.IConfigFieldHolder;
/*    */ import journeymap.client.ui.component.TextBox;
/*    */ import journeymap.common.properties.config.ConfigField;
/*    */ import journeymap.common.properties.config.CustomField;
/*    */ import net.minecraft.client.gui.Font;
/*    */ 
/*    */ public class TextFieldButton extends TextBoxButton implements IConfigFieldHolder<CustomField> {
/*    */   protected final CustomField field;
/* 11 */   private int WIDTH_BUFFER = 50;
/*    */ 
/*    */   
/*    */   public TextFieldButton(CustomField field) {
/* 15 */     super(field.get().toString());
/* 16 */     this.field = field;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   protected TextBox getTextBox() {
/* 22 */     if (this.textBox == null) {
/*    */       
/* 24 */       if (this.field.isNumber()) {
/*    */         
/* 26 */         this.textBox = new TextBox(this.field.get().toString(), this.fontRenderer, this.width, this.height, this.field.isNumber(), this.field.allowNeg());
/* 27 */         this.textBox.setClamp(Integer.valueOf(this.field.getMinValue()), Integer.valueOf(this.field.getMaxValue()));
/*    */       }
/*    */       else {
/*    */         
/* 31 */         this.textBox = new TextBox(this.field.get().toString(), this.fontRenderer, this.width, this.height);
/*    */       } 
/* 33 */       this.textBox.setY(this.textBox.getY() - 1);
/* 34 */       this.textBox.setHeight(this.textBox.getHeight() - 4);
/*    */     } 
/* 36 */     return this.textBox;
/*    */   }
/*    */ 
/*    */   
/*    */   public void setValue(Object value) {
/* 41 */     if (!this.field.get().equals(value)) {
/*    */       
/* 43 */       this.field.set(value);
/* 44 */       this.field.save();
/*    */     } 
/* 46 */     getTextBox().setText(value);
/*    */   }
/*    */ 
/*    */   
/*    */   public void updateValue(Object value) {
/* 51 */     if (!this.field.get().equals(value)) {
/*    */       
/* 53 */       this.field.set(value);
/* 54 */       this.field.save();
/*    */     } 
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public boolean charTyped(char typedChar, int keyCode) {
/* 61 */     boolean press = getTextBox().charTyped(typedChar, keyCode);
/* 62 */     updateValue(getTextBox().getValue());
/* 63 */     return press;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public boolean keyPressed(int key, int value, int modifier) {
/* 69 */     boolean press = getTextBox().keyPressed(key, value, modifier);
/* 70 */     updateValue(getTextBox().getValue());
/* 71 */     return press;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public int getFitWidth(Font fr) {
/* 77 */     return fr.width(getTextBox().getValue()) + this.WIDTH_PAD + this.WIDTH_BUFFER;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public CustomField getConfigField() {
/* 84 */     return this.field;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public void refresh() {
/* 90 */     setValue(this.field.get());
/*    */   }
/*    */ }


/* Location:              C:\Users\Administrator\Downloads\journeymap-neoforge-1.21-6.0.0-beta.18.jar!\journeymap\clien\\ui\component\buttons\TextFieldButton.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */