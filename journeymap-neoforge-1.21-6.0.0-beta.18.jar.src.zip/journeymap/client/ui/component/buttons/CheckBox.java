/*     */ package journeymap.client.ui.component.buttons;
/*     */ 
/*     */ import java.util.Objects;
/*     */ import journeymap.common.properties.config.BooleanField;
/*     */ import net.minecraft.client.gui.Font;
/*     */ import net.minecraft.client.gui.GuiGraphics;
/*     */ import net.minecraft.client.gui.components.Button;
/*     */ import net.minecraft.client.gui.navigation.CommonInputs;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class CheckBox
/*     */   extends BooleanPropertyButton
/*     */ {
/*  22 */   public int boxWidth = 11;
/*     */ 
/*     */ 
/*     */   
/*  26 */   String glyph = "✔";
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public CheckBox(String label, boolean checked, Button.OnPress pressable) {
/*  36 */     this(label, (BooleanField)null, pressable);
/*  37 */     this.toggled = Boolean.valueOf(checked);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public CheckBox(String label, BooleanField field, Button.OnPress pressable) {
/*  48 */     super(label, label, field, pressable);
/*     */     
/*  50 */     Objects.requireNonNull(this.fontRenderer); setHeight(9 + 2);
/*  51 */     setWidth(getFitWidth(this.fontRenderer));
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public CheckBox(String label, boolean checked) {
/*  57 */     this(label, checked, emptyPressable());
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public CheckBox(String label, BooleanField field) {
/*  63 */     this(label, field, emptyPressable());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getFitWidth(Font fr) {
/*  70 */     return super.getFitWidth(fr) + this.boxWidth + 2;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void renderWidget(GuiGraphics graphics, int mouseX, int mouseY, float ticks) {
/*  80 */     if (this.booleanField != null && this.booleanField.hasEnabledAttribute())
/*     */     {
/*  82 */       setEnabled(this.booleanField.isEnabled());
/*     */     }
/*     */     
/*  85 */     if (this.visible) {
/*     */ 
/*     */       
/*  88 */       setHovered((isEnabled() && mouseX >= getX() && mouseY >= getY() && mouseX < getX() + this.width && mouseY < getY() + this.height));
/*     */       
/*  90 */       int yoffset = (this.height - this.boxWidth) / 2;
/*  91 */       graphics.blitSprite(Button.SPRITES.disabled(), 
/*  92 */           getX(), 
/*  93 */           getY() + yoffset, this.boxWidth, this.boxWidth);
/*     */ 
/*     */       
/*  96 */       mouseDragged(mouseX, mouseY, 0, getX(), getY());
/*  97 */       int color = 14737632;
/*     */       
/*  99 */       if (isHoveredOrFocused()) {
/*     */         
/* 101 */         color = 16777120;
/*     */       }
/* 103 */       else if (!isEnabled()) {
/*     */         
/* 105 */         color = 4210752;
/*     */       }
/* 107 */       else if (this.labelColor != null) {
/*     */         
/* 109 */         color = this.labelColor.intValue();
/*     */       }
/* 111 */       else if (getActiveColor() != 0) {
/*     */         
/* 113 */         color = getActiveColor();
/*     */       } 
/*     */       
/* 116 */       int labelPad = 4;
/*     */       
/* 118 */       if (this.toggled.booleanValue())
/*     */       {
/* 120 */         graphics.drawCenteredString(this.fontRenderer, this.glyph, getX() + this.boxWidth / 2 + 1, getY() + 1 + yoffset, color);
/*     */       }
/*     */       
/* 123 */       graphics.drawString(this.fontRenderer, getMessage(), getX() + this.boxWidth + labelPad, getY() + 2 + yoffset, color);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean mouseClicked(double mouseX, double mouseY, int button) {
/* 134 */     if (isEnabled() && this.visible && mouseX >= getX() && mouseY >= getY() && mouseX < (getX() + this.width) && mouseY < (getY() + this.height))
/*     */     {
/* 136 */       toggle();
/*     */     }
/*     */     
/* 139 */     return super.mouseClicked(mouseX, mouseY, button);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean keyPressed(int key, int value, int modifier) {
/* 145 */     if (isEnabled() && this.visible)
/*     */     {
/* 147 */       if (CommonInputs.selected(key)) {
/*     */         
/* 149 */         toggle();
/* 150 */         return true;
/*     */       } 
/*     */     }
/* 153 */     return false;
/*     */   }
/*     */ }


/* Location:              C:\Users\Administrator\Downloads\journeymap-neoforge-1.21-6.0.0-beta.18.jar!\journeymap\clien\\ui\component\buttons\CheckBox.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */