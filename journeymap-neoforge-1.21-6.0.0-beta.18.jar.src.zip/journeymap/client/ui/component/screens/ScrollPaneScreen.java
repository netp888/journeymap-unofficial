/*     */ package journeymap.client.ui.component.screens;
/*     */ 
/*     */ import java.util.List;
/*     */ import journeymap.client.ui.component.DropDownItem;
/*     */ import journeymap.client.ui.component.Removable;
/*     */ import journeymap.client.ui.component.ScrollPane;
/*     */ import journeymap.client.ui.component.buttons.Button;
/*     */ import net.minecraft.client.Minecraft;
/*     */ import net.minecraft.client.gui.GuiGraphics;
/*     */ import net.minecraft.network.chat.Component;
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ScrollPaneScreen
/*     */   extends LayeredScreen
/*     */ {
/*     */   private static final int MAX_DISPLAY_SIZE = 6;
/*     */   protected ScrollPane scrollPane;
/*     */   protected Removable removable;
/*     */   private int paneWidth;
/*     */   private int paneHeight;
/*     */   public boolean visible = false;
/*     */   private int paneX;
/*     */   private int paneY;
/*     */   private List<DropDownItem> items;
/*     */   protected boolean renderDecorations = true;
/*     */   protected boolean renderSolidBackground = false;
/*     */   
/*     */   public ScrollPaneScreen(Removable parent, List<DropDownItem> items, int paneWidth, int paneHeight, int paneX, int paneY) {
/*  30 */     super((Component)Component.literal(""));
/*  31 */     this.removable = parent;
/*  32 */     this.paneWidth = paneWidth;
/*  33 */     this.paneHeight = paneHeight;
/*  34 */     this.paneX = paneX;
/*  35 */     this.paneY = paneY;
/*  36 */     this.items = items;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean mouseClicked(double mouseX, double mouseY, int button) {
/*  42 */     boolean paneClicked = this.scrollPane.mouseClicked(mouseX, mouseY, button);
/*  43 */     DropDownItem pressed = (DropDownItem)this.scrollPane.mouseClicked((int)mouseX, (int)mouseX, button);
/*  44 */     this.scrollPane.scrolling = false;
/*  45 */     boolean mouseOver = this.scrollPane.isMouseOver(mouseX, mouseY);
/*  46 */     if (mouseOver) {
/*     */       
/*  48 */       this.scrollPane.updateScrollingState(mouseX, mouseY, button);
/*  49 */       if (pressed != null)
/*     */       {
/*  51 */         onClick(pressed);
/*  52 */         return true;
/*     */       }
/*     */     
/*     */     } else {
/*     */       
/*  57 */       onClose();
/*  58 */       return false;
/*     */     } 
/*     */ 
/*     */     
/*  62 */     return super.mouseClicked(mouseX, mouseY, button);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void renderPopupScreen(GuiGraphics graphics, int mouseX, int mouseY, float partialTicks) {
/*  68 */     if (this.scrollPane != null) {
/*     */       
/*  70 */       this.scrollPane.setDimensions(this.paneWidth - 6, this.paneHeight, 0, 0, this.paneX + 2, this.paneY);
/*  71 */       this.scrollPane.render(graphics, mouseX, mouseY, partialTicks);
/*  72 */       if (this.visible && this.scrollPane.isMouseOver(mouseX, mouseY))
/*     */       {
/*  74 */         renderTooltip(graphics, mouseX, mouseY);
/*     */       }
/*  76 */       super.renderPopupScreen(graphics, mouseX, mouseY, partialTicks);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   private void renderTooltip(GuiGraphics graphics, int mouseX, int mouseY) {
/*  82 */     Button button = this.scrollPane.getButton(mouseX, mouseY);
/*  83 */     if (button != null)
/*     */     {
/*  85 */       graphics.renderTooltip(this.font, button.getWrappedTooltip(), mouseX, mouseY);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public void setRenderSolidBackground(boolean renderSolidBackground) {
/*  91 */     this.renderSolidBackground = renderSolidBackground;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean mouseOverPane(double x, double y) {
/*  96 */     return this.scrollPane.isMouseOver(x, y);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean mouseScrolled(double x, double y, double f, double scroll) {
/* 102 */     if (this.scrollPane.isMouseOver(x, y))
/*     */     {
/* 104 */       return this.scrollPane.mouseScrolled(x, y, f, scroll);
/*     */     }
/* 106 */     return super.mouseScrolled(x, y, f, scroll);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean mouseReleased(double mouseX, double mouseY, int mouseButton) {
/* 112 */     this.scrollPane.mouseReleased(mouseX, mouseY, mouseButton);
/* 113 */     return super.mouseReleased(mouseX, mouseY, mouseButton);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean mouseDragged(double mouseX, double mouseY, int button, double mouseDX, double mouseDY) {
/* 119 */     this.scrollPane.mouseDragged(mouseX, mouseY, button, mouseDX, mouseDY);
/* 120 */     return super.mouseDragged(mouseX, mouseY, button, mouseDX, mouseDY);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void mouseMoved(double mouseX, double mouseY) {
/* 126 */     this.scrollPane.mouseMoved(mouseX, mouseY);
/* 127 */     super.mouseMoved(mouseX, mouseY);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean keyReleased(int keyCode, int scanCode, int modifiers) {
/* 133 */     this.scrollPane.keyReleased(keyCode, scanCode, modifiers);
/* 134 */     return super.keyReleased(keyCode, scanCode, modifiers);
/*     */   }
/*     */ 
/*     */   
/*     */   public void setPaneWidth(int paneWidth) {
/* 139 */     this.paneWidth = paneWidth;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setPaneHeight(int paneHeight) {
/* 144 */     this.paneHeight = paneHeight;
/*     */   }
/*     */ 
/*     */   
/*     */   public int getPaneWidth() {
/* 149 */     if (this.scrollPane != null)
/*     */     {
/* 151 */       return this.scrollPane.getWidth();
/*     */     }
/* 153 */     return this.paneWidth;
/*     */   }
/*     */ 
/*     */   
/*     */   public int getPaneHeight() {
/* 158 */     return this.paneHeight;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setPaneX(int paneX) {
/* 163 */     this.paneX = paneX;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setPaneY(int paneY) {
/* 168 */     this.paneY = paneY;
/*     */   }
/*     */ 
/*     */   
/*     */   public int getPaneX() {
/* 173 */     return this.paneX;
/*     */   }
/*     */ 
/*     */   
/*     */   public int getPaneY() {
/* 178 */     return this.paneY;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setParent(Removable removable) {
/* 183 */     this.removable = removable;
/*     */   }
/*     */ 
/*     */   
/*     */   public ScrollPane getScrollPane() {
/* 188 */     return this.scrollPane;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isPauseScreen() {
/* 193 */     return this.backgroundScreen.isPauseScreen();
/*     */   }
/*     */ 
/*     */   
/*     */   public void setItems(List<DropDownItem> items) {
/* 198 */     this.items = items;
/*     */   }
/*     */ 
/*     */   
/*     */   public void display() {
/* 203 */     this.scrollPane = new ScrollPane(null, Minecraft.getInstance(), 0, 0, this.items, ((DropDownItem)this.items.get(0)).getHeight(), 2);
/* 204 */     this.scrollPane.setDrawPartialScrollable(false);
/* 205 */     this.scrollPane.setRenderSelection(false);
/* 206 */     this.scrollPane.setRenderDecorations(this.renderDecorations);
/* 207 */     this.scrollPane.setRenderSolidBackground(this.renderSolidBackground);
/* 208 */     super.display();
/* 209 */     this.visible = true;
/*     */   }
/*     */ 
/*     */   
/*     */   public void onClick(DropDownItem pressed) {
/* 214 */     onClose();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void onClose() {
/* 220 */     this.visible = false;
/* 221 */     this.removable.onRemove();
/* 222 */     super.onClose();
/*     */   }
/*     */ 
/*     */   
/*     */   public void setRenderDecorations(boolean renderDecorations) {
/* 227 */     this.renderDecorations = renderDecorations;
/*     */   }
/*     */ }


/* Location:              C:\Users\Administrator\Downloads\journeymap-neoforge-1.21-6.0.0-beta.18.jar!\journeymap\clien\\ui\component\screens\ScrollPaneScreen.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */