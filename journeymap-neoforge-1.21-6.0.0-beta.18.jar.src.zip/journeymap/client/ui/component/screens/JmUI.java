/*     */ package journeymap.client.ui.component.screens;
/*     */ 
/*     */ import java.awt.Color;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Objects;
/*     */ import java.util.Stack;
/*     */ import journeymap.client.Constants;
/*     */ import journeymap.client.render.RenderWrapper;
/*     */ import journeymap.client.render.draw.DrawUtil;
/*     */ import journeymap.client.ui.UIManager;
/*     */ import journeymap.client.ui.component.LogoWidget;
/*     */ import journeymap.client.ui.component.UnscaledStringWidget;
/*     */ import journeymap.client.ui.component.buttons.Button;
/*     */ import journeymap.common.Journeymap;
/*     */ import net.minecraft.client.Minecraft;
/*     */ import net.minecraft.client.gui.Font;
/*     */ import net.minecraft.client.gui.GuiGraphics;
/*     */ import net.minecraft.client.gui.components.AbstractWidget;
/*     */ import net.minecraft.client.gui.components.Renderable;
/*     */ import net.minecraft.client.gui.components.StringWidget;
/*     */ import net.minecraft.client.gui.components.events.GuiEventListener;
/*     */ import net.minecraft.client.gui.layouts.FrameLayout;
/*     */ import net.minecraft.client.gui.layouts.GridLayout;
/*     */ import net.minecraft.client.gui.layouts.Layout;
/*     */ import net.minecraft.client.gui.layouts.LayoutElement;
/*     */ import net.minecraft.client.gui.layouts.LinearLayout;
/*     */ import net.minecraft.client.gui.screens.Screen;
/*     */ import net.minecraft.client.renderer.MultiBufferSource;
/*     */ import net.minecraft.client.renderer.RenderType;
/*     */ import net.minecraft.network.chat.Component;
/*     */ import net.minecraft.util.FormattedCharSequence;
/*     */ import org.apache.logging.log4j.Logger;
/*     */ import org.joml.Matrix4f;
/*     */ 
/*     */ public class JmUI
/*     */   extends Screen
/*     */ {
/*  39 */   protected final int topHeaderHeight = 24;
/*  40 */   protected final int bottomHeaderHeight = 12;
/*  41 */   protected final int headerHeight = 36;
/*  42 */   protected final int footerHeight = 30;
/*     */   
/*  44 */   protected final int centerHeight = 66;
/*     */   
/*     */   protected final String title;
/*  47 */   protected final Logger logger = Journeymap.getLogger();
/*  48 */   protected double scaleFactor = 1.0D;
/*  49 */   public static Stack<Screen> returnDisplayStack = new Stack<>();
/*     */   
/*     */   protected final boolean hasHeaderAndFooter;
/*  52 */   protected final GridLayout headerLayout = new GridLayout();
/*     */   protected LogoWidget logoWidget;
/*     */   protected StringWidget titleWidget;
/*     */   protected UnscaledStringWidget apiVersionWidget;
/*     */   protected FrameLayout topLeftHeader;
/*     */   protected FrameLayout topRightHeader;
/*     */   protected FrameLayout bottomHeader;
/*  59 */   protected LinearLayout footerLayout = LinearLayout.horizontal();
/*     */   
/*     */   protected boolean showLayoutDebug = false;
/*     */   
/*     */   protected FrameLayout contentLayout;
/*     */   
/*     */   public JmUI(String title, boolean hasHeaderAndFooter) {
/*  66 */     this(title, hasHeaderAndFooter, (Screen)null);
/*     */   }
/*     */ 
/*     */   
/*     */   public JmUI(String title, boolean hasHeaderAndFooter, Screen returnDisplay) {
/*  71 */     super((Component)Constants.getStringTextComponent(title));
/*  72 */     this.title = title;
/*  73 */     this.hasHeaderAndFooter = hasHeaderAndFooter;
/*  74 */     returnDisplayStack.push(returnDisplay);
/*     */   }
/*     */ 
/*     */   
/*     */   public Minecraft getMinecraft() {
/*  79 */     return this.minecraft = Minecraft.getInstance();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void init(Minecraft minecraft, int width, int height) {
/*  85 */     this.scaleFactor = calculateScaleFactor();
/*     */     
/*  87 */     clearWidgets();
/*  88 */     super.init(minecraft, width, height);
/*     */     
/*  90 */     if (this.hasHeaderAndFooter) {
/*     */       
/*  92 */       this.headerLayout.visitWidgets(x$0 -> (AbstractWidget)rec$.addRenderableWidget(x$0));
/*  93 */       this.headerLayout.visitWidgets(w -> w.setTabOrderGroup(0));
/*  94 */       this.bottomHeader.visitWidgets(x$0 -> (AbstractWidget)rec$.addRenderableWidget(x$0));
/*  95 */       this.bottomHeader.visitWidgets(w -> w.setTabOrderGroup(1));
/*  96 */       this.footerLayout.visitWidgets(x$0 -> (AbstractWidget)rec$.addRenderableWidget(x$0));
/*  97 */       this.footerLayout.visitWidgets(w -> w.setTabOrderGroup(3));
/*     */     } 
/*     */     
/* 100 */     this.contentLayout.visitWidgets(x$0 -> (AbstractWidget)rec$.addRenderableWidget(x$0));
/* 101 */     this.contentLayout.visitWidgets(w -> w.setTabOrderGroup(2));
/* 102 */     repositionElements();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void init() {
/* 108 */     if (this.hasHeaderAndFooter) {
/*     */       
/* 110 */       this.headerLayout.spacing(0);
/* 111 */       this.logoWidget = (LogoWidget)this.headerLayout.addChild((LayoutElement)new LogoWidget(JmUI::calculateScaleFactor), 0, 0, 2, 1);
/* 112 */       Objects.requireNonNull(this); this.titleWidget = (StringWidget)this.headerLayout.addChild((LayoutElement)(new StringWidget(this.font.width(this.title) + 10, 36, (Component)Component.literal(this.title), this.font)).setColor(Color.CYAN.getRGB()), 0, 2, 2, 1);
/* 113 */       String apiVersion = " API v2.0.0-SNAPSHOT ";
/* 114 */       Objects.requireNonNull(this); this.apiVersionWidget = (UnscaledStringWidget)this.headerLayout.addChild((LayoutElement)(new UnscaledStringWidget(0, 36, (Component)Component.literal(apiVersion), this.font, JmUI::calculateScaleFactor)).setColor(13421772), 0, 4, 2, 1);
/* 115 */       Objects.requireNonNull(this); this.topLeftHeader = (FrameLayout)this.headerLayout.addChild((LayoutElement)new FrameLayout(0, 24), 0, 1);
/* 116 */       Objects.requireNonNull(this); this.topRightHeader = (FrameLayout)this.headerLayout.addChild((LayoutElement)new FrameLayout(0, 24), 0, 3);
/*     */       
/* 118 */       Objects.requireNonNull(this); this.bottomHeader = new FrameLayout(0, 12);
/*     */       
/* 120 */       this.footerLayout.spacing(12).defaultCellSetting().alignVerticallyMiddle();
/*     */       
/* 122 */       Objects.requireNonNull(this); this.contentLayout = new FrameLayout(0, 36, 0, 0);
/*     */     }
/*     */     else {
/*     */       
/* 126 */       this.contentLayout = new FrameLayout(0, 0, 0, 0);
/*     */     } 
/*     */   }
/*     */   
/*     */   public Screen getReturnDisplay() {
/* 131 */     return returnDisplayStack.peek();
/*     */   }
/*     */ 
/*     */   
/*     */   protected void repositionElements() {
/* 136 */     this.scaleFactor = calculateScaleFactor();
/*     */     
/* 138 */     if (this.hasHeaderAndFooter) {
/*     */       
/* 140 */       int fixedLeftHeaderWidth = this.logoWidget.getWidth() + this.titleWidget.getWidth() / 2;
/* 141 */       int fixedRightHeaderWidth = this.apiVersionWidget.getWidth() + this.titleWidget.getWidth() / 2;
/* 142 */       int halfWidth = this.width / 2;
/* 143 */       this.topLeftHeader.setMinWidth(halfWidth - fixedLeftHeaderWidth);
/* 144 */       this.topRightHeader.setMinWidth(halfWidth - fixedRightHeaderWidth);
/* 145 */       this.headerLayout.arrangeElements();
/*     */       
/* 147 */       Objects.requireNonNull(this); this.bottomHeader.setPosition(0, 24);
/* 148 */       this.bottomHeader.setMinWidth(this.width);
/* 149 */       this.bottomHeader.arrangeElements();
/*     */       
/* 151 */       this.footerLayout.arrangeElements();
/* 152 */       Objects.requireNonNull(this); this.footerLayout.setPosition((this.width - this.footerLayout.getWidth()) / 2, this.height - (30 + this.footerLayout.getHeight()) / 2);
/*     */       
/* 154 */       Objects.requireNonNull(this); Objects.requireNonNull(this); this.contentLayout.setMinDimensions(this.width, this.height - 36 - 30);
/*     */     }
/*     */     else {
/*     */       
/* 158 */       this.contentLayout.setMinDimensions(this.width, this.height);
/*     */     } 
/*     */     
/* 161 */     this.contentLayout.arrangeElements();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static double calculateScaleFactor() {
/* 173 */     Minecraft minecraft = Minecraft.getInstance();
/* 174 */     double scaleFactor = minecraft.getWindow().getGuiScale();
/* 175 */     int monitorWidth = minecraft.getWindow().findBestMonitor().getCurrentMode().getWidth();
/* 176 */     int windowWidth = minecraft.getWindow().getWidth();
/* 177 */     int screenWidth = minecraft.getWindow().getScreenWidth();
/* 178 */     int scaledWidth = minecraft.getWindow().getGuiScaledWidth();
/* 179 */     if (Minecraft.ON_OSX && windowWidth > monitorWidth) {
/*     */       
/* 181 */       scaleFactor = minecraft.getWindow().getGuiScale() / windowWidth / screenWidth;
/* 182 */       if (screenWidth == monitorWidth)
/*     */       {
/* 184 */         scaleFactor = minecraft.getWindow().getGuiScale() / windowWidth / monitorWidth;
/*     */       }
/*     */     } 
/* 187 */     return scaleFactor;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isPauseScreen() {
/* 193 */     return true;
/*     */   }
/*     */ 
/*     */   
/*     */   public Font getFontRenderer() {
/* 198 */     return this.font;
/*     */   }
/*     */ 
/*     */   
/*     */   public void renderBackground(GuiGraphics graphics, int i, int j, float f) {
/* 203 */     if ((Minecraft.getInstance()).level == null) {
/*     */       
/* 205 */       drawGradientRect(graphics, 0, 0, this.width, this.height, -1072689136, -804253680, 0);
/*     */     }
/*     */     else {
/*     */       
/* 209 */       super.renderBackground(graphics, i, j, f);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void render(GuiGraphics graphics, int x, int y, float partialTicks) {
/* 216 */     renderBackground(graphics, x, y, partialTicks);
/*     */     
/* 218 */     if (this.hasHeaderAndFooter) {
/*     */       
/* 220 */       DrawUtil.drawRectangle(graphics, 0.0D, 0.0D, this.width, 36.0D, 0, 0.9F);
/* 221 */       DrawUtil.drawRectangle(graphics, 0.0D, (this.height - 30), this.width, this.height, 0, 0.6F);
/*     */     } 
/*     */     
/* 224 */     List<FormattedCharSequence> tooltip = null;
/* 225 */     for (Renderable renderable : getRenderables()) {
/*     */       
/* 227 */       renderable.render(graphics, x, y, partialTicks);
/* 228 */       if (tooltip == null)
/*     */       {
/* 230 */         if (renderable instanceof Button) { Button button = (Button)renderable;
/*     */           
/* 232 */           if (button.mouseOver(x, y))
/*     */           {
/* 234 */             tooltip = button.getWrappedTooltip();
/*     */           } }
/*     */       
/*     */       }
/*     */     } 
/*     */     
/* 240 */     if (this.showLayoutDebug) {
/*     */       
/* 242 */       debugLayoutRender(graphics, (LayoutElement)this.headerLayout);
/* 243 */       debugLayoutRender(graphics, (LayoutElement)this.bottomHeader);
/* 244 */       debugLayoutRender(graphics, (LayoutElement)this.contentLayout);
/* 245 */       debugLayoutRender(graphics, (LayoutElement)this.footerLayout);
/*     */     } 
/* 247 */     if (tooltip != null && !tooltip.isEmpty())
/*     */     {
/* 249 */       renderWrappedToolTip(graphics, tooltip, x, y, getFontRenderer());
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public void drawGradientRect(GuiGraphics graphics, int pX1, int pY1, int pX2, int pY2, int pColorFrom, int pColorTo, int pBlitOffset) {
/* 255 */     graphics.fillGradient(RenderType.guiOverlay(), pX1, pY1, pX2, pY2, pColorFrom, pColorTo, pBlitOffset);
/*     */   }
/*     */ 
/*     */   
/*     */   protected void closeAndReturn() {
/* 260 */     onClose();
/* 261 */     if (returnDisplayStack == null || returnDisplayStack.peek() == null) {
/*     */       
/* 263 */       UIManager.INSTANCE.closeAll();
/*     */     }
/*     */     else {
/*     */       
/* 267 */       UIManager.INSTANCE.open(returnDisplayStack.pop());
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void closeWithKeyBind() {
/* 273 */     closeAndReturn();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean keyPressed(int key, int value, int modifier) {
/* 280 */     switch (key) {
/*     */ 
/*     */       
/*     */       case 256:
/* 284 */         closeAndReturn();
/*     */         
/* 286 */         return true;
/*     */     } 
/*     */     
/* 289 */     return super.keyPressed(key, value, modifier);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void renderWrappedToolTip(GuiGraphics graphics, List<FormattedCharSequence> tooltip, int mouseX, int mouseY, Font fontRenderer) {
/* 296 */     if (!tooltip.isEmpty() && tooltip.get(0) instanceof FormattedCharSequence && (Minecraft.getInstance()).screen == this) {
/*     */       
/* 298 */       RenderWrapper.disableDepthTest();
/* 299 */       int maxLineWidth = 0;
/* 300 */       Iterator<FormattedCharSequence> iterator = tooltip.iterator();
/*     */       
/* 302 */       while (iterator.hasNext()) {
/*     */         
/* 304 */         FormattedCharSequence line = iterator.next();
/* 305 */         int lineWidth = fontRenderer.width(line);
/* 306 */         if (fontRenderer.isBidirectional())
/*     */         {
/* 308 */           lineWidth = (int)Math.ceil(lineWidth * 1.25D);
/*     */         }
/*     */         
/* 311 */         if (lineWidth > maxLineWidth)
/*     */         {
/* 313 */           maxLineWidth = lineWidth;
/*     */         }
/*     */       } 
/*     */       
/* 317 */       int drawX = mouseX + 12;
/* 318 */       int drawY = mouseY - 12;
/* 319 */       int boxHeight = 8;
/*     */       
/* 321 */       if (tooltip.size() > 1)
/*     */       {
/* 323 */         boxHeight += 2 + (tooltip.size() - 1) * 10;
/*     */       }
/*     */       
/* 326 */       if (drawX + maxLineWidth > this.width)
/*     */       {
/* 328 */         drawX -= 28 + maxLineWidth;
/*     */       }
/*     */       
/* 331 */       if (drawY + boxHeight + 6 > this.height)
/*     */       {
/* 333 */         drawY = this.height - boxHeight - 6;
/*     */       }
/*     */       
/* 336 */       int j1 = -267386864;
/* 337 */       drawGradientRect(graphics, drawX - 3, drawY - 4, drawX + maxLineWidth + 3, drawY - 3, j1, j1, 300);
/* 338 */       drawGradientRect(graphics, drawX - 3, drawY + boxHeight + 3, drawX + maxLineWidth + 3, drawY + boxHeight + 4, j1, j1, 300);
/* 339 */       drawGradientRect(graphics, drawX - 3, drawY - 3, drawX + maxLineWidth + 3, drawY + boxHeight + 3, j1, j1, 300);
/* 340 */       drawGradientRect(graphics, drawX - 4, drawY - 3, drawX - 3, drawY + boxHeight + 3, j1, j1, 300);
/* 341 */       drawGradientRect(graphics, drawX + maxLineWidth + 3, drawY - 3, drawX + maxLineWidth + 4, drawY + boxHeight + 3, j1, j1, 300);
/* 342 */       int k1 = 1347420415;
/* 343 */       int l1 = (k1 & 0xFEFEFE) >> 1 | k1 & 0xFF000000;
/* 344 */       drawGradientRect(graphics, drawX - 3, drawY - 3 + 1, drawX - 3 + 1, drawY + boxHeight + 3 - 1, k1, l1, 300);
/* 345 */       drawGradientRect(graphics, drawX + maxLineWidth + 2, drawY - 3 + 1, drawX + maxLineWidth + 3, drawY + boxHeight + 3 - 1, k1, l1, 300);
/* 346 */       drawGradientRect(graphics, drawX - 3, drawY - 3, drawX + maxLineWidth + 3, drawY - 3 + 1, k1, k1, 300);
/* 347 */       drawGradientRect(graphics, drawX - 3, drawY + boxHeight + 2, drawX + maxLineWidth + 3, drawY + boxHeight + 3, l1, l1, 300);
/*     */ 
/*     */       
/* 350 */       for (int i2 = 0; i2 < tooltip.size(); i2++) {
/*     */         
/* 352 */         FormattedCharSequence line = tooltip.get(i2);
/* 353 */         Matrix4f matrixPos = graphics.pose().last().pose();
/* 354 */         if (fontRenderer.isBidirectional()) {
/*     */           
/* 356 */           int lineWidth = (int)Math.ceil(fontRenderer.width(line) * 1.1D);
/* 357 */           fontRenderer.drawInBatch(line, (drawX + maxLineWidth - lineWidth), drawY, -1, true, matrixPos, (MultiBufferSource)graphics.bufferSource(), Font.DisplayMode.NORMAL, 0, 15728880);
/*     */         }
/*     */         else {
/*     */           
/* 361 */           fontRenderer.drawInBatch(line, drawX, drawY, -1, true, matrixPos, (MultiBufferSource)graphics.bufferSource(), Font.DisplayMode.NORMAL, 0, 15728880);
/*     */         } 
/*     */         
/* 364 */         if (i2 == 0)
/*     */         {
/* 366 */           drawY += 2;
/*     */         }
/*     */         
/* 369 */         drawY += 10;
/*     */       } 
/* 371 */       RenderWrapper.enableDepthTest();
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public List<Renderable> getRenderables() {
/* 377 */     return this.renderables;
/*     */   }
/*     */ 
/*     */   
/*     */   private static void debugLayoutRender(GuiGraphics graphics, LayoutElement lElement) {
/* 382 */     int hash = lElement.hashCode();
/* 383 */     int color = Color.HSBtoRGB((hash % 256) / 255.0F, (hash % 128) / 127.0F + 128.0F, (hash % 128) / 127.0F + 128.0F);
/* 384 */     DrawUtil.drawRectangle(graphics, lElement.getX(), lElement.getY(), lElement.getWidth(), 1.0D, color, 0.8F);
/* 385 */     DrawUtil.drawRectangle(graphics, lElement.getX(), lElement.getY(), 1.0D, lElement.getHeight(), color, 0.8F);
/* 386 */     DrawUtil.drawRectangle(graphics, lElement.getX(), (lElement.getY() + lElement.getHeight() - 1), (lElement.getWidth() - 1), 1.0D, color, 0.8F);
/* 387 */     DrawUtil.drawRectangle(graphics, (lElement.getX() + lElement.getWidth() - 1), (lElement.getY() + 1), 1.0D, (lElement.getHeight() - 1), color, 0.8F);
/* 388 */     if (lElement instanceof Layout) { Layout layout = (Layout)lElement;
/*     */       
/* 390 */       layout.visitChildren(l -> debugLayoutRender(graphics, l)); }
/*     */   
/*     */   }
/*     */ }


/* Location:              C:\Users\Administrator\Downloads\journeymap-neoforge-1.21-6.0.0-beta.18.jar!\journeymap\clien\\ui\component\screens\JmUI.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */