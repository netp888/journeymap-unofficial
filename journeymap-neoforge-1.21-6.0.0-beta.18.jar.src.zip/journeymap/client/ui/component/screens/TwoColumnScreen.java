/*    */ package journeymap.client.ui.component.screens;
/*    */ 
/*    */ import java.util.HashMap;
/*    */ import java.util.Map;
/*    */ import journeymap.client.ui.component.ScrollListPane;
/*    */ import net.minecraft.client.gui.GuiGraphics;
/*    */ import net.minecraft.client.gui.components.StringWidget;
/*    */ import net.minecraft.client.gui.screens.Screen;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class TwoColumnScreen<LEFT extends ScrollListPane<?>, RIGHT extends ScrollListPane<?>>
/*    */   extends JmUI
/*    */ {
/*    */   protected StringWidget leftTitle;
/*    */   protected StringWidget rightTitle;
/* 20 */   private final Map<LEFT, RIGHT> panelMap = new HashMap<>();
/*    */ 
/*    */   
/*    */   public TwoColumnScreen(String title, boolean hasHeaderAndFooter, Screen returnDisplay, StringWidget rightTitle, StringWidget leftTitle) {
/* 24 */     super(title, hasHeaderAndFooter, returnDisplay);
/* 25 */     this.leftTitle = leftTitle;
/* 26 */     this.rightTitle = rightTitle;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public void init() {
/* 32 */     super.init();
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   protected void repositionElements() {
/* 38 */     super.repositionElements();
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   protected abstract LEFT getLeftPane();
/*    */ 
/*    */ 
/*    */   
/*    */   protected abstract RIGHT getRightPane();
/*    */ 
/*    */ 
/*    */   
/*    */   protected int getLeftColumnWidth() {
/* 52 */     return 120;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   protected int getRightColumnWidth() {
/* 63 */     return 0;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public void render(GuiGraphics graphics, int x, int y, float partialTicks) {
/* 69 */     super.render(graphics, x, y, partialTicks);
/*    */   }
/*    */ }


/* Location:              C:\Users\Administrator\Downloads\journeymap-neoforge-1.21-6.0.0-beta.18.jar!\journeymap\clien\\ui\component\screens\TwoColumnScreen.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */